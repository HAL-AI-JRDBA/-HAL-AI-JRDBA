# HALL-AI V44 — Complete Source Snapshot

**AJDS Informatica LTDA — Brazil**

Local-first AI, with Ollama, voice, RAG, agent workflows and enterprise database capabilities.

This is a source snapshot assembled from the user-supplied V44 Windows installation archive, with two voice/transcription updates applied in manifest-verified order (correction, then adjustment).

## Install (Windows)

Extract `HALL_V44_D` into `D:\AI_HALL\HALL_V44_D`. Read `HALL_V44_D/00_LEIA_PRIMEIRO.txt`, then inspect and run `01_INSTALAR_HALL_D.bat`. Dependencies and model weights may download during setup. This package was not runtime-tested on Windows.

## Security and licensing

Before turning your repository public, review all source and settings for secrets, personal information, proprietary assets, and dependency licensing. `.gitignore` only prevents future untracked files; it does not remove secrets embedded in committed source.

Use Apache-2.0 for original material only when rights are confirmed. Third-party dependencies/models retain their own licenses.

## Hugging Face

https://huggingface.co/spaces/HAL-AI-JRDBA/README
