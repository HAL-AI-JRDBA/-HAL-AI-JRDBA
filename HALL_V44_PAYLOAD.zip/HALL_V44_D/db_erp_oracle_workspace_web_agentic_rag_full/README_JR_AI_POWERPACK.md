# JR-AI PowerPack

Esta versão adiciona recursos inspirados no conceito de assistente executor/orquestrador:

- 3 cérebros: raciocínio, decisão e memória.
- 17 agentes especializados.
- Visão de tela segura por upload de screenshot.
- Suporte opcional a modelos vision do Ollama, como llava ou llama3.2-vision.
- Skills sob medida.
- Geração de entregáveis locais.
- Plano de deploy/publicação governado.
- Integração com Chat JR-AI, JR Voz Global e OpenClaw Runtime.

## Segurança

A visão de tela é segura e governada: a aplicação não recebe controle irrestrito de mouse/teclado. O usuário envia um screenshot, e a IA analisa. Ações críticas continuam exigindo aprovação humana.

## Endpoints

```text
GET  /api/jr-powerpack/status
GET  /api/jr-powerpack/agents
POST /api/jr-powerpack/orchestrate
GET  /api/jr-powerpack/skills
POST /api/jr-powerpack/skills
POST /api/jr-powerpack/deploy-plan
POST /api/jr-powerpack/deliverable
GET  /api/jr-powerpack/deliverables
POST /api/jr-powerpack/screen/upload
POST /api/jr-powerpack/screen/analyze
GET  /api/jr-powerpack/audit
```

## Exemplo de uso no Chat JR-AI

```text
Use os 3 cérebros e os 17 agentes para criar uma landing page, proposta comercial e plano de deploy para uma empresa de transporte.
```

```text
Analise esta tela e diga quais problemas visuais ou funcionais devo corrigir.
```

## Para análise visual automática

Instale um modelo vision no Ollama, por exemplo:

```bat
ollama pull llava
```

Depois use a aba JR PowerPack, envie uma imagem e informe o modelo `llava`.

Se não houver modelo vision instalado, a ferramenta ainda salva o screenshot e retorna um checklist de diagnóstico.
