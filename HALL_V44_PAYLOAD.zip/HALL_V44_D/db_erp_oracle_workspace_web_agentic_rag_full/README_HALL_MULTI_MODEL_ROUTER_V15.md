# HAL Multi-Model Router V15

Esta versão corrige o ponto observado no boot: o projeto verificava/testava apenas o modelo padrão `qwen2.5:7b`, mesmo havendo modelos especializados instalados para código, SQL, embedding e visão.

## Modelos reconhecidos

Por padrão, o V15 usa:

```text
Chat geral:       qwen2.5:7b
Diálogo natural:  qwen2.5:7b
Code principal:   qwen2.5-coder:14b
Code rápido:      qwen2.5-coder:7b
Code profundo:    deepseek-coder-v2:16b
SQL:              sqlcoder:7b-q4_0
Embedding/RAG:    embeddinggemma:latest
Vision/imagem:    llava:latest
Fast:             phi3:mini
```

## Roteamento automático

O HAL agora seleciona o modelo conforme o tipo de tarefa:

```text
Pergunta comum / bate-papo
→ qwen2.5:7b

Criar software, App Factory, Python, FastAPI, frontend/backend
→ qwen2.5-coder:14b

Correção rápida de código
→ qwen2.5-coder:7b

Arquitetura/refatoração complexa
→ deepseek-coder-v2:16b

SQL, SELECT, banco de dados, ERP, relatórios de banco
→ sqlcoder:7b-q4_0

RAG, documentos, busca semântica, Knowledge Center
→ embeddinggemma:latest

Imagem, print, tela, screenshot
→ llava:latest
```

## Novos scripts

```text
HALL_AUTO_MODELS_V15.bat
CONFIGURAR_MODELOS_HALL_V15.bat
runtime_scripts/pull_modelos_v15_especializados.bat
INICIAR_JR_AI_HALL_MULTI_MODEL_ROUTER_V15.bat
```

## Boot mais transparente

O boot agora mostra os modelos por papel:

```text
[OK] CHAT: qwen2.5:7b
[OK] CODE: qwen2.5-coder:14b
[OK] FAST CODE: qwen2.5-coder:7b
[OK] DEEP CODE: deepseek-coder-v2:16b
[OK] SQL: sqlcoder:7b-q4_0
[OK] EMBED: embeddinggemma:latest
[OK] VISION: llava:latest
[OK] FAST: phi3:mini
```

Se algum faltar, ele mostra:

```text
ollama pull <modelo>
```

Se você quiser que ele baixe automaticamente os modelos faltantes no boot:

```bat
setx HALL_AUTO_PULL_MODELS "1"
```

## Endpoints

```text
/api/unified/multi-model/status
/api/unified/multi-model/boot-report
/api/unified/multi-model/route
/api/unified/multi-model/generate
/api/unified/multi-model/embed
/api/unified/multi-model/config

/api/multi-model/status
/api/multi-model/boot-report
/api/multi-model/route
/api/multi-model/generate
/api/multi-model/embed
/api/multi-model/config
```

## Variáveis de ambiente

```bat
setx HALL_MODEL_CHAT "qwen2.5:7b"
setx HALL_MODEL_DIALOG "qwen2.5:7b"
setx HALL_MODEL_CODE "qwen2.5-coder:14b"
setx HALL_MODEL_FAST_CODE "qwen2.5-coder:7b"
setx HALL_MODEL_DEEP_CODE "deepseek-coder-v2:16b"
setx HALL_MODEL_SQL "sqlcoder:7b-q4_0"
setx HALL_MODEL_EMBED "embeddinggemma:latest"
setx HALL_MODEL_VISION "llava:latest"
setx HALL_MODEL_FAST "phi3:mini"
```

## Integração no núcleo de conversa

O `Human Conversation Gateway` agora consulta o Multi-Model Router antes de chamar o Ollama. Assim, pedidos de software/code, SQL, RAG ou imagem deixam de depender cegamente do `qwen2.5:7b`.
