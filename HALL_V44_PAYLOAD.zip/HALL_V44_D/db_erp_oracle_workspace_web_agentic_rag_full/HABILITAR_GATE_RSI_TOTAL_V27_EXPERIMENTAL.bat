@echo off
chcp 65001 >nul
setlocal EnableExtensions
set "SCRIPT_DIR=%~dp0"
set "HALL_HOME="
if exist "%SCRIPT_DIR%INICIAR_JR_AI_HALL_V26_2.bat" set "HALL_HOME=%SCRIPT_DIR%"
if not defined HALL_HOME if exist "%SCRIPT_DIR%..\INICIAR_JR_AI_HALL_V26_2.bat" set "HALL_HOME=%SCRIPT_DIR%..\"
if not defined HALL_HOME if exist "C:\AI_HALL\INICIAR_JR_AI_HALL_V26_2.bat" set "HALL_HOME=C:\AI_HALL\"
if not defined HALL_HOME if exist "C:\AI_HALL\AI_HALL\INICIAR_JR_AI_HALL_V26_2.bat" set "HALL_HOME=C:\AI_HALL\AI_HALL\"

if not defined HALL_HOME (
  echo [ERRO] Raiz da HAL nao encontrada.
  pause
  exit /b 90
)

set "HALL_PROJECT=%HALL_HOME%db_erp_oracle_workspace_web_agentic_rag_full"
if not exist "%HALL_PROJECT%\web_app\backend\main.py" (
  echo [ERRO] Backend da HAL nao encontrado em %HALL_PROJECT%.
  pause
  exit /b 91
)

echo ============================================================
echo HAL V27 - GATE LOCAL RSI TOTAL EXPERIMENTAL
echo ============================================================
echo ATENCAO: este BAT SOMENTE libera o gate local do processo.
echo A ativacao da RSI Total continua exigindo login de Administrador
echo e a confirmacao explicita no painel Evolution / RSI.
echo.
set "HALL_ALLOW_TOTAL_RSI=1"
set "HALL_V27_EVOLUTION_ENGINE=1"
call "%HALL_HOME%INICIAR_JR_AI_HALL_V26_2.bat"
set "HALL_RC=%ERRORLEVEL%"
endlocal & exit /b %HALL_RC%
