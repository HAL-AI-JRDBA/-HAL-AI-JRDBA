# HAL V23 - Always-On Natural Voice

A HAL V23 adiciona presença de voz hands-free. Depois que o navegador recebe permissão de microfone uma vez, o usuário pode dizer **HAL ativar**, conversar em turnos naturais e sair dizendo **HAL desativar**.

## Web
- auto-arm após login;
- wake/sleep phrase local no browser;
- fala comum em modo de espera não é enviada ao backend;
- silêncio final configurável;
- conversa contínua com o mesmo session_id;
- TTS no idioma do usuário;
- barge-in com monitor de microfone e echo cancellation;
- RBAC e Safety permanecem ativos.

## Companion Windows opcional
Instale `INSTALAR_HALL_VOICE_PRESENCE_V23.bat`, configure as credenciais via Windows Credential Manager e execute `INICIAR_HALL_VOICE_PRESENCE_V23.bat`. O companion usa `faster-whisper` local, `sounddevice` e TTS do Windows. Áudio de espera é processado em memória e descartado.

## Frases
- pt-BR: HAL ativar / HAL desativar
- en-US: HAL activate / HAL deactivate
- es-ES: HAL activar / HAL desactivar
- zh-CN: HAL 启动 / HAL 停用
- ja-JP: HAL 起動 / HAL 停止
