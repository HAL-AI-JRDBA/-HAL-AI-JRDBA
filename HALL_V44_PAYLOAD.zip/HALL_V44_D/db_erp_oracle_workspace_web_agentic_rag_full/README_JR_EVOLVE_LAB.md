# JR-Evolve Lab — Evolução Autônoma Governada da JR-AI

Esta versão adiciona a aba **JR-Evolve Lab**, inspirada no conceito de frameworks evolutivos de IA, mas adaptada para uso seguro, local/open-source e empresarial.

## Fases implementadas

### Fase 1 — JR-Evolve Lab básico
Cria uma interface e serviço para gerenciar ciclos evolutivos da JR-AI.

### Fase 2 — Banco de experimentos e Cognition Base
Armazena:
- experimentos
- hipóteses
- patches candidatos
- resultados de teste
- decisões
- conhecimento acumulado
- regras de segurança
- heurísticas por módulo

### Fase 3 — Geração de hipóteses e patches
Gera hipóteses de melhoria e patches candidatos em sandbox.  
Por segurança, o patch inicial é não destrutivo: cria testes customizados para o Agent Evaluation e artefatos `.patch`.

### Fase 4 — Execução automática de testes
Executa automaticamente a suíte **Agent Evaluation** para obter score e regressão.

### Fase 5 — Analyzer antes/depois
Compara baseline e resultado posterior, calcula delta e recomenda aprovar, revisar ou rejeitar.

### Fase 6 — Aprovação humana e aplicação controlada
Nenhum patch é aplicado automaticamente.  
A JR-AI exige aprovação humana. Depois de aprovado, aplica apenas alterações seguras e controladas, com snapshot/backup.

## Recursos adicionados

- Nova aba **JR-Evolve Lab**
- Cognition Base
- Banco de experimentos
- Geração de hipóteses
- Geração de patch candidato
- Execução de Agent Evaluation
- Analyzer com comparação antes/depois
- Aprovação humana
- Aplicação controlada
- Snapshots antes de aplicar
- Auditoria local
- Relatório Markdown por experimento
- Integração com Chat JR-AI
- Integração com JR Voz
- Integração com OpenClaw Runtime

## Endpoints

```text
GET  /api/jr-evolve/status
GET  /api/jr-evolve/cognition
POST /api/jr-evolve/cognition
POST /api/jr-evolve/experiment
GET  /api/jr-evolve/experiments
GET  /api/jr-evolve/experiments/{filename}
POST /api/jr-evolve/baseline
POST /api/jr-evolve/hypotheses
POST /api/jr-evolve/patch
POST /api/jr-evolve/run-tests
POST /api/jr-evolve/analyze
POST /api/jr-evolve/request-approval
GET  /api/jr-evolve/approvals
POST /api/jr-evolve/approval-decision
POST /api/jr-evolve/apply
POST /api/jr-evolve/full-cycle
GET  /api/jr-evolve/report/{experiment_id}
GET  /api/jr-evolve/audit
```

## Segurança

O JR-Evolve Lab **não altera código em produção automaticamente**.

Fluxo correto:

```text
Gerar hipótese
Gerar patch em sandbox
Executar testes
Analisar antes/depois
Solicitar aprovação humana
Aplicar somente patch aprovado e seguro
Salvar snapshot/backup
```

## Exemplo de uso

```text
Melhorar o roteamento da JR-AI para perguntas de Zabbix, Grafana, Power BI, DBA Oracle e Agent Evaluation sem quebrar funcionalidades existentes.
```

Depois clique em:

```text
Executar ciclo completo
```

O ciclo termina com aprovação pendente. O usuário precisa aprovar explicitamente para aplicar.
