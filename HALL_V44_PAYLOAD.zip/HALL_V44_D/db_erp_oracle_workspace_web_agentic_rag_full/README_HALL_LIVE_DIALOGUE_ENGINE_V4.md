# HAL Live Dialogue Engine V4 — Conversa Natural Real

Esta versão corrige o problema principal apontado pelo usuário:

```text
A plataforma não estava conversando de forma natural.
Ela parecia um roteador de ferramentas/painéis e não um assistente vivo.
```

## Mudança principal

Agora a rota principal do chat e da voz passa primeiro pelo:

```text
HAL Live Dialogue Engine V4
```

O comportamento correto é:

```text
Usuário pergunta
HAL responde naturalmente
Usuário discorda ou pergunta de novo
HAL continua pelo contexto
Se precisar de ferramenta, ela roda por trás
O painel técnico não abre sozinho
O usuário não precisa apertar botão para continuar
```

## O que foi corrigido de verdade

```text
O Agentic Pro não chama mais diretamente /api/agent/turn como roteador técnico.
A rota /api/agent/turn agora também usa conversa natural primeiro.
O Console Unificado força modo conversa primeiro no automático.
O painel técnico não abre sozinho.
A voz usa a mesma conversa natural.
O HAL mantém sessão e histórico.
O modelo local/Ollama recebe histórico e contexto das ferramentas.
As respostas de ferramentas são transformadas em conversa natural quando o modelo local está disponível.
Se o modelo local não estiver disponível, o HAL avisa de forma clara em vez de responder genericamente.
```

## Diferença prática

Antes, ao perguntar algo, a plataforma podia responder com texto de módulo ou abrir tela.

Agora:

```text
HAL deve responder a pergunta no chat.
Se precisar consultar banco, ERP, Power BI, finanças ou internet, ele trata isso nos bastidores.
Se faltar dado, ele pergunta exatamente o que falta.
```

## Exemplo

Usuário:

```text
HAL, como está a saúde financeira da empresa?
```

Resposta esperada:

```text
Consigo analisar, mas não vou inventar números. Para te responder com precisão, preciso saber qual fonte devo consultar: ERP, banco de dados, Power BI, DRE contábil ou planilha autorizada. Você quer visão consolidada da empresa ou por filial?
```

Usuário:

```text
Por filial.
```

Resposta esperada:

```text
Perfeito. Então vou separar a análise por filial. Agora preciso da fonte: devo usar ERP, Power BI, DRE ou banco financeiro?
```

## Modelo local

Para conversa aberta e natural sobre qualquer assunto, o modelo local precisa estar ativo.

O projeto já inclui Auto Ollama, que tenta:

```text
instalar Ollama via winget
iniciar Ollama
baixar qwen2.5:7b
configurar OLLAMA_MODEL
configurar HALL_DIALOG_MODEL
```

Se o modelo local não estiver disponível, o HAL continua funcionando, mas perguntas abertas ficam limitadas. Ele passa a avisar claramente que o modelo local não respondeu, em vez de fingir que entendeu.

## Regra operacional

```text
Conversa primeiro.
Ferramenta depois.
Painel só se o usuário quiser.
Sem resposta de papagaio.
Sem jogar o usuário para tela errada.
Sem botão obrigatório para continuar.
```


## HAL Voice STT Fallback V5

Corrigido o estado “Não ouvi nada ainda...” adicionando gravação local com MediaRecorder e transcrição local por faster-whisper/openai-whisper quando o Web Speech do navegador falhar.


## HAL Live Chat Kernel V6

Corrigido o bate-papo curto e natural: mensagens como “comigo”, “converse comigo”, “sim”, “pode” e frases pequenas agora são tratadas como conversa viva, não como fallback mecânico de formulário.


## HAL Topic Switch & Full Question Capture V7

Corrigida a mudança de assunto e a captura truncada de perguntas por voz. O HAL agora identifica mudança entre temas como almoço/cardápio e ciência/buracos negros, e usa por padrão gravação completa + STT local para evitar cortes na pergunta.
