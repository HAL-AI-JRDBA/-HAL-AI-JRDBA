@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo CONFIGURAR MODELOS HAL AGENTIC PRO
echo ============================================================
echo.

if not exist "hall_transporte_agentic_pro\CONFIGURAR_MODELOS_OLLAMA.bat" (
  echo [ERRO] Configurador nao encontrado.
  pause
  exit /b 1
)

cd /d "hall_transporte_agentic_pro"
call "CONFIGURAR_MODELOS_OLLAMA.bat"

endlocal
