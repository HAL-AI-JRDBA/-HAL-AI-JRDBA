@echo off
chcp 65001 >nul
setlocal

echo.
echo ============================================================
echo HAL - AUTO STT LOCAL / TRANSCRICAO DE VOZ
echo ============================================================
echo.

if "%HALL_STT_MODEL%"=="" set "HALL_STT_MODEL=base"

where python >nul 2>nul
if errorlevel 1 (
  echo [AVISO] Python nao encontrado no PATH. O STT local nao sera instalado automaticamente.
  goto end_ok
)

echo [AUTO] Verificando faster-whisper...
python -c "import faster_whisper" >nul 2>nul
if errorlevel 1 (
  echo [AUTO] Instalando faster-whisper para transcricao local.
  echo [INFO] Isso pode demorar na primeira execucao.
  python -m pip install --upgrade pip
  python -m pip install faster-whisper
) else (
  echo [OK] faster-whisper ja instalado.
)

echo [AUTO] Verificando PyAV/ffmpeg interno...
python -c "import av" >nul 2>nul
if errorlevel 1 (
  echo [AUTO] Instalando av para leitura de audio.
  python -m pip install av
) else (
  echo [OK] av disponivel.
)

echo.
echo [OK] Auto STT finalizado.
:end_ok
endlocal
exit /b 0
