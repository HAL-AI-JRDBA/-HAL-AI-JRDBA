
if not "%HALL_OLLAMA_AUTO_DONE%"=="1" (
  if exist "HALL_AUTO_OLLAMA.bat" call "HALL_AUTO_OLLAMA.bat"
)
@echo off
setlocal
cd /d %~dp0

if not exist .venv\Scripts\python.exe (
  echo [ERRO] Ambiente virtual nao encontrado.
  echo Execute primeiro: install_local.bat
  pause
  exit /b 1
)

call .venv\Scripts\activate.bat
if errorlevel 1 (
  echo [ERRO] Falha ao ativar o ambiente virtual.
  pause
  exit /b 1
)

python check_runtime_deps.py
if errorlevel 1 (
  echo.
  echo [ERRO] Dependencias essenciais nao estao ok. Rode novamente o install_local.bat.
  pause
  exit /b 1
)

streamlit run app.py
