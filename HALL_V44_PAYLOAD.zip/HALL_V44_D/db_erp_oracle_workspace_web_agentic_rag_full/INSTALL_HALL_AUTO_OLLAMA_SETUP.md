# Instalação / Inicialização com Auto Ollama

## Caminho mais simples

Execute:

```bat
INICIAR_JR_AI_HALL_AUTO_OLLAMA.bat
```

Esse arquivo chama automaticamente:

```text
HALL_AUTO_OLLAMA.bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

## O que ele faz

```text
1. Configura OLLAMA_MODEL, HALL_DIALOG_MODEL e OLLAMA_URL.
2. Verifica se o Ollama existe.
3. Se não existir, tenta instalar via winget.
4. Inicia o serviço Ollama.
5. Baixa qwen2.5:7b se faltar.
6. Abre a plataforma HAL.
```

## Se der problema

Execute:

```bat
VERIFICAR_HALL_OLLAMA_STATUS.bat
```

Se o Ollama não instalar automaticamente, instale manualmente e depois abra novamente o HAL.

## O sistema não trava

Mesmo que o Ollama falhe, o HAL abre usando o fallback contextual do Dialogue Brain V2.
