@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist ".venv_web\Scripts\python.exe" (
  ".venv_web\Scripts\python.exe" scripts\validar_hall_safety_v18.py
) else (
  python scripts\validar_hall_safety_v18.py
)
if errorlevel 1 (
  echo.
  echo [ERRO] Validacao HAL Safety V18 falhou.
) else (
  echo.
  echo [OK] HAL Safety V18 validado.
)
pause
endlocal
