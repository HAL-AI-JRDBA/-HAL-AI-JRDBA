@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist ".venv_web\Scripts\python.exe" (
  call ".venv_web\Scripts\activate.bat"
)
python scripts\validar_enterprise_rag_v17.py
if errorlevel 1 (
  echo.
  echo [ERRO] Validacao Enterprise RAG V17 falhou.
  pause
  exit /b 1
)
echo.
echo [OK] HAL Enterprise RAG V17 validado.
pause
endlocal
