@echo off
chcp 65001 >nul
setlocal
if exist "%~dp0..\INICIAR_JR_AI_HALL_V28_1.bat" (
  call "%~dp0..\INICIAR_JR_AI_HALL_V28_1.bat"
  set "RC=%ERRORLEVEL%"
) else (
  echo [ERRO] Launcher V28.1 nao encontrado na raiz HAL.
  set "RC=111"
  pause
)
endlocal & exit /b %RC%
