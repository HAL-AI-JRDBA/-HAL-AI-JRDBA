# Correção de inicialização do `run_web.bat`

Esta versão inclui ajustes para evitar que a janela feche sozinha quando o backend falhar ao subir.

## O que mudou

- `run_web.bat` agora valida dependências antes de iniciar o servidor.
- `run_web.bat` valida a importação do backend antes de abrir o `uvicorn`.
- Se houver erro, a janela permanece aberta com `pause`.
- Novo `run_web_debug.bat` gera o arquivo `web_startup_error.log` com o erro completo.
- Novo `check_web_deps.py` valida dependências web, incluindo `python-pptx` para a aba **Apresentações IA**.
- A importação do Deck Studio no backend ficou lazy, evitando que a aplicação inteira deixe de subir por dependência opcional de apresentação.

## Como corrigir no ambiente do cliente

1. Extraia este ZIP em uma pasta nova.
2. Execute:

```bat
install_web.bat
```

3. Depois execute:

```bat
run_web.bat
```

Se ainda fechar ou falhar, execute:

```bat
run_web_debug.bat
```

E veja o arquivo:

```text
web_startup_error.log
```

## Observação

A nova aba **Apresentações IA** usa o pacote open-source `python-pptx`. Se você apenas substituir arquivos sobre uma `.venv_web` antiga, rode novamente `install_web.bat` para instalar/atualizar as dependências.
