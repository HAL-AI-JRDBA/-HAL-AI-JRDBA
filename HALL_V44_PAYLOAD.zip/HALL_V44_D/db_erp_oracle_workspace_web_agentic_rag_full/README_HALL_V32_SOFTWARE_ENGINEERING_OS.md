# HAL V32 — Software Engineering OS

A V32 preserva a plataforma HAL existente e adiciona uma camada de engenharia de software acima da geração de código.

## Novo pipeline de engenharia

1. Requirements Engineer: requisitos funcionais, NFRs, premissas e perguntas em aberto.
2. Architecture Decision Engine: estilo arquitetural e ADRs.
3. C4 Generator: contexto, containers, componentes e diagrama Mermaid.
4. Architecture Critic: tenta encontrar fragilidades antes da implementação.
5. Threat Model / Security Engineering: STRIDE, least privilege, SAST/SCA/SBOM readiness.
6. Database Architect: modelo, planos, índices, transações, locking, pooling, backup e migração.
7. Test Engineering: Unit, Integration, Contract, E2E, Security, Performance, Resilience e Database.
8. Performance Engineering: baseline, peak, stress, soak; p50/p95/p99 e saturação.
9. SRE / Failure Engineering: SLI/SLO, Error Budget, RPO/RTO, health, observabilidade e falhas.
10. Technical Decision Council: Product, Architect, Security, DBA, Performance, SRE, QA e Tech Lead.
11. Engineering Quality Gate: não autoriza produção apenas porque o código compila.

## Preservação das funções anteriores

A V32 mantém OpenClaw Runtime/Teams, Codex Consultor, Multiagentes, Chat/Human Conversation, Web Access,
Evolution Engine/RSI experimental, Model Lifecycle/Hugging Face, Zabbix/Grafana, Presentation Builder,
Database Access Wizard SQL/NoSQL, voz, Screen Assist, workspaces multiusuário, App Factory, Autonomous Software Studio,
Safety/Governance e Reinforcement Learning Lab.

## Hugging Face / atualização de modelos

O Model Lifecycle permanece habilitado e o backend chama `start_auto_scanner()` no startup.
O padrão é verificar candidatos GGUF periodicamente, registrar propostas e exigir aprovação administrativa antes da instalação.
A instalação usa integração Ollama + `hf.co/<repo>:<quant>` e executa smoke test antes de trocar o modelo no router.

> A disponibilidade real do Hugging Face depende de rede/DNS/proxy e, para repositórios restritos, `HALL_HF_TOKEN`.

## GitHub

A V32 preserva geração de CI/GitHub Actions e adiciona Git/GitHub ao Toolchain Status do Engineering OS.
Operações remotas dependem de `git`/`gh`, rede e credenciais configuradas. Push/merge/deploy não são automáticos sem aprovação.

## API V32

- `GET /api/v32/status`
- `GET /api/software-engineering/status`
- `GET /api/software-engineering/toolchain`
- `GET /api/software-engineering/preservation-check`
- `POST /api/software-engineering/assess`
- `GET /api/software-engineering/runs`
- `GET /api/software-engineering/runs/{run_id}`
- `GET /api/software-engineering/audit`

## Produção

Engineering Assessment é evidência de projeto, não autorização de deploy. O candidato real ainda deve passar por testes,
security review, performance, recuperação/rollback e aprovação humana.
