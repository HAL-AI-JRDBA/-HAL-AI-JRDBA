# Integração GenAI sobre a V3.2.3

Esta versão preserva os fluxos originais da `oracle_view_local_assistant_v3_2_3` e adiciona, na mesma aplicação Streamlit:

- Catálogo semântico Oracle
- SQL Copilot seguro (NL2SQL + explain + tuning + execução controlada)
- RAG persistente para PDFs, textos e planilhas
- Assistente de DBA com coletas prontas
- Segurança / anomalias com score e resumo executivo
- Dados sintéticos para homologação e demos

## Novas abas

As abas novas ficam no final da interface:

- Catálogo GenAI
- SQL Copilot GenAI
- RAG Persistente
- Assistente DBA
- Segurança / Anomalias
- Dados sintéticos

## Diretórios gerados

- `genai_data/catalog`
- `genai_data/vectors`
- `genai_data/uploads`
- `genai_data/cache`
- `genai_data/logs`

## Observações

- O projeto usa a mesma conexão Oracle definida na barra lateral.
- O projeto usa os mesmos modelos definidos na barra lateral.
- O módulo RAG tenta usar Chroma persistente; se não estiver disponível, cai automaticamente para armazenamento vetorial JSON local.
- O módulo NL2SQL é somente leitura e bloqueia DDL/DML.
