# Instalação opcional — Pesquisa Web Confiável

## Execução normal

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

## Recomendado para busca local confiável

Instalar SearxNG local ou em servidor interno e configurar:

```text
SEARXNG_URL=http://127.0.0.1:8080
```

## Recomendado para síntese local

Instalar Ollama e baixar modelo:

```bat
ollama pull qwen2.5:7b
```

Configurar:

```text
HALL_WEB_SUMMARY_MODEL=qwen2.5:7b
```

## Sem isso

O HAL ainda tenta responder usando DuckDuckGo HTML e síntese extrativa.
