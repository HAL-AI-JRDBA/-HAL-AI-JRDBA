# Instalação — HAL Meeting Intelligence Gateway

Execute:

```bat
INICIAR_JR_AI_HALL_MEETING_INTELLIGENCE.bat
```

ou:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Acesse:

```text
http://127.0.0.1:8000
```

## Variáveis de ambiente sugeridas

Microsoft Teams:

```text
HALL_TEAMS_TENANT_ID
HALL_TEAMS_CLIENT_ID
HALL_TEAMS_CLIENT_SECRET
HALL_TEAMS_BOT_APP_ID
HALL_TEAMS_BOT_PASSWORD
```

Google Meet / Workspace:

```text
HALL_GOOGLE_CLIENT_ID
HALL_GOOGLE_CLIENT_SECRET
HALL_GOOGLE_WORKSPACE_DOMAIN
```

Áudio local:

```text
HALL_STT_PROVIDER
HALL_TTS_PROVIDER
HALL_AUDIO_INPUT_DEVICE
HALL_AUDIO_OUTPUT_DEVICE
```

## Observação

Para teste inicial, use a tela Meeting Intelligence Gateway e clique em Demo Reunião.
Para uso real em call, configure bot oficial ou Desktop/Browser Companion.
