# HAL Software Builder & Anti-Parrot V11

Esta versão corrige o problema mostrado no print:

```text
Usuário:
Eu quero um software para controlar minhas finanças pessoais

HAL:
Entendi. Vou seguir com você de forma mais objetiva. Me diga só o ponto central...
```

Isso estava errado. A frase do usuário já tinha assunto, objetivo e tipo de entrega.

## Correção principal

Foi adicionada a intenção:

```text
software_builder
```

Ela reconhece pedidos como:

```text
quero um software
crie um sistema
faça um app
software em Python
interface web
controle de finanças pessoais
dashboard
programa
aplicação web
```

## Resposta esperada agora

Para:

```text
Eu quero um software para controlar minhas finanças pessoais
```

O HAL deve responder:

```text
Perfeito — isso é um pedido claro de criação de software.

Eu montaria para você um sistema local em Python com interface web para controle de finanças pessoais, com dashboard, receitas, despesas, categorias, metas, gráficos, SQLite local e exportação CSV...
```

## Novo módulo

```text
HAL Software Builder Center
```

Capacidades:

```text
Detectar pedido de software/app/sistema
Planejar arquitetura
Sugerir telas
Sugerir banco de dados
Sugerir stack Python
Gerar scaffold local
Gerar app de finanças pessoais
Criar README e BAT de execução
Evitar resposta genérica tipo “ponto central”
```

## Projeto gerável

O módulo consegue gerar localmente:

```text
hall_financas_pessoais/
  app.py
  requirements.txt
  README.md
  INICIAR_FINANCAS_PESSOAIS.bat
  templates/index.html
  static/style.css
  static/app.js
```

Stack:

```text
Python
FastAPI
SQLite
HTML/CSS/JavaScript
```

## Endpoints

```text
/api/software-builder/status
/api/software-builder/plan
/api/software-builder/generate-personal-finance
/api/software-builder/requests

/api/unified/software-builder/status
/api/unified/software-builder/plan
/api/unified/software-builder/generate-personal-finance
/api/unified/software-builder/requests
```

## Correção anti-papagaio

Também foi adicionada proteção na interface:

```text
Não adiciona duas respostas idênticas consecutivas no chat
Remove resposta mecânica "me diga o ponto central" para pedidos de software
```

## Regra V11

```text
Se o usuário pediu software, responda como arquiteto/desenvolvedor.
Não peça o que já foi dito.
Não repita frase genérica.
Não roteie para Skills se o pedido é app/sistema/software.
Ofereça arquitetura, telas, banco, código inicial e guia de execução.
```


## HAL App Factory Pro V12

Adicionada fábrica de sistemas completos estilo Lovable/Zheus local: login, páginas, CRUD, filtros, cálculos, estado vazio, settings, cobrança falhou, teto de custo de IA, preview, GitHub manifest, deploy Docker/local, templates, white-label e quality gate.


## HAL Enterprise Productization V13

Adicionada camada de produto comercial robusto: saúde da plataforma, testes automáticos de roteamento, 60 Skills, 45 templates, 20 integrações configuráveis, deploy assistido, GitHub manifest, Quality Gate global, Agent Fleet Manager 24/7, Knowledge/RAG Center e white-label com planos, custo de IA e alerta de cobrança.
