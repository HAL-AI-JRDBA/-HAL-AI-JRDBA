@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
if exist "db_erp_oracle_workspace_web_agentic_rag_full\scripts\corrigir_utf8_bom_v18_2.py" (
  set "P=%CD%\db_erp_oracle_workspace_web_agentic_rag_full"
) else (
  set "P=%CD%"
)
if exist "%P%\.venv_web\Scripts\python.exe" (
  "%P%\.venv_web\Scripts\python.exe" "%P%\scripts\corrigir_utf8_bom_v18_2.py" --root "%P%"
) else (
  python "%P%\scripts\corrigir_utf8_bom_v18_2.py" --root "%P%"
)
pause
endlocal
