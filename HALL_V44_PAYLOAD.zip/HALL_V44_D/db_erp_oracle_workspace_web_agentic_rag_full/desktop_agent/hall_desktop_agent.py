from __future__ import annotations

import base64
import json
import os
import subprocess
import sys
import time
import traceback
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any


HOST = "127.0.0.1"
PORT = int(os.environ.get("HALL_DESKTOP_PORT", "8765"))
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "hall_desktop_agent"
CAPTURES = DATA / "captures"
LOG = DATA / "desktop_agent.log"
APPROVAL_REQUIRED = True
BLOCKED_TEXT_TOKENS = [
    "powershell", "cmd.exe", "diskpart", "format ", "reg.exe", "reg add", "reg delete",
    "net user", "sc.exe", "shutdown", "bcdedit", "wmic process call create", "taskkill /f",
    "del /s", "rmdir /s", "remove-item -recurse", "invoke-expression", "iex(",
]
BLOCKED_HOTKEYS = {
    ("win", "r"), ("winleft", "r"), ("winright", "r"), ("win", "x"),
    ("ctrl", "shift", "esc"),
}


def ensure_dirs() -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    CAPTURES.mkdir(parents=True, exist_ok=True)


def log(msg: str) -> None:
    ensure_dirs()
    LOG.open("a", encoding="utf-8").write(time.strftime("%Y-%m-%d %H:%M:%S") + " " + msg + "\n")


def try_import(name: str):
    try:
        return __import__(name)
    except Exception:
        return None


def status() -> dict[str, Any]:
    pyautogui = try_import("pyautogui")
    mss = try_import("mss")
    cv2 = try_import("cv2")
    return {
        "ok": True,
        "name": "HAL Desktop Agent",
        "host": HOST,
        "port": PORT,
        "capabilities": {
            "screenshot": bool(pyautogui or mss),
            "mouse_keyboard": bool(pyautogui),
            "camera": bool(cv2),
            "open_url": True,
            "create_folder": True,
            "type_text": bool(pyautogui),
            "hotkey": bool(pyautogui),
            "transport_shortcuts": True,
        },
        "optional_modules": {
            "pyautogui": bool(pyautogui),
            "mss": bool(mss),
            "opencv_python": bool(cv2),
        },
        "security": {
            "local_only": True,
            "approval_required_for_actions": APPROVAL_REQUIRED,
            "dangerous_commands_blocked": True,
            "unrestricted_windows_access": False,
            "shell_launch_hotkeys_blocked": True,
            "filesystem_write_scoped": True,
        },
    }


def require_approved(payload: dict[str, Any]) -> tuple[bool, dict[str, Any] | None]:
    if payload.get("approved") is True:
        return True, None
    return False, {
        "ok": False,
        "requires_approval": True,
        "summary": "Esta ação controla o computador e exige aprovação explícita.",
        "expected": {"approved": True},
    }


def screenshot(payload: dict[str, Any]) -> dict[str, Any]:
    ensure_dirs()
    # Captura de tela é segura, mas ainda deve vir de um botão/autorização do usuário.
    pyautogui = try_import("pyautogui")
    if pyautogui:
        img = pyautogui.screenshot()
        path = CAPTURES / f"screen_{time.strftime('%Y%m%d_%H%M%S')}.png"
        img.save(path)
        return {"ok": True, "path": str(path), "relative_path": str(path.relative_to(ROOT)), "summary": "Tela capturada."}

    mss = try_import("mss")
    if mss:
        from PIL import Image
        with mss.mss() as sct:
            monitor = sct.monitors[1]
            raw = sct.grab(monitor)
            img = Image.frombytes("RGB", raw.size, raw.rgb)
            path = CAPTURES / f"screen_{time.strftime('%Y%m%d_%H%M%S')}.png"
            img.save(path)
            return {"ok": True, "path": str(path), "relative_path": str(path.relative_to(ROOT)), "summary": "Tela capturada via MSS."}

    return {"ok": False, "summary": "Instale pyautogui ou mss para capturar tela."}


def camera_capture(payload: dict[str, Any]) -> dict[str, Any]:
    ensure_dirs()
    cv2 = try_import("cv2")
    if not cv2:
        return {"ok": False, "summary": "Instale opencv-python para usar câmera no Desktop Agent."}
    cam_index = int(payload.get("camera_index", 0))
    cap = cv2.VideoCapture(cam_index)
    ok, frame = cap.read()
    cap.release()
    if not ok:
        return {"ok": False, "summary": "Não consegui capturar imagem da câmera."}
    path = CAPTURES / f"camera_{time.strftime('%Y%m%d_%H%M%S')}.png"
    cv2.imwrite(str(path), frame)
    return {"ok": True, "path": str(path), "relative_path": str(path.relative_to(ROOT)), "summary": "Imagem da câmera capturada."}


def open_url(payload: dict[str, Any]) -> dict[str, Any]:
    approved, error = require_approved(payload)
    if not approved:
        return error
    url = payload.get("url") or ""
    if not url:
        return {"ok": False, "summary": "URL não informada."}
    if not url.startswith(("http://", "https://")):
        url = "https://www.google.com/search?q=" + urllib.parse.quote(url)
    webbrowser.open(url)
    return {"ok": True, "summary": f"URL aberta: {url}", "url": url}


def create_folder(payload: dict[str, Any]) -> dict[str, Any]:
    approved, error = require_approved(payload)
    if not approved:
        return error
    folder = payload.get("folder") or "Curso"
    requested_base = Path(payload.get("base") or Path.home() / "Desktop").expanduser().resolve()
    allowed_roots = [(Path.home() / "Desktop").resolve(), (ROOT / "data" / "desktop_workspace").resolve()]
    if not any(requested_base == r or r in requested_base.parents for r in allowed_roots):
        return {"ok": False, "summary": "Gravação fora das áreas autorizadas foi bloqueada.", "allowed_roots": [str(x) for x in allowed_roots]}
    base = requested_base
    safe = "".join(c for c in folder if c.isalnum() or c in " _-").strip() or "Nova Pasta"
    path = base / safe
    path.mkdir(parents=True, exist_ok=True)
    return {"ok": True, "path": str(path), "summary": "Pasta criada."}


def type_text(payload: dict[str, Any]) -> dict[str, Any]:
    approved, error = require_approved(payload)
    if not approved:
        return error
    pyautogui = try_import("pyautogui")
    if not pyautogui:
        return {"ok": False, "summary": "Instale pyautogui para digitar em janelas do computador."}
    text = payload.get("text") or ""
    low = text.lower()
    if any(tok in low for tok in BLOCKED_TEXT_TOKENS):
        return {"ok": False, "summary": "Texto bloqueado por poder iniciar/alterar o Windows via shell ou comando administrativo."}
    pyautogui.write(text, interval=float(payload.get("interval", 0.005)))
    return {"ok": True, "summary": "Texto digitado na janela ativa."}


def hotkey(payload: dict[str, Any]) -> dict[str, Any]:
    approved, error = require_approved(payload)
    if not approved:
        return error
    pyautogui = try_import("pyautogui")
    if not pyautogui:
        return {"ok": False, "summary": "Instale pyautogui para usar atalhos."}
    keys = payload.get("keys") or []
    if not isinstance(keys, list) or not keys:
        return {"ok": False, "summary": "Informe a lista de teclas."}
    normalized = tuple(str(k).lower() for k in keys)
    if normalized in BLOCKED_HOTKEYS:
        return {"ok": False, "summary": "Atalho bloqueado pela política: pode abrir shell/console administrativo."}
    pyautogui.hotkey(*keys)
    return {"ok": True, "summary": "Atalho executado.", "keys": keys}


def click(payload: dict[str, Any]) -> dict[str, Any]:
    approved, error = require_approved(payload)
    if not approved:
        return error
    pyautogui = try_import("pyautogui")
    if not pyautogui:
        return {"ok": False, "summary": "Instale pyautogui para clicar."}
    x = int(payload.get("x", 0))
    y = int(payload.get("y", 0))
    pyautogui.click(x, y)
    return {"ok": True, "summary": f"Clique executado em {x},{y}."}


def organize_desktop(payload: dict[str, Any]) -> dict[str, Any]:
    approved, error = require_approved(payload)
    if not approved:
        return error
    # Versão segura: cria pasta e não move arquivos automaticamente sem regras.
    folder = payload.get("folder") or "Curso"
    result = create_folder({"folder": folder, "approved": True})
    return {"ok": result.get("ok"), "summary": "Área de trabalho preparada com pasta segura. Não movi arquivos sem regra explícita.", "details": result}


def transport_command(payload: dict[str, Any]) -> dict[str, Any]:
    """Atalhos pensados para empresas de transporte de passageiros."""
    approved, error = require_approved(payload)
    if not approved:
        return error
    command = (payload.get("command") or "").lower()
    actions = []
    if "arrecada" in command or "bilheteria" in command:
        actions.append(open_url({"url": "http://127.0.0.1:8000/#powerbi", "approved": True}))
    if "zabbix" in command or "monitoramento" in command:
        actions.append(open_url({"url": "http://127.0.0.1:8000/#monitoring", "approved": True}))
    if "sql" in command or "base de dados" in command or "oracle" in command:
        actions.append(open_url({"url": "http://127.0.0.1:8000/#sql", "approved": True}))
    return {"ok": True, "summary": "Comando de transporte processado.", "actions": actions}


ACTIONS = {
    "status": lambda payload: status(),
    "screenshot": screenshot,
    "camera": camera_capture,
    "open_url": open_url,
    "create_folder": create_folder,
    "type_text": type_text,
    "hotkey": hotkey,
    "click": click,
    "organize_desktop": organize_desktop,
    "transport_command": transport_command,
}


class Handler(BaseHTTPRequestHandler):
    def _send(self, status_code: int, data: dict[str, Any]) -> None:
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "http://127.0.0.1:8000")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_OPTIONS(self):
        self._send(200, {"ok": True})

    def do_GET(self):
        if self.path.startswith("/status"):
            self._send(200, status())
        else:
            self._send(404, {"ok": False, "summary": "Endpoint não encontrado."})

    def do_POST(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            payload = json.loads(self.rfile.read(length).decode("utf-8") or "{}")
            action = payload.get("action") or ""
            if action not in ACTIONS:
                self._send(400, {"ok": False, "summary": f"Ação não suportada: {action}", "available": list(ACTIONS)})
                return
            result = ACTIONS[action](payload)
            log(json.dumps({"action": action, "result_ok": result.get("ok")}, ensure_ascii=False))
            self._send(200, result)
        except Exception as exc:
            log(traceback.format_exc())
            self._send(500, {"ok": False, "summary": "Falha controlada no Desktop Agent.", "error": str(exc)})

    def log_message(self, fmt, *args):
        return


def main():
    ensure_dirs()
    print("=" * 60)
    print("HAL Desktop Agent")
    print(f"Rodando em http://{HOST}:{PORT}")
    print("Este agente controla recursos locais apenas com aprovação explícita.")
    print("=" * 60)
    HTTPServer((HOST, PORT), Handler).serve_forever()


if __name__ == "__main__":
    main()
