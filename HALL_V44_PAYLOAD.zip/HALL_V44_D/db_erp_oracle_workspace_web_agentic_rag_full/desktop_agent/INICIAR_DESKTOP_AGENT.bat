@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0\.."

echo ============================================================
echo HAL DESKTOP AGENT
echo ============================================================
echo.

if not exist ".venv_web\Scripts\python.exe" (
  echo [ERRO] Ambiente .venv_web nao encontrado.
  echo Execute primeiro install_web.bat
  pause
  exit /b 1
)

call ".venv_web\Scripts\activate.bat"

echo Abrindo agente em http://127.0.0.1:8765
python desktop_agent\hall_desktop_agent.py

pause
endlocal
