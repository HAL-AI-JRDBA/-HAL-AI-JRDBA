@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0\.."

echo ============================================================
echo HAL DESKTOP AGENT - INSTALACAO
echo ============================================================
echo.

if not exist ".venv_web\Scripts\python.exe" (
  echo [ERRO] Ambiente .venv_web nao encontrado.
  echo Execute primeiro install_web.bat
  pause
  exit /b 1
)

call ".venv_web\Scripts\activate.bat"

echo Instalando bibliotecas opcionais de desktop...
pip install pyautogui pillow mss opencv-python

echo.
echo [OK] Instalacao concluida.
echo Agora execute: desktop_agent\INICIAR_DESKTOP_AGENT.bat
pause
endlocal
