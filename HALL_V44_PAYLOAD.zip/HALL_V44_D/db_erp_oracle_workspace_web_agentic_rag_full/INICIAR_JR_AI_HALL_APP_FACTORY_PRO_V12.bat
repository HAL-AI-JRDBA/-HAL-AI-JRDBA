@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist "HALL_AUTO_MODELS_V15.bat" call "HALL_AUTO_MODELS_V15.bat"
if exist "INICIAR_JR_AI_HALL_SOFTWARE_BUILDER_V11.bat" (
  call "INICIAR_JR_AI_HALL_SOFTWARE_BUILDER_V11.bat"
) else if exist "INICIAR_JR_AI_HALL_VOICE_SAFETY_V10.bat" (
  call "INICIAR_JR_AI_HALL_VOICE_SAFETY_V10.bat"
) else if exist "INICIAR_JR_AI_CONSOLE_UNIFICADO.bat" (
  call "INICIAR_JR_AI_CONSOLE_UNIFICADO.bat"
) else (
  echo [ERRO] Inicializador principal nao encontrado.
  pause
)
endlocal
