# IA Autônoma Governada — Oracle/ERP

Esta versão adiciona uma camada de **autonomia segura** ao projeto DB ERP Oracle Workspace.

Ela permite que a IA:

- aprenda com feedback de SQL, erros Oracle, validações e aprovações do usuário;
- escolha automaticamente estratégias por `PolicyBandit`;
- rode ciclos de autoaprendizado;
- gere propostas de melhoria com evidências;
- crie arquivos de laboratório em `data/autonomy_lab/`;
- transforme propostas aprovadas em regras aprendidas;
- execute planos autônomos usando ferramentas read-only: RAG, schema, SQL SELECT, validação, tuning e coletas DBA.

## Segurança

A autonomia **não** faz:

- alteração automática de código de produção;
- execução de `DROP`, `ALTER`, `TRUNCATE`, `CREATE`, `INSERT`, `UPDATE`, `DELETE`, `MERGE`;
- execução de `PL/SQL`, `DBMS_`, `UTL_`, shell, BAT, PowerShell ou EXE;
- escrita em arquivos sensíveis;
- aplicação de patch sem aprovação humana.

Ela funciona em modo **governado**:

```text
Pergunta → Plano → Ferramentas read-only → Validação → Feedback → Propostas → Aprovação humana
```

## Novos arquivos principais

```text
services/autonomy_manager.py
services/autonomous_orchestrator.py
README_IA_AUTONOMA.md
scripts/run_autonomous_cycle.py
```

## Novos endpoints

```text
GET  /api/autonomous/status
POST /api/autonomous/ask
POST /api/autonomous/cycle
GET  /api/autonomous/proposals
POST /api/autonomous/proposals/decision
POST /api/autonomous/feedback
```

## Nova aba na interface

A interface Web recebeu a aba:

```text
IA Autônoma
```

Nela você pode:

1. Fazer uma pergunta para a IA autônoma.
2. Rodar um ciclo de autoaprendizado.
3. Ver propostas de melhoria.
4. Aprovar/rejeitar propostas.
5. Ver regras aprendidas.

## Como rodar

Use o mesmo comando atual do projeto:

```bat
run_agentic_web.bat
```

ou:

```bat
run_web.bat
```

Depois abra a aplicação e acesse a aba **IA Autônoma**.

## Como rodar ciclo pelo terminal

```bat
python scripts\run_autonomous_cycle.py --focus "reduzir ORA-00904 em consultas de estoque"
```

## Onde ficam os aprendizados

```text
data/learning/feedback.sqlite
data/learning/sql_learning.json
data/policies/policy_bandit.json
data/autonomy/proposals.json
data/autonomy/learned_rules.json
data/autonomy_lab/cycle_*/
```

## Fluxo recomendado

1. Use normalmente SQL Copilot, Codex, DBA e Agent Gateway.
2. Aprove/rejeite respostas e SQLs.
3. Rode o ciclo na aba **IA Autônoma**.
4. Revise as propostas.
5. Aprove apenas as regras seguras.
6. Repita após novos testes reais.

## Observação importante

Esta versão entrega autonomia **operacional e governada**, não uma IA que altera a si mesma livremente. Isso é intencional para proteger seu Oracle, seu ERP e o código do sistema.
