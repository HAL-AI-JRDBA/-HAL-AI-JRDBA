# Correção de carregamento no navegador

Nesta versão, o `run_web_chat_jr_ai.bat` foi ajustado para:

- usar `127.0.0.1:8000` em vez de depender de resolução de `localhost`;
- abrir o navegador somente depois que o servidor responder;
- remover `--reload`, que pode confundir a abertura no Windows em alguns ambientes;
- adicionar rota `/index.html` e `/favicon.ico`.

## Como rodar

```bat
install_web.bat
run_web_chat_jr_ai.bat
```

Se não abrir automaticamente:

```text
http://127.0.0.1:8000/
```

Para diagnóstico:

```bat
run_web_chat_jr_ai_debug.bat
```

Se `http://127.0.0.1:8000/docs` abrir e `/` não abrir, o problema é frontend/static.
Se nem `/docs` abrir, o problema é porta, firewall, ambiente virtual ou backend.
