@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

if "%HALL_OLLAMA_MODEL%"=="" set "HALL_OLLAMA_MODEL=qwen2.5:7b"
if "%OLLAMA_URL%"=="" set "OLLAMA_URL=http://127.0.0.1:11434"
set "OLLAMA_MODEL=%HALL_OLLAMA_MODEL%"
set "HALL_DIALOG_MODEL=%HALL_OLLAMA_MODEL%"
set "HALL_WEB_SUMMARY_MODEL=%HALL_OLLAMA_MODEL%"

if not "%HALL_OLLAMA_AUTO_DONE%"=="1" (
  if exist "HALL_AUTO_OLLAMA.bat" call "HALL_AUTO_OLLAMA.bat"
)


echo ============================================================
echo JR-AI HAL - WEB DEBUG
echo ============================================================
echo.

if not exist ".venv_web\Scripts\python.exe" (
  echo [ERRO] Ambiente .venv_web nao encontrado.
  echo Execute primeiro: install_web.bat
  pause
  exit /b 1
)

call ".venv_web\Scripts\activate.bat"

echo Python:
python --version
echo.

echo Validando importacao do backend...
python -c "import web_app.backend.main; print('[OK] Backend importado')"
if errorlevel 1 (
  echo.
  echo [ERRO] Backend falhou ao importar.
  echo Copie o erro acima para diagnostico.
  pause
  exit /b 1
)

echo.
echo Subindo servidor sem reload para facilitar diagnostico...
start "" "http://127.0.0.1:8000"
python -m uvicorn web_app.backend.main:app --host 127.0.0.1 --port 8000

echo.
echo Servidor encerrado.
pause
endlocal
