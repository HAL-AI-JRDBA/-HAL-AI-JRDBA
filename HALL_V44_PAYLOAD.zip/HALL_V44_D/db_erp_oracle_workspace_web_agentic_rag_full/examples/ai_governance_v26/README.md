# Exemplo de telemetria Shadow AI

Importe `shadow_ai_telemetry.jsonl` pelo painel Administração > AI Governance / Shadow AI ou envie os eventos para `POST /api/ai-governance/telemetry/ingest`.

Não envie conteúdo sensível bruto quando o coletor já conhece a classificação. Prefira `data_class` e metadados. Quando `content_hint` for usado, o DLP processa localmente e o audit não armazena o conteúdo bruto.
