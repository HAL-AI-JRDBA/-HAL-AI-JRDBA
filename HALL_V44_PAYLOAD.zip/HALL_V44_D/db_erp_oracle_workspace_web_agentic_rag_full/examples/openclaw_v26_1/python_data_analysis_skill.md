---
id: python_data_analysis_safe
name: Python Data Analysis Safe
category: analytics
risk: medium
requires_approval: true
read_only: false
---

Exemplo de workflow especializado de análise. O script abaixo nunca roda no host;
o Declarative Skills Runtime força Docker sandbox sem rede.

```hall-workflow
[
  {
    "id": "contexto",
    "type": "template",
    "template": "Objetivo de análise: {{question}}",
    "save_as": "objetivo"
  },
  {
    "id": "python",
    "type": "script",
    "language": "python",
    "sandbox": true,
    "code": "import json\nfrom pathlib import Path\ndata=json.loads(Path('/work/input.json').read_text())\nPath('/work/output.json').write_text(json.dumps({'ok': True, 'objective': data.get('objective','')}, ensure_ascii=False))",
    "inputs": {
      "objective": "{{vars.objetivo}}"
    }
  },
  {
    "id": "resumo",
    "type": "template",
    "template": "Análise concluída no sandbox: {{steps.python.output.objective}}"
  }
]
```
