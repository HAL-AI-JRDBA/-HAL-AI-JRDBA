# Instalação — HAL Topic Switch & Full Question Capture V7

Execute:

```bat
INICIAR_JR_AI_HALL_TOPIC_SWITCH_V7.bat
```

ou:

```bat
INICIAR_JR_AI_HALL_LIVE_CHAT_V6.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Teste recomendado

Teste 1:

```text
Me recomenda um cardápio para almoço.
```

Depois, sem limpar a conversa:

```text
Agora me explica buracos negros e horizonte de eventos.
```

O HAL deve reconhecer que mudou de assunto.

## Teste de voz

Clique em Conversar. O padrão agora é gravar a pergunta completa e transcrever localmente para evitar cortes.

Se quiser voltar ao modo antigo do navegador, no console do navegador use:

```javascript
localStorage.setItem('hallVoiceCaptureMode','browser_first')
```

Para retornar ao modo recomendado:

```javascript
localStorage.setItem('hallVoiceCaptureMode','recorded_first')
```
