# HAL Natural Voice — Conversa mais natural

Esta versão adiciona a camada **HAL Natural Voice**, voltada para deixar a conversa parecida com a de uma pessoa falando com outra pessoa.

## O que foi implementado

- Nova aba **Voz Natural**
- Escuta contínua pelo navegador
- Espera de silêncio antes de responder
- Não interromper o usuário
- Barge-in: se o usuário falar durante a resposta, o HAL para de falar
- VAD básico por energia para análise de áudio
- Upload de utterance para backend
- Conversão automática para WAV quando houver ffmpeg
- STT local configurável
- TTS local configurável
- Uso do perfil de voz `voice_aprigio_hall`
- Integração com HAL Router
- Integração com Voz Própria
- Scripts opcionais para motores de voz

## O que já funciona sem instalar nada

```text
Conversa contínua no navegador
Aguardar a pessoa terminar
Cancelar resposta se o usuário voltar a falar
Roteamento automático para ferramenta correta
Resposta por voz via SpeechSynthesis do navegador
Uso do perfil de voz como referência/configuração
```

## Para ficar no nível mais natural

Configure motores locais:

### STT recomendado

```text
faster-whisper
whisper.cpp
Vosk
```

### TTS recomendado

```text
Coqui XTTS
OpenVoice
F5-TTS
Piper com voz treinada
```

## Scripts opcionais

Na pasta:

```text
voice_engines/
```

Foi incluído:

```text
INSTALAR_MOTORES_VOZ_OPCIONAIS.bat
stt_faster_whisper_local.py
README_MOTORES_VOZ.md
```

## Comandos configuráveis

Na aba **Voz Natural**, configure:

### STT local

```text
python voice_engines/stt_faster_whisper_local.py --audio "{audio}" --language pt --out "{output_json}"
```

### TTS local

```text
python voice_engines/tts_xtts_local.py --text "{text}" --speaker "{speaker_wav}" --out "{output_wav}" --language pt
```

## Importante

O ZIP já prepara toda a arquitetura, mas não instala modelos pesados automaticamente.  
Para clonagem real e naturalidade máxima, o cliente precisa instalar o motor local escolhido e os modelos correspondentes, respeitando licenças.
