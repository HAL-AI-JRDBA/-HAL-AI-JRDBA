@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
call "CONFIGURAR_MODELOS_HALL_AGENTIC_PRO.bat"
endlocal
