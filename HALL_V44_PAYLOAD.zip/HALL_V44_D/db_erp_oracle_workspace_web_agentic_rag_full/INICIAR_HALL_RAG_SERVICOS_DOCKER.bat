@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo HAL ENTERPRISE RAG - QDRANT + PGVECTOR VIA DOCKER
echo ============================================================
where docker >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Docker nao encontrado no PATH.
  pause
  exit /b 1
)

docker compose -f "docker\docker-compose.enterprise-rag.yml" up -d
if errorlevel 1 (
  echo [ERRO] Falha ao iniciar os servicos.
  pause
  exit /b 1
)

echo.
echo [OK] Qdrant:  http://127.0.0.1:6333
echo [OK] PGVector: postgresql://hall:hall_change_me@127.0.0.1:5433/hall_rag
echo.
echo Troque a senha antes de usar em producao.
pause
endlocal
