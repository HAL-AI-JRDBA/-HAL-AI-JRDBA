@echo off
cd /d "%~dp0\.."
if exist "INICIAR_JR_AI_HALL_V20.bat" (call "INICIAR_JR_AI_HALL_V20.bat") else (echo [ERRO] Launcher V20 nao encontrado na raiz.)
