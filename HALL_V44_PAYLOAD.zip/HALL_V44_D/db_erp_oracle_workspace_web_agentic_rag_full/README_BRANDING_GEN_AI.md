# Branding atualizado

A identidade visual/textual da plataforma foi atualizada para:

```text
JR-AI
Plataforma Gen-AI Open Source para ERP, Oracle, Agentes e Automação
```

## O que foi ajustado

- Título da interface web.
- Subtítulo da marca no topo da aplicação.
- Título FastAPI/backend.
- Subtítulo padrão das apresentações IA.
- Mensagens de inicialização em arquivos `.bat`.
- Módulo central `services/branding.py` com constantes de marca.

## Observação

A marca principal continua sendo **JR-AI**. O termo **Gen-AI Open Source** foi aplicado como posicionamento comercial/tecnológico da plataforma.
