@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ============================================================
echo HAL V18 - EMERGENCY KILL SWITCH
echo ============================================================
echo.
set "REASON=%~1"
if "%REASON%"=="" set "REASON=Parada de emergencia acionada pelo administrador local"
if exist ".venv_web\Scripts\python.exe" (
  ".venv_web\Scripts\python.exe" scripts\hall_safety_cli.py kill --reason "%REASON%" --actor local_admin
) else (
  python scripts\hall_safety_cli.py kill --reason "%REASON%" --actor local_admin
)
echo.
echo [SAFE] Novas execucoes agentic serao bloqueadas pelo Safety Supervisor.
pause
endlocal
