# Instalação — HAL Visual Mission Control + Universal ERP Connector

## Execução padrão

```bat
INSTALAR_TUDO_JR_AI_HALL_COMPLETO.bat
INICIAR_JR_AI_HALL_VISUAL_MISSION_CONTROL.bat
```

ou:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Acesse:

```text
http://127.0.0.1:8000
```

## Dependências opcionais por integração

### Bancos relacionais

```bash
pip install oracledb pyodbc pymssql psycopg pymysql mariadb firebird-driver ibm_db
```

### NoSQL

```bash
pip install pymongo redis elasticsearch cassandra-driver
```

### APIs e arquivos

```bash
pip install requests httpx pandas openpyxl lxml
```

### Browser/RPA

```bash
pip install playwright selenium
python -m playwright install chromium
```

## Variáveis de ambiente recomendadas

```text
ERP_TRANSPORTE_HOST
ERP_TRANSPORTE_PORT
ERP_TRANSPORTE_DATABASE
ERP_TRANSPORTE_USER
ERP_TRANSPORTE_PASSWORD
ERP_TRANSPORTE_DSN

N8N_API_KEY
WHATSAPP_TOKEN
TELEGRAM_TOKEN
SLACK_BOT_TOKEN
TEAMS_CLIENT_SECRET
DISCORD_BOT_TOKEN
SMTP_PASSWORD
```

## Política

Nunca gravar senha/token em JSON ou log. Usar variáveis de ambiente ou cofre local/corporativo.
