@echo off
chcp 65001 >nul
echo Instalando modelos leves para CPU via Ollama...
ollama pull qwen2.5:3b
ollama pull gemma3:4b
ollama pull nomic-embed-text
echo Concluido. Valide os nomes dos modelos conforme sua instalacao do Ollama.
pause
