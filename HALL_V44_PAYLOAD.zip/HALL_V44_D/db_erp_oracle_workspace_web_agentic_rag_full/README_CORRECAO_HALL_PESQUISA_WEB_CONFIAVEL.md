# Correção — HAL Pesquisa Web Confiável

Esta versão corrige o problema em que o HAL respondia sempre a mesma frase:

> "Essa pergunta depende de informação externa ou atual. Vou pesquisar em fontes confiáveis..."

O erro era que o roteamento detectava corretamente que precisava pesquisar, mas a camada de resposta final não estava sintetizando uma resposta de fato.

## O que foi adicionado

```text
HAL Reliable Web Answer Engine
Nova área: Pesquisa Web Confiável
Endpoint de resposta direta
Normalização de perguntas capturadas por voz
Busca em fontes confiáveis
Priorização de fontes oficiais
SearxNG local opcional
DuckDuckGo HTML como fallback sem API key
Wikipedia API como fallback auxiliar
Ollama local opcional para síntese
Resposta direta com fontes
Roteamento automático para perguntas atuais
Correção da frase genérica repetida
```

## Exemplo corrigido

Pergunta:

```text
Quem é o presidente atual do Brasil?
```

Resposta esperada:

```text
O presidente atual do Brasil é Luiz Inácio Lula da Silva, conhecido como Lula.
```

Com fontes verificadas quando a internet local estiver disponível.

## Configuração recomendada para produção

Para deixar a pesquisa mais robusta e totalmente local/open-source, configure:

```text
SEARXNG_URL=http://127.0.0.1:8080
HALL_WEB_SUMMARY_MODEL=qwen2.5:7b
OLLAMA_MODEL=qwen2.5:7b
```

Sem SearxNG, o sistema tenta DuckDuckGo HTML.
Sem Ollama, o sistema usa síntese extrativa baseada nas fontes encontradas.

## Importante

Esta camada não usa API da OpenAI nem Anthropic. Ela segue a filosofia local/open-source do projeto.


## HAL Human Conversation Gateway

Adicionada camada de conversa natural sem botões. Em modo automático, o usuário pode falar ou digitar livremente; o HAL responde como bate-papo quando for conversa comum e aciona Database Access, ERP, Web, Mission Control ou automações nos bastidores quando for trabalho.
