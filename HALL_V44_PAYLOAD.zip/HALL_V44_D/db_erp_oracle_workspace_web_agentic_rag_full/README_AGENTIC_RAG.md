# DB ERP Oracle Workspace — Agentic RAG

Esta versão mantém a base original do projeto e adiciona uma camada de **Agentic RAG** por cima do RAG já existente.

## O que foi adicionado

- `services/agentic_rag_orchestrator.py`  
  Orquestrador principal: planeja, decompõe, recupera, avalia, reescreve busca, sintetiza e reflete.

- `services/evidence_grader.py`  
  Avalia qualidade da evidência recuperada: cobertura, overlap, diversidade de fontes, lacunas e necessidade de nova busca.

- `services/document_graph.py`  
  Graph RAG local simples: extrai entidades dos trechos recuperados, monta relações por coocorrência e entrega contexto adicional para perguntas multi-hop.

- `services/agentic_memory.py`  
  Grava trilhas locais do Agentic RAG em `data/agentic_rag/traces.jsonl`.

## Fluxo novo

```text
Pergunta
  -> Planner agentic
  -> Subperguntas
  -> RAG híbrido / vetorial / vectorless por etapa
  -> Evidence grading
  -> Query rewrite quando a evidência é fraca
  -> Graph context
  -> Síntese final aterrada nas fontes
  -> Reflection / checagem de suporte
  -> Trace local
```

## Como executar

### Instalação recomendada para a versão nova

```bat
install_agentic.bat
```

### Execução da interface web

```bat
run_agentic_web.bat
```

A aplicação abrirá em:

```text
http://127.0.0.1:8010
```

## Compatibilidade preservada

Foram mantidos:

- `install_local.bat`
- `install_web.bat`
- `run_local.bat`
- `run_web.bat`
- `requirements.txt`
- `requirements_web.txt`
- Agent Gateway / OpenClaw
- RAG tradicional, vectorless e híbrido
- Schema Ground Truth
- NL2SQL com validação
- execução somente SELECT
- DBA read-only
- ChartDB
- RL/feedback para SQL

## Onde usar na interface

Na aba **RAG**, o seletor de modo agora tem:

```text
Agentic RAG
Auto clássico
Traditional
Vectorless
Hybrid
```

O modo **Agentic RAG** é o recomendado para perguntas compostas, como:

```text
Identifique materiais com baixo giro, estoque parado há mais de 90 dias, itens com risco de ruptura e aumento relevante de custo médio. Agrupe por almoxarifado, família de material e valor financeiro imobilizado.
```

## Endpoint

```http
POST /api/context/ask
```

Exemplo de payload:

```json
{
  "question": "Quais regras o documento traz sobre materiais com baixo giro e risco de ruptura?",
  "mode": "agentic",
  "top_k": 8,
  "agentic_iterations": 2,
  "agentic_subquestions": 5,
  "enable_reflection": true
}
```

O Agent Gateway também usa o modo agentic por padrão em:

```http
POST /api/agent/tools/rag_search
```

## Observação importante

A camada Agentic RAG foi feita para funcionar **localmente**. Quando o Ollama não estiver disponível, ela ainda executa o planejamento heurístico, recuperação, grade de evidências e resposta baseada em trechos. Com Ollama disponível, a síntese e a reflexão ficam melhores.
