# HAL — Conversa humana estilo assistente do vídeo

Esta versão adiciona a camada **HAL Human Conversation Engine**.

## O que foi corrigido

Antes o HAL respondia de forma muito técnica, por exemplo:

```text
Vou usar SQL Copilot.
```

Agora ele conversa como uma pessoa:

```text
Entendi. Você quer descobrir o último mês ou o último período disponível na base de dados.
Para eu fazer isso certo, preciso saber de qual módulo estamos falando:
arrecadação, bilheteria, viagens, contas a receber, escala, financeiro ou outro?
```

## Características implementadas

- Resposta mais humana e natural
- Entendimento de perguntas curtas de voz
- Correção de pequenos erros de transcrição
- Saudação natural
- Uma pergunta de esclarecimento por vez
- Menos respostas robóticas
- Não expõe JSON para o usuário final
- Integração com:
  - HAL Natural Voice
  - HAL Filme
  - HAL Desktop Agent
  - Memória local
  - Roteador de ferramentas
  - Automação por voz

## Exemplos

```text
Usuário: Oi Hall
HAL: Olá! Pode falar comigo naturalmente. Eu entendo o pedido, faço perguntas quando precisar e aciono a ferramenta correta.
```

```text
Usuário: último mês da base de dados
HAL: Entendi. Você quer descobrir o último mês ou o último período disponível na base de dados. Para eu fazer isso certo, preciso saber de qual módulo estamos falando...
```

```text
Usuário: veja minha tela
HAL: Consigo fazer isso. Para preservar sua privacidade, eu só vou enxergar a tela ou a câmera quando você clicar para capturar ou compartilhar...
```

```text
Usuário: escreva nessa tela uma resposta educada para o cliente
HAL: Entendi. Isso exige controle do computador local, então vou usar o HAL Desktop Agent... só executo com sua aprovação marcada.
```

## Foco em transporte

O motor de conversa foi ajustado para empresas de transporte urbano e rodoviário, com módulos como:

```text
Arrecadação
Bilheteria
Viagens
Frota
Manutenção
Escala
Frequência
CRC / Contas a Receber
CPG / Contas a Pagar
Financeiro
Bancos
Contabilidade
Folha
Jurídico
Monitoramento
Power BI
Zabbix/Grafana
Oracle
```

## Endpoint novo

```text
GET  /api/hall-human/status
POST /api/hall-human/turn
GET  /api/hall-human/sessions
```

A aba Voz Natural agora usa essa camada internamente para responder melhor.
