@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
call "INICIAR_HALL_AGENTIC_PRO.bat"
endlocal
