@echo off
setlocal
cd /d %~dp0

echo ============================================================
echo OPCIONAL - VOZ 100%% LOCAL COM WHISPER/PIPER
ECHO ============================================================
echo.
echo A versao atual do JR ja ouve e fala via navegador, sem dependencias extras.
echo Este instalador opcional e apenas para futura evolucao com STT/TTS offline no backend.
echo.
echo Pacotes sugeridos:
echo - faster-whisper para fala -> texto local
echo - piper-tts para texto -> voz local
echo.
set /p CONFIRMAR="Deseja instalar dependencias opcionais pesadas? (S/N): "
if /I not "%CONFIRMAR%"=="S" (
  echo Cancelado.
  pause
  exit /b 0
)

if not exist .venv_web\Scripts\activate.bat (
  echo [ERRO] Ambiente .venv_web nao encontrado. Rode install_web.bat primeiro.
  pause
  exit /b 1
)
call .venv_web\Scripts\activate.bat
python -m pip install faster-whisper piper-tts

echo.
echo [OK] Dependencias opcionais instaladas.
echo Observacao: os endpoints offline ainda devem ser habilitados conforme o modelo/voz escolhidos.
pause
endlocal
