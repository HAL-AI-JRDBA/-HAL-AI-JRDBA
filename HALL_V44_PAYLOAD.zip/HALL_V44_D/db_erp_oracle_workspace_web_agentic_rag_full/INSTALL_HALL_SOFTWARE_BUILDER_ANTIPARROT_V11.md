# Instalação — HAL Software Builder & Anti-Parrot V11

Execute:

```bat
INICIAR_JR_AI_HALL_SOFTWARE_BUILDER_V11.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Teste principal

Digite:

```text
Eu quero um software para controlar minhas finanças pessoais
```

O HAL deve responder com proposta de sistema Python/Web, não com "me diga o ponto central".

## Gerar app de finanças pessoais via API

```text
POST http://127.0.0.1:8000/api/unified/software-builder/plan
```

JSON:

```json
{
  "message": "Eu quero um software em python com interface web para controle de finanças pessoais",
  "generate_project": true,
  "project_name": "hall_financas_pessoais"
}
```

O projeto será salvo dentro da área local de dados do HAL.
