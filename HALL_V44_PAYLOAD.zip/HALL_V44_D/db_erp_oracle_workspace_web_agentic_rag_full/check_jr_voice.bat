@echo off
setlocal
cd /d %~dp0

echo ============================================================
echo CHECK JR - VOZ E TEXTO
echo ============================================================
echo.

echo 1. Verificando ambiente Python...
if not exist .venv_web\Scripts\activate.bat (
  echo [AVISO] .venv_web nao existe. Rode install_web.bat.
  pause
  exit /b 1
)
call .venv_web\Scripts\activate.bat

echo.
echo 2. Validando importacao do backend...
python -c "import web_app.backend.main; print('Backend OK')"
if %errorlevel% neq 0 (
  echo [ERRO] Backend nao importou.
  pause
  exit /b 1
)

echo.
echo 3. Validando rota JR com FastAPI TestClient...
python -c "from fastapi.testclient import TestClient; from web_app.backend.main import app; c=TestClient(app); r=c.get('/api/jr/status'); print(r.status_code); print(r.json())"
if %errorlevel% neq 0 (
  echo [ERRO] Teste JR falhou.
  pause
  exit /b 1
)

echo.
echo 4. Para testar microfone e fala, rode run_web_jr.bat e abra a aba JR Voz.
echo    Use Microsoft Edge ou Google Chrome.
echo.
pause
endlocal
