# Instalação — HAL Voice Safety V10

Execute:

```bat
INICIAR_JR_AI_HALL_VOICE_SAFETY_V10.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Teste

1. Clique em Conversar.
2. Se o STT local estiver pronto, ele pode gravar e transcrever.
3. Se não estiver pronto, ele usa o reconhecimento do navegador.
4. Se nada captar, ele mostra mensagem clara e volta para Pronto.

Para ativar STT local:

```bat
HALL_AUTO_STT.bat
```

Verifique:

```text
http://127.0.0.1:8000/api/unified/stt/status
```
