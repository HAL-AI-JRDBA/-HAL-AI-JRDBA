@echo off
chcp 65001 >nul
echo Configuração opcional para respostas mais naturais com Ollama.
echo.
echo 1. Instale o Ollama
echo 2. Execute:
echo.
echo ollama pull qwen2.5:7b
echo setx OLLAMA_MODEL "qwen2.5:7b"
echo setx HALL_DIALOG_MODEL "qwen2.5:7b"
echo setx OLLAMA_URL "http://127.0.0.1:11434"
echo.
echo Depois feche e abra o terminal novamente.
pause
