# Codex Consultor Oracle

Esta versão transforma a aba **Codex** em um modo **Consultor Oracle**, mais parecido com um assistente técnico completo.

## O que foi adicionado

- Novo endpoint backend: `POST /api/codex/consultor`.
- Novo serviço: `services/codex_consultor.py`.
- Novo modo na interface: **Auto Consultor — recomendado**.
- Resposta com explicação técnica, código/SQL em bloco, validação, riscos e instruções de teste.
- Roteamento automático por intenção:
  - geração de SQL SELECT;
  - criação/correção de View, PL/SQL, Python, BAT, PowerShell etc.;
  - explicação DBA Oracle;
  - tuning/índices;
  - RAG/documentos quando aplicável.
- Uso do schema canônico já carregado no Mapa ERP.
- Uso do pipeline seguro de SQL quando a pergunta for de relatório/consulta.
- Bloqueio de execução automática; execução de SELECT continua dependendo do botão específico e confirmação do usuário.

## Como usar

1. Execute `run_web.bat`.
2. Acesse `http://127.0.0.1:8010`.
3. Configure Oracle e LLM/Ollama, se ainda não estiverem configurados.
4. Abra a aba **Codex**.
5. Deixe o campo **Modo da IA** em **Auto Consultor — recomendado**.
6. Faça perguntas como:

```text
Integre nesta view o histórico de compras dos itens e explique como validar.
```

```text
Gere uma query para mostrar estoque parado há mais de 90 dias por almoxarifado e família.
```

```text
Analise essa SQL de custo alto e sugira índices.
```

## Observação importante

O programa não acessa a cadeia de pensamento interna de nenhum modelo. O que ele faz é apresentar um **raciocínio operacional resumido**, com entendimento, decisão, código, validação e riscos, que é o comportamento ideal para usuário final e ambiente corporativo.
