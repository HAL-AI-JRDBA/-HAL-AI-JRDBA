# HAL V34 — Local MCP Platform

Esta versão adiciona uma implementação MCP real à HAL sem substituir o Ollama e sem exigir LLM em nuvem.

## Componentes

- Servidor MCP da HAL em `POST /mcp` usando JSON-RPC 2.0 e Streamable HTTP.
- Cliente MCP para descoberta e chamada de servidores locais ou remotos autorizados.
- `tools/list`, `tools/call`, `resources/list`, `resources/read`, `prompts/list` e `prompts/get`.
- Painel `Administração > MCP V34`.
- Política local-only ativada por padrão.
- Ferramentas somente leitura por padrão.
- Aprovação humana obrigatória para servidores marcados com escrita.
- IAM administrativo e auditoria encadeada por hash.
- Tokens referenciados por variável de ambiente; nenhum segredo é salvo no JSON.

## Ollama

As LLMs continuam locais. O MCP é executado no backend da HAL. Modelos com tool calling podem selecionar ferramentas diretamente; os demais podem continuar usando o roteador e saídas estruturadas da HAL.

## Primeiro teste

1. Inicie a HAL com `INICIAR_JR_AI_HALL_V34.bat`.
2. Entre com uma conta administradora.
3. Abra `Administração > MCP V34`.
4. Mantenha `Somente servidores locais` marcado.
5. Cadastre `HAL MCP Local` com URL `http://127.0.0.1:8000/mcp`.
6. Clique em `Descobrir`.

O diagnóstico deve listar as ferramentas, os recursos e os prompts publicados pela HAL.

## Segurança

Conexões externas permanecem bloqueadas enquanto `local_only=true`. Para um cliente fora do servidor, configure `HALL_MCP_SERVER_TOKEN` no ambiente e envie o valor como Bearer token ou `X-HAL-MCP-TOKEN`. Não conceda escrita a um servidor antes de revisar suas ferramentas e permissões.
