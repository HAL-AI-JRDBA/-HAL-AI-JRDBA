@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo Instalando drivers opcionais SQL/NoSQL...
python -m pip install --upgrade pip
python -m pip install requests pymongo redis elasticsearch psycopg pymysql pyodbc
echo.
echo Alguns drivers corporativos exigem instalador do fornecedor:
echo Oracle Client / ODBC SQL Server / IBM DB2 / Firebird / etc.
echo.
pause
endlocal
