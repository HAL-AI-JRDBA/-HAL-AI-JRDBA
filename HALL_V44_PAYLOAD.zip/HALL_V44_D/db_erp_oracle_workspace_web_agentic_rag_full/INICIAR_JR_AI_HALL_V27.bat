@echo off
chcp 65001 >nul
setlocal EnableExtensions

set "SCRIPT_DIR=%~dp0"
set "HALL_HOME="

rem ============================================================
rem HAL V27 STARTUP HOTFIX
rem Resolve a raiz pela localizacao real do BAT; nao depende apenas
rem de C:\AI_HALL e funciona tambem se o ZIP foi extraido com
rem uma pasta AI_HALL adicional.
rem ============================================================
if exist "%SCRIPT_DIR%INICIAR_JR_AI_HALL_V26_2.bat" set "HALL_HOME=%SCRIPT_DIR%"
if not defined HALL_HOME if exist "%SCRIPT_DIR%..\INICIAR_JR_AI_HALL_V26_2.bat" set "HALL_HOME=%SCRIPT_DIR%..\"
if not defined HALL_HOME if exist "C:\AI_HALL\INICIAR_JR_AI_HALL_V26_2.bat" set "HALL_HOME=C:\AI_HALL\"
if not defined HALL_HOME if exist "C:\AI_HALL\AI_HALL\INICIAR_JR_AI_HALL_V26_2.bat" set "HALL_HOME=C:\AI_HALL\AI_HALL\"

if not defined HALL_HOME (
  echo ============================================================
  echo [ERRO] Nao encontrei a raiz da instalacao do HAL.
  echo ============================================================
  echo.
  echo O arquivo abaixo precisa existir na raiz:
  echo   INICIAR_JR_AI_HALL_V26_2.bat
  echo.
  echo Locais verificados:
  echo   %SCRIPT_DIR%
  echo   %SCRIPT_DIR%..\
  echo   C:\AI_HALL\
  echo   C:\AI_HALL\AI_HALL\
  echo.
  pause
  exit /b 90
)

set "HALL_PROJECT=%HALL_HOME%db_erp_oracle_workspace_web_agentic_rag_full"
if not exist "%HALL_PROJECT%\web_app\backend\main.py" (
  echo ============================================================
  echo [ERRO] Backend do HAL nao encontrado.
  echo ============================================================
  echo Esperado:
  echo   %HALL_PROJECT%\web_app\backend\main.py
  echo.
  pause
  exit /b 91
)

set "HALL_ALLOW_TOTAL_RSI=0"
set "HALL_V27_EVOLUTION_ENGINE=1"
set "HALL_V27_STARTUP_HOTFIX=1"

if not exist "%HALL_PROJECT%\.venv_web\Scripts\python.exe" (
  echo ============================================================
  echo [ERRO] Ambiente Python .venv_web nao encontrado.
  echo ============================================================
  echo Projeto detectado:
  echo   %HALL_PROJECT%
  echo.
  echo Execute uma vez:
  echo   cd /d "%HALL_PROJECT%"
  echo   install_web.bat
  echo.
  echo Depois execute novamente:
  echo   INICIAR_JR_AI_HALL_V27.bat
  echo.
  pause
  exit /b 92
)

echo ============================================================
echo JR-AI / HAL V27 - GOVERNED SELF-IMPROVEMENT
echo STARTUP HOTFIX 27.0.1
echo ============================================================
echo [ROOT] %HALL_HOME%
echo [APP ] %HALL_PROJECT%
echo [RSI ] Total RSI: DESABILITADA por padrao
echo [EVO ] Evolution Engine: ATIVO
echo.

echo [START] Encadeando inicializacao pela raiz correta...
call "%HALL_HOME%INICIAR_JR_AI_HALL_V26_2.bat"
set "HALL_RC=%ERRORLEVEL%"

if not "%HALL_RC%"=="0" (
  echo.
  echo ============================================================
  echo [ERRO] O inicializador HAL terminou com codigo %HALL_RC%.
  echo Execute DIAGNOSTICAR_INICIO_HALL_V27.bat para detalhes.
  echo ============================================================
  pause
)

endlocal & exit /b %HALL_RC%
