# Instalação — HAL Live Chat Kernel V6

Execute:

```bat
INICIAR_JR_AI_HALL_LIVE_CHAT_V6.bat
```

ou:

```bat
INICIAR_JR_AI_HALL_VOICE_STT_V5.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Teste recomendado

Digite ou fale:

```text
comigo
```

A resposta esperada deve ser uma conversa natural, não uma pergunta mecânica sobre "ponto central".

Depois diga:

```text
estou pensando em como vender melhor essa IA
```

O HAL deve continuar o assunto e ajudar a organizar a conversa.
