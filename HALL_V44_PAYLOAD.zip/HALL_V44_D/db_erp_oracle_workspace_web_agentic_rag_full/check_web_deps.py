from __future__ import annotations

REQUIRED = [
    ('fastapi', 'fastapi'),
    ('uvicorn', 'uvicorn[standard]'),
    ('requests', 'requests'),
    ('oracledb', 'oracledb'),
    ('pypdf', 'pypdf'),
    ('numpy', 'numpy'),
    ('pandas', 'pandas'),
    ('openpyxl', 'openpyxl'),
    ('faker', 'faker'),
    ('multipart', 'python-multipart'),
    ('pptx', 'python-pptx'),
]

OPTIONAL = [
    ('chromadb', 'chromadb'),
    ('qdrant_client', 'qdrant-client'),
    ('psycopg', 'psycopg[binary]'),
    ('pgvector', 'pgvector'),
]


def main() -> int:
    failed: list[str] = []
    optional_missing: list[str] = []
    for module_name, package_name in REQUIRED:
        try:
            __import__(module_name)
        except Exception as exc:
            failed.append(f'{package_name}  ({type(exc).__name__}: {exc})')

    for module_name, package_name in OPTIONAL:
        try:
            __import__(module_name)
        except Exception:
            optional_missing.append(package_name)

    if failed:
        print('[ERRO] Dependencias WEB ausentes ou quebradas:')
        for item in failed:
            print(f' - {item}')
        print('')
        print('Corrija executando:')
        print('  install_web.bat')
        print('')
        print('Ou, com o ambiente ativado:')
        print('  pip install -r requirements_web.txt')
        return 1

    print('[OK] Dependencias web importadas com sucesso.')
    if optional_missing:
        print('[AVISO] Dependencias opcionais ausentes; alguns recursos podem usar fallback local:')
        for item in optional_missing:
            print(f' - {item}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
