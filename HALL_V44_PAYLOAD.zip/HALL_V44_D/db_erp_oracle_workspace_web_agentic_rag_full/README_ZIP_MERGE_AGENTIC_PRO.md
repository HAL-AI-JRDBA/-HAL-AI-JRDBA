# Correção do ZIP — preservando a JR-AI completa

Você estava correto: o ZIP `hall_transporte_agentic_pro_com_guias.zip` tinha cerca de 30 KB porque era uma base limpa/standalone criada para provar o novo motor Agentic Pro.

Ele **não preservava** todas as funcionalidades do projeto anterior.

Este novo pacote corrige isso:

- Mantém o projeto anterior completo: `db_erp_oracle_workspace_web_agentic_rag_full`
- Mantém todas as abas existentes da JR-AI/HAL
- Mantém serviços já existentes: Oracle, RAG, DBA, ChartDB, OpenClaw, Power BI, Zabbix/Grafana, Voz Natural, Voz Própria, HAL Filme, Agent Evaluation, JR-Evolve etc.
- Adiciona a nova pasta: `hall_transporte_agentic_pro`
- Adiciona launchers para instalar/iniciar o Agentic Pro
- Adiciona uma aba visual na JR-AI antiga chamada `HAL Agentic Pro`, apontando para `http://127.0.0.1:8030`

## Tamanhos comparados

Arquivo antigo enviado:
- Nome: `db_erp_oracle_workspace_jr_ai_hall_conversa_humana_estilo_alfred(1).zip`
- Tamanho: 2,081,283 bytes
- Arquivos internos: 379

Arquivo Agentic Pro limpo:
- Nome: `hall_transporte_agentic_pro_com_guias(1).zip`
- Tamanho: 30,556 bytes
- Arquivos internos: 26

Este pacote mesclado deve ficar próximo ao tamanho do projeto antigo, pois ele preserva tudo e acrescenta a nova camada.

## Execução recomendada

Instalar tudo:

```bat
INSTALAR_TUDO_JR_AI_HALL_COMPLETO.bat
```

Abrir a plataforma completa e o Agentic Pro:

```bat
INICIAR_PLATAFORMA_COMPLETA_COM_AGENTIC_PRO.bat
```

Ou executar separadamente:

```bat
INICIAR_JR_AI_HALL.bat
INICIAR_HALL_AGENTIC_PRO.bat
```

## Portas

- JR-AI completa antiga: `http://127.0.0.1:8000`
- HAL Agentic Pro: `http://127.0.0.1:8030`
