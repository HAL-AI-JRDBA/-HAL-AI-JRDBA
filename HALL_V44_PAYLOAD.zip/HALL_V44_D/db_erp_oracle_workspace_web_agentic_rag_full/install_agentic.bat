@echo off
setlocal
cd /d %~dp0

echo ============================================================
echo INSTALACAO - DB ERP ORACLE WORKSPACE AGENTIC RAG
echo ============================================================
echo.

set "PY_CMD="
where py >nul 2>nul
if %errorlevel%==0 set "PY_CMD=py -3"
if not defined PY_CMD (
  where python >nul 2>nul
  if %errorlevel%==0 set "PY_CMD=python"
)

if not defined PY_CMD (
  echo [ERRO] Python nao encontrado no PATH.
  echo Instale Python 3.12 x64 padrao ^(com GIL^) e marque Add Python to PATH.
  pause
  exit /b 1
)

echo Verificando interpretador Python...
%PY_CMD% check_python_env.py
if errorlevel 1 (
  echo [ERRO] Interpretador Python incompativel.
  pause
  exit /b 1
)

if not exist .venv_agentic (
  echo Criando ambiente virtual .venv_agentic...
  %PY_CMD% -m venv .venv_agentic
  if errorlevel 1 (
    echo [ERRO] Falha ao criar ambiente virtual.
    pause
    exit /b 1
  )
)

call .venv_agentic\Scripts\activate.bat
if errorlevel 1 (
  echo [ERRO] Falha ao ativar ambiente virtual.
  pause
  exit /b 1
)

echo Atualizando pip/setuptools/wheel...
python -m pip install --upgrade pip setuptools wheel
if errorlevel 1 (
  echo [ERRO] Falha ao atualizar ferramentas base.
  pause
  exit /b 1
)

echo Instalando requirements.txt...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo [ERRO] Falha ao instalar requirements.txt.
  pause
  exit /b 1
)

echo Instalando requirements_web.txt...
python -m pip install -r requirements_web.txt
if errorlevel 1 (
  echo [ERRO] Falha ao instalar requirements_web.txt.
  pause
  exit /b 1
)

echo Verificando imports essenciais...
python check_runtime_deps.py
if errorlevel 1 (
  echo [ERRO] Ambiente incompleto ou pacote quebrado.
  pause
  exit /b 1
)

echo.
echo [OK] Instalacao concluida.
echo Para executar a interface web: run_agentic_web.bat
echo Para executar Streamlit legado: run_local.bat
pause
exit /b 0
