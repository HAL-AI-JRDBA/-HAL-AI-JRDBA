@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist "INICIAR_JR_AI_HALL_REPAIR_V8.bat" (
  call "INICIAR_JR_AI_HALL_REPAIR_V8.bat"
) else if exist "INICIAR_JR_AI_HALL_TOPIC_SWITCH_V7.bat" (
  call "INICIAR_JR_AI_HALL_TOPIC_SWITCH_V7.bat"
) else (
  call "INICIAR_JR_AI_CONSOLE_UNIFICADO.bat"
)
endlocal
