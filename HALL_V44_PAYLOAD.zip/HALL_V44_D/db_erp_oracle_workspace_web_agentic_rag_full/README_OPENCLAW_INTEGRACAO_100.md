# OpenClaw Runtime - Integração 100% das Abas

Esta versão adiciona a ponte final entre o OpenClaw Runtime e as abas/ferramentas já existentes do projeto.

## Agora integradas como skills do OpenClaw

- Codex: `codex_consultor`, `codex_explain_plan`
- DBA: `dba_collect`, `dba_analyze`
- SQL Copilot: `find_tables`, `generate_sql`, `validate_sql`, `run_select`, `suggest_indexes`
- View Studio: `viewstudio_draft`, `viewstudio_review`, `viewstudio_validate`
- Segurança: `security_score`, `security_summary`
- Sintéticos: `synthetic_table_columns`, `synthetic_generate`
- ERD/ChartDB: `chartdb_health`, `chartdb_export_dbml`, `chartdb_export_ddl`
- Engenharia LLM: `llm_context_build`, `llm_memory_search`, `llm_tools_manifest`
- IA Autônoma: `autonomy_ask`, `autonomy_cycle`
- Insights: `predictive_insights`
- Fábrica de Software: `software_factory_propose`
- Memória/Notificações: `memory_record`, `notify_log`

## Novo endpoint

```text
GET /api/openclaw-runtime/bridge/manifest
```

## Agente novo

Foi adicionado o agente padrão `oc_integracao_total` / **Agente Integrador 100%**, que já vem com permissões para acionar as skills de todas as abas, mantendo governança.

## Segurança

A integração não libera DML/DDL, shell, BAT/PowerShell/EXE ou alterações automáticas em produção. Skills críticas continuam exigindo aprovação humana.
