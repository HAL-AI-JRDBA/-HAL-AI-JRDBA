# HAL Segmentos & Precisão — Correção Multi-Segmento

Esta versão corrige um problema estrutural: a IA não pode apenas escolher abas ou responder mensagens genéricas. Para atender qualquer segmento com qualidade, ela precisa:

```text
1. Entender o segmento do pedido
2. Entender a intenção do usuário
3. Verificar se existe fonte de dados configurada
4. Escolher a ferramenta correta
5. Responder diretamente quando houver evidência
6. Perguntar exatamente o que falta quando não houver dados
7. Não inventar números, conexões ou resultados
8. Validar a resposta por casos de teste
```

## Nova camada adicionada

```text
HAL Industry Precision Engine
```

## Segmentos contemplados

```text
Transporte de Passageiros
Logística
Financeiro / Contábil
Varejo / Atacado
Saúde
Indústria / Manufatura
Serviços / Projetos
Educação
Segmento Genérico / Corporativo
```

## O que esta camada resolve

Antes, quando a pergunta não caía bem em uma aba, o HAL podia responder apenas uma frase de roteamento. Agora ele cria uma resposta de negócio com:

```text
segmento detectado
intenção detectada
ferramenta principal recomendada
ferramentas de apoio
fontes de dados necessárias
o que falta configurar
pergunta de esclarecimento objetiva
política de precisão
exemplos do segmento
```

## Regra de precisão

Não existe “precisão total” sem dados, mapeamento e validação. O HAL agora segue esta regra:

```text
Se houver fonte configurada: consultar e responder.
Se faltar fonte: dizer exatamente o que falta.
Se for ação sensível: pedir aprovação.
Se for dado atual: pesquisar fonte confiável.
Se for ERP: usar Universal ERP Connector.
Se for sistema sem API: usar Browser Automation.
Se for automação: usar n8n/Cron.
Se for atendimento: usar Channel Gateway/RAG.
```

## Exemplos

```text
HAL, como atender varejo com ruptura de estoque?
HAL, quais contas a receber vencidas devo priorizar?
HAL, consulte vendas de passagens de hoje por linha.
HAL, quais entregas estão atrasadas na logística?
HAL, quais chamados estão perto de estourar SLA?
```

## Importante

Esta camada não promete mágica. Ela evita a falha mais perigosa: parecer que sabe quando não tem dados reais.
Para cada cliente/segmento, configure fontes de dados, sistemas, processos e testes.
