# Dev Studio Universal Avançado — JR-AI

Esta versão amplia o Dev Studio Universal para atuar como uma plataforma de desenvolvimento de sistemas.

## Novas categorias

- Sistemas web
- APIs
- Scripts e console
- Full-stack
- Mobile
- Jogos 2D
- Templates customizados para outras linguagens

## Novas stacks/templates

- Full-stack React + FastAPI
- Full-stack React + Node Express
- Next.js + Prisma
- Spring Boot + React
- ASP.NET Minimal API
- Flutter
- React Native / Expo
- Android Kotlin
- iOS Swift
- Phaser 2D
- Pygame
- Godot

## Bancos contemplados

Relacionais:

- Oracle
- SQL Server
- PostgreSQL
- MySQL
- MariaDB
- SQLite

NoSQL / complementares:

- MongoDB
- Redis

Observação: MariaDB é banco relacional compatível com ecossistema MySQL; MongoDB é NoSQL/documental.

## Endpoints

```text
GET  /api/dev-studio/status
GET  /api/dev-studio/profiles
GET  /api/dev-studio/databases
POST /api/dev-studio/plan
POST /api/dev-studio/generate
GET  /api/dev-studio/projects
GET  /api/dev-studio/download/{filename}
```

## Exemplos de prompt

```text
Crie um sistema full-stack React + FastAPI com Oracle para controlar ordens de serviço, veículos, peças e dashboard de frota parada. Gerar projeto em ZIP.
```

```text
Crie um app mobile Flutter com MongoDB para apontamento de manutenção da frota em campo.
```

```text
Crie uma API Java Spring Boot com SQL Server para contas a pagar e contas a receber.
```

```text
Crie um jogo 2D em Phaser para treinamento de motoristas com obstáculos e pontuação.
```

## Uso recomendado

O Dev Studio cria a estrutura inicial. Para evoluir código existente com patch, revisão, testes e rollback, use também a aba Fábrica de Software IA.
