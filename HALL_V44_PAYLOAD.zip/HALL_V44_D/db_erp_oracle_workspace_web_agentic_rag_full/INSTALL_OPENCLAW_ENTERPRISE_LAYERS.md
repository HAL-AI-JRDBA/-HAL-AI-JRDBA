# Guia rápido — Instalação das camadas OpenClaw Enterprise

## Channel Gateway

Configure tokens em variáveis de ambiente:

```text
WHATSAPP_TOKEN
TELEGRAM_TOKEN
SLACK_BOT_TOKEN
TEAMS_CLIENT_SECRET
DISCORD_BOT_TOKEN
SMTP_PASSWORD
```

## n8n

```text
N8N_API_KEY
N8N_BASE_URL=http://127.0.0.1:5678
```

## Browser Automation

```bash
pip install playwright
python -m playwright install chromium
```

## Cron Enterprise

Windows:
```text
Usar Task Scheduler ou NSSM.
```

Linux:
```text
Criar serviço systemd para o worker.
```

## Sandbox Enterprise

```text
Instalar Docker ou Docker Desktop.
Executar containers sem privilégios, com rede bloqueada por padrão.
```

## Agent Framework Bridge

Opcional:

```bash
pip install crewai langgraph
```

MCP/OpenClaw externos devem ser configurados conforme o servidor escolhido.
