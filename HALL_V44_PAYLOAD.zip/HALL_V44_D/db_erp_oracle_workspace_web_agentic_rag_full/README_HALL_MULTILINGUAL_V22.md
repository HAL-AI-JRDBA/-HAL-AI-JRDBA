# HAL V22 - Multilingual User Experience

JR-AI / HAL V22 - MULTILINGUAL USER EXPERIENCE
==================================================

Idiomas suportados por usuario:
- Portugues (Brasil) - pt-BR
- English - en-US
- Espanol - es-ES
- Mandarin / Chinese Simplified - zh-CN
- Japanese - ja-JP

A preferencia fica salva no usuario IAM e controla:
- interface principal e tela de login;
- resposta final do HAL;
- STT do navegador;
- idioma enviado ao Whisper local;
- TTS do navegador;
- idioma padrao de novos chats.

O administrador pode definir o idioma inicial de cada usuario. O proprio usuario pode altera-lo no seletor do topo.

Inicializador: C:/AI_HALL/INICIAR_JR_AI_HALL_V22.bat
