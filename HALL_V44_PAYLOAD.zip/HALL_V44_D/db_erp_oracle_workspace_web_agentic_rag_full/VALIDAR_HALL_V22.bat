@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
set "PROJ=db_erp_oracle_workspace_web_agentic_rag_full"
if exist "web_app\backend\main.py" set "PROJ=."
if not exist "%PROJ%\scripts\validar_hall_v22.py" (
  echo [ERRO] Validador V22 nao encontrado.
  pause
  exit /b 1
)
if exist "%PROJ%\.venv_web\Scripts\python.exe" (
  "%PROJ%\.venv_web\Scripts\python.exe" "%PROJ%\scripts\validar_hall_v22.py"
) else (
  python "%PROJ%\scripts\validar_hall_v22.py"
)
if errorlevel 1 (
  echo.
  echo [ERRO] Validacao HAL V22 falhou.
  pause
  exit /b 1
)
echo.
echo [OK] HAL V22 Multilingual validada.
pause
endlocal
