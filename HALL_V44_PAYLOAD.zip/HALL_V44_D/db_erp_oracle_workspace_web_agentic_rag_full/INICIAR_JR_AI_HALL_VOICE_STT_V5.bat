@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist "HALL_AUTO_STT.bat" call "HALL_AUTO_STT.bat"
if exist "INICIAR_JR_AI_HALL_LIVE_DIALOGUE_V4.bat" (
  call "INICIAR_JR_AI_HALL_LIVE_DIALOGUE_V4.bat"
) else (
  call "INICIAR_JR_AI_CONSOLE_UNIFICADO.bat"
)
endlocal
