@echo off
cd /d "%~dp0\.."
call "INICIAR_JR_AI_HALL_V21.bat"
