@echo off
setlocal
cd /d %~dp0
title JR-AI - Plataforma Gen-AI Open Source para ERP, Oracle, Agentes e Automação - Diagnóstico de Voz Global

echo Verificando arquivos do JR-AI Voz Global...
if not exist web_app\frontend\app.js echo ERRO: app.js nao encontrado
if not exist web_app\frontend\index.html echo ERRO: index.html nao encontrado
if not exist web_app\backend\main.py echo ERRO: main.py nao encontrado
if not exist README_JR_VOZ_GLOBAL.md echo ERRO: README_JR_VOZ_GLOBAL.md nao encontrado

echo.
echo Compilando backend...
if exist .venv_web\Scripts\python.exe (
  .venv_web\Scripts\python.exe -m py_compile web_app\backend\main.py
) else (
  python -m py_compile web_app\backend\main.py
)
if errorlevel 1 pause & exit /b 1

echo.
echo OK. Para testar voz, execute run_web_jr_global.bat e abra no Chrome/Edge.
echo Dica: instale vozes pt-BR no Windows em Configuracoes ^> Hora e idioma ^> Fala.
pause
