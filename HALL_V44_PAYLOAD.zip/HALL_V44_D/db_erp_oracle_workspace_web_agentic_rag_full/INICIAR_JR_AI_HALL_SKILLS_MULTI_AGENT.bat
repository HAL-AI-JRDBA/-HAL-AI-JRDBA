@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist "HALL_AUTO_STT.bat" call "HALL_AUTO_STT.bat"
call "INICIAR_JR_AI_HALL_EXECUTIVE_FINANCE.bat"
endlocal
