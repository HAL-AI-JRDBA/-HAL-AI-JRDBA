from dataclasses import dataclass
import os


@dataclass
class AppConfig:
    ollama_base_url: str = os.getenv('OLLAMA_BASE_URL', 'http://127.0.0.1:11435')
    generator_model: str = os.getenv('OLLAMA_GENERATOR_MODEL', 'qwen2.5-coder:3b')
    reviewer_model: str = os.getenv('OLLAMA_REVIEWER_MODEL', 'qwen2.5-coder:3b')
    analyst_model: str = os.getenv('OLLAMA_ANALYST_MODEL', 'qwen2.5:3b')
    embedding_model: str = os.getenv('OLLAMA_EMBEDDING_MODEL', 'embeddinggemma')
    default_oracle_lib_dir: str = os.getenv('ORACLE_CLIENT_LIB_DIR', '')
    default_owner: str = os.getenv('ORACLE_DEFAULT_OWNER', '')
    max_chunks_for_prompt: int = int(os.getenv('MAX_CHUNKS_FOR_PROMPT', '10'))
    chunk_size: int = int(os.getenv('CHUNK_SIZE', '3200'))
    chunk_overlap: int = int(os.getenv('CHUNK_OVERLAP', '80'))
    temperature: float = float(os.getenv('MODEL_TEMPERATURE', '0.1'))
    history_db_path: str = os.getenv('HISTORY_DB_PATH', 'history_versions.db')
    index_path: str = os.getenv('INDEX_PATH', 'local_index.json')
    preview_limit: int = int(os.getenv('PREVIEW_LIMIT', '50'))
    analytics_row_limit: int = int(os.getenv('ANALYTICS_ROW_LIMIT', '50000'))

    embedding_batch_size: int = int(os.getenv('EMBEDDING_BATCH_SIZE', '10'))
    embedding_timeout: int = int(os.getenv('EMBEDDING_TIMEOUT', '900'))
    embedding_keep_alive: str = os.getenv('EMBEDDING_KEEP_ALIVE', '15m')
    embedding_max_chars_per_batch: int = int(os.getenv('EMBEDDING_MAX_CHARS_PER_BATCH', '18000'))
    embedding_max_chars_per_chunk: int = int(os.getenv('EMBEDDING_MAX_CHARS_PER_CHUNK', '3200'))
    adaptive_chunk_target: int = int(os.getenv('ADAPTIVE_CHUNK_TARGET', '500'))
    adaptive_chunk_max_size: int = int(os.getenv('ADAPTIVE_CHUNK_MAX_SIZE', '4200'))
    adaptive_chunk_min_overlap: int = int(os.getenv('ADAPTIVE_CHUNK_MIN_OVERLAP', '80'))
    hybrid_parent_group_size: int = int(os.getenv('HYBRID_PARENT_GROUP_SIZE', '4'))
    hybrid_parent_max_chars: int = int(os.getenv('HYBRID_PARENT_MAX_CHARS', '7000'))
    hybrid_lexical_top_k: int = int(os.getenv('HYBRID_LEXICAL_TOP_K', '18'))
    hybrid_vector_top_k: int = int(os.getenv('HYBRID_VECTOR_TOP_K', '10'))

    view_prompt_max_chars: int = int(os.getenv('VIEW_PROMPT_MAX_CHARS', '9500'))
    view_schema_max_chars: int = int(os.getenv('VIEW_SCHEMA_MAX_CHARS', '3200'))
    view_chunk_max_chars: int = int(os.getenv('VIEW_CHUNK_MAX_CHARS', '900'))
    view_chunks_for_prompt: int = int(os.getenv('VIEW_CHUNKS_FOR_PROMPT', '2'))
    view_prompt_retry_chars_1: int = int(os.getenv('VIEW_PROMPT_RETRY_CHARS_1', '7000'))
    view_prompt_retry_chars_2: int = int(os.getenv('VIEW_PROMPT_RETRY_CHARS_2', '5200'))
    ollama_generate_timeout: int = int(os.getenv('OLLAMA_GENERATE_TIMEOUT', '900'))
    ollama_keep_alive: str = os.getenv('OLLAMA_KEEP_ALIVE', '10m')
    ollama_num_ctx_primary: int = int(os.getenv('OLLAMA_NUM_CTX_PRIMARY', '4096'))
    ollama_num_ctx_retry_1: int = int(os.getenv('OLLAMA_NUM_CTX_RETRY_1', '3072'))
    ollama_num_ctx_retry_2: int = int(os.getenv('OLLAMA_NUM_CTX_RETRY_2', '2048'))
    ollama_num_predict: int = int(os.getenv('OLLAMA_NUM_PREDICT', '900'))


CONFIG = AppConfig()
