@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
call "INICIAR_JR_AI_HALL_CONVERSATIONAL_RUNTIME_V3.bat"
endlocal
