# JR-AI Voz Global por Módulo

Esta versão transforma o JR em uma camada global de voz. Todas as abas/módulos podem receber perguntas por voz ou texto e devolver resposta em texto e voz.

## Como usar

1. Execute `install_web.bat` se ainda não instalou dependências.
2. Execute `run_web_jr_global.bat`.
3. Abra no Chrome ou Edge.
4. Permita o uso do microfone.
5. Use a barra superior `JR-AI Voz Global` em qualquer aba.

## Voz brasileira paulista

O navegador usa as vozes instaladas no Windows/Edge/Chrome. A aplicação prioriza vozes `pt-BR` e nomes brasileiros como Antonio/Antônio, Francisca, Maria, Daniel e equivalentes.

Observação: o navegador não garante sotaque paulista exato. Para controle total offline, use Piper TTS com um modelo brasileiro local e informe o caminho no perfil do JR.

## Módulos ERP entendidos por voz

Abastecimento, Frota, Manutenção, Estoque, Contas a Pagar, CRC Contas a Receber, Controller/Financeiro, Bancos/Tesouraria, Bilheteria, Arrecadação, Escala, Frequência, Contabilidade, Folha de Pagamento, Jurídico e Acidentes.

## Exemplos

- JR, analise contas a pagar vencidas, fornecedores críticos e impacto no caixa.
- JR, analise CRC de contas a receber vencidas e diga quais clientes devo priorizar.
- JR, analise bilheteria, arrecadação e divergências por garagem e linha.
- JR, analise escala e frequência dos motoristas e aponte risco de hora extra.
- JR, analise os riscos do Oracle hoje e diga o que devo priorizar.
