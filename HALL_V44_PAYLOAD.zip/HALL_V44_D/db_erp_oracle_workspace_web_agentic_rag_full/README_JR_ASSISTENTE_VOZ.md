# JR — Assistente por Voz e Texto

O JR adiciona interação por voz e texto à IA, sem APIs pagas.

## O que foi adicionado

- Nova aba: **JR Voz**
- Botão de microfone para o usuário falar com a IA
- Resposta em texto e voz
- Roteamento automático para:
  - Multiagentes
  - SQL Copilot
  - Codex
  - DBA
  - Insights Preditivos
  - OpenClaw Runtime
  - Apresentações IA
  - Fábrica de Software IA
- Histórico local em `data/jr_assistant/jr_history.jsonl`
- Endpoints:
  - `GET /api/jr/status`
  - `GET /api/jr/history`
  - `POST /api/jr/ask`
  - `POST /api/jr/stop`
- Skill OpenClaw: `jr_ask`
- Agente OpenClaw: `oc_jr_voice_assistant`

## Como a voz funciona

Esta versão usa recursos nativos do navegador:

- Entrada de voz: Web Speech API / `webkitSpeechRecognition`
- Saída de voz: `SpeechSynthesis`

Recomendado: Microsoft Edge ou Google Chrome.

## Como rodar

Primeira vez:

```bat
install_web.bat
```

Depois:

```bat
run_web_jr.bat
```

Ou:

```bat
run_web.bat
```

## Observações

- O navegador pode pedir permissão para usar o microfone.
- A voz depende do navegador e das vozes instaladas no Windows.
- Tudo continua local/open-source. Não há uso de API paga.
- Para modo offline avançado com Whisper/Piper, use o arquivo `install_jr_voice_offline_opcional.bat` como base.

## Exemplos para falar

- “JR, analise os riscos do Oracle hoje e diga o que devo priorizar.”
- “JR, gere uma SQL de consumo de diesel por veículo e garagem.”
- “JR, crie uma apresentação para cliente de transporte explicando a plataforma.”
- “JR, crie um agente OpenClaw para monitorar backup e tablespace todo dia às 8 horas.”
