# HAL V28 — Enterprise Conversational & Omnichannel Intelligence

## Languages
HAL V28 exposes 99 selectable languages. **All language names in every selector are displayed in English**. Examples: `Portuguese`, `Japanese`, `Chinese (Simplified)`, `Chinese (Traditional)`, `Spanish`, `Arabic`.

The user preference is persisted by IAM and is used for response localization and Whisper/STT language selection. TTS metadata is provided for every language, but actual speech synthesis depends on the locally installed engine/voice. HAL never reports a voice as available if the engine/model is absent.

## New V28 blocks
- Emotional Voice Engine: local text/prosody heuristic now; optional acoustic model hook.
- Telephony/SIP Gateway readiness: Asterisk/FreeSWITCH first; Twilio/Telnyx/Genesys adapters remain disabled until configured.
- Unified Conversation ID: explicit/authenticated customer identity can resume context across channels.
- Contact Center Analytics: event store and aggregate resolution, escalation, CSAT, latency, tool success and hallucination metrics.
- Enterprise Connector Hub: CRM, service desk, ERP, communication and database connector catalog.
- Corporate SSO readiness: LDAP/Active Directory, OIDC, Microsoft Entra ID, Keycloak and SAML 2.0 configuration states.

## Security
External services are OFF by default. Secrets must be supplied through environment variables. Cross-channel identity is only resolved from an explicit customer key or authenticated user; HAL does not guess identities.

## Start
Run `C:\AI_HALL\INICIAR_JR_AI_HALL_V28.bat` (V28.1 direct startup; it no longer chains V24/V25/V26/V27 launchers).

## Validate
Run `C:\AI_HALL\VALIDAR_HALL_V28.bat`.
