# JR-AI / HAL V17 — Enterprise RAG V2

Esta versão preserva a HAL V16 e adiciona uma camada RAG corporativa local/open-source.

## Implementado

- **Vector Backend Router**: Local SQLite/NumPy, ChromaDB, Qdrant e PostgreSQL + pgvector.
- **Isolamento multiempresa**: toda coleção é particionada por `tenant_id` + `collection`.
- **Controle por usuário e roles**: `visibility`, `allowed_roles` e `allowed_users` são aplicados antes da resposta.
- **Filtros por metadados**: filtros JSON na consulta, além de tags e metadata de cada documento.
- **Ingestão incremental**: SHA-256 por arquivo; arquivo inalterado não é reprocessado nem re-embedado.
- **Deduplicação**: SHA-256 de conteúdo + SimHash para duplicidade aproximada durante a ingestão.
- **Cache de embeddings**: reaproveita embeddings locais já calculados.
- **Reranking**: combina similaridade vetorial, overlap lexical e diversidade de fontes.
- **Observabilidade**: SQLite local com eventos de indexação, busca e pergunta; latência, candidatos, resultados e filtros por ACL.
- **Agent Gateway**: `rag_search` pode usar Enterprise RAG V2 com `enterprise_rag=true`.
- **Interface**: aba RAG ganhou backend, tenant, usuário, roles, coleção, ACL, filtros, incremental, reranking, status e métricas.

## Inicialização

Na raiz do pacote:

```bat
INICIAR_JR_AI_HALL_V17.bat
```

Primeira instalação/atualização das dependências Enterprise RAG:

```bat
cd db_erp_oracle_workspace_web_agentic_rag_full
INSTALAR_HALL_ENTERPRISE_RAG_V17.bat
```

O backend **Local** não depende de servidor vetorial externo. ChromaDB é local persistente. Qdrant pode funcionar embedded local ou como servidor. PGVector requer PostgreSQL com a extensão `vector`.

## Backends

### Local

Selecionar `Local SQLite/NumPy`. Os vetores ficam em:

```text
data/enterprise_rag_v2/local/vectors.sqlite3
```

É a opção de compatibilidade máxima para ambiente local e CPU.

### ChromaDB

Selecionar `ChromaDB`. Persistência:

```text
data/enterprise_rag_v2/chroma/
```

### Qdrant

Sem URL, o Qdrant Client usa armazenamento embedded local:

```text
data/enterprise_rag_v2/qdrant/
```

Para servidor Qdrant, configure na interface:

```text
http://127.0.0.1:6333
```

ou variável:

```bat
set HALL_RAG_QDRANT_URL=http://127.0.0.1:6333
```

### PostgreSQL + pgvector

Configure o DSN na interface ou por variável de ambiente:

```bat
set HALL_RAG_PGVECTOR_DSN=postgresql://hall:senha@127.0.0.1:5433/hall_rag
```

A HAL tenta executar `CREATE EXTENSION IF NOT EXISTS vector` e cria `hall_rag_vectors`. Em produção, conceda somente os privilégios necessários.

## Docker opcional

O arquivo abaixo sobe Qdrant e PostgreSQL/pgvector:

```bat
INICIAR_HALL_RAG_SERVICOS_DOCKER.bat
```

Compose:

```text
docker/docker-compose.enterprise-rag.yml
```

**Troque a senha de exemplo antes de produção.**

## Segurança multiempresa

A HAL nunca consulta vetores de outro tenant. `public` significa público **dentro do tenant**, não entre empresas.

Metadados de acesso:

- `tenant_id`: empresa/organização.
- `owner_user_id`: proprietário do documento.
- `visibility`: `tenant`, `private` ou `public`.
- `allowed_roles`: roles autorizadas.
- `allowed_users`: usuários explicitamente autorizados.

Mesmo quando o backend vetorial retorna candidatos, a HAL executa uma segunda validação de ACL antes do reranking e da síntese.

## Endpoints

```text
GET  /api/enterprise-rag/status
GET  /api/enterprise-rag/config
POST /api/enterprise-rag/config
GET  /api/enterprise-rag/collections
GET  /api/enterprise-rag/documents
POST /api/enterprise-rag/index
POST /api/enterprise-rag/ask
POST /api/enterprise-rag/delete-source
GET  /api/enterprise-rag/metrics
GET  /api/enterprise-rag/events
```

## Observabilidade

Persistência:

```text
data/enterprise_rag_v2/observability.sqlite3
```

O log não precisa armazenar a pergunta em claro: por padrão registra hash SHA-256 da pergunta, latência, backend, tenant, coleção, usuário, candidatos, resultados e quantidade filtrada por ACL.

## Ingestão incremental

Manifesto local:

```text
data/enterprise_rag_v2/manifest.sqlite3
```

Ao reenviar um documento:

- hash igual → arquivo é ignorado;
- hash diferente → somente essa fonte é removida/reindexada;
- documentos não alterados permanecem no backend.

## Configuração persistente

```text
data/enterprise_rag_v2/config.json
```

Segredos também podem vir por variáveis de ambiente para não ficarem gravados no projeto.
