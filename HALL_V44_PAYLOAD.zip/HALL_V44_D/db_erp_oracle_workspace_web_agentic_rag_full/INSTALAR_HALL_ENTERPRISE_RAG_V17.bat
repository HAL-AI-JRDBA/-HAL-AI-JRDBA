@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================================
echo HAL ENTERPRISE RAG V2 - INSTALADOR DE BACKENDS
echo ============================================================
echo.

if not exist ".venv_web\Scripts\python.exe" (
  echo [INFO] Ambiente web ainda nao existe. Executando install_web.bat...
  call "install_web.bat"
  if errorlevel 1 exit /b 1
)

call ".venv_web\Scripts\activate.bat"

echo.
echo [1/2] Instalando ChromaDB, Qdrant Client e PostgreSQL/pgvector...
python -m pip install -r "requirements_enterprise_rag.txt"
if errorlevel 1 (
  echo [ERRO] Falha ao instalar dependencias Enterprise RAG.
  pause
  exit /b 1
)

echo.
echo [2/2] Validando imports...
python -c "import chromadb, qdrant_client, psycopg, pgvector; print('[OK] Backends Python do Enterprise RAG disponiveis.')"
if errorlevel 1 (
  echo [ERRO] Um ou mais backends nao puderam ser importados.
  pause
  exit /b 1
)

echo.
echo [OK] HAL Enterprise RAG V2 instalado.
echo.
echo Qdrant pode funcionar em modo embedded local sem servidor separado.
echo PGVector exige PostgreSQL com extensao vector; ha um docker-compose de exemplo em docker\docker-compose.enterprise-rag.yml.
echo.
pause
endlocal
