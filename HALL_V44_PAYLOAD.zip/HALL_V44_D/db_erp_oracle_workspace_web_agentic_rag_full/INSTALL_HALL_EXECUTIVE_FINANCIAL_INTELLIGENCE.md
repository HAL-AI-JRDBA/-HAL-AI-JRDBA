# Instalação — HAL Executive Financial Intelligence

Execute:

```bat
INICIAR_JR_AI_HALL_EXECUTIVE_FINANCE.bat
```

ou:

```bat
INICIAR_JR_AI_HALL_CONVERSATIONAL_RUNTIME_V3.bat
```

ou:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Teste rápido

Na tela Executive Financial Intelligence, clique em:

```text
Demo Executiva
```

Depois pergunte:

```text
HAL, como está a saúde financeira da empresa?
```

ou:

```text
HAL, qual é o EBITDA e a margem EBITDA?
```

## Produção

Para produção, configure uma fonte real:

```text
ERP
Banco SQL/NoSQL
Power BI
DRE
Contabilidade
Planilha autorizada
```

O HAL não deve inventar indicadores sem uma fonte real.
