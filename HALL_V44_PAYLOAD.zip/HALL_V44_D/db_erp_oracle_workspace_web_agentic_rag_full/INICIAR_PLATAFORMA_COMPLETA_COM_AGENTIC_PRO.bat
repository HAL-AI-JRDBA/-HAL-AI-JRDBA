@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist "HALL_AUTO_MODELS_V15.bat" call "HALL_AUTO_MODELS_V15.bat"

echo ============================================================
echo JR-AI COMPLETA + HAL AGENTIC PRO
echo ============================================================
echo.
echo Abrindo em janelas separadas:
echo - JR-AI antiga/completa: http://127.0.0.1:8000
echo - HAL Agentic Pro:    http://127.0.0.1:8030
echo.
echo Se algum ambiente virtual nao existir, execute:
echo INSTALAR_TUDO_JR_AI_HALL_COMPLETO.bat
echo.

start "JR-AI Completa" cmd /k "cd /d %~dp0 && call INICIAR_JR_AI_HALL.bat"
timeout /t 3 /nobreak >nul
start "HAL Agentic Pro" cmd /k "cd /d %~dp0 && call INICIAR_HALL_AGENTIC_PRO.bat"

echo.
echo [OK] Comandos enviados para janelas separadas.
pause
endlocal
