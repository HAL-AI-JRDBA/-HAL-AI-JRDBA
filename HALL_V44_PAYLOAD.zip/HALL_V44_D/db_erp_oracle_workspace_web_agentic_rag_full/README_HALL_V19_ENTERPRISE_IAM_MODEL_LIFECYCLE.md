JR-AI / HAL V19 - ENTERPRISE IAM & MODEL LIFECYCLE
=====================================================

PASTA PADRAO
C:\AI_HALL

INICIALIZADOR
C:\AI_HALL\INICIAR_JR_AI_HALL_V19.bat

PRIMEIRO ACESSO
1. Inicie o HAL V19.
2. O sistema exibira a tela Criar administrador inicial.
3. Cadastre o primeiro administrador. Nao existe usuario ou senha padrao.
4. Depois, use Administracao para criar usuarios e definir modulos/permissoes.

CONTROLE DE ACESSO
- Login corporativo com sessao HttpOnly.
- PBKDF2-HMAC-SHA256 para senhas.
- Bloqueio temporario apos tentativas invalidas.
- Troca obrigatoria de senha opcional.
- RBAC por modulo da plataforma e por modulo ERP.
- Permissoes: view, chat, query, execute, export, approve, configure, admin.
- Frontend filtra o que o usuario enxerga.
- Backend aplica o mesmo controle e retorna 403 em acesso indevido.
- Endpoints novos nao catalogados seguem DEFAULT DENY para nao-admins.
- O ultimo administrador ativo nao pode ser removido/desativado.

PERFIS RAPIDOS INCLUIDOS
- Arrecadacao
- Contabilidade
- RH + Folha + Frequencia
- Financeiro / Controller
- Frota + Manutencao + Abastecimento
- Operacao + Escala + Trafego
- Bilheteria
- Estoque + Compras
- Escrita Fiscal
- Juridico
- Fretamento + Turismo
- Administrativo
- TI / DBA
- BI / Gestao

MODEL LIFECYCLE / HUGGING FACE
- Scanner automatico, por padrao a cada 24 horas.
- Busca candidatos GGUF no Hugging Face.
- Nenhum candidato e instalado automaticamente.
- Administrador aprova ou rejeita no Console HAL.
- A instalacao usa Ollama + referencia hf.co/repositorio:quantizacao.
- Smoke test antes de alterar o Router.
- Snapshot do Router antes da troca.
- Modelo anterior fica registrado para rollback.
- A troca exige reinicio controlado do HAL.
- O validador de boot le dinamicamente os modelos aprovados no Router.

VALIDACAO
Execute opcionalmente:
C:\AI_HALL\VALIDAR_HALL_V19.bat

IMPORTANTE
O scanner do Hugging Face precisa de acesso a Internet. A operacao normal dos modelos continua local via Ollama.
Para repositorios privados, configure HALL_HF_TOKEN quando aplicavel.
