@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist "INICIAR_JR_AI_HALL_VOICE_STT_V5.bat" (
  call "INICIAR_JR_AI_HALL_VOICE_STT_V5.bat"
) else (
  call "INICIAR_JR_AI_CONSOLE_UNIFICADO.bat"
)
endlocal
