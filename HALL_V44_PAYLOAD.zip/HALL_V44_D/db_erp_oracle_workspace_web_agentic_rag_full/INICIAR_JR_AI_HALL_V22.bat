@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo [HAL] Esta versao foi atualizada para V23.
call "INICIAR_JR_AI_HALL_V23.bat"
