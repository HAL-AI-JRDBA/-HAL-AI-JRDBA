@echo off
cd /d "%~dp0\.."
if exist "INICIAR_JR_AI_HALL_V19_2.bat" (call "INICIAR_JR_AI_HALL_V19_2.bat") else (echo [ERRO] Launcher V19.2 nao encontrado na raiz.)
