@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================================
echo JR-AI / HAL V18.2 - UTF8 ROBUST ^& SAFETY ALIGNMENT
echo ============================================================
echo.

rem Funciona tanto na raiz C:\AI_HALL quanto dentro da pasta do projeto.
if exist "web_app\backend\main.py" (
    set "HALL_PROJECT=%CD%"
) else if exist "db_erp_oracle_workspace_web_agentic_rag_full\web_app\backend\main.py" (
    set "HALL_PROJECT=%CD%\db_erp_oracle_workspace_web_agentic_rag_full"
) else (
    echo [ERRO] Nao encontrei o projeto JR-AI/HAL.
    echo.
    echo Estrutura esperada:
    echo C:\AI_HALL\INICIAR_JR_AI_HALL_V18_2.bat
    echo C:\AI_HALL\db_erp_oracle_workspace_web_agentic_rag_full\
    echo.
    pause
    exit /b 1
)

cd /d "%HALL_PROJECT%"

if not exist ".venv_web\Scripts\python.exe" (
    echo.
    echo [ERRO] Ambiente virtual .venv_web nao encontrado.
    echo Execute primeiro:
    echo     install_web.bat
    echo.
    pause
    exit /b 1
)

call ".venv_web\Scripts\activate.bat"

rem V18.2: corrige automaticamente qualquer UTF-8 BOM residual antes do backend.
if exist "scripts\corrigir_utf8_bom_v18_2.py" (
    python "scripts\corrigir_utf8_bom_v18_2.py" --root "%HALL_PROJECT%" --quiet
    if errorlevel 1 (
        echo [AVISO] Nao foi possivel concluir a verificacao UTF-8 BOM.
    )
)

if not defined HALL_MODELS_VALIDATED_THIS_BOOT (
    set "HALL_MODELS_VALIDATED_THIS_BOOT=1"
    if exist "HALL_VALIDAR_MODELOS_V15_UMA_VEZ.bat" (
        call "HALL_VALIDAR_MODELOS_V15_UMA_VEZ.bat"
    )
)

if "%HALL_OLLAMA_MODEL%"=="" set "HALL_OLLAMA_MODEL=qwen2.5:7b"
if "%OLLAMA_URL%"=="" set "OLLAMA_URL=http://127.0.0.1:11434"

set "OLLAMA_MODEL=%HALL_OLLAMA_MODEL%"
set "HALL_DIALOG_MODEL=%HALL_OLLAMA_MODEL%"
set "HALL_WEB_SUMMARY_MODEL=%HALL_OLLAMA_MODEL%"
set "HALL_SKIP_MODEL_CHECK=1"
set "HALL_DISABLE_AUTO_MODELS=1"
set "HALL_BOOT_MODE=SAFETY_ALIGNMENT_V18_2"

set "HALL_DIALOG_TIMEOUT=120"
set "HALL_SQL_TIMEOUT=120"
set "HALL_FAST_CODE_TIMEOUT=120"
set "HALL_CODE_TIMEOUT=180"
set "HALL_DEEP_CODE_TIMEOUT=240"
set "HALL_VISION_TIMEOUT=180"
set "HALL_CHAT_KEEP_ALIVE=15m"
set "HALL_SPECIALIST_KEEP_ALIVE=2m"

if exist "check_web_deps.py" (
    echo [AUTO] Verificando dependencias Python...
    python "check_web_deps.py"
    if errorlevel 1 (
        echo.
        echo [ERRO] Dependencias obrigatorias incompletas.
        echo Execute:
        echo     install_web.bat
        echo.
        pause
        exit /b 1
    )
)

echo.
echo [UTF8] Leitura JSON tolerante a BOM: ATIVA
echo [RAG] Enterprise RAG V2: ATIVO
echo [RAG] Backends: Local / ChromaDB / Qdrant / PGVector
echo [SAFE] HAL Safety Supervisor V18: ATIVO
echo [SAFE] Constitution + Permission Firewall + Audit Chain
echo [SAFE] Circuit Breaker + Resource Governor + Quarantine + Kill Switch
echo.
echo [START] http://127.0.0.1:8000
echo.

start "" "http://127.0.0.1:8000"
python -m uvicorn web_app.backend.main:app --host 127.0.0.1 --port 8000

echo.
echo [INFO] HAL V18.2 encerrado.
pause
endlocal
