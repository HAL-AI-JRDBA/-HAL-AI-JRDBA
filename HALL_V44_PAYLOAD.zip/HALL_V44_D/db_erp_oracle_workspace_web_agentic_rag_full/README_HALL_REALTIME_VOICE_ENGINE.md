# HAL Real-Time Voice Engine

Esta camada adiciona ao projeto uma experiência de voz mais próxima de assistentes modernos como GPT-Live/Alexa: conversa em tempo real, escuta contínua, pausa natural, barge-in, transcrição parcial/final, voz mais lenta e audível, avatar com estados e roteamento automático para a ferramenta correta.

## O que foi adicionado

```text
Nova aba: Real-Time Voice Engine
Escuta contínua no navegador
Microfone com permissão do usuário
Transcrição parcial
Transcrição final
Detecção de silêncio final
Política para não responder enquanto o usuário fala
Barge-in: o usuário fala e o HAL para de responder
TTS mais lento e audível
Avatar com estados: pronto, ouvindo, pensando, falando, interrompido e erro
Envio automático da transcrição final para o HAL
Roteamento automático para SQL, RAG, Business Teams, SaaS Builder, Agent Runtime, Power BI, Zabbix/Grafana etc.
Sessões de voz persistidas localmente
Plano de instalação local para CPU/GPU
Preparação para faster-whisper, whisper.cpp, Piper, Coqui XTTS, F5-TTS e OpenVoice
Preparação para voz própria autorizada
```

## Como usar

1. Inicie a plataforma.
2. Acesse http://127.0.0.1:8000
3. Abra a aba/área Real-Time Voice Engine.
4. Clique em “Iniciar Voz em Tempo Real”.
5. Permita o uso do microfone.
6. Fale naturalmente com o HAL.
7. O HAL aguarda a pausa final antes de responder.
8. Se você voltar a falar enquanto ele responde, ele para a fala.
9. A transcrição final é enviada para o Console Unificado.
10. O HAL escolhe a ferramenta certa automaticamente.

## Exemplos de fala

```text
HAL, bom dia.

HAL, atue como meu assistente pessoal e organize minhas prioridades.

HAL, trabalhe como funcionário financeiro e analise contas a receber vencidas.

HAL, crie uma tarefa longa com sandbox, testes e scorecard.

HAL, crie um app white-label de vendas para varejo com MongoDB.

HAL, verifique alertas críticos do Zabbix e Grafana.

HAL, consulte documentos internos sobre política de atendimento.
```

## Modo rápido usando navegador

A versão pronta usa:

```text
SpeechRecognition / webkitSpeechRecognition
speechSynthesis
localhost ou HTTPS
Chrome ou Edge recomendado
```

Isso permite demonstração rápida sem instalar motor pesado.

## Modo produção local recomendado

Para qualidade realmente comercial:

```text
STT:
- faster-whisper local
- whisper.cpp local

TTS:
- Piper pt-BR para CPU
- Coqui XTTS para voz natural
- F5-TTS para voz natural/customizada
- OpenVoice para timbre/autorização

Voz própria:
- exige amostra autorizada do usuário
- mínimo 3 minutos
- recomendado 5 a 10 minutos
- armazenar localmente
```

## Observação honesta

Esta implementação entrega a aba, endpoints, configurações, política de turn-taking, frontend funcional com Web Speech API, barge-in no navegador, persistência de sessão, adaptação de TTS e integração com o roteamento do HAL.

Para ficar com qualidade de voz final no nível GPT-Live/Alexa, será necessário instalar e configurar modelos locais de STT/TTS neural no ambiente do cliente.


## HAL Open AI Access Center

Adicionada camada para democratizar IA local: escolha CPU/GPU, catálogo de modelos open-source/open-weight, plano Ollama, marketplace de funcionários digitais, modo empresa pequena/profissional/enterprise local, acesso externo seguro, ROI, backup, atualização e rollback.


## HAL OpenClaw Enterprise Layers

Adicionadas 6 camadas: Channel Gateway, n8n Workflow Center, Browser Automation, Cron Enterprise, Sandbox Enterprise e Agent Framework Bridge. Essas camadas conectam o HAL a canais externos, workflows n8n, navegador controlado, agendamentos, sandbox Docker e frameworks como CrewAI, LangGraph, AutoGen, MCP e OpenClaw.


## HAL Visual Mission Control

Adicionado painel visual futurístico estilo escritório digital de agentes, com salas por área, avatares, missões, aprovações, notas do dia, produtividade, modo operação e modo apresentação para clientes.


## HAL Universal ERP & Application Connector

Adicionada camada universal para conectar ERP, bancos relacionais/NoSQL, APIs, arquivos, n8n, browser/RPA e sistemas individuais, incluindo venda de passagens, bilhetagem e vale-transporte, com consulta somente leitura por padrão e aprovação humana para ações sensíveis.
