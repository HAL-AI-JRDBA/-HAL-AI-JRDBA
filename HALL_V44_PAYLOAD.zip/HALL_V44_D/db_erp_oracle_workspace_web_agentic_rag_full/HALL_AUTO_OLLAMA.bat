@echo off
chcp 65001 >nul

echo.
echo ============================================================
echo HAL - AUTO OLLAMA / MODELO DE CONVERSA NATURAL
echo ============================================================
echo.

if "%HALL_OLLAMA_MODEL%"=="" set "HALL_OLLAMA_MODEL=qwen2.5:7b"
if "%OLLAMA_URL%"=="" set "OLLAMA_URL=http://127.0.0.1:11434"

set "OLLAMA_MODEL=%HALL_OLLAMA_MODEL%"
set "HALL_DIALOG_MODEL=%HALL_OLLAMA_MODEL%"
set "HALL_WEB_SUMMARY_MODEL=%HALL_OLLAMA_MODEL%"

echo Modelo padrao: %HALL_OLLAMA_MODEL%
echo Ollama URL:    %OLLAMA_URL%
echo.

where ollama >nul 2>nul
if errorlevel 1 (
    echo [AVISO] Ollama nao encontrado no PATH.
    echo [AUTO] Tentando instalar automaticamente via winget...
    where winget >nul 2>nul
    if errorlevel 1 (
        echo [AVISO] winget nao encontrado. Nao foi possivel instalar automaticamente.
        echo [INFO] Instale o Ollama manualmente depois, se quiser respostas mais naturais.
        echo [INFO] O HAL vai continuar em modo fallback sem travar.
        goto end_ok
    )

    winget install --id Ollama.Ollama -e --silent --accept-package-agreements --accept-source-agreements
    echo.
    echo [INFO] Revalidando Ollama apos tentativa de instalacao...
)

where ollama >nul 2>nul
if errorlevel 1 (
    echo [AVISO] Ollama ainda nao esta disponivel no PATH.
    echo [INFO] O HAL vai abrir normalmente em modo fallback.
    goto end_ok
)

echo [OK] Ollama encontrado.
echo [AUTO] Verificando se o servico Ollama esta respondendo...

powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-RestMethod -Uri '%OLLAMA_URL%/api/tags' -TimeoutSec 2 | Out-Null; exit 0 } catch { exit 1 }" >nul 2>nul
if errorlevel 1 (
    echo [AUTO] Iniciando Ollama em segundo plano...
    start "" /min ollama serve
    timeout /t 4 /nobreak >nul
)

set "OLLAMA_READY=0"
for /L %%i in (1,1,15) do (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-RestMethod -Uri '%OLLAMA_URL%/api/tags' -TimeoutSec 2 | Out-Null; exit 0 } catch { exit 1 }" >nul 2>nul
    if not errorlevel 1 (
        set "OLLAMA_READY=1"
        goto ollama_ready
    )
    timeout /t 2 /nobreak >nul
)

:ollama_ready
if "%OLLAMA_READY%"=="0" (
    echo [AVISO] Ollama nao respondeu a tempo.
    echo [INFO] O HAL vai abrir em modo fallback e tentara usar Ollama quando estiver disponivel.
    goto end_ok
)

echo [OK] Ollama respondendo.

echo [AUTO] Verificando modelo %HALL_OLLAMA_MODEL%...
ollama list | findstr /I /C:"%HALL_OLLAMA_MODEL%" >nul 2>nul
if errorlevel 1 (
    echo.
    echo [AUTO] Modelo nao encontrado. Baixando automaticamente: %HALL_OLLAMA_MODEL%
    echo [INFO] Esse download pode demorar e consumir alguns GB, dependendo do modelo.
    echo.
    ollama pull "%HALL_OLLAMA_MODEL%"
    if errorlevel 1 (
        echo [AVISO] Falha ao baixar o modelo. O HAL vai continuar em fallback.
        goto end_ok
    )
) else (
    echo [OK] Modelo ja instalado.
)

echo [AUTO] Testando resposta rapida do modelo...
ollama run "%HALL_OLLAMA_MODEL%" "Responda apenas: HAL OK" >nul 2>nul
if errorlevel 1 (
    echo [AVISO] Teste do modelo falhou, mas o HAL continuara abrindo.
) else (
    echo [OK] Modelo pronto para conversa natural.
)

:end_ok
set "HALL_OLLAMA_AUTO_DONE=1"
echo.
echo [OK] Auto Ollama finalizado. Continuando inicializacao do HAL...
echo.
exit /b 0
