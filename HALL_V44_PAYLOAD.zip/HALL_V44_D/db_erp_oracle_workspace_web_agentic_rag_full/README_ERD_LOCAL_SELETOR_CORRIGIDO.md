# ERD / ChartDB - Seletor gráfico corrigido

Esta versão deixa o ERD Local explícito na aba **ERD / ChartDB**.

## Fluxo recomendado

1. Rode `run_web.bat`.
2. Acesse `http://127.0.0.1:8010`.
3. Entre em **Mapa ERP / Metadados**.
4. Informe o owner/schema e clique em **Analisar schema**.
5. Entre em **ERD / ChartDB**.
6. Clique em **Atualizar lista**.
7. Marque as tabelas graficamente.
8. Clique em **Gerar ERD Local com selecionadas**.

## Observação sobre cache

Foi alterado o versionamento dos arquivos estáticos para evitar que o navegador use `app.js` antigo em cache.
Se ainda assim não aparecer o botão, pressione `Ctrl+F5` no navegador.

## ChartDB externo

O ERD Local funciona sem ChartDB. O ChartDB externo continua opcional.
Para usar o ChartDB externo, rode `run_chartdb_local.bat` e depois use **Gerar DBML** para importar no ChartDB.
