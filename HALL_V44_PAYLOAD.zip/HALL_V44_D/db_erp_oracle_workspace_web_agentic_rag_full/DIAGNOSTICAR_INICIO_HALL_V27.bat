@echo off
chcp 65001 >nul
setlocal EnableExtensions
set "SCRIPT_DIR=%~dp0"
set "HALL_HOME="
if exist "%SCRIPT_DIR%INICIAR_JR_AI_HALL_V26_2.bat" set "HALL_HOME=%SCRIPT_DIR%"
if not defined HALL_HOME if exist "%SCRIPT_DIR%..\INICIAR_JR_AI_HALL_V26_2.bat" set "HALL_HOME=%SCRIPT_DIR%..\"
if not defined HALL_HOME if exist "C:\AI_HALL\INICIAR_JR_AI_HALL_V26_2.bat" set "HALL_HOME=C:\AI_HALL\"
if not defined HALL_HOME if exist "C:\AI_HALL\AI_HALL\INICIAR_JR_AI_HALL_V26_2.bat" set "HALL_HOME=C:\AI_HALL\AI_HALL\"

set "LOG=%SCRIPT_DIR%HALL_V27_STARTUP_DIAGNOSTICO.txt"
>"%LOG%" echo HAL V27 STARTUP DIAGNOSTIC
>>"%LOG%" echo DATE=%DATE% TIME=%TIME%
>>"%LOG%" echo SCRIPT_DIR=%SCRIPT_DIR%
>>"%LOG%" echo HALL_HOME=%HALL_HOME%

if not defined HALL_HOME (
  echo [ERRO] Raiz HAL nao localizada.
  >>"%LOG%" echo ROOT_CHECK=FAIL
  goto :finish
)

set "HALL_PROJECT=%HALL_HOME%db_erp_oracle_workspace_web_agentic_rag_full"
set "WEBPY=%HALL_PROJECT%\.venv_web\Scripts\python.exe"

echo ============================================================
echo HAL V27 - DIAGNOSTICO DE INICIALIZACAO
echo ============================================================
echo [ROOT] %HALL_HOME%
echo [APP ] %HALL_PROJECT%
echo.

if exist "%HALL_PROJECT%\web_app\backend\main.py" (
  echo [OK] main.py encontrado.
  >>"%LOG%" echo MAIN_PY=OK
) else (
  echo [ERRO] main.py nao encontrado.
  >>"%LOG%" echo MAIN_PY=FAIL
)

if exist "%WEBPY%" (
  echo [OK] .venv_web encontrado.
  >>"%LOG%" echo VENV_WEB=OK
  "%WEBPY%" --version >>"%LOG%" 2>&1
  "%WEBPY%" -c "import uvicorn; print('UVICORN=OK')" >>"%LOG%" 2>&1
  "%WEBPY%" -m py_compile "%HALL_PROJECT%\web_app\backend\main.py" >>"%LOG%" 2>&1
  if errorlevel 1 (
    echo [ERRO] Falha ao compilar/importar dependencias basicas.
    >>"%LOG%" echo PY_COMPILE=FAIL
  ) else (
    echo [OK] main.py passou no py_compile.
    >>"%LOG%" echo PY_COMPILE=OK
  )
) else (
  echo [ERRO] .venv_web nao encontrado.
  >>"%LOG%" echo VENV_WEB=FAIL
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "$c=Get-NetTCPConnection -LocalPort 8000 -State Listen -ErrorAction SilentlyContinue;if($c){Write-Output 'PORT_8000=IN_USE';exit 5}else{Write-Output 'PORT_8000=FREE';exit 0}" >>"%LOG%" 2>&1
if errorlevel 5 (
  echo [AVISO] Porta 8000 ja esta em uso. Veja o log.
) else (
  echo [OK] Porta 8000 livre.
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "try{$r=Invoke-WebRequest -UseBasicParsing http://127.0.0.1:11434/api/tags -TimeoutSec 2;Write-Output 'OLLAMA=ONLINE'}catch{Write-Output 'OLLAMA=OFFLINE_OR_NOT_INSTALLED'}" >>"%LOG%" 2>&1

:finish
echo.
echo Log gerado em:
echo   %LOG%
echo.
type "%LOG%"
echo.
pause
endlocal
