@echo off
chcp 65001 >nul
setlocal
if "%HALL_OLLAMA_MODEL%"=="" set "HALL_OLLAMA_MODEL=qwen2.5:7b"
if "%OLLAMA_URL%"=="" set "OLLAMA_URL=http://127.0.0.1:11434"

echo ============================================================
echo HAL - STATUS OLLAMA
echo ============================================================
echo Modelo: %HALL_OLLAMA_MODEL%
echo URL:    %OLLAMA_URL%
echo.

where ollama >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Ollama nao encontrado no PATH.
  pause
  exit /b 1
)

echo [OK] Ollama encontrado:
where ollama
echo.

echo [INFO] Modelos instalados:
ollama list
echo.

echo [INFO] Testando API local...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Invoke-RestMethod -Uri '%OLLAMA_URL%/api/tags' -TimeoutSec 3 | ConvertTo-Json -Depth 3; exit 0 } catch { Write-Host $_.Exception.Message; exit 1 }"
echo.
pause
endlocal
