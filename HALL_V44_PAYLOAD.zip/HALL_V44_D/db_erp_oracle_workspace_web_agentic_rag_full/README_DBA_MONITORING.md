# Módulo DBA — Monitoramento Oracle remoto

Esta versão amplia o módulo **DBA** sem remover as funcionalidades existentes. A aplicação Web pode ficar em um **Servidor Web separado** do Servidor de Banco Oracle; as coletas são feitas por conexão Oracle Net usando `HOST`, `PORT` e `SERVICE_NAME`.

## O que foi adicionado

Na aba **DBA** e na API `/api/dba/collect`, foram adicionadas coletas read-only para:

- Health Snapshot executivo com severidade;
- status do banco/instância;
- sessões e resumo de conexões por usuário/máquina/programa;
- limites de `sessions`, `processes` e `transactions`;
- SQL ativo agora;
- Top SQL por tempo, CPU e I/O;
- operações longas (`GV$SESSION_LONGOPS`);
- wait events ativos;
- locks, sessões bloqueadoras e objetos bloqueados;
- tablespaces com percentual usado considerando autoextend;
- uso de TEMP;
- FRA;
- geração de archivelog por hora;
- backups RMAN e resumo do último backup com sucesso;
- tabela opcional `MON_BACKUP_EXECUCAO` para Data Pump/scripts externos;
- Data Pump jobs;
- Scheduler jobs rodando e jobs com erro;
- alert log via `V$DIAG_ALERT_EXT`;
- objetos inválidos;
- índices `UNUSABLE`;
- backlog de demandas priorizadas para o time de banco;
- notas de arquitetura para Servidor Web remoto.

## Arquitetura recomendada

```text
Usuário no navegador
    ↓
Servidor Web da aplicação IA
    ↓ Oracle Net / TCP 1521
Servidor Oracle Database
```

A aplicação não precisa estar instalada no servidor do banco. Porém, o Servidor Web precisa conseguir resolver e acessar o `HOST:PORT/SERVICE_NAME` do Oracle.

## Segurança recomendada

Não use `SYS`, `SYSTEM` ou usuário dono da aplicação no monitoramento Web. Crie um usuário dedicado, por exemplo `MONITOR_IA`, com `CREATE SESSION` e grants de SELECT apenas nas views necessárias.

Use o script:

```text
scripts/create_monitor_user_oracle.sql
```

Ajuste a senha e valide as permissões conforme a política do cliente.

## Data Pump e logs de arquivo

Como a aplicação roda no Servidor Web, ela não consegue ler diretamente arquivos `.log` ou `.dmp` existentes no Servidor de Banco, a menos que exista compartilhamento de rede ou rotina autorizada.

Para monitorar Data Pump com segurança, prefira gravar o resultado dos scripts em uma tabela de controle, por exemplo:

```text
MONITOR_IA.MON_BACKUP_EXECUCAO
```

A coleta `backup_control` lê essa tabela. No campo **Filtro / tabela controle**, você pode informar outro nome de tabela, como `MONITOR_IA.MON_BACKUP_EXECUCAO`.

## Observação sobre AWR/ASH

As coletas adicionadas evitam depender de AWR/ASH. Caso você adicione relatórios históricos usando `DBA_HIST_*` ou ASH, valide antes o licenciamento do Oracle Diagnostic Pack.

## Compatibilidade

As opções antigas continuam aceitas:

- `sessions`
- `locks`
- `top_sql`
- `tablespaces`
- `invalid_objects`
- `parametros`
- `datapump_jobs`

A API também aceita as novas opções, por exemplo:

```json
{"option":"health_snapshot","search_term":""}
{"option":"active_sql","search_term":""}
{"option":"rman_backups","search_term":""}
{"option":"backup_control","search_term":"MONITOR_IA.MON_BACKUP_EXECUCAO"}
```
