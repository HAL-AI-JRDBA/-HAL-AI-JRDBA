# OpenClaw Local Runtime Governado

Esta camada transforma o projeto em um runtime de agentes autônomos locais, inspirado no conceito OpenClaw, sem depender de APIs pagas.

## O que foi adicionado

- Criação de agentes personalizados pela interface.
- Skills plugáveis e governadas.
- Agenda por agente: diária, semanal, intervalo, uma vez.
- Gatilhos por evento, como tablespace alto, locks, backup e outros sinais coletáveis.
- Fila de tarefas persistente.
- Worker cooperativo para rodar ciclos.
- Conectores locais: log local, webhook opcional, outbox SMTP/Telegram.
- Memória persistente via `memory_record`.
- Aprovação humana para skills críticas.
- Auditoria em JSONL.

## Arquivos principais

```text
services/openclaw_runtime/
  agent_registry.py
  agent_builder.py
  skill_manager.py
  permission_manager.py
  scheduler.py
  event_watcher.py
  connector_hub.py
  notification_center.py
  task_queue.py
  background_worker.py
  runtime.py
scripts/run_openclaw_worker.py
```

## Endpoints

```text
GET  /api/openclaw-runtime/status
GET  /api/openclaw-runtime/agents
POST /api/openclaw-runtime/agents
POST /api/openclaw-runtime/agents/{agent_id}
DELETE /api/openclaw-runtime/agents/{agent_id}
POST /api/openclaw-runtime/agents/{agent_id}/run
GET  /api/openclaw-runtime/skills
GET  /api/openclaw-runtime/tasks
POST /api/openclaw-runtime/tasks
POST /api/openclaw-runtime/tasks/{task_id}/run
POST /api/openclaw-runtime/tasks/{task_id}/decision
POST /api/openclaw-runtime/cycle
GET  /api/openclaw-runtime/connectors
POST /api/openclaw-runtime/connectors
GET  /api/openclaw-runtime/notifications
POST /api/openclaw-runtime/notify
GET  /api/openclaw-runtime/audit
```

## Rodar worker manualmente

```bat
python scripts\run_openclaw_worker.py --once
```

Ou em loop:

```bat
python scripts\run_openclaw_worker.py --interval 300
```

## Segurança

Por padrão, continua bloqueado:

```text
DROP, ALTER, TRUNCATE, INSERT, UPDATE, DELETE, MERGE, DBMS_, UTL_, shell, BAT, PowerShell, EXE.
```

A execução de `SELECT` e a proposta de mudanças no código podem exigir aprovação humana conforme permissões do agente.
