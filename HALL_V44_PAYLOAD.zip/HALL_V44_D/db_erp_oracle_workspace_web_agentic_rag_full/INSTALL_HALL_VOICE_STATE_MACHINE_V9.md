# Instalação — HAL Voice State Machine V9

Execute:

```bat
INICIAR_JR_AI_HALL_VOICE_STATE_V9.bat
```

ou:

```bat
INICIAR_JR_AI_HALL_REPAIR_V8.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Teste de voz

1. Clique em `Conversar`.
2. Fale a pergunta.
3. Quando terminar, clique em `Responder agora` ou aguarde até 9 segundos.
4. O HAL deve passar para `Transcrevendo pergunta completa...`.
5. Depois deve responder.

## Se não transcrever

Execute:

```bat
HALL_AUTO_STT.bat
```

ou verifique:

```text
http://127.0.0.1:8000/api/unified/stt/status
```
