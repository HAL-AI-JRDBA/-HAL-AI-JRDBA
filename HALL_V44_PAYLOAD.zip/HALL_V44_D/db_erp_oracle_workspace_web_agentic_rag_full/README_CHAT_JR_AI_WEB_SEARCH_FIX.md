# JR-AI Chat estilo GPT — correções e Pesquisa Web

Correções incluídas nesta versão:

- O menu do botão `+` fecha automaticamente ao escolher uma opção.
- O menu do botão `+` fecha ao clicar fora dele.
- O menu fecha com a tecla `Esc`.
- Nova opção `🌐 Pesquisar na Web` dentro do botão `+`.
- Novo destino `Pesquisar na Web` no seletor do Chat JR-AI e no JR Voz.
- Novo endpoint backend: `POST /api/chat/web-search`.
- O alvo `web` também funciona via `/api/chat/ask` e `/api/jr/ask`.

## Como pesquisar na Web

No Chat JR-AI:

1. Clique no botão `+`.
2. Escolha `Pesquisar na Web`.
3. Digite o tema ou complete o texto.
4. Clique na seta `↑`.

Exemplos:

```text
Pesquise na web tendências recentes de IA para empresas de transporte.
```

```text
Pesquise na web novidades sobre monitoramento Oracle com IA e resuma oportunidades práticas.
```

## Observação

A pesquisa Web usa DuckDuckGo HTML sem API paga. O servidor onde a aplicação roda precisa ter acesso à Internet.
