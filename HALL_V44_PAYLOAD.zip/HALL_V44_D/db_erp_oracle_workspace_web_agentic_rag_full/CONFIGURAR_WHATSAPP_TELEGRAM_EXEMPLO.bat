@echo off
chcp 65001 >nul
echo Configure as variaveis abaixo com seus tokens reais.
echo.
echo setx WHATSAPP_TOKEN "SEU_TOKEN_WHATSAPP"
echo setx WHATSAPP_PHONE_NUMBER_ID "SEU_PHONE_NUMBER_ID"
echo setx TELEGRAM_BOT_TOKEN "SEU_TOKEN_TELEGRAM"
echo.
echo Depois feche e abra o terminal novamente.
pause
