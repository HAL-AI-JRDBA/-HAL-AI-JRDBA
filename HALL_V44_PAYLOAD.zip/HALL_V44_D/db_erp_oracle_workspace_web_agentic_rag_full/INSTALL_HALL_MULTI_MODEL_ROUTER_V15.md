# Instalação — HAL Multi-Model Router V15

Execute:

```bat
INICIAR_JR_AI_HALL_MULTI_MODEL_ROUTER_V15.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Configurar variáveis

Execute uma vez:

```bat
CONFIGURAR_MODELOS_HALL_V15.bat
```

Feche e abra o terminal novamente.

## Verificar modelos

Execute:

```bat
HALL_AUTO_MODELS_V15.bat
```

ou acesse:

```text
http://127.0.0.1:8000/api/unified/multi-model/status
```

## Baixar modelos, se algum faltar

```bat
runtime_scripts\pull_modelos_v15_especializados.bat
```

## Teste no chat

```text
Crie um software em Python com interface web para controle de finanças pessoais.
```

Deve usar modelo de código.

```text
Crie um SELECT para listar clientes ativos por mês.
```

Deve usar modelo SQL.

```text
Indexe esse documento no RAG.
```

Deve usar modelo de embedding.

```text
Analise esse print/tela.
```

Deve usar modelo de visão quando houver imagem.
