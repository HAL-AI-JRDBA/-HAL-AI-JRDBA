# RAG no DB ERP Local Studio V3.3 GenAI Web

Esta versão implementa as 4 fases pedidas:

## Fase 1 — Traditional + lexical
- Chunking semântico
- Embeddings em blocos-pai
- Busca lexical FTS5 em todos os chunks
- Busca vetorial sobre blocos-pai

## Fase 2 — Vectorless / estrutural
- Profiling automático de documentos
- Extração de nós estruturais (documento/página/seção)
- Busca FTS5 dedicada em seções
- Expansão de evidências por hierarquia pai/filho

## Fase 3 — Roteador automático
- Modo `auto`
- Seleção entre `traditional`, `vectorless` e `hybrid`
- Decisão baseada no tipo da pergunta e no perfil do corpus

## Fase 4 — Re-rank + answer guard
- Fusão por RRF
- Re-rank heurístico por overlap lexical e contexto estrutural
- Guard de evidência para reduzir alucinação
- Resposta aterrada por evidências

## Endpoints impactados
- `POST /api/context/index`
- `GET /api/context/docs`
- `POST /api/context/ask`

## UI
Na aba **RAG Persistente**, use:
- `Automático`
- `Traditional RAG`
- `Vectorless RAG`
- `Hybrid RAG`

E ajuste `Top K` conforme o volume de evidências desejado.
