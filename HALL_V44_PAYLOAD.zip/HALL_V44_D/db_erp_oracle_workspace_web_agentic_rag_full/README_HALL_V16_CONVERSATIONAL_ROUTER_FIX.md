# JR-AI / HAL V16 - Conversational Router Fix

## Correções principais

- O `qwen2.5:7b` (CHAT/DIALOG) passa a produzir a **resposta final** para o usuário.
- SQLCoder, Qwen Coder, DeepSeek Coder e Vision são especialistas internos; seus resultados entram como contexto para o HAL.
- Timeout de diálogo passa de 18s para 120s por padrão.
- Timeouts por papel: SQL 120s, Fast Code 120s, Code 180s, Deep Code 240s, Vision 180s.
- CHAT usa `keep_alive=15m`, evitando descarregar o Qwen logo após a validação.
- Especialistas usam `keep_alive=2m` por padrão.
- O boot valida os modelos uma única vez e mantém CHAT aquecido.
- Erros do Ollama deixam de ser silenciosos: são gravados em `data/human_conversation_gateway/audit.jsonl`.
- A resposta da API unificada passa a incluir `model_runtime` com modelo final, especialista sugerido, tempo e erro quando houver.
- Menções genéricas a Oracle/PostgreSQL/MySQL não mandam automaticamente a resposta final para SQLCoder; SQLCoder é selecionado quando existe tarefa SQL explícita.

## Arquitetura

`Usuário -> Classificador -> Ferramenta/Especialista -> HAL qwen2.5:7b -> Resposta final`

## Inicialização

Execute `INICIAR_JR_AI_HALL_V16.bat` na raiz.
