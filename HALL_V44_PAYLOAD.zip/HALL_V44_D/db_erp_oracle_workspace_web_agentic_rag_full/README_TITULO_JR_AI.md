# Ajuste de título para JR-AI

O título principal exibido na interface web está configurado como:

```text
JR-AI — Plataforma Gen-AI Open Source para ERP, Oracle, Agentes e Automação
```

A marca principal continua **JR-AI** e o posicionamento comercial/tecnológico passa a ser:

```text
Plataforma Gen-AI Open Source para ERP, Oracle, Agentes e Automação
```
