@echo off
call "%~dp0..\VALIDAR_HALL_V32.bat"
