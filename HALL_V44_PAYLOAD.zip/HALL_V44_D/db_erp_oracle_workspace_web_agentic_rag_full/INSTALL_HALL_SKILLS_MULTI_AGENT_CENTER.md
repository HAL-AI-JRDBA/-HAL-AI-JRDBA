# Instalação — HAL Skills & Multi-Agent Center

Execute:

```bat
INICIAR_JR_AI_HALL_SKILLS_MULTI_AGENT.bat
```

ou:

```bat
INICIAR_JR_AI_HALL_EXECUTIVE_FINANCE.bat
```

ou:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Teste rápido

Na tela `Skills & Multi-Agent Center`, clique em:

```text
Demo
```

Depois teste:

```text
HAL, crie uma colaboração multiagente para analisar uma empresa usando financeiro, dados e operações.
```

Ou:

```text
HAL, gere uma imagem futurista do painel HAL com agentes colaborando.
```

## Endpoint local de imagem opcional

A camada prepara prompts e briefing mesmo sem endpoint.

Para geração real, configure no arquivo ou endpoint do projeto:

```text
image_endpoint=http://127.0.0.1:7860
```

ou outro gerador local compatível.

## Segurança

```text
Ações sensíveis exigem aprovação.
Código real exige sandbox.
Banco de dados deve ser somente leitura por padrão.
Envio externo exige aprovação/política.
```
