# Correção: SQL Copilot para Controller / Saúde Financeira-Contábil

Esta versão corrige uma falha de roteamento que fazia perguntas de Controller/Saúde da empresa caírem como intenção genérica no módulo de Contabilidade.

## Problema corrigido

Perguntas como:

> Atue como Controller Sênior... Analise a saúde da empresa... indicadores financeiros, contábeis...

podiam gerar SQL usando tabelas fiscais auxiliares, como `CTBLANCA_APURPISCOFINS`, e aplicar filtro de data em coluna de código, como `CODIGOEMPRESA BETWEEN TO_DATE(...)`.

## Alterações implementadas

- Nova intenção `controller_saude_contabil` em `services/query_intents.py`.
- Priorização do núcleo contábil `CTBSALDO` + `CTBCONTA` para análise de saldos/contas.
- Extração automática de período em datas brasileiras, convertendo `01/01/2025 a 30/05/2025` para `PERIODOSALDO BETWEEN '202501' AND '202505'` quando `PERIODOSALDO` é texto.
- Penalização de tabelas auxiliares/fiscais no ranking canônico: `APURPISCOFINS`, `PISCOFINS`, `ECF`, `SPED`, `LALUR`, `ASSOC`, `REFERENCIAL`, etc.
- Novo `services/sql_semantic_guard.py`, bloqueando SQL semanticamente incorreta, mesmo quando as colunas existem.
- O validador agora bloqueia filtros como `CODIGOEMPRESA BETWEEN TO_DATE(...)`.
- O prompt NL2SQL foi reforçado para Controller/Contabilidade.

## Resultado esperado

Para análise Controller/Contabilidade, a SQL passa a usar uma base de balancete/saldos, por exemplo:

```sql
FROM OWNER.CTBSALDO sa
JOIN OWNER.CTBCONTA co
  ON sa.CODCONTACTB = co.CODCONTACTB
 AND sa.NROPLANO = co.NROPLANO
WHERE sa.PERIODOSALDO BETWEEN '202501' AND '202505'
```

A SQL incorreta com `CTBLANCA_APURPISCOFINS` e filtro de data em `CODIGOEMPRESA` passa a ser bloqueada pelo semantic guard.
