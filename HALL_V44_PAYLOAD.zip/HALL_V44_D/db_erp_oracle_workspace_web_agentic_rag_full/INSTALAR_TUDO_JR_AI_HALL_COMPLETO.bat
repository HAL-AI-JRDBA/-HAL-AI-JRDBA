@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo INSTALAR JR-AI COMPLETA + HAL AGENTIC PRO
echo ============================================================
echo.

echo [1/2] Instalando plataforma JR-AI original...
call "install_web.bat"

echo.
echo [2/2] Instalando HAL Transporte Agentic Pro...
call "INSTALAR_HALL_AGENTIC_PRO.bat"

echo.
echo [3/3] Preparando Ollama/modelo de conversa natural automaticamente...
if exist "HALL_AUTO_OLLAMA.bat" call "HALL_AUTO_OLLAMA.bat"

echo.
echo [OK] Instalacao geral concluida.
echo Para abrir a plataforma antiga: INICIAR_JR_AI_HALL.bat
echo Para abrir o Agentic Pro: INICIAR_HALL_AGENTIC_PRO.bat
pause
endlocal
