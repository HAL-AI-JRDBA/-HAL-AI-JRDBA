# Instalação — HAL Enterprise Integration & Team Intelligence

Execute normalmente:

```bat
INICIAR_JR_AI_HALL_ENTERPRISE_TEAMS.bat
```

ou:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Acesse:

```text
http://127.0.0.1:8000
```

## Variáveis de ambiente sugeridas

Power BI:

```text
HALL_POWERBI_TENANT_ID
HALL_POWERBI_CLIENT_ID
HALL_POWERBI_CLIENT_SECRET
HALL_POWERBI_WORKSPACE_ID
```

Zabbix:

```text
HALL_ZABBIX_URL
HALL_ZABBIX_API_TOKEN
```

Grafana:

```text
HALL_GRAFANA_URL
HALL_GRAFANA_API_TOKEN
```

CRM:

```text
HALL_CRM_BASE_URL
HALL_CRM_API_TOKEN
```

Teams:

```text
HALL_TEAMS_TENANT_ID
HALL_TEAMS_CLIENT_ID
HALL_TEAMS_CLIENT_SECRET
```

WhatsApp / Telegram:

```text
HALL_WHATSAPP_TOKEN
HALL_TELEGRAM_BOT_TOKEN
```

Agenda:

```text
HALL_CALENDAR_TOKEN
```

Banco/ERP:

```text
ERP_TRANSPORTE_HOST
ERP_TRANSPORTE_DATABASE
ERP_TRANSPORTE_USER
ERP_TRANSPORTE_PASSWORD
```

## Observação

A camada cria estrutura, endpoints, telas, times, agendas e roteamento. Para produção real, cada ferramenta precisa receber suas credenciais e permissões no cliente.
