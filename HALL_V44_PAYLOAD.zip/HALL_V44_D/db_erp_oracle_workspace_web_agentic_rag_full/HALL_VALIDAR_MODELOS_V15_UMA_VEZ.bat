@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion

echo.
echo ============================================================
echo HAL MULTI-MODEL ROUTER V19 - VALIDACAO DINAMICA E SEGURA
echo ============================================================
echo.

if "%OLLAMA_URL%"=="" set "OLLAMA_URL=http://127.0.0.1:11434"

rem HAL V19: carrega os modelos ativos do Model Lifecycle / Router config.
if exist "scripts\hall_model_env_v19.py" (
    for /f "usebackq delims=" %%L in (`python "scripts\hall_model_env_v19.py"`) do %%L
)

if "%HALL_MODEL_CHAT%"=="" set "HALL_MODEL_CHAT=qwen2.5:7b"
if "%HALL_MODEL_DIALOG%"=="" set "HALL_MODEL_DIALOG=%HALL_MODEL_CHAT%"
if "%HALL_MODEL_CODE%"=="" set "HALL_MODEL_CODE=qwen2.5-coder:14b"
if "%HALL_MODEL_FAST_CODE%"=="" set "HALL_MODEL_FAST_CODE=qwen2.5-coder:7b"
if "%HALL_MODEL_DEEP_CODE%"=="" set "HALL_MODEL_DEEP_CODE=deepseek-coder-v2:16b"
if "%HALL_MODEL_SQL%"=="" set "HALL_MODEL_SQL=sqlcoder:7b-q4_0"
if "%HALL_MODEL_EMBED%"=="" set "HALL_MODEL_EMBED=embeddinggemma:latest"
if "%HALL_MODEL_VISION%"=="" set "HALL_MODEL_VISION=llava:latest"
if "%HALL_MODEL_FAST%"=="" set "HALL_MODEL_FAST=phi3:mini"

echo Ollama URL: %OLLAMA_URL%
echo.
echo Modelos esperados:
echo [CHAT]      %HALL_MODEL_CHAT%
echo [DIALOG]    %HALL_MODEL_DIALOG%
echo [CODE]      %HALL_MODEL_CODE%
echo [FAST CODE] %HALL_MODEL_FAST_CODE%
echo [DEEP CODE] %HALL_MODEL_DEEP_CODE%
echo [SQL]       %HALL_MODEL_SQL%
echo [EMBED]     %HALL_MODEL_EMBED%
echo [VISION]    %HALL_MODEL_VISION%
echo [FAST]      %HALL_MODEL_FAST%
echo.

where ollama >nul 2>nul
if errorlevel 1 (
    echo [ERRO] Ollama nao encontrado no PATH.
    exit /b 1
)

echo [AUTO] Verificando servico Ollama...
ollama list >nul 2>nul
if errorlevel 1 (
    echo [AUTO] Tentando iniciar Ollama...
    start "" /min ollama serve
    timeout /t 4 /nobreak >nul
)

ollama list >nul 2>nul
if errorlevel 1 (
    echo [ERRO] Ollama nao respondeu.
    exit /b 2
)

echo [OK] Ollama respondendo.
echo.

set /a HALL_MISSING=0
call :checkModel "CHAT" "%HALL_MODEL_CHAT%"
call :checkModel "DIALOG" "%HALL_MODEL_DIALOG%"
call :checkModel "CODE" "%HALL_MODEL_CODE%"
call :checkModel "FAST CODE" "%HALL_MODEL_FAST_CODE%"
call :checkModel "DEEP CODE" "%HALL_MODEL_DEEP_CODE%"
call :checkModel "SQL" "%HALL_MODEL_SQL%"
call :checkModel "EMBED" "%HALL_MODEL_EMBED%"
call :checkModel "VISION" "%HALL_MODEL_VISION%"
call :checkModel "FAST" "%HALL_MODEL_FAST%"

echo.
if !HALL_MISSING! GTR 0 (
    echo [AVISO] !HALL_MISSING! modelo^(s^) esperado^(s^) nao esta^(ao^) instalado^(s^).
    echo [AVISO] O HAL ainda pode iniciar e usar os modelos disponiveis.
) else (
    echo [OK] Todos os modelos esperados estao instalados.
)

echo.
echo [AUTO] Testes rapidos controlados...
echo [INFO] Para evitar travamento, o boot testa CHAT e EMBED.
echo [INFO] CODE/SQL/VISION sao validados por instalacao e testados sob demanda.
echo.

call :quickGenerate "CHAT" "%HALL_MODEL_CHAT%" "Responda somente OK."
call :quickEmbed "%HALL_MODEL_EMBED%"

echo.
echo [OK] Validacao Multi-Model V19 concluida UMA VEZ. CHAT mantido aquecido por 15 minutos.
echo ============================================================
echo.
exit /b 0


:checkModel
set "LABEL=%~1"
set "MODEL=%~2"
ollama list | findstr /I /C:"%MODEL%" >nul
if errorlevel 1 (
    echo [FALTANDO] %LABEL%: %MODEL%
    set /a HALL_MISSING+=1
) else (
    echo [OK] %LABEL%: %MODEL%
)
exit /b 0


:quickGenerate
set "LABEL=%~1"
set "MODEL=%~2"
set "PROMPT=%~3"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "$body=@{model='%MODEL%';prompt='%PROMPT%';stream=$false;keep_alive='15m';options=@{num_predict=3}}|ConvertTo-Json -Depth 5;" ^
  "try {$null=Invoke-RestMethod -Uri '%OLLAMA_URL%/api/generate' -Method Post -ContentType 'application/json' -Body $body -TimeoutSec 45; exit 0} catch {exit 1}" >nul 2>nul

if errorlevel 1 (
    echo [AVISO] Teste %LABEL% nao concluiu em ate 45s: %MODEL%
) else (
    echo [OK] Teste %LABEL%: %MODEL%
)
exit /b 0


:quickEmbed
set "MODEL=%~1"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='Stop';" ^
  "$body=@{model='%MODEL%';input='teste embedding';keep_alive=0}|ConvertTo-Json;" ^
  "try {$r=Invoke-RestMethod -Uri '%OLLAMA_URL%/api/embed' -Method Post -ContentType 'application/json' -Body $body -TimeoutSec 30; if($r.embeddings -or $r.embedding){exit 0}else{exit 2}} catch {exit 1}" >nul 2>nul

if errorlevel 1 (
    echo [AVISO] Teste EMBED nao concluiu: %MODEL%
) else (
    echo [OK] Teste EMBED: %MODEL%
)
exit /b 0
