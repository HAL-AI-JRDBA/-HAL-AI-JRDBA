# Instalação — HAL App Factory Pro V12

Execute:

```bat
INICIAR_JR_AI_HALL_APP_FACTORY_PRO_V12.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Teste principal

Digite:

```text
Quero um software em Python com interface web para controle de finanças pessoais com login, filtros, cálculos, estado vazio, cobrança falhou, teto de custo de IA, GitHub e deploy.
```

O HAL deve direcionar para `app_factory` e responder com arquitetura de sistema completo.

## Gerar app completo pela API

```text
POST /api/unified/app-factory/generate
```

JSON:

```json
{
  "message": "Quero um software em Python com interface web para controle de finanças pessoais com login, filtros, cálculos, estado vazio, cobrança falhou, teto de custo de IA, GitHub e deploy",
  "app_name": "Minha Finanças Pro",
  "template_id": "personal_finance",
  "include_sample_data": true
}
```

O app será gerado em:

```text
hall_transporte_agentic_pro/data/app_factory_pro/generated_apps
```

Para rodar o app gerado, entre na pasta dele e execute:

```bat
INICIAR_APP.bat
```
