@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo Instalando dependencias opcionais das camadas OpenClaw Enterprise...
python -m pip install --upgrade pip
python -m pip install playwright selenium requests
python -m playwright install chromium
echo.
echo Opcional para frameworks:
echo python -m pip install crewai langgraph
echo.
pause
endlocal
