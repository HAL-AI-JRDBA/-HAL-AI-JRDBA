@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo INSTALAR HAL TRANSPORTE AGENTIC PRO
echo ============================================================
echo.

if not exist "hall_transporte_agentic_pro\install_web.bat" (
  echo [ERRO] Pasta hall_transporte_agentic_pro nao encontrada.
  pause
  exit /b 1
)

cd /d "hall_transporte_agentic_pro"
call "install_web.bat"

endlocal
