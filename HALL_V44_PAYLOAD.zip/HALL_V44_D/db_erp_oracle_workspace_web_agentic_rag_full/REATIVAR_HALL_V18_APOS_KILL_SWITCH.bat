@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ============================================================
echo HAL V18 - REATIVAR APOS KILL SWITCH
echo ============================================================
echo.
echo Esta acao exige confirmacao humana de administrador.
set /p CONF=Digite APROVAR para reativar: 
if /I not "%CONF%"=="APROVAR" (
  echo Operacao cancelada.
  pause
  exit /b 1
)
if exist ".venv_web\Scripts\python.exe" (
  ".venv_web\Scripts\python.exe" scripts\hall_safety_cli.py resume --actor local_admin --role admin --approved
) else (
  python scripts\hall_safety_cli.py resume --actor local_admin --role admin --approved
)
pause
endlocal
