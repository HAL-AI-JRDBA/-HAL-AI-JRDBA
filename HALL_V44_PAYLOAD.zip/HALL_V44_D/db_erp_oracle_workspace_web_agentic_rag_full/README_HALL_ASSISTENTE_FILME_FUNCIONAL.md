# HAL — Assistente estilo filme funcional

Esta versão adiciona uma camada funcional inspirada em assistentes futuristas, sem depender de nuvem obrigatória.

## O que foi adicionado

### 1. HAL Vision

Permite ao usuário autorizar:

```text
Captura de tela
Câmera
Upload de imagem
Análise visual
```

Privacidade: o HAL **não captura nada sozinho**. Ele só vê tela/câmera quando o usuário clica para permitir.

Sem modelo multimodal, ele salva e analisa metadados.  
Com Ollama Vision configurado, ele descreve a imagem/tela usando modelo local.

### 2. Memória persistente

O HAL pode memorizar localmente frases como:

```text
HAL, lembre que eu prefiro respostas objetivas para clientes de transporte.
```

As memórias ficam em:

```text
data/hall_memory/memories.json
```

### 3. Automações por voz

O HAL agora planeja automações seguras:

```text
Abrir/preencher aba correta
Salvar memória
Criar nota local
Pedir captura de tela
Planejar fluxo de automação
```

Ações sensíveis exigem aprovação humana.

### 4. Interface futurista

Nova aba:

```text
HAL Filme
```

Com visual neon, esfera animada, equalizer, área de câmera/tela, memória e automações.

### 5. Integração com roteador

O roteador agora entende pedidos como:

```text
HAL, veja minha tela.
HAL, olhe pela câmera.
HAL, memorize que eu gosto de respostas claras.
HAL, automatize essa rotina.
```

## Para visão real com IA local

Instale um modelo multimodal no Ollama, por exemplo:

```bat
ollama pull llava
```

Depois, na aba **HAL Filme**:

```text
Marcar: Usar Ollama Vision local
Modelo: llava:latest
```

Também pode usar outro modelo multimodal local compatível com Ollama.

## Limitações honestas

- A câmera/tela depende de permissão do navegador.
- A visão detalhada depende de modelo multimodal local instalado.
- Automações perigosas não são executadas sem aprovação.
- Para voz natural máxima, configure STT/TTS local na aba Voz Natural.
