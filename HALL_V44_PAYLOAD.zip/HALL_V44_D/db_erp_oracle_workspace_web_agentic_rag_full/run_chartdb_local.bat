
@echo off
setlocal
set CHARTDB_DIR=%USERPROFILE%\chartdb
if not exist "%CHARTDB_DIR%\package.json" (
  echo ChartDB nao encontrado em %CHARTDB_DIR%.
  echo Rode primeiro install_chartdb_local.bat
  pause
  exit /b 1
)
cd /d "%CHARTDB_DIR%"
call npm run dev -- --host 127.0.0.1 --port 5173
endlocal
