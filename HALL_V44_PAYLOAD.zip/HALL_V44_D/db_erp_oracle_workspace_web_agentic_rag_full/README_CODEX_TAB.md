# Aba Codex Oracle Chat

Esta versão adiciona uma aba **Codex** na interface Web Zero, sem Streamlit.

Funcionalidades principais:

- Chat leve para perguntas em português.
- Busca de tabelas no schema/ground truth.
- Geração de SQL com Ollama local.
- Validação segura via Agent Gateway.
- Bloqueio de DML/DDL/PLSQL.
- Execução apenas de SELECT com limite de linhas e confirmação humana.
- EXPLAIN PLAN real no Oracle via `DBMS_XPLAN.DISPLAY()`.
- Tuning/sugestão de índices.
- Envio da SQL para a aba SQL Copilot.
- Fixar SQL no Workspace.

## Como rodar

```bat
run_web.bat
```

Depois acesse:

```text
http://127.0.0.1:8010
```

Na aba **Conexão**, configure Oracle e modelos Ollama.
Na aba **Codex**, faça perguntas em português e use os botões do painel lateral.
