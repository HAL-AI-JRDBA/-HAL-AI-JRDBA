# Engenharia LLM na IA Multiagentes Open-source

Esta versão adiciona uma camada completa de **LLM Engineering local** à IA multiagentes Oracle/ERP, sem API paga, sem SaaS obrigatório e sem execução destrutiva automática.

## Conceitos implementados

1. **Context Engineering** — `services/context_engine.py`  
   Monta o contexto ideal para cada pergunta: intenção, módulo, schema Oracle, RAG, memória, cache e guardrails.

2. **Tool Calling / Tool Registry** — `services/tool_registry.py`  
   Catálogo local das ferramentas permitidas. Os agentes só podem chamar ferramentas registradas.

3. **MCP Gateway Local** — `services/mcp_gateway.py`  
   Manifesto MCP simplificado, in-process, para expor ferramentas e recursos locais de forma padronizada.

4. **A2A Bus Local** — `services/a2a_bus.py`  
   Barramento auditável em JSONL para troca de mensagens entre agentes.

5. **Semantic Cache** — `services/semantic_cache.py`  
   Cache semântico em SQLite para reaproveitar respostas e SQLs semelhantes sem embeddings pagos.

6. **Contextual Compression** — `services/contextual_compressor.py`  
   Reduz documentos, evidências e schema antes do LLM, preservando partes relevantes.

7. **Reranking** — `services/reranker.py`  
   Reordena evidências com bônus para tabelas, colunas, views aprovadas e módulo correto.

8. **Hybrid Retrieval** — `services/hybrid_retriever.py`  
   Combina busca textual/BM25-like com sinais Oracle/ERP para não perder nomes como `CTBSALDO`, `EST_ITENSMOVTO`, `CPR_ITENSDEPEDIDO`.

9. **Agent Memory** — `services/memory_manager.py`  
   Memória local por camadas: episódica, semântica, preferência e curto prazo.

10. **Inference Gateway / Routing** — `services/inference_gateway.py`  
   Escolhe modelos locais Ollama por tipo de tarefa: SQL, DBA, revisão, RAG, resumo ou chat.

## Facade principal

```text
services/llm_engineering_suite.py
```

Esse arquivo une todos os módulos e é usado pelo backend e pelo `MultiAgentCoordinator`.

## Endpoints novos

```text
GET  /api/llm-engineering/status
GET  /api/llm-engineering/tools
GET  /api/llm-engineering/mcp/manifest
GET  /api/llm-engineering/mcp/resources
GET  /api/llm-engineering/a2a/recent
GET  /api/llm-engineering/cache/stats
GET  /api/llm-engineering/memory/status
GET  /api/llm-engineering/memory/search?q=...
POST /api/llm-engineering/memory/record
POST /api/llm-engineering/context
```

## Interface

Foi adicionada a aba:

```text
Engenharia LLM
```

Nela você pode:

- montar contexto completo antes de gerar SQL;
- consultar Tool Registry;
- visualizar MCP Manifest local;
- ver mensagens A2A recentes;
- consultar cache semântico;
- verificar memória dos agentes.

A aba **Multiagentes** também ganhou opções para ligar/desligar:

```text
Context Engineering
Hybrid Retrieval
Reranking
Contextual Compression
Semantic Cache
Agent Memory
Inference Gateway
A2A Bus
MCP Local
```

## Workflow novo

```text
Engenharia LLM completa
```

Esse workflow executa os agentes e módulos ligados aos 10 conceitos.

## Segurança

Continuam bloqueados automaticamente:

```text
DROP
ALTER
TRUNCATE
CREATE
INSERT
UPDATE
DELETE
MERGE
EXEC
BEGIN/PLSQL
DBMS_
UTL_
Shell/BAT/PowerShell/EXE
Alteração automática de código de produção
```

O sistema é **local/open-source** e foi desenhado para usar Ollama/modelos locais.

## Arquivos persistentes

```text
data/tools/tool_registry.json
data/semantic_cache/semantic_cache.sqlite
data/memory/multi_agent_memory.sqlite
data/a2a/a2a_messages.jsonl
data/mcp/local_mcp_manifest.json
data/multi_agent/multi_agent_audit.jsonl
```

## Como rodar

```bat
run_agentic_web.bat
```

ou:

```bat
run_web.bat
```

Depois abra:

```text
Engenharia LLM
```

ou use o workflow:

```text
Multiagentes > Engenharia LLM completa
```
