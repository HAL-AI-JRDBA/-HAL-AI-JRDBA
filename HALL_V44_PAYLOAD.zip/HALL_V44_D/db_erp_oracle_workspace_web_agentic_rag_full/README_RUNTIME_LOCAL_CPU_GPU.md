# Runtime Local / CPU-GPU — JR-AI

Esta versão adiciona uma nova aba **Runtime Local** para garantir que a JR-AI rode sempre localmente, com opções explícitas para CPU, GPU ou Auto.

## Objetivo

Permitir que a JR-AI rode:

- No notebook sem GPU, usando **CPU**
- Em clientes com GPU NVIDIA, usando **GPU**
- Em modo **Auto**
- Sempre local, sem OpenAI, sem Anthropic e sem depender de nuvem

## Recursos adicionados

- Nova aba **Runtime Local / CPU-GPU**
- Configuração de:
  - runtime_mode: auto / cpu / gpu
  - context_length
  - Ollama Base URL
  - modelo de chat
  - modelo SQL/código
  - modelo embedding
  - SearXNG local
- Status do Ollama:
  - `/api/version`
  - `/api/tags`
  - `ollama ps`
  - `ollama list`
- Status de GPU:
  - `nvidia-smi`, quando disponível
  - fallback para controlador de vídeo no Windows
- Healthcheck completo
- Geração de scripts:
  - `run_ollama_cpu.bat`
  - `run_ollama_gpu.bat`
  - `run_ollama_auto.bat`
  - `pull_modelos_recomendados.bat`
  - `verificar_runtime_ollama.bat`
  - `install_windows_task_startup_jr_ai.bat`
  - `install_windows_service_nssm_example.bat`
  - `jr-ai.service.example`
- Docker:
  - `docker/Dockerfile.jr-ai`
  - `docker/docker-compose.cpu.yml`
  - `docker/docker-compose.gpu.yml`
- Integração com:
  - Chat JR-AI
  - JR Voz
  - OpenClaw Runtime

## Como usar em notebook sem GPU

Abra a aba **Runtime Local**:

```text
Modo de execução: CPU somente
Context length: 4096 ou 8192
```

Clique em:

```text
Salvar configuração
Gerar scripts CPU/GPU/Docker
```

Depois use:

```bat
runtime_scripts\run_ollama_cpu.bat
```

## Como usar em cliente com GPU NVIDIA

No cliente com driver NVIDIA instalado:

```text
Modo de execução: GPU se disponível
Context length: 64000
```

Use:

```bat
runtime_scripts\run_ollama_gpu.bat
```

Valide com:

```bat
runtime_scripts\verificar_runtime_ollama.bat
```

ou pela aba **Runtime Local**, botão **Status Ollama**.

## Docker CPU

```bat
cd docker
docker compose -f docker-compose.cpu.yml up -d
```

## Docker GPU

Requer NVIDIA Container Toolkit.

```bat
cd docker
docker compose -f docker-compose.gpu.yml up -d
```

## Busca Web local

Para manter a JR-AI 100% local, use SearXNG local:

```text
http://127.0.0.1:8081/search
```

A aba Runtime Local permite configurar e testar esse endpoint.

## Endpoints adicionados

```text
GET  /api/local-runtime/status
GET  /api/local-runtime/config
POST /api/local-runtime/config
GET  /api/local-runtime/ollama-status
GET  /api/local-runtime/gpu-status
GET  /api/local-runtime/healthcheck
POST /api/local-runtime/generate-scripts
POST /api/local-runtime/searxng-test
GET  /api/local-runtime/audit
```

## Observação

A JR-AI continua local/open-source. O uso de Power BI, Zabbix ou Grafana depende do ambiente do cliente, mas a IA em si não depende de APIs da OpenAI ou Anthropic.
