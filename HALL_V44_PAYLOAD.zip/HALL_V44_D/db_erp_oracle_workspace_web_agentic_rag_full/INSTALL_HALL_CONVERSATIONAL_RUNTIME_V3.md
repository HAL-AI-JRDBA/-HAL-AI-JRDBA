# Instalação — HAL Conversational Runtime V3

Execute:

```bat
INICIAR_JR_AI_HALL_CONVERSATIONAL_RUNTIME_V3.bat
```

ou:

```bat
INICIAR_JR_AI_HALL_AUTO_OLLAMA.bat
```

ou:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Teste recomendado

Digite na tela principal, sem escolher aba:

```text
ação prática
```

Depois responda:

```text
eu quero que você transforme isso numa ação prática pode ser
```

O HAL não deve repetir a mesma frase. Ele deve continuar o diálogo e pedir o tema/objetivo da ação.

## Importante

O painel técnico não abre sozinho por padrão. A conversa fica no centro.
