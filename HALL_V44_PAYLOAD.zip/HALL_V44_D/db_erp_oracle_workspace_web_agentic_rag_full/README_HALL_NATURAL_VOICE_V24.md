# HAL V24 — Natural Voice Engine

A V24 mantém o Voice Presence V23 e adiciona uma camada de fala mais natural.

## Motores
- **XTTS v2**: opcional, local, mantém o modelo carregado em `127.0.0.1:8024`; pode usar voz cadastrada somente com consentimento explícito.
- **Piper**: alternativa neural local e leve; exige um modelo `.onnx` configurado para o idioma.
- **Browser Enhanced**: fallback imediato, com segmentação por sentença, pausas e prosódia por usuário.

## Resposta falada x tela
A tela preserva a resposta completa. A fala pode ser `Curta`, `Natural` ou `Completa`. Em respostas extensas/código, a HAL fala o essencial e avisa que os detalhes estão na tela.

## Instalação neural XTTS
Execute `C:\AI_HALL\INSTALAR_HALL_NATURAL_VOICE_V24.bat`. O instalador procura Python 3.10/3.11 e cria um ambiente separado `.venv_voice24`, evitando incompatibilidades com o Python 3.13 do backend.

Depois use `INICIAR_HALL_V24_COM_VOZ_NEURAL.bat` ou inicie o motor e a HAL separadamente.

> O modelo XTTS não é empacotado neste ZIP. Na primeira utilização ele pode precisar ser obtido pelo próprio pacote TTS e pode estar sujeito aos termos/licença do modelo. Verifique a licença antes de uso comercial.

## Voz própria
A V24 reutiliza os perfis já existentes em `Voz Própria`. Voz clonada só é usada quando o perfil contém consentimento confirmado.

## Associação segura da voz clonada
Por segurança, um usuário não pode escolher arbitrariamente o perfil de voz de outra pessoa. O administrador associa um perfil consentido ao usuário com `C:\AI_HALL\ATRIBUIR_PERFIL_VOZ_HALL_V24.bat`. Depois disso o próprio usuário pode ativar/desativar o uso da voz clonada nas preferências.
