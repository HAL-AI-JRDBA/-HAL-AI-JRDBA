# JR-AI / HAL V20 — Enterprise Web Access

A V20 mantém o backend FastAPI em `127.0.0.1:8000` e acrescenta uma camada de borda corporativa para publicar a HAL com uma URL amigável sem expor diretamente o Uvicorn.

## Modos

- **LOCAL** — acesso apenas no servidor.
- **INTRANET** — acesso em LAN/VPN, com DNS interno e TLS interno/custom opcional.
- **INTERNET** — acesso público via domínio HTTPS, mantendo o backend em loopback.

## Arquitetura

`Usuário -> HTTPS / Caddy -> 127.0.0.1:8000 -> IAM/RBAC -> HAL`

## Controles da aplicação

A camada `services/enterprise_web_access.py` aplica controles mesmo se houver erro de configuração no proxy:

- allowlist de Host;
- confiança de `X-Forwarded-For` somente quando o peer direto pertence à lista de proxies confiáveis;
- whitelist CIDR opcional;
- rate limiting em memória, com limite próprio para autenticação;
- validação de Origin em métodos mutáveis;
- cookies Secure quando HTTPS estiver habilitado;
- Security Headers e HSTS configurável;
- logs de acesso JSONL com request-id.

## Caddy

O Caddyfile é gerado em `C:\AI_HALL\gateway_v20\Caddyfile`.

- INTERNET + `tls automatic`: Caddy administra HTTPS automaticamente quando DNS e conectividade pública estão corretos.
- INTRANET + `tls internal`: Caddy usa CA interna; distribua a raiz aos clientes.
- `tls custom`: informe certificado e chave corporativos.

## Administração

Entre como administrador e abra **Administração > Acesso Web / HTTPS** para configurar URL, TLS, redes, proxies e limites. Alterações de borda pedem reinício controlado.

## Model Lifecycle

O scanner do Hugging Face permanece ativo por padrão a cada 24h. A tela mostra último scan, próximo scan, estado do scanner e propostas pendentes. Atualizações continuam exigindo aprovação explícita do administrador, smoke test e rollback disponível.
