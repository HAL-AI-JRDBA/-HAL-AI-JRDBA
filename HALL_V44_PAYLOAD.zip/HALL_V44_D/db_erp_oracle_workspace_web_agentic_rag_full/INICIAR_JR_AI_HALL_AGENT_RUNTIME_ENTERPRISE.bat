@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
call "INICIAR_JR_AI_CONSOLE_UNIFICADO.bat"
endlocal
