
function mmAgenticOut(obj){ const el=qs('multiModelOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj,null,2); }
async function mmAgenticGet(path){ mmAgenticOut(await fetchJson('/api/multi-model/'+path)); }


function cyberAgenticOut(obj){ const el=qs('cyberDefenseOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj,null,2); }
async function cyberAgenticGet(path){ cyberAgenticOut(await fetchJson('/api/cyber-defense/'+path)); }


function v13AgenticOut(obj){ const el=qs('enterpriseV13OutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj,null,2); }
async function v13AgenticGet(path){ v13AgenticOut(await fetchJson('/api/enterprise-v13/'+path)); }


function appFactorySetOutput(obj){const el=qs('appFactoryOutput'); if(el) el.textContent=typeof obj==='string'?obj:JSON.stringify(obj,null,2);}
async function appFactoryStatus(){appFactorySetOutput(await fetchJson('/api/app-factory/status'));}
async function appFactoryCatalog(){appFactorySetOutput(await fetchJson('/api/app-factory/catalog'));}
async function appFactoryBlueprint(){const msg=(qs('appFactoryPrompt')?.value||qs('prompt')?.value||'Crie um sistema completo com login, filtros, cálculos, cobrança e custo de IA.').trim(); const data=await fetchJson('/api/app-factory/blueprint',{method:'POST',body:JSON.stringify({message:msg,app_name:qs('appFactoryName')?.value||''})}); appFactorySetOutput(data); if(data.answer) addMsg('assistant',data.answer);}
async function appFactoryGenerate(){const msg=(qs('appFactoryPrompt')?.value||qs('prompt')?.value||'Crie um sistema completo com login, filtros, cálculos, cobrança e custo de IA.').trim(); const data=await fetchJson('/api/app-factory/generate',{method:'POST',body:JSON.stringify({message:msg,app_name:qs('appFactoryName')?.value||'HAL App Pro',template_id:qs('appFactoryTemplate')?.value||'',include_sample_data:true})}); appFactorySetOutput(data); if(data.ok) addMsg('assistant','Gerei o app completo e rodei o Quality Gate. Caminho local: '+data.path+' | Preview: '+data.url);}


function skillsCenterAgenticSetOutput(obj){ const el = qs('skillsCenterOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function skillsCenterAgenticStatus(){ skillsCenterAgenticSetOutput(await fetchJson('/api/skills-center/status')); }
async function skillsCenterAgenticSkills(){ skillsCenterAgenticSetOutput(await fetchJson('/api/skills-center/skills')); }
async function skillsCenterAgenticAgents(){ skillsCenterAgenticSetOutput(await fetchJson('/api/skills-center/agents')); }
async function skillsCenterAgenticSeed(){ const data = await fetchJson('/api/skills-center/seed-demo', {method:'POST', body:JSON.stringify({})}); skillsCenterAgenticSetOutput(data); if(data.summary) addMsg('assistant', data.summary); }
async function skillsCenterAgenticAsk(){ const message = (qs('skillsCenterObjectiveAgentic')?.value || qs('prompt')?.value || 'HAL Skills Center').trim(); const data = await fetchJson('/api/skills-center/ask', {method:'POST', body:JSON.stringify({message, approved: qs('approved')?.checked || false})}); skillsCenterAgenticSetOutput(data); if(data.answer || data.summary) addMsg('assistant', data.answer || data.summary); }


function executiveFinanceAgenticSetOutput(obj){ const el = qs('executiveFinanceOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function executiveFinanceAgenticStatus(){ executiveFinanceAgenticSetOutput(await fetchJson('/api/executive-finance/status')); }
async function executiveFinanceAgenticCatalog(){ executiveFinanceAgenticSetOutput(await fetchJson('/api/executive-finance/catalog')); }
async function executiveFinanceAgenticSeed(){
  const data = await fetchJson('/api/executive-finance/seed-demo', {method:'POST', body:JSON.stringify({})});
  executiveFinanceAgenticSetOutput(data);
  if(data.summary?.answer) addMsg('assistant', data.summary.answer);
}
async function executiveFinanceAgenticAsk(){
  const message = (qs('executiveFinanceQuestionAgentic')?.value || qs('prompt')?.value || 'HAL, mostre os indicadores fundamentalistas da empresa.').trim();
  const data = await fetchJson('/api/executive-finance/ask', {method:'POST', body:JSON.stringify({message, approved: qs('approved')?.checked || false})});
  executiveFinanceAgenticSetOutput(data);
  if(data.answer) addMsg('assistant', data.answer);
}


function omnichannelAgenticSetOutput(obj){ const el = qs('omnichannelOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function omnichannelAgenticStatus(){ omnichannelAgenticSetOutput(await fetchJson('/api/omnichannel/status')); }
async function omnichannelAgenticCatalog(){ omnichannelAgenticSetOutput(await fetchJson('/api/omnichannel/catalog')); }
async function omnichannelAgenticSeed(){ omnichannelAgenticSetOutput(await fetchJson('/api/omnichannel/seed-demo', {method:'POST', body:JSON.stringify({})})); }
async function omnichannelAgenticDeliver(){
  const question = (qs('omnichannelQuestionAgentic')?.value || qs('prompt')?.value || '').trim();
  const answer = (qs('omnichannelAnswerAgentic')?.value || 'Resposta do HAL.').trim();
  const data = await fetchJson('/api/omnichannel/deliver', {method:'POST', body:JSON.stringify({question, answer, requester_email: qs('omnichannelRequesterEmailAgentic')?.value || '', approved: qs('approved')?.checked || false, source:'agentic_panel'})});
  omnichannelAgenticSetOutput(data);
  if(data.summary) addMsg('assistant', data.summary);
}


function meetingIntelligenceAgenticSetOutput(obj){ const el = qs('meetingIntelligenceOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function meetingIntelligenceAgenticStatus(){ meetingIntelligenceAgenticSetOutput(await fetchJson('/api/meeting-intelligence/status')); }
async function meetingIntelligenceAgenticCatalog(){ meetingIntelligenceAgenticSetOutput(await fetchJson('/api/meeting-intelligence/catalog')); }
async function meetingIntelligenceAgenticSeed(){ meetingIntelligenceAgenticSetOutput(await fetchJson('/api/meeting-intelligence/seed-demo', {method:'POST', body:JSON.stringify({})})); }
async function meetingIntelligenceAgenticAnswer(){
  const message = (qs('meetingIntelligencePromptAgentic')?.value || qs('prompt')?.value || 'Meeting Intelligence').trim();
  const data = await fetchJson('/api/meeting-intelligence/status');
  const answer = 'Vou usar o HAL Meeting Intelligence para Teams, Google Meet ou áudio local. Ele prepara perguntas por voz/texto, respostas no chat, ata automática, decisões, tarefas e integração com ERP, CRM, Power BI, Zabbix, Grafana e bancos.';
  meetingIntelligenceAgenticSetOutput({ok:true, answer, status:data, message});
  addMsg('assistant', answer);
}


function enterpriseIntelligenceAgenticSetOutput(obj){ const el = qs('enterpriseIntelligenceOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function enterpriseIntelligenceAgenticStatus(){ enterpriseIntelligenceAgenticSetOutput(await fetchJson('/api/enterprise-intelligence/status')); }
async function enterpriseIntelligenceAgenticCatalog(){ enterpriseIntelligenceAgenticSetOutput(await fetchJson('/api/enterprise-intelligence/catalog')); }
async function enterpriseIntelligenceAgenticSeed(){ enterpriseIntelligenceAgenticSetOutput(await fetchJson('/api/enterprise-intelligence/seed-enterprise', {method:'POST', body:JSON.stringify({})})); }
async function enterpriseIntelligenceAgenticTask(){
  const message = (qs('enterpriseIntelligenceMessageAgentic')?.value || qs('prompt')?.value || 'Planejar integração corporativa.').trim();
  const data = await fetchJson('/api/enterprise-intelligence/guided-answer', {method:'POST', body:JSON.stringify({message, approved: qs('approved')?.checked || false})});
  enterpriseIntelligenceAgenticSetOutput(data);
  if(data.answer) addMsg('assistant', data.answer);
}


let humanConversationAgenticSessionId = localStorage.getItem("hallHumanConversationAgenticSessionId") || "";
function humanConversationAgenticSetOutput(obj){ const el = qs('humanConversationOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function humanConversationAgenticStatus(){ humanConversationAgenticSetOutput(await fetchJson('/api/human-conversation/status')); }
async function humanConversationAgenticPolicy(){ humanConversationAgenticSetOutput(await fetchJson('/api/human-conversation/policy')); }
async function humanConversationAgenticSend(){
  const message = (qs('humanConversationMessageAgentic')?.value || qs('prompt')?.value || 'Oi HAL').trim();
  const data = await fetchJson('/api/human-conversation/converse', {method:'POST', body:JSON.stringify({message, session_id: humanConversationAgenticSessionId, approved: qs('approved')?.checked || false, run_tools:true})});
  humanConversationAgenticSessionId = data.session_id || humanConversationAgenticSessionId;
  if(humanConversationAgenticSessionId) localStorage.setItem("hallHumanConversationAgenticSessionId", humanConversationAgenticSessionId);
  humanConversationAgenticSetOutput(data);
  if(data.answer) addMsg('assistant', data.answer);
}


function databaseAccessAgenticSetOutput(obj){ const el = qs('databaseAccessOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function databaseAccessAgenticStatus(){ databaseAccessAgenticSetOutput(await fetchJson('/api/database-access/status')); }
async function databaseAccessAgenticCatalog(){ databaseAccessAgenticSetOutput(await fetchJson('/api/database-access/catalog')); }
async function databaseAccessAgenticSeed(){ databaseAccessAgenticSetOutput(await fetchJson('/api/database-access/seed-examples', {method:'POST', body:JSON.stringify({})})); }
async function databaseAccessAgenticGuided(){
  const message = (qs('databaseAccessQuestionAgentic')?.value || qs('prompt')?.value || 'Consultar banco.').trim();
  const data = await fetchJson('/api/database-access/guided-answer', {method:'POST', body:JSON.stringify({message, approved: qs('approved')?.checked || false})});
  databaseAccessAgenticSetOutput(data);
  if(data.answer) addMsg('assistant', data.answer);
}


function industryPrecisionAgenticSetOutput(obj){ const el = qs('industryPrecisionOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function industryPrecisionAgenticStatus(){ industryPrecisionAgenticSetOutput(await fetchJson('/api/industry-precision/status')); }
async function industryPrecisionAgenticCatalog(){ industryPrecisionAgenticSetOutput(await fetchJson('/api/industry-precision/catalog')); }
async function industryPrecisionAgenticAnswer(){
  const message = (qs('industryPrecisionQuestionAgentic')?.value || qs('prompt')?.value || '').trim();
  const data = await fetchJson('/api/industry-precision/answer', {method:'POST', body:JSON.stringify({message, approved: qs('approved')?.checked || false, context:{}})});
  industryPrecisionAgenticSetOutput(data);
  if(data.answer) addMsg('assistant', data.answer);
}
async function industryPrecisionAgenticTests(){
  await fetchJson('/api/industry-precision/seed-tests', {method:'POST', body:JSON.stringify({})});
  industryPrecisionAgenticSetOutput(await fetchJson('/api/industry-precision/run-tests?limit=200'));
}


function reliableWebAgenticSetOutput(obj){ const el = qs('reliableWebOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function reliableWebAgenticStatus(){ reliableWebAgenticSetOutput(await fetchJson('/api/reliable-web/status')); }
async function reliableWebAgenticAnswer(){
  const message = (qs('reliableWebQuestionAgentic')?.value || qs('prompt')?.value || 'Quem é o presidente atual do Brasil?').trim();
  const data = await fetchJson('/api/reliable-web/answer', {method:'POST', body:JSON.stringify({message, approved:true, max_sources:5})});
  reliableWebAgenticSetOutput(data);
  if(data.answer) addMsg('assistant', data.answer);
}


function universalERPAgenticSetOutput(obj){ const el = qs('universalERPOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function universalERPAgenticStatus(){ universalERPAgenticSetOutput(await fetchJson('/api/universal-erp/status')); }
async function universalERPAgenticCatalog(){ universalERPAgenticSetOutput(await fetchJson('/api/universal-erp/catalog')); }
async function universalERPAgenticSeed(){ universalERPAgenticSetOutput(await fetchJson('/api/universal-erp/seed-transport-pack', {method:'POST', body:JSON.stringify({})})); }
async function universalERPAgenticPlan(){
  const question = (qs('universalERPQuestionAgentic')?.value || qs('prompt')?.value || 'Consultar ERP.').trim();
  universalERPAgenticSetOutput(await fetchJson('/api/universal-erp/query-plan', {method:'POST', body:JSON.stringify({question, approved: qs('approved')?.checked || false})}));
}


function visualMissionAgenticSetOutput(obj){ const el = qs('visualMissionOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function visualMissionAgenticMap(){ visualMissionAgenticSetOutput(await fetchJson('/api/visual-mission/map')); }
async function visualMissionAgenticSeed(){ visualMissionAgenticSetOutput(await fetchJson('/api/visual-mission/seed-demo', {method:'POST', body:JSON.stringify({})})); }
async function visualMissionAgenticPresentation(){ visualMissionAgenticSetOutput(await fetchJson('/api/visual-mission/presentation')); }
async function visualMissionAgenticMetrics(){ visualMissionAgenticSetOutput(await fetchJson('/api/visual-mission/metrics')); }
async function visualMissionAgenticCreate(){
  const objective = (qs('visualMissionObjectiveAgentic')?.value || qs('prompt')?.value || 'Missão visual HAL').trim();
  const data = await fetchJson('/api/visual-mission/create', {method:'POST', body: JSON.stringify({title:'Missão criada pelo HAL', objective, source:'agentic_pro', requires_approval:true, presentation:true})});
  visualMissionAgenticSetOutput(data);
  if(data.summary) addMsg('assistant', data.summary);
}


function openClawAgenticSetOutput(obj){ const el = qs('openClawOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function openClawAgenticStatus(){
  const endpoints = [
    '/api/channel-gateway/status',
    '/api/n8n/status',
    '/api/browser-automation/status',
    '/api/cron-enterprise/status',
    '/api/sandbox-enterprise/status',
    '/api/framework-bridge/status'
  ];
  const data = {};
  for(const ep of endpoints){ data[ep] = await fetchJson(ep); }
  openClawAgenticSetOutput(data);
}
async function channelAgenticStatus(){ openClawAgenticSetOutput(await fetchJson('/api/channel-gateway/channels')); }
async function n8nAgenticStatus(){ openClawAgenticSetOutput(await fetchJson('/api/n8n/status')); }
async function browserAgenticStatus(){ openClawAgenticSetOutput(await fetchJson('/api/browser-automation/status')); }
async function cronAgenticStatus(){ openClawAgenticSetOutput(await fetchJson('/api/cron-enterprise/status')); }
async function sandboxAgenticStatus(){ openClawAgenticSetOutput(await fetchJson('/api/sandbox-enterprise/status')); }
async function frameworkAgenticStatus(){ openClawAgenticSetOutput(await fetchJson('/api/framework-bridge/frameworks')); }


function openAIAgenticSetOutput(obj){ const el = qs('openAIOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function openAIAgenticStatus(){ openAIAgenticSetOutput(await fetchJson('/api/open-ai-access/status')); }
async function openAIAgenticModels(){ openAIAgenticSetOutput(await fetchJson('/api/open-ai-access/model-catalog')); }
async function openAIAgenticMarketplace(){ openAIAgenticSetOutput(await fetchJson('/api/open-ai-access/marketplace')); }
async function openAIAgenticRecommend(){
  const use_case = (qs('openAIUseCaseAgentic')?.value || qs('prompt')?.value || 'geral').trim();
  openAIAgenticSetOutput(await fetchJson('/api/open-ai-access/recommend-stack', {method:'POST', body: JSON.stringify({profile:'cpu_light', business_mode:'small_business', use_case})}));
}
async function openAIAgenticROI(){
  openAIAgenticSetOutput(await fetchJson('/api/open-ai-access/roi', {method:'POST', body: JSON.stringify({employees:5, hours_per_week:6, hourly_cost:60, reduction_percent:40, monthly_fee:3500})}));
}


function rtvAgenticSetOutput(obj){ const el = qs('rtvOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function rtvAgenticStatus(){ rtvAgenticSetOutput(await fetchJson('/api/realtime-voice/status')); }
async function rtvAgenticPolicy(){ rtvAgenticSetOutput(await fetchJson('/api/realtime-voice/policy')); }
async function rtvAgenticInstall(){ rtvAgenticSetOutput(await fetchJson('/api/realtime-voice/local-install-plan?cpu_only=true&has_gpu=false&vram_gb=0')); }
async function rtvAgenticSample(){ rtvAgenticSetOutput(await fetchJson('/api/realtime-voice/voice-sample-requirements')); }
async function rtvAgenticSession(){
  const data = await fetchJson('/api/realtime-voice/session', {method:'POST', body: JSON.stringify({mode:'assistant', channel:'web'})});
  rtvAgenticSetOutput(data);
  if(data.summary) addMsg('assistant', data.summary);
}


function humanVoiceAgenticSetOutput(obj){ const el = qs('humanVoiceOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function humanVoiceAgenticStatus(){ humanVoiceAgenticSetOutput(await fetchJson('/api/human-voice/status')); }
async function humanVoiceAgenticProfiles(){ humanVoiceAgenticSetOutput(await fetchJson('/api/human-voice/profiles')); }
async function humanVoiceAgenticPersonas(){ humanVoiceAgenticSetOutput(await fetchJson('/api/human-voice/personas')); }
async function humanVoiceAgenticClone(){ humanVoiceAgenticSetOutput(await fetchJson('/api/human-voice/clone-requirements')); }
async function humanVoiceAgenticAnswer(){
  const message = (qs('humanVoiceMessageAgentic')?.value || qs('prompt')?.value || '').trim();
  const data = await fetchJson('/api/human-voice/answer', {method:'POST', body: JSON.stringify({message})});
  humanVoiceAgenticSetOutput(data);
  const answer = data.answer || data.greeting || '';
  if(answer){ addMsg('assistant', answer); speak(answer); }
}


let lastRuntimeAgenticJobId = "";
function runtimeAgenticSetOutput(obj){ const el = qs('runtimeOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function runtimeAgenticAgents(){ runtimeAgenticSetOutput(await fetchJson('/api/agent-runtime/agents')); }
async function runtimeAgenticJobs(){ runtimeAgenticSetOutput(await fetchJson('/api/agent-runtime/list?limit=50')); }
async function runtimeAgenticMetrics(){ runtimeAgenticSetOutput(await fetchJson('/api/agent-runtime/metrics')); }
async function runtimeAgenticCreate(){
  const objective = (qs('runtimeObjectiveAgentic')?.value || qs('prompt')?.value || '').trim();
  const data = await fetchJson('/api/agent-runtime/create', {method:'POST', body: JSON.stringify({objective, requires_approval:true, estimated_human_minutes:90})});
  lastRuntimeAgenticJobId = data.job?.id || "";
  runtimeAgenticSetOutput(data); addMsg('assistant', data.summary || 'Job criado.');
}
async function runtimeAgenticStart(){
  if(!lastRuntimeAgenticJobId) await runtimeAgenticCreate();
  if(!lastRuntimeAgenticJobId) return;
  const data = await fetchJson('/api/agent-runtime/start', {method:'POST', body: JSON.stringify({job_id:lastRuntimeAgenticJobId, approved: qs('approved').checked})});
  runtimeAgenticSetOutput(data); addMsg('assistant', data.summary || 'Job iniciado.');
}
async function runtimeAgenticAdvance(){
  if(!lastRuntimeAgenticJobId){ runtimeAgenticSetOutput('Crie um job primeiro.'); return; }
  const data = await fetchJson('/api/agent-runtime/advance', {method:'POST', body: JSON.stringify({job_id:lastRuntimeAgenticJobId, steps_to_advance:1})});
  runtimeAgenticSetOutput(data); addMsg('assistant', data.summary || 'Job avançado.');
}


let lastSaasAgenticProjectId = "";
function saasAgenticSetOutput(obj){ const el = qs('saasOutputAgentic'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function saasAgenticTemplates(){ saasAgenticSetOutput(await fetchJson('/api/saas-builder/templates')); }
async function saasAgenticProjects(){ saasAgenticSetOutput(await fetchJson('/api/saas-builder/list?limit=50')); }
async function saasAgenticCreate(){
  const idea = (qs('saasIdeaAgentic')?.value || qs('prompt')?.value || '').trim();
  const data = await fetchJson('/api/saas-builder/create', {method:'POST', body: JSON.stringify({idea, logo_text:'AJDS', deploy_target:'local', billing_provider:'manual'})});
  lastSaasAgenticProjectId = data.project?.id || "";
  saasAgenticSetOutput(data); addMsg('assistant', data.summary || 'Projeto SaaS criado.');
}
async function saasAgenticGenerate(){
  if(!lastSaasAgenticProjectId) await saasAgenticCreate();
  if(!lastSaasAgenticProjectId) return;
  const data = await fetchJson('/api/saas-builder/generate-code', {method:'POST', body: JSON.stringify({project_id:lastSaasAgenticProjectId})});
  saasAgenticSetOutput(data); addMsg('assistant', data.summary || 'Código gerado.');
}
async function saasAgenticDeploy(){
  if(!lastSaasAgenticProjectId){ saasAgenticSetOutput('Crie um projeto primeiro.'); return; }
  saasAgenticSetOutput(await fetchJson('/api/saas-builder/deploy-plan', {method:'POST', body: JSON.stringify({project_id:lastSaasAgenticProjectId})}));
}


function teamSetOutput(obj){ const el = qs('teamOutput'); if(el) el.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2); }
async function teamTemplates(){ const data = await fetchJson('/api/business-teams/templates'); teamSetOutput(data); }
async function teamCreate(){
  const goal = (qs('teamGoal')?.value || qs('prompt')?.value || '').trim();
  const data = await fetchJson('/api/business-teams/create', { method:'POST', body: JSON.stringify({ goal, channels:['webchat'], approval_required:true }) });
  teamSetOutput(data); addMsg('assistant', data.summary || 'Time criado.');
}
async function teamRun(){
  const goal = (qs('teamGoal')?.value || qs('prompt')?.value || '').trim();
  const data = await fetchJson('/api/business-teams/run', { method:'POST', body: JSON.stringify({ goal, approved: qs('approved').checked, channel:'webchat' }) });
  teamSetOutput(data); addMsg('assistant', data.summary || 'Time processado.'); if(data.summary) speak(data.summary);
}
async function teamApprovals(){ const data = await fetchJson('/api/business-teams/approvals?status=pending&limit=50'); teamSetOutput(data); }

const qs=id=>document.getElementById(id);
let recognition=null,listening=false,lastAnswer='',mediaStream=null,silenceTimer=null,micRestartTimer=null,micRetryCount=0,micManualStop=false,micHadSpeech=false,liveDialogueSessionId=localStorage.getItem('hallLiveDialogueSessionId')||'',voiceRecorder=null,voiceChunks=[],voiceStream=null,voiceMode='';

function setState(t,active=false){qs('state').textContent=t;qs('orb').classList.toggle('active',active);}
function escapeHtml(s){return (s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function addMsg(role,text){const chat=qs('chat');const clean=String(text||'').trim();const last=chat?.lastElementChild;if(last&&last.classList.contains(role)){const p=last.querySelector('p');if(p&&p.textContent.trim()===clean)return}const el=document.createElement('div');el.className='msg '+role;el.innerHTML=`<strong>${role==='user'?'Você':'HAL'}</strong><p>${escapeHtml(clean)}</p>`;chat.appendChild(el);chat.scrollTop=chat.scrollHeight;}
async function fetchJson(url,opts={}){opts.headers={...(opts.headers||{}),'Content-Type':'application/json'};const r=await fetch(url,opts);const txt=await r.text();let data;try{data=JSON.parse(txt)}catch{data={ok:false,raw:txt}};if(!r.ok)throw new Error(data.detail||data.summary||txt);return data;}
function speak(text){lastAnswer=text;if(!('speechSynthesis'in window))return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='pt-BR';u.rate=0.92;u.pitch=0.95;const voices=speechSynthesis.getVoices();const v=voices.find(x=>(x.lang||'').toLowerCase().includes('pt-br')||(x.name||'').toLowerCase().includes('brasil')||(x.name||'').toLowerCase().includes('portugu'));if(v)u.voice=v;u.onstart=()=>setState('Respondendo...',true);u.onend=()=>setState('Pronto',false);speechSynthesis.speak(u);}
async function sendTurn(msg){
  msg=(msg||qs('prompt').value||'').trim();
  if(!msg)return;
  qs('prompt').value='';
  addMsg('user',msg);
  setState('Pensando...',true);
  try{
    const data=await fetchJson('/api/human-conversation/converse',{
      method:'POST',
      body:JSON.stringify({message:msg,session_id:liveDialogueSessionId,approved:qs('approved').checked,run_tools:true})
    });
    liveDialogueSessionId=data.session_id||liveDialogueSessionId;
    if(liveDialogueSessionId)localStorage.setItem('hallLiveDialogueSessionId',liveDialogueSessionId);
    const answer=data.answer||data.summary||'Estou aqui. Pode continuar a pergunta.';
    addMsg('assistant',answer);
    if(qs('planOutput'))qs('planOutput').textContent=JSON.stringify({mode:'live_dialogue_engine_v4',intent:data.classification?.intent,tool:data.tool_result?.tool,tools_in_background:true},null,2);
    if(qs('technical'))qs('technical').textContent=JSON.stringify(data,null,2);
    speak(answer);
    setState('Pronto',false);
  }catch(e){
    addMsg('assistant','Não consegui responder por voz agora, mas podemos continuar por texto: '+e.message);
    setState('Erro',false);
  }
}


let localSttStatusCache=null, localSttStatusAt=0;

async function getLocalSttStatus(){
  const now=Date.now();
  if(localSttStatusCache && (now-localSttStatusAt)<30000) return localSttStatusCache;
  try{
    const r=await fetch('/api/stt/status');
    const data=await r.json();
    localSttStatusCache=data;
    localSttStatusAt=now;
    return data;
  }catch(e){
    return {ok:false, ready:false, error:e.message};
  }
}
async function shouldUseRecordedVoice(){
  const forced=localStorage.getItem('hallVoiceCaptureMode');
  if(forced==='recorded_first') return true;
  if(forced==='browser_first') return false;
  const stt=await getLocalSttStatus();
  return !!(stt && stt.ready);
}
function explainSttNotReady(stt){
  const engines=(stt&&stt.engines_available&&stt.engines_available.length)?stt.engines_available.join(', '):'nenhum';
  return 'O STT local ainda não está pronto para transcrever voz gravada. Motores disponíveis: '+engines+'. Execute HALL_AUTO_STT.bat ou use Enviar texto enquanto isso.';
}
const VOICE_MAX_RECORD_MS = 9000;
const VOICE_WATCHDOG_MS = 12000;
let voiceStopHandled=false, voiceCountdownTimer=null, voiceWatchdogTimer=null, voiceStartedAt=0, voiceFinishReason='';

function setVoiceButtons(recording=false, transcribing=false){
  const b=qs('btnListen');
  const stop=qs('btnStop');
  if(b){b.textContent=recording?'✅ Responder agora':(transcribing?'Transcrevendo...':'🎙️ Conversar');b.disabled=!!transcribing}
  if(stop){stop.textContent=recording?'Parar e responder':'Parar';stop.disabled=!!transcribing}
}
function clearVoiceTimers(){clearTimeout(silenceTimer);clearTimeout(micRestartTimer);clearInterval(voiceCountdownTimer);clearTimeout(voiceWatchdogTimer)}
async function handleRecordedBlob(blob,reason='auto'){
  if(voiceStopHandled)return;
  voiceStopHandled=true;
  clearVoiceTimers();
  try{voiceStream?.getTracks().forEach(t=>t.stop())}catch{}
  voiceStream=null;voiceRecorder=null;listening=false;voiceMode='';
  setVoiceButtons(false,true);
  setState('Transcrevendo pergunta completa...',true);
  if(!blob||blob.size<900){
    addMsg('assistant','O áudio ficou curto ou vazio. Eu não quero adivinhar sua pergunta. Fale novamente por alguns segundos ou digite a pergunta completa.');
    setState('Pronto',false);setVoiceButtons(false,false);return;
  }
  const ok=await transcribeRecordedVoice(blob);
  setState('Pronto',false);setVoiceButtons(false,false);
  if(!ok)addMsg('assistant','Para evitar erro, não vou inventar o que você disse. Digite a pergunta ou clique em Conversar novamente e fale até o fim.');
}
function finishRecordedVoice(reason='manual'){
  voiceFinishReason=reason;
  clearVoiceTimers();
  if(voiceRecorder&&voiceRecorder.state==='recording'){
    setState('Fechando gravação para responder...',true);
    try{voiceRecorder.requestData()}catch{}
    setTimeout(()=>{try{if(voiceRecorder&&voiceRecorder.state==='recording')voiceRecorder.stop()}catch(e){const blob=new Blob(voiceChunks,{type:'audio/webm'});handleRecordedBlob(blob,reason)}},250);
    return;
  }
  if(voiceChunks&&voiceChunks.length){
    const blob=new Blob(voiceChunks,{type:'audio/webm'});
    handleRecordedBlob(blob,reason);
    return;
  }
  try{voiceStream?.getTracks().forEach(t=>t.stop())}catch{}
  voiceStream=null;listening=false;voiceMode='';
  setState('Pronto',false);setVoiceButtons(false,false);
}
async function transcribeRecordedVoice(blob){
  try{
    const fd=new FormData();
    fd.append('file',blob,'hall_voice.webm');
    fd.append('language','pt');
    const res=await fetch('/api/stt/transcribe',{method:'POST',body:fd});
    const data=await res.json();
    if(qs('technical'))qs('technical').textContent=JSON.stringify(data,null,2);
    if(data.ok&&data.text&&data.text.trim()){
      const text=data.text.trim();
      qs('prompt').value=text;
      addMsg('assistant','Ouvi sua pergunta. Vou responder agora.');
      await sendTurn(text);
      return true;
    }
    const msg=data.error||'não consegui transformar o áudio em texto';
    addMsg('assistant','Recebi o áudio, mas não consegui transcrever com segurança: '+msg+'.');
    return false;
  }catch(e){
    addMsg('assistant','Não consegui usar o STT local agora: '+e.message+'.');
    return false;
  }
}
async function startRecordedVoiceFallback(){
  if(listening&&voiceMode==='recording'){finishRecordedVoice('listen_button_toggle');return}
  const forced=localStorage.getItem('hallVoiceCaptureMode')==='recorded_first';
  const stt=await getLocalSttStatus();
  if(!forced&&!(stt&&stt.ready)){addMsg('assistant',explainSttNotReady(stt));setState('Pronto',false);setVoiceButtons(false,false);return}
  const perm=await ensureMicrophonePermission();
  if(!perm.ok){addMsg('assistant','Não consegui acessar o microfone: '+perm.error);setState('Microfone indisponível',false);return}
  if(!window.MediaRecorder){addMsg('assistant','Seu navegador não suporta MediaRecorder. Use Chrome ou Edge atualizado, ou digite a pergunta.');return}
  try{
    voiceStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
    voiceChunks=[];voiceStopHandled=false;voiceFinishReason='';voiceStartedAt=Date.now();
    const opts=MediaRecorder.isTypeSupported('audio/webm;codecs=opus')?{mimeType:'audio/webm;codecs=opus'}:(MediaRecorder.isTypeSupported('audio/webm')?{mimeType:'audio/webm'}:{});
    voiceRecorder=new MediaRecorder(voiceStream,opts);
    voiceMode='recording';listening=true;micManualStop=false;setVoiceButtons(true,false);
    voiceRecorder.ondataavailable=e=>{if(e.data&&e.data.size)voiceChunks.push(e.data)};
    voiceRecorder.onerror=e=>{addMsg('assistant','Falha na gravação do áudio: '+(e?.error?.message||e?.message||'erro desconhecido')+'. Pode digitar a pergunta.');finishRecordedVoice('recorder_error')};
    voiceRecorder.onstop=async()=>{const blob=new Blob(voiceChunks,{type:'audio/webm'});await handleRecordedBlob(blob,voiceFinishReason||'onstop')};
    voiceRecorder.start(1000);
    setState('Gravando voz completa... fale a pergunta até o fim',true);
    voiceCountdownTimer=setInterval(()=>{const elapsed=Date.now()-voiceStartedAt;const left=Math.max(0,Math.ceil((VOICE_MAX_RECORD_MS-elapsed)/1000));if(left>0){setState(`Gravando... ${left}s restantes. Clique em “Responder agora” quando terminar.`,true)}else{finishRecordedVoice('countdown_zero')}},1000);
    silenceTimer=setTimeout(()=>finishRecordedVoice('auto_timeout'),VOICE_MAX_RECORD_MS);
    voiceWatchdogTimer=setTimeout(()=>{if(listening&&voiceMode==='recording'){try{voiceRecorder?.requestData()}catch{}try{voiceRecorder?.stop()}catch{finishRecordedVoice('watchdog')}}},VOICE_WATCHDOG_MS);
  }catch(e){
    addMsg('assistant','Não consegui iniciar a gravação local do microfone: '+e.message);
    setState('Erro no microfone',false);listening=false;voiceMode='';setVoiceButtons(false,false);
  }
}

async function ensureMicrophonePermission(){
  if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){
    return{ok:false,error:'mediaDevices indisponível. Use Chrome ou Edge em localhost/HTTPS.'}
  }
  try{
    const stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
    stream.getTracks().forEach(t=>t.stop());
    return{ok:true}
  }catch(e){
    const name=e?.name||e?.message||'erro desconhecido';
    if(name.includes('NotAllowed')||name.includes('Permission'))return{ok:false,error:'permissão negada. Clique no cadeado do navegador e libere o microfone.'};
    if(name.includes('NotFound')||name.includes('DevicesNotFound'))return{ok:false,error:'nenhum microfone encontrado no Windows/navegador.'};
    return{ok:false,error:name}
  }
}
function micErrorMessage(error){
  const e=String(error||'').toLowerCase();
  if(e==='no-speech')return'Não captei sua fala pelo navegador.';
  if(e==='audio-capture')return'Não consegui capturar o áudio. Verifique se o microfone correto está selecionado no Windows e no navegador.';
  if(e==='not-allowed'||e==='service-not-allowed')return'O navegador bloqueou o microfone. Libere o acesso no cadeado da barra de endereço.';
  if(e==='network')return'O reconhecimento de voz do navegador falhou por rede/serviço. Vou tentar gravação local quando possível.';
  return'Microfone: '+(error||'falha desconhecida')
}
function restartRecognitionSoon(reason){
  clearTimeout(micRestartTimer);
  if(micManualStop||!listening)return;
  setState('Vou tentar gravação local...',true);
  try{recognition?.abort()}catch{}
  listening=false;
  startRecordedVoiceFallback();
}
async function startListen(){
  speechSynthesis?.cancel();
  if(listening){stopListen(true);return}
  // V10: gravação local só é padrão se o STT local estiver pronto.
  if(await shouldUseRecordedVoice()){
    await startRecordedVoiceFallback();
    return;
  }
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){
    addMsg('assistant','O reconhecimento de voz do navegador não está disponível. Vou usar gravação local como alternativa.');
    await startRecordedVoiceFallback();
    return;
  }
  const perm=await ensureMicrophonePermission();
  if(!perm.ok){
    addMsg('assistant','Não consegui acessar o microfone: '+perm.error);
    setState('Microfone indisponível',false);
    return;
  }
  recognition=new SR();
  recognition.lang='pt-BR';
  recognition.continuous=false;
  recognition.interimResults=true;
  recognition.maxAlternatives=1;
  listening=true;
  voiceMode='speech';
  micManualStop=false;
  micHadSpeech=false;
  micRetryCount=0;
  let finalText='';
  recognition.onstart=()=>setState('Ouvindo... pode falar naturalmente',true);
  recognition.onerror=async e=>{
    const err=e?.error||'erro';
    if(err==='no-speech'){
      try{recognition?.abort()}catch{}
      listening=false;
      const stt=await getLocalSttStatus();
      if(stt&&stt.ready){setState('Não captei pelo navegador. Vou gravar sua voz agora...',true);await startRecordedVoiceFallback()}else{addMsg('assistant','Não consegui captar sua fala pelo navegador e o STT local ainda não está pronto. Digite a pergunta ou execute HALL_AUTO_STT.bat para ativar a transcrição local.');setState('Pronto',false);setVoiceButtons(false,false)}
      return;
    }
    addMsg('assistant',micErrorMessage(err));
    setState('Tentando gravação local...',true);
    try{recognition?.abort()}catch{}
    listening=false;
    await startRecordedVoiceFallback();
  };
  recognition.onresult=e=>{
    speechSynthesis?.cancel();
    micHadSpeech=true;
    micRetryCount=0;
    let interim='';
    for(let i=e.resultIndex;i<e.results.length;i++){
      const txt=e.results[i][0].transcript;
      if(e.results[i].isFinal)finalText+=' '+txt;else interim+=txt
    }
    qs('prompt').value=(finalText+' '+interim).trim();
  };
  recognition.onend=()=>{
    if(micManualStop){
      listening=false;
      setState('Pronto',false);
      return;
    }
    const captured=(qs('prompt').value||'').trim();
    if(captured.length>2){
      listening=false;
      setState('Respondendo...',true);
      sendTurn(captured);
      return;
    }
    if(!micHadSpeech){
      listening=false;
      getLocalSttStatus().then(stt=>{if(stt&&stt.ready){setState('Não captei pelo navegador. Vou tentar gravação local...',true);startRecordedVoiceFallback()}else{addMsg('assistant','Não ouvi sua fala pelo navegador. Como o STT local não está pronto, use Enviar texto ou execute HALL_AUTO_STT.bat.');setState('Pronto',false);setVoiceButtons(false,false)}});
      return;
    }
    listening=false;
    setState('Pronto',false);
  };
  try{recognition.start()}
  catch(e){
    addMsg('assistant','Não consegui iniciar o reconhecimento do navegador. Vou usar gravação local.');
    listening=false;
    await startRecordedVoiceFallback()
  }
}
function stopListen(send=false){
  micManualStop=true;
  try{recognition?.stop()}catch{}
  if(voiceRecorder&&voiceRecorder.state==='recording'){finishRecordedVoice(send?'stop_send':'stop_button');return}
  clearVoiceTimers();
  try{voiceStream?.getTracks().forEach(t=>t.stop())}catch{}
  voiceStream=null;listening=false;voiceMode='';
  setVoiceButtons(false,false);
  setState('Pronto',false);
  if(send&&qs('prompt').value.trim())setTimeout(()=>sendTurn(),250)
}

async function desktop(action,payload={}){const data=await fetchJson('/api/desktop/action',{method:'POST',body:JSON.stringify({action,approved:qs('approved').checked,payload})});qs('technical').textContent=JSON.stringify(data,null,2);addMsg('assistant',data.summary||JSON.stringify(data));if(data.summary)speak(data.summary);}
async function startScreen(){stopMedia();try{mediaStream=await navigator.mediaDevices.getDisplayMedia({video:true,audio:false});qs('video').srcObject=mediaStream;setState('Tela compartilhada',true)}catch(e){addMsg('assistant','Tela: '+e.message)}}
async function startCamera(){stopMedia();try{mediaStream=await navigator.mediaDevices.getUserMedia({video:true,audio:false});qs('video').srcObject=mediaStream;setState('Câmera ativa',true)}catch(e){addMsg('assistant','Câmera: '+e.message)}}
function stopMedia(){if(mediaStream){mediaStream.getTracks().forEach(t=>t.stop());mediaStream=null}qs('video').srcObject=null;setState('Pronto',false)}
async function analyzeFrame(){const v=qs('video'),c=qs('canvas');if(!v.videoWidth){addMsg('assistant','Ative tela ou câmera primeiro.');return}c.width=v.videoWidth;c.height=v.videoHeight;c.getContext('2d').drawImage(v,0,0,c.width,c.height);const blob=await new Promise(res=>c.toBlob(res,'image/png',0.92));const fd=new FormData();fd.append('file',blob,'capture.png');fd.append('source','browser');fd.append('question',qs('visionQuestion').value||'Descreva a imagem');setState('Analisando imagem...',true);const r=await fetch('/api/vision/upload',{method:'POST',body:fd});const data=await r.json();qs('technical').textContent=JSON.stringify(data,null,2);const answer=data.analysis?.analysis||data.analysis?.content||JSON.stringify(data.analysis);addMsg('assistant',answer);speak(answer);setState('Pronto',false);}
async function memorySave(){const data=await fetchJson('/api/memory/add',{method:'POST',body:JSON.stringify({text:qs('memoryText').value,tags:['hall','transporte'],importance:4})});addMsg('assistant',data.summary);memoryList();}
async function memorySearch(){const data=await fetchJson('/api/memory/search',{method:'POST',body:JSON.stringify({query:qs('prompt').value||qs('memoryText').value,limit:8})});renderMem(data.rows||[]);qs('technical').textContent=JSON.stringify(data,null,2);}
async function memoryList(){const data=await fetchJson('/api/memory/list?limit=50');renderMem(data.rows||[]);}
function renderMem(rows){qs('memoryList').innerHTML=rows.length?rows.map(r=>`<div class="memory-item">${escapeHtml(r.text)}<br><small>${escapeHtml(r.created_at||'')} • score ${r.score||''}</small></div>`).join(''):'<p>Nenhuma memória.</p>'}
async function modelStatus(){const data=await fetchJson('/api/models/status');qs('modelStatus').textContent=data.ollama_online?'Ollama online':'Ollama offline';qs('technical').textContent=JSON.stringify(data,null,2);}
async function pullModel(model){addMsg('assistant','Iniciando download do modelo '+model+'. Isso pode demorar.');const data=await fetchJson('/api/models/pull',{method:'POST',body:JSON.stringify({model})});qs('technical').textContent=JSON.stringify(data,null,2);addMsg('assistant',data.ok?'Modelo baixado: '+model:'Falha ao baixar: '+model);}
async function status(){const data=await fetchJson('/api/status');qs('statusPill').textContent=data.models.ollama_online?'Ollama online':'Ollama offline / fallback ativo';qs('modelStatus').textContent=data.models.ollama_online?'Ollama online':'Fallback determinístico';qs('technical').textContent=JSON.stringify(data,null,2);memoryList();}
document.addEventListener('click',e=>{const ex=e.target.closest('[data-example]');if(ex){qs('prompt').value=ex.dataset.example;sendTurn()}const pull=e.target.closest('[data-pull]');if(pull){pullModel(pull.dataset.pull)}});
qs('btnListen').onclick=startListen;qs('btnSend').onclick=()=>sendTurn();qs('btnStop').onclick=()=>stopListen(false);qs('btnRepeat').onclick=()=>speak(lastAnswer);
qs('btnScreen').onclick=startScreen;qs('btnCamera').onclick=startCamera;qs('btnStopMedia').onclick=stopMedia;qs('btnAnalyze').onclick=analyzeFrame;
qs('btnDesktopShot').onclick=async()=>{const r=await fetch('/api/desktop/screenshot');const d=await r.json();qs('technical').textContent=JSON.stringify(d,null,2);addMsg('assistant',d.summary||'Screenshot')};
qs('btnDesktopCam').onclick=async()=>{const r=await fetch('/api/desktop/camera');const d=await r.json();qs('technical').textContent=JSON.stringify(d,null,2);addMsg('assistant',d.summary||'Câmera')};
qs('btnType').onclick=()=>desktop('type_text',{text:qs('desktopText').value});qs('btnFolder').onclick=()=>desktop('create_folder',{name:'Relatorios_Transporte'});qs('btnOpenUrl').onclick=()=>desktop('open_url',{url:qs('prompt').value});
qs('btnMemorySave').onclick=memorySave;qs('btnMemorySearch').onclick=memorySearch;qs('btnMemoryList').onclick=memoryList;qs('btnModelStatus').onclick=modelStatus;
status();setInterval(()=>speechSynthesis.getVoices(),1000);


if(qs('btnTeamTemplates')) qs('btnTeamTemplates').onclick = teamTemplates;
if(qs('btnTeamCreate')) qs('btnTeamCreate').onclick = teamCreate;
if(qs('btnTeamRun')) qs('btnTeamRun').onclick = teamRun;
if(qs('btnTeamApprovals')) qs('btnTeamApprovals').onclick = teamApprovals;


if(qs('btnSaasTemplatesAgentic')) qs('btnSaasTemplatesAgentic').onclick = saasAgenticTemplates;
if(qs('btnSaasProjectsAgentic')) qs('btnSaasProjectsAgentic').onclick = saasAgenticProjects;
if(qs('btnSaasCreateAgentic')) qs('btnSaasCreateAgentic').onclick = saasAgenticCreate;
if(qs('btnSaasGenerateAgentic')) qs('btnSaasGenerateAgentic').onclick = saasAgenticGenerate;
if(qs('btnSaasDeployAgentic')) qs('btnSaasDeployAgentic').onclick = saasAgenticDeploy;


if(qs('btnRuntimeAgentsAgentic')) qs('btnRuntimeAgentsAgentic').onclick = runtimeAgenticAgents;
if(qs('btnRuntimeJobsAgentic')) qs('btnRuntimeJobsAgentic').onclick = runtimeAgenticJobs;
if(qs('btnRuntimeMetricsAgentic')) qs('btnRuntimeMetricsAgentic').onclick = runtimeAgenticMetrics;
if(qs('btnRuntimeCreateAgentic')) qs('btnRuntimeCreateAgentic').onclick = runtimeAgenticCreate;
if(qs('btnRuntimeStartAgentic')) qs('btnRuntimeStartAgentic').onclick = runtimeAgenticStart;
if(qs('btnRuntimeAdvanceAgentic')) qs('btnRuntimeAdvanceAgentic').onclick = runtimeAgenticAdvance;


if(qs('btnHumanVoiceStatusAgentic')) qs('btnHumanVoiceStatusAgentic').onclick = humanVoiceAgenticStatus;
if(qs('btnHumanVoiceProfilesAgentic')) qs('btnHumanVoiceProfilesAgentic').onclick = humanVoiceAgenticProfiles;
if(qs('btnHumanVoicePersonasAgentic')) qs('btnHumanVoicePersonasAgentic').onclick = humanVoiceAgenticPersonas;
if(qs('btnHumanVoiceAnswerAgentic')) qs('btnHumanVoiceAnswerAgentic').onclick = humanVoiceAgenticAnswer;
if(qs('btnHumanVoiceCloneAgentic')) qs('btnHumanVoiceCloneAgentic').onclick = humanVoiceAgenticClone;


if(qs('btnRTVStatusAgentic')) qs('btnRTVStatusAgentic').onclick = rtvAgenticStatus;
if(qs('btnRTVPolicyAgentic')) qs('btnRTVPolicyAgentic').onclick = rtvAgenticPolicy;
if(qs('btnRTVInstallAgentic')) qs('btnRTVInstallAgentic').onclick = rtvAgenticInstall;
if(qs('btnRTVSampleAgentic')) qs('btnRTVSampleAgentic').onclick = rtvAgenticSample;
if(qs('btnRTVSessionAgentic')) qs('btnRTVSessionAgentic').onclick = rtvAgenticSession;


if(qs('btnOpenAIStatusAgentic')) qs('btnOpenAIStatusAgentic').onclick = openAIAgenticStatus;
if(qs('btnOpenAIModelsAgentic')) qs('btnOpenAIModelsAgentic').onclick = openAIAgenticModels;
if(qs('btnOpenAIRecommendAgentic')) qs('btnOpenAIRecommendAgentic').onclick = openAIAgenticRecommend;
if(qs('btnOpenAIMarketplaceAgentic')) qs('btnOpenAIMarketplaceAgentic').onclick = openAIAgenticMarketplace;
if(qs('btnOpenAIROIAgentic')) qs('btnOpenAIROIAgentic').onclick = openAIAgenticROI;


if(qs('btnOpenClawStatusAgentic')) qs('btnOpenClawStatusAgentic').onclick = openClawAgenticStatus;
if(qs('btnChannelStatusAgentic')) qs('btnChannelStatusAgentic').onclick = channelAgenticStatus;
if(qs('btnN8NStatusAgentic')) qs('btnN8NStatusAgentic').onclick = n8nAgenticStatus;
if(qs('btnBrowserStatusAgentic')) qs('btnBrowserStatusAgentic').onclick = browserAgenticStatus;
if(qs('btnCronStatusAgentic')) qs('btnCronStatusAgentic').onclick = cronAgenticStatus;
if(qs('btnSandboxStatusAgentic')) qs('btnSandboxStatusAgentic').onclick = sandboxAgenticStatus;
if(qs('btnFrameworkStatusAgentic')) qs('btnFrameworkStatusAgentic').onclick = frameworkAgenticStatus;


if(qs('btnVisualMissionMapAgentic')) qs('btnVisualMissionMapAgentic').onclick = visualMissionAgenticMap;
if(qs('btnVisualMissionSeedAgentic')) qs('btnVisualMissionSeedAgentic').onclick = visualMissionAgenticSeed;
if(qs('btnVisualMissionCreateAgentic')) qs('btnVisualMissionCreateAgentic').onclick = visualMissionAgenticCreate;
if(qs('btnVisualMissionPresentationAgentic')) qs('btnVisualMissionPresentationAgentic').onclick = visualMissionAgenticPresentation;
if(qs('btnVisualMissionMetricsAgentic')) qs('btnVisualMissionMetricsAgentic').onclick = visualMissionAgenticMetrics;


if(qs('btnUniversalERPStatusAgentic')) qs('btnUniversalERPStatusAgentic').onclick = universalERPAgenticStatus;
if(qs('btnUniversalERPCatalogAgentic')) qs('btnUniversalERPCatalogAgentic').onclick = universalERPAgenticCatalog;
if(qs('btnUniversalERPSeedAgentic')) qs('btnUniversalERPSeedAgentic').onclick = universalERPAgenticSeed;
if(qs('btnUniversalERPPlanAgentic')) qs('btnUniversalERPPlanAgentic').onclick = universalERPAgenticPlan;


if(qs('btnReliableWebStatusAgentic')) qs('btnReliableWebStatusAgentic').onclick = reliableWebAgenticStatus;
if(qs('btnReliableWebAnswerAgentic')) qs('btnReliableWebAnswerAgentic').onclick = reliableWebAgenticAnswer;


if(qs('btnIndustryPrecisionStatusAgentic')) qs('btnIndustryPrecisionStatusAgentic').onclick = industryPrecisionAgenticStatus;
if(qs('btnIndustryPrecisionCatalogAgentic')) qs('btnIndustryPrecisionCatalogAgentic').onclick = industryPrecisionAgenticCatalog;
if(qs('btnIndustryPrecisionAnswerAgentic')) qs('btnIndustryPrecisionAnswerAgentic').onclick = industryPrecisionAgenticAnswer;
if(qs('btnIndustryPrecisionTestsAgentic')) qs('btnIndustryPrecisionTestsAgentic').onclick = industryPrecisionAgenticTests;


if(qs('btnDatabaseAccessStatusAgentic')) qs('btnDatabaseAccessStatusAgentic').onclick = databaseAccessAgenticStatus;
if(qs('btnDatabaseAccessCatalogAgentic')) qs('btnDatabaseAccessCatalogAgentic').onclick = databaseAccessAgenticCatalog;
if(qs('btnDatabaseAccessGuidedAgentic')) qs('btnDatabaseAccessGuidedAgentic').onclick = databaseAccessAgenticGuided;
if(qs('btnDatabaseAccessSeedAgentic')) qs('btnDatabaseAccessSeedAgentic').onclick = databaseAccessAgenticSeed;


if(qs('btnHumanConversationStatusAgentic')) qs('btnHumanConversationStatusAgentic').onclick = humanConversationAgenticStatus;
if(qs('btnHumanConversationSendAgentic')) qs('btnHumanConversationSendAgentic').onclick = humanConversationAgenticSend;
if(qs('btnHumanConversationPolicyAgentic')) qs('btnHumanConversationPolicyAgentic').onclick = humanConversationAgenticPolicy;


if(qs('btnEnterpriseIntelligenceStatusAgentic')) qs('btnEnterpriseIntelligenceStatusAgentic').onclick = enterpriseIntelligenceAgenticStatus;
if(qs('btnEnterpriseIntelligenceCatalogAgentic')) qs('btnEnterpriseIntelligenceCatalogAgentic').onclick = enterpriseIntelligenceAgenticCatalog;
if(qs('btnEnterpriseIntelligenceSeedAgentic')) qs('btnEnterpriseIntelligenceSeedAgentic').onclick = enterpriseIntelligenceAgenticSeed;
if(qs('btnEnterpriseIntelligenceTaskAgentic')) qs('btnEnterpriseIntelligenceTaskAgentic').onclick = enterpriseIntelligenceAgenticTask;


if(qs('btnMeetingIntelligenceStatusAgentic')) qs('btnMeetingIntelligenceStatusAgentic').onclick = meetingIntelligenceAgenticStatus;
if(qs('btnMeetingIntelligenceCatalogAgentic')) qs('btnMeetingIntelligenceCatalogAgentic').onclick = meetingIntelligenceAgenticCatalog;
if(qs('btnMeetingIntelligenceSeedAgentic')) qs('btnMeetingIntelligenceSeedAgentic').onclick = meetingIntelligenceAgenticSeed;
if(qs('btnMeetingIntelligenceAnswerAgentic')) qs('btnMeetingIntelligenceAnswerAgentic').onclick = meetingIntelligenceAgenticAnswer;


if(qs('btnOmnichannelStatusAgentic')) qs('btnOmnichannelStatusAgentic').onclick = omnichannelAgenticStatus;
if(qs('btnOmnichannelCatalogAgentic')) qs('btnOmnichannelCatalogAgentic').onclick = omnichannelAgenticCatalog;
if(qs('btnOmnichannelSeedAgentic')) qs('btnOmnichannelSeedAgentic').onclick = omnichannelAgenticSeed;
if(qs('btnOmnichannelDeliverAgentic')) qs('btnOmnichannelDeliverAgentic').onclick = omnichannelAgenticDeliver;


if(qs('btnExecutiveFinanceStatusAgentic')) qs('btnExecutiveFinanceStatusAgentic').onclick = executiveFinanceAgenticStatus;
if(qs('btnExecutiveFinanceCatalogAgentic')) qs('btnExecutiveFinanceCatalogAgentic').onclick = executiveFinanceAgenticCatalog;
if(qs('btnExecutiveFinanceSeedAgentic')) qs('btnExecutiveFinanceSeedAgentic').onclick = executiveFinanceAgenticSeed;
if(qs('btnExecutiveFinanceAskAgentic')) qs('btnExecutiveFinanceAskAgentic').onclick = executiveFinanceAgenticAsk;

if(qs('btnSkillsCenterStatusAgentic')) qs('btnSkillsCenterStatusAgentic').onclick = skillsCenterAgenticStatus;
if(qs('btnSkillsCenterSkillsAgentic')) qs('btnSkillsCenterSkillsAgentic').onclick = skillsCenterAgenticSkills;
if(qs('btnSkillsCenterAgentsAgentic')) qs('btnSkillsCenterAgentsAgentic').onclick = skillsCenterAgenticAgents;
if(qs('btnSkillsCenterSeedAgentic')) qs('btnSkillsCenterSeedAgentic').onclick = skillsCenterAgenticSeed;
if(qs('btnSkillsCenterAskAgentic')) qs('btnSkillsCenterAskAgentic').onclick = skillsCenterAgenticAsk;

if(qs('btnAppFactoryStatus')) qs('btnAppFactoryStatus').onclick=appFactoryStatus;
if(qs('btnAppFactoryCatalog')) qs('btnAppFactoryCatalog').onclick=appFactoryCatalog;
if(qs('btnAppFactoryBlueprint')) qs('btnAppFactoryBlueprint').onclick=appFactoryBlueprint;
if(qs('btnAppFactoryGenerate')) qs('btnAppFactoryGenerate').onclick=appFactoryGenerate;


if(qs('btnV13AgenticStatus')) qs('btnV13AgenticStatus').onclick = () => v13AgenticGet('status');
if(qs('btnV13AgenticQuality')) qs('btnV13AgenticQuality').onclick = () => v13AgenticGet('quality-gate');
if(qs('btnV13AgenticSkills')) qs('btnV13AgenticSkills').onclick = () => v13AgenticGet('skills?seed=true');
if(qs('btnV13AgenticTemplates')) qs('btnV13AgenticTemplates').onclick = () => v13AgenticGet('templates');
if(qs('btnV13AgenticIntegrations')) qs('btnV13AgenticIntegrations').onclick = () => v13AgenticGet('integrations');
if(qs('btnV13AgenticFleet')) qs('btnV13AgenticFleet').onclick = () => v13AgenticGet('fleet');


if(qs('btnCyberAgenticStatus')) qs('btnCyberAgenticStatus').onclick = () => cyberAgenticGet('status');
if(qs('btnCyberAgenticPosture')) qs('btnCyberAgenticPosture').onclick = () => cyberAgenticGet('posture');
if(qs('btnCyberAgenticPlan')) qs('btnCyberAgenticPlan').onclick = () => cyberAgenticGet('ransomware-guard-plan');
if(qs('btnCyberAgenticBackup')) qs('btnCyberAgenticBackup').onclick = () => cyberAgenticGet('backup-readiness');
if(qs('btnCyberAgenticAlerts')) qs('btnCyberAgenticAlerts').onclick = () => cyberAgenticGet('alerts');


if(qs('btnMMAgenticStatus')) qs('btnMMAgenticStatus').onclick = () => mmAgenticGet('status');
if(qs('btnMMAgenticTest')) qs('btnMMAgenticTest').onclick = () => mmAgenticGet('status?test=true');
if(qs('btnMMAgenticBoot')) qs('btnMMAgenticBoot').onclick = () => mmAgenticGet('boot-report?test=false');
