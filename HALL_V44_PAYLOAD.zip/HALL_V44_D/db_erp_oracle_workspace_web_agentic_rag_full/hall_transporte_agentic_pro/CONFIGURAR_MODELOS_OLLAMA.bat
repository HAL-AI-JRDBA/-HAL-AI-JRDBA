@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo HAL - CONFIGURAR MODELOS OLLAMA
echo ============================================================
echo.
echo Este script baixa modelos locais. Pode demorar bastante.
echo.

where ollama >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Ollama nao encontrado no PATH.
  echo Instale Ollama primeiro: https://ollama.com
  pause
  exit /b 1
)

echo Verificando Ollama...
ollama list

echo.
echo Escolha:
echo 1 - Basico CPU/fallback: qwen2.5:7b + llava
echo 2 - Recomendado: gemma4:12b + qwen2.5:7b + llava
echo 3 - Coding adicional: qwen2.5-coder:7b
echo.
set /p OPCAO="Opcao: "

if "%OPCAO%"=="1" (
  ollama pull qwen2.5:7b
  ollama pull llava:latest
  goto fim
)

if "%OPCAO%"=="2" (
  ollama pull gemma4:12b
  ollama pull qwen2.5:7b
  ollama pull llava:latest
  goto fim
)

if "%OPCAO%"=="3" (
  ollama pull qwen2.5-coder:7b
  goto fim
)

:fim
echo.
echo [OK] Processo finalizado. Rode INICIAR_HALL_AGENTIC_PRO.bat
pause
endlocal
