from __future__ import annotations

import json
import re
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "industry_precision_engine"
PROFILE_FILE = DATA_DIR / "industry_profiles.json"
CASES_FILE = DATA_DIR / "precision_cases.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"


INDUSTRIES: dict[str, dict[str, Any]] = {
    "transporte_passageiros": {
        "label": "Transporte de Passageiros",
        "keywords": ["transporte", "passageiro", "passagens", "bilhetagem", "vale-transporte", "vale transporte", "ônibus", "onibus", "linha", "viagem", "frota", "rodoviário", "rodoviario", "urbano"],
        "processes": ["venda de passagens", "bilhetagem", "vale-transporte", "linhas/viagens", "arrecadação", "frota", "garagem", "SAC"],
        "kpis": ["passagens vendidas", "ocupação", "receita por linha", "arrecadação", "cancelamentos", "VT pendente", "SLA atendimento"],
        "systems": ["ERP Transporte", "bilhetagem", "venda de passagens", "vale-transporte", "Power BI", "Zabbix/Grafana", "bancos Oracle/SQL Server/PostgreSQL/MongoDB"],
        "example_questions": [
            "Quantas passagens foram vendidas hoje por linha?",
            "Quais empresas estão com vale-transporte pendente?",
            "Houve queda de arrecadação por veículo?",
            "Qual rota está com baixa ocupação?",
            "Quais reclamações do WhatsApp precisam de prioridade?",
        ],
    },
    "logistica": {
        "label": "Logística",
        "keywords": ["logística", "logistica", "entrega", "cte", "mdfe", "romaneio", "rota", "frete", "transportadora", "estoque", "armazém", "armazem"],
        "processes": ["roteirização", "entregas", "fretes", "armazém", "tracking", "SLA", "ocorrências"],
        "kpis": ["OTIF", "entregas no prazo", "custo por km", "frete por cliente", "ocupação do veículo", "ocorrências"],
        "systems": ["TMS", "WMS", "ERP", "rastreamento", "planilhas", "API de tracking"],
        "example_questions": [
            "Quais entregas estão atrasadas hoje?",
            "Qual rota tem maior custo por km?",
            "Gere resumo de ocorrências de entrega.",
            "Quais clientes tiveram SLA abaixo do combinado?",
            "Otimize as rotas de amanhã.",
        ],
    },
    "financeiro_contabil": {
        "label": "Financeiro / Contábil",
        "keywords": ["financeiro", "contábil", "contabil", "contas a receber", "contas a pagar", "dre", "fluxo de caixa", "conciliação", "conciliacao", "fiscal", "nf-e", "boleto"],
        "processes": ["contas a receber", "contas a pagar", "DRE", "fluxo de caixa", "conciliação", "cobrança", "fiscal"],
        "kpis": ["inadimplência", "saldo", "vencidos", "DRE", "margem", "cash burn", "previsão de caixa"],
        "systems": ["ERP Financeiro", "banco", "planilhas", "NF-e", "boletos", "Power BI"],
        "example_questions": [
            "Quais contas a receber vencidas devo priorizar?",
            "Qual previsão de caixa para os próximos 7 dias?",
            "Quais títulos estão sem conciliação?",
            "Gere DRE resumida do mês.",
            "Prepare mensagem de cobrança para aprovação.",
        ],
    },
    "varejo_atacado": {
        "label": "Varejo / Atacado",
        "keywords": ["varejo", "atacado", "loja", "pdv", "ecommerce", "estoque", "produto", "sku", "pedido", "cliente", "marketplace"],
        "processes": ["vendas", "estoque", "compras", "pricing", "campanhas", "PDV", "e-commerce"],
        "kpis": ["sell-out", "margem", "ruptura", "giro de estoque", "ticket médio", "conversão", "devoluções"],
        "systems": ["ERP Varejo", "PDV", "e-commerce", "marketplace", "CRM", "WMS", "Power BI"],
        "example_questions": [
            "Quais produtos estão com risco de ruptura?",
            "Qual margem por categoria nesta semana?",
            "Quais SKUs vendem muito e têm pouco estoque?",
            "Crie campanha para clientes inativos.",
            "Compare venda por loja e canal.",
        ],
    },
    "saude": {
        "label": "Saúde",
        "keywords": ["saúde", "saude", "clínica", "clinica", "hospital", "paciente", "agenda médica", "agenda medica", "convênio", "convenio", "consulta"],
        "processes": ["agendamento", "autorização", "faturamento", "prontuário", "atendimento", "ocupação"],
        "kpis": ["no-show", "tempo de espera", "ocupação", "glosa", "faturamento", "SLA autorização"],
        "systems": ["ERP Saúde", "agenda", "prontuário", "convênios", "faturamento"],
        "example_questions": [
            "Quais pacientes estão com risco de no-show?",
            "Quais guias estão pendentes de autorização?",
            "Qual taxa de ocupação por médico?",
            "Liste glosas por convênio.",
            "Prepare confirmação de agenda.",
        ],
    },
    "industria": {
        "label": "Indústria / Manufatura",
        "keywords": ["indústria", "industria", "produção", "producao", "chão de fábrica", "chao de fabrica", "op", "ordem de produção", "manutenção", "manutencao", "qualidade"],
        "processes": ["produção", "PCP", "qualidade", "manutenção", "estoque", "compras", "OEE"],
        "kpis": ["OEE", "refugo", "parada", "produtividade", "ordens atrasadas", "custo produção"],
        "systems": ["ERP Industrial", "MES", "SCADA", "manutenção", "qualidade", "Power BI"],
        "example_questions": [
            "Quais ordens de produção estão atrasadas?",
            "Qual máquina mais parou hoje?",
            "Gere resumo de refugo por produto.",
            "Qual OEE por linha?",
            "Quais itens críticos estão sem estoque?",
        ],
    },
    "servicos": {
        "label": "Serviços / Projetos",
        "keywords": ["serviço", "servicos", "projeto", "chamado", "os", "ordem de serviço", "consultoria", "field service", "sla"],
        "processes": ["ordens de serviço", "projetos", "SLA", "apontamento", "faturamento", "suporte"],
        "kpis": ["SLA", "backlog", "horas faturáveis", "margem por projeto", "reabertura", "tempo de resposta"],
        "systems": ["ERP Serviços", "CRM", "Service Desk", "planilhas", "Jira/GLPI/ServiceNow"],
        "example_questions": [
            "Quais chamados estão próximos de estourar SLA?",
            "Qual projeto está consumindo mais horas?",
            "Gere resumo de ordens de serviço abertas.",
            "Quais clientes têm maior backlog?",
            "Prepare relatório semanal de suporte.",
        ],
    },
    "educacao": {
        "label": "Educação",
        "keywords": ["educação", "educacao", "escola", "aluno", "matrícula", "matricula", "curso", "aula", "ead", "inadimplência escolar"],
        "processes": ["matrículas", "financeiro escolar", "atendimento", "aulas", "retenção", "campanhas"],
        "kpis": ["matrículas", "evasão", "inadimplência", "frequência", "NPS", "conversão de leads"],
        "systems": ["ERP Educacional", "LMS", "CRM", "portal aluno", "financeiro"],
        "example_questions": [
            "Quais alunos estão com risco de evasão?",
            "Quantas matrículas vieram por campanha?",
            "Liste inadimplência por turma.",
            "Prepare mensagem para alunos ausentes.",
            "Resumo de desempenho por curso.",
        ],
    },
    "generico": {
        "label": "Segmento Genérico / Corporativo",
        "keywords": ["empresa", "negócio", "negocio", "processo", "cliente", "operação", "operacao", "sistema"],
        "processes": ["atendimento", "financeiro", "vendas", "operações", "dados", "TI", "RH"],
        "kpis": ["produtividade", "SLA", "receita", "custo", "qualidade", "risco"],
        "systems": ["ERP", "CRM", "planilhas", "bancos", "APIs", "documentos", "canais"],
        "example_questions": [
            "Quais tarefas devo priorizar hoje?",
            "Resuma os principais indicadores.",
            "Quais clientes precisam de atenção?",
            "Automatize uma rotina recorrente.",
            "Gere um relatório executivo.",
        ],
    },
}


INTENTS: dict[str, dict[str, Any]] = {
    "consultar_dados": {
        "label": "Consultar dados",
        "keywords": ["quantos", "quais", "qual", "listar", "consultar", "verifique", "verificar", "analise", "analisar", "compare", "comparar"],
        "needs": ["fonte de dados", "mapeamento de entidade", "período ou filtro"],
        "default_tool": "universal_erp_connector",
    },
    "automatizar": {
        "label": "Automatizar processo",
        "keywords": ["automatizar", "automação", "automacao", "workflow", "n8n", "agendar", "rotina", "executar todo dia"],
        "needs": ["gatilho", "passos", "aprovação", "canal de entrega"],
        "default_tool": "n8n_workflow",
    },
    "atender_cliente": {
        "label": "Atender cliente/usuário",
        "keywords": ["atendimento", "responder", "whatsapp", "telegram", "email", "cliente", "sac", "mensagem"],
        "needs": ["canal", "base de conhecimento", "política de aprovação"],
        "default_tool": "channel_gateway",
    },
    "criar_relatorio": {
        "label": "Criar relatório/BI",
        "keywords": ["relatório", "relatorio", "dashboard", "power bi", "indicador", "kpi", "gráfico", "grafico"],
        "needs": ["fonte de dados", "métricas", "layout", "periodicidade"],
        "default_tool": "power_bi",
    },
    "executar_sistema_legado": {
        "label": "Operar sistema legado sem API",
        "keywords": ["navegador", "tela", "clicar", "preencher", "sistema legado", "sem api", "rpa"],
        "needs": ["URL/app", "credencial segura", "passos permitidos", "aprovação"],
        "default_tool": "browser_automation",
    },
    "desenvolver_software": {
        "label": "Desenvolver/alterar software",
        "keywords": ["código", "codigo", "programa", "alterar projeto", "gerar zip", "implementar", "corrigir erro"],
        "needs": ["escopo", "arquivos", "critério de aceite", "testes"],
        "default_tool": "dev_studio",
    },
    "responder_conhecimento": {
        "label": "Responder conhecimento geral/externo",
        "keywords": ["quem é", "quem e", "o que é", "o que e", "atual", "internet", "pesquisar", "notícia", "noticia"],
        "needs": ["fonte confiável ou web"],
        "default_tool": "reliable_web_answer",
    },
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not PROFILE_FILE.exists():
        PROFILE_FILE.write_text(json.dumps({"profiles": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not CASES_FILE.exists():
        CASES_FILE.write_text(json.dumps({"cases": []}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def status() -> dict[str, Any]:
    profiles = _load(PROFILE_FILE, {"profiles": []}).get("profiles", [])
    cases = _load(CASES_FILE, {"cases": []}).get("cases", [])
    return {
        "ok": True,
        "name": "HAL Industry Precision Engine",
        "description": "Camada para atender múltiplos segmentos com precisão controlada: classifica setor/intenção, exige fontes/mapeamentos quando necessário e evita prometer execução sem dados configurados.",
        "industries": len(INDUSTRIES),
        "intents": len(INTENTS),
        "profiles_count": len(profiles),
        "test_cases_count": len(cases),
        "truth_policy": truth_policy(),
        "capabilities": [
            "Classificação de segmento",
            "Classificação de intenção",
            "Roteamento por segmento + ferramenta",
            "Perguntas de esclarecimento quando faltar fonte de dados",
            "Resposta útil mesmo quando não há ERP conectado",
            "Onboarding de segmento",
            "Matriz de aderência por setor",
            "Casos de teste para validação",
            "Controle de precisão por evidência e confiança",
        ],
    }


def truth_policy() -> dict[str, Any]:
    return {
        "precision_total": "Não prometer precisão total. O sistema deve buscar alta precisão com fontes, testes, mapeamento e validação humana.",
        "when_data_missing": "Responder o que é possível e informar exatamente o que falta configurar.",
        "default_action": "Somente leitura por padrão.",
        "sensitive_actions": "Escrita, cancelamento, baixa, reembolso, cobrança, envio externo e exportação de dados pessoais exigem aprovação.",
        "evidence_required_for": ["números reais", "presidente/atualidades", "dados de ERP", "financeiro", "jurídico", "saúde", "decisões críticas"],
    }


def catalog() -> dict[str, Any]:
    return {
        "ok": True,
        "industries": [{"key": k, **v} for k, v in INDUSTRIES.items()],
        "intents": [{"key": k, **v} for k, v in INTENTS.items()],
    }


def classify(message: str) -> dict[str, Any]:
    t = (message or "").lower()
    industry_scores = []
    for key, meta in INDUSTRIES.items():
        score = sum(1 for kw in meta["keywords"] if kw in t)
        if score:
            industry_scores.append((score, key, meta))
    if not industry_scores:
        industry_scores = [(1, "generico", INDUSTRIES["generico"])]
    industry_scores.sort(reverse=True, key=lambda x: x[0])

    intent_scores = []
    for key, meta in INTENTS.items():
        score = sum(1 for kw in meta["keywords"] if kw in t)
        if score:
            intent_scores.append((score, key, meta))
    if not intent_scores:
        intent_scores = [(1, "consultar_dados", INTENTS["consultar_dados"])]
    intent_scores.sort(reverse=True, key=lambda x: x[0])

    i_score, industry_key, industry = industry_scores[0]
    n_score, intent_key, intent = intent_scores[0]
    confidence = min(0.95, 0.45 + 0.12 * i_score + 0.10 * n_score)

    return {
        "ok": True,
        "industry_key": industry_key,
        "industry": industry,
        "intent_key": intent_key,
        "intent": intent,
        "confidence": round(confidence, 2),
        "all_industry_scores": [{"key": k, "score": s, "label": m["label"]} for s, k, m in industry_scores[:5]],
        "all_intent_scores": [{"key": k, "score": s, "label": m["label"]} for s, k, m in intent_scores[:5]],
    }


def answer(message: str, context: dict[str, Any] | None = None, approved: bool = False) -> dict[str, Any]:
    c = classify(message)
    industry = c["industry"]
    intent = c["intent"]
    missing = required_setup(c["industry_key"], c["intent_key"], context or {})
    needs_clarification = bool(missing["critical_missing"])
    recommended = recommended_tools(c["industry_key"], c["intent_key"])

    if needs_clarification:
        text = (
            f"Entendi o pedido no segmento **{industry['label']}** com intenção de **{intent['label']}**. "
            "Para responder com precisão real, não posso inventar dados: preciso que pelo menos a fonte de dados ou o sistema esteja configurado. "
            f"O que falta agora: {', '.join(missing['critical_missing'])}. "
            "\n\nMesmo assim, já consigo preparar o caminho correto: "
            f"usar {recommended['primary_tool']} em modo somente leitura, mapear as entidades necessárias, validar período/filtro e só executar ações sensíveis com aprovação humana."
        )
        clarification = build_clarification_question(c["industry_key"], c["intent_key"], missing)
    else:
        text = (
            f"Vou atender esse pedido como **{industry['label']}**, intenção **{intent['label']}**. "
            f"A ferramenta principal deve ser **{recommended['primary_tool']}** e as ferramentas de apoio são {', '.join(recommended['support_tools'])}. "
            "A execução deve seguir a política de precisão: buscar evidência, usar conexão/mapeamento configurado, responder com resultado verificável e pedir aprovação antes de qualquer ação sensível."
        )
        clarification = ""

    result = {
        "ok": True,
        "answer": text,
        "classification": c,
        "recommended_tools": recommended,
        "missing_setup": missing,
        "clarification_question": clarification,
        "precision_contract": precision_contract(c["industry_key"], c["intent_key"]),
        "examples": industry.get("example_questions", [])[:5],
        "summary": "Resposta de segmento gerada com política de precisão e checagem de pré-requisitos.",
    }
    _audit({"event": "answer", "industry": c["industry_key"], "intent": c["intent_key"], "needs_clarification": needs_clarification})
    return result


def required_setup(industry_key: str, intent_key: str, context: dict[str, Any]) -> dict[str, Any]:
    configured = set(context.get("configured_items", []) or [])
    # padrão: tratar como não configurado até provar o contrário
    required = ["segmento escolhido", "fonte de dados", "mapeamento de entidade", "período/filtro"]
    if intent_key == "responder_conhecimento":
        required = ["pesquisa web confiável ou base RAG"]
    elif intent_key == "automatizar":
        required = ["gatilho", "workflow ou ferramenta", "canal de entrega", "regra de aprovação"]
    elif intent_key == "atender_cliente":
        required = ["canal", "base de conhecimento", "política de resposta", "aprovação para envio externo"]
    elif intent_key == "executar_sistema_legado":
        required = ["URL/app", "perfil de navegador isolado", "passos permitidos", "aprovação"]
    elif intent_key == "desenvolver_software":
        required = ["arquivos do projeto", "escopo", "testes", "critério de aceite"]
    elif intent_key == "criar_relatorio":
        required = ["fonte de dados", "métricas", "layout", "destinatário ou painel"]

    critical_missing = [r for r in required if r not in configured]
    return {
        "required": required,
        "configured": sorted(configured),
        "critical_missing": critical_missing,
        "industry_key": industry_key,
        "intent_key": intent_key,
    }


def build_clarification_question(industry_key: str, intent_key: str, missing: dict[str, Any]) -> str:
    if "fonte de dados" in missing["critical_missing"]:
        return "Qual sistema ou banco devo usar para responder isso? Pode ser ERP, banco Oracle/SQL Server/PostgreSQL/MongoDB, API, planilha, n8n ou sistema via navegador."
    if "canal" in missing["critical_missing"]:
        return "Qual canal devo usar: WhatsApp, Telegram, e-mail, Slack, Teams, Discord ou Web Chat?"
    if "URL/app" in missing["critical_missing"]:
        return "Qual é o sistema, tela ou URL que devo operar via navegador/RPA?"
    return "Qual informação ainda falta para eu executar com precisão: fonte, período, entidade, canal, aprovação ou credencial?"


def recommended_tools(industry_key: str, intent_key: str) -> dict[str, Any]:
    primary = INTENTS.get(intent_key, INTENTS["consultar_dados"])["default_tool"]
    support = ["visual_mission_control", "sandbox_enterprise", "cron_enterprise"]
    if primary == "universal_erp_connector":
        support = ["visual_mission_control", "reliable_web_answer", "power_bi", "sandbox_enterprise"]
    elif primary == "n8n_workflow":
        support = ["channel_gateway", "cron_enterprise", "sandbox_enterprise"]
    elif primary == "channel_gateway":
        support = ["reliable_web_answer", "rag", "human_voice", "visual_mission_control"]
    elif primary == "browser_automation":
        support = ["sandbox_enterprise", "visual_mission_control", "human_approval"]
    elif primary == "reliable_web_answer":
        support = ["rag", "ollama", "source_validation"]
    return {"primary_tool": primary, "support_tools": support}


def precision_contract(industry_key: str, intent_key: str) -> dict[str, Any]:
    return {
        "answer_must_include": [
            "resposta direta quando houver dados/fonte",
            "fonte usada ou sistema consultado",
            "limitações quando faltar configuração",
            "próxima ação clara",
        ],
        "must_not_do": [
            "inventar número do ERP",
            "fingir conexão com sistema não configurado",
            "executar escrita sem aprovação",
            "dar resposta genérica sem plano ou pergunta de esclarecimento",
        ],
        "validation": [
            "testar com 10 perguntas por segmento",
            "comparar resposta esperada x resposta gerada",
            "registrar confiança e causa de falha",
            "corrigir roteamento e prompts de cada segmento",
        ],
    }


def create_industry_profile(industry_key: str, company_name: str, systems: list[dict[str, Any]] | None = None, processes: list[str] | None = None, approval_level: str = "safe") -> dict[str, Any]:
    if industry_key not in INDUSTRIES:
        return {"ok": False, "summary": "Segmento não suportado.", "available": list(INDUSTRIES)}
    data = _load(PROFILE_FILE, {"profiles": []})
    pid = f"profile_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    profile = {
        "id": pid,
        "company_name": company_name,
        "industry_key": industry_key,
        "industry_label": INDUSTRIES[industry_key]["label"],
        "systems": systems or [],
        "processes": processes or INDUSTRIES[industry_key]["processes"],
        "approval_level": approval_level,
        "created_at": _now(),
        "precision_readiness": readiness_score(systems or [], processes or []),
    }
    data.setdefault("profiles", []).insert(0, profile)
    _save(PROFILE_FILE, data)
    _audit({"event": "create_profile", "profile_id": pid, "industry": industry_key})
    return {"ok": True, "profile": profile, "summary": "Perfil de segmento criado."}


def readiness_score(systems: list[dict[str, Any]], processes: list[str]) -> dict[str, Any]:
    score = 10
    if systems:
        score += 45
    if processes:
        score += 20
    if any(s.get("type") in {"database", "api_rest", "api_soap", "file", "browser_rpa", "n8n"} for s in systems):
        score += 15
    if any(s.get("mapped") for s in systems):
        score += 10
    score = min(100, score)
    return {
        "score": score,
        "label": "baixo" if score < 40 else "médio" if score < 75 else "alto",
        "explanation": "Quanto mais sistemas, campos, processos e testes estiverem mapeados, maior a precisão real.",
    }


def list_profiles(limit: int = 100) -> dict[str, Any]:
    profiles = _load(PROFILE_FILE, {"profiles": []}).get("profiles", [])
    return {"ok": True, "profiles": profiles[:max(1, min(limit, 500))], "count": len(profiles)}


def create_test_case(industry_key: str, question: str, expected_behavior: str, expected_tool: str = "") -> dict[str, Any]:
    if industry_key not in INDUSTRIES:
        industry_key = "generico"
    data = _load(CASES_FILE, {"cases": []})
    case = {
        "id": f"case_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "industry_key": industry_key,
        "question": question,
        "expected_behavior": expected_behavior,
        "expected_tool": expected_tool,
        "created_at": _now(),
    }
    data.setdefault("cases", []).insert(0, case)
    _save(CASES_FILE, data)
    _audit({"event": "create_test_case", "industry": industry_key})
    return {"ok": True, "case": case, "summary": "Caso de teste criado."}


def seed_precision_tests() -> dict[str, Any]:
    created = []
    for industry_key, meta in INDUSTRIES.items():
        for q in meta.get("example_questions", [])[:3]:
            expected_tool = "universal_erp_connector"
            if any(x in q.lower() for x in ["mensagem", "whatsapp", "atendimento"]):
                expected_tool = "channel_gateway"
            created.append(create_test_case(industry_key, q, "Responder com dados reais se fonte estiver configurada; se não, pedir a fonte sem inventar.", expected_tool)["case"])
    return {"ok": True, "created": len(created), "summary": "Casos de teste por segmento criados."}


def run_precision_tests(limit: int = 100) -> dict[str, Any]:
    cases = _load(CASES_FILE, {"cases": []}).get("cases", [])[:max(1, min(limit, 500))]
    results = []
    for case in cases:
        c = classify(case["question"])
        expected_tool = case.get("expected_tool") or ""
        actual_tool = recommended_tools(c["industry_key"], c["intent_key"])["primary_tool"]
        passed = (not expected_tool) or (expected_tool == actual_tool)
        results.append({
            "case_id": case["id"],
            "question": case["question"],
            "industry_expected": case["industry_key"],
            "industry_actual": c["industry_key"],
            "tool_expected": expected_tool,
            "tool_actual": actual_tool,
            "passed": passed,
        })
    passed_count = len([r for r in results if r["passed"]])
    return {
        "ok": True,
        "total": len(results),
        "passed": passed_count,
        "failed": len(results) - passed_count,
        "pass_rate": round((passed_count / len(results)) * 100, 2) if results else 0,
        "results": results,
    }


def answer_for_router(message: str = "") -> str:
    return answer(message).get("answer", "")
