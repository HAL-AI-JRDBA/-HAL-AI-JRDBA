from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "visual_mission_control"
CONFIG_FILE = DATA_DIR / "config.json"
MISSIONS_FILE = DATA_DIR / "missions.json"
EVENTS_FILE = DATA_DIR / "events.jsonl"
NOTES_FILE = DATA_DIR / "daily_notes.json"
APPROVALS_FILE = DATA_DIR / "approvals.json"


ROOMS: dict[str, dict[str, Any]] = {
    "executivo": {
        "label": "Sala Executiva",
        "x": 50,
        "y": 60,
        "color": "#f7d774",
        "description": "Visão geral, riscos, aprovações e decisões.",
    },
    "financeiro": {
        "label": "Financeiro / Contábil",
        "x": 230,
        "y": 80,
        "color": "#22c55e",
        "description": "Contas a receber, cobrança, DRE, conciliação, vale-transporte e receitas.",
    },
    "atendimento": {
        "label": "Atendimento / Canais",
        "x": 430,
        "y": 90,
        "color": "#38bdf8",
        "description": "WhatsApp, Telegram, Slack, Teams, Discord, e-mail e webchat.",
    },
    "ti_dba": {
        "label": "TI / DBA / Monitoramento",
        "x": 630,
        "y": 80,
        "color": "#a78bfa",
        "description": "Zabbix, Grafana, Oracle, SQL Server, incidentes e performance.",
    },
    "dados_bi": {
        "label": "Dados / BI",
        "x": 130,
        "y": 270,
        "color": "#60a5fa",
        "description": "SQL, NoSQL, Power BI, indicadores, RAG e relatórios.",
    },
    "operacoes": {
        "label": "Operações / Transporte",
        "x": 350,
        "y": 300,
        "color": "#fb923c",
        "description": "Venda de passagens, bilhetagem, linhas, viagens, frota e vale-transporte.",
    },
    "automacoes": {
        "label": "n8n / Browser / Cron",
        "x": 570,
        "y": 300,
        "color": "#ec4899",
        "description": "Workflows, navegador controlado, rotinas recorrentes e integrações.",
    },
    "sandbox": {
        "label": "Sandbox / Dev / Segurança",
        "x": 770,
        "y": 285,
        "color": "#14b8a6",
        "description": "Docker, testes, patches, logs imutáveis, cofre de credenciais e aprovação.",
    },
}

AGENTS: dict[str, dict[str, Any]] = {
    "hall": {
        "label": "HAL Orquestrador",
        "room": "executivo",
        "avatar": "H",
        "role": "Recebe pedidos, escolhe ferramentas, coordena agentes e pede aprovação quando necessário.",
        "skills": ["roteamento", "planejamento", "aprovação", "voz", "resumo executivo"],
    },
    "financeiro": {
        "label": "Agente Financeiro",
        "room": "financeiro",
        "avatar": "F",
        "role": "Analisa contas, cobrança, DRE, inadimplência, conciliação e vale-transporte.",
        "skills": ["contas a receber", "cobrança", "DRE", "vale-transporte", "conciliação"],
    },
    "atendimento": {
        "label": "Agente Atendimento",
        "room": "atendimento",
        "avatar": "A",
        "role": "Atende clientes e usuários por canais externos com tom humanizado.",
        "skills": ["WhatsApp", "Telegram", "e-mail", "webchat", "escalonamento"],
    },
    "ti_dba": {
        "label": "Agente TI/DBA",
        "room": "ti_dba",
        "avatar": "D",
        "role": "Diagnostica incidentes, bancos, alertas, logs e performance.",
        "skills": ["Oracle", "SQL Server", "Zabbix", "Grafana", "logs"],
    },
    "dados_bi": {
        "label": "Agente Dados/BI",
        "room": "dados_bi",
        "avatar": "B",
        "role": "Consulta bancos, cruza dados, cria indicadores e relatórios.",
        "skills": ["SQL", "MongoDB", "Power BI", "RAG", "dashboards"],
    },
    "operacoes": {
        "label": "Agente Operações",
        "room": "operacoes",
        "avatar": "O",
        "role": "Monitora operação, viagens, bilhetagem, venda de passagens e produtividade.",
        "skills": ["venda de passagens", "bilhetagem", "linhas", "viagens", "frota"],
    },
    "vendas": {
        "label": "Agente Vendas/SDR",
        "room": "atendimento",
        "avatar": "V",
        "role": "Qualifica leads, prepara propostas e acompanha oportunidades.",
        "skills": ["CRM", "leads", "propostas", "follow-up", "campanhas"],
    },
    "n8n": {
        "label": "Agente n8n",
        "room": "automacoes",
        "avatar": "N",
        "role": "Aciona workflows determinísticos e integrações por webhook/API.",
        "skills": ["n8n", "webhook", "workflow", "callback", "integração"],
    },
    "browser": {
        "label": "Agente Browser",
        "room": "automacoes",
        "avatar": "W",
        "role": "Usa navegador isolado para sistemas sem API.",
        "skills": ["Playwright", "Selenium", "screenshot", "clique", "preenchimento"],
    },
    "cron": {
        "label": "Agente Cron",
        "room": "automacoes",
        "avatar": "C",
        "role": "Mantém rotinas agendadas e tarefas recorrentes.",
        "skills": ["cron", "scheduler", "retry", "serviço", "rotina"],
    },
    "sandbox": {
        "label": "Agente Sandbox",
        "room": "sandbox",
        "avatar": "S",
        "role": "Executa testes e código em ambiente isolado.",
        "skills": ["Docker", "limites", "segurança", "testes", "patch"],
    },
    "framework": {
        "label": "Agente Framework",
        "room": "sandbox",
        "avatar": "G",
        "role": "Integra CrewAI, LangGraph, MCP, AutoGen, OpenClaw e runtime nativo.",
        "skills": ["CrewAI", "LangGraph", "MCP", "AutoGen", "OpenClaw"],
    },
}


STATUS_LABELS = {
    "idle": "Disponível",
    "working": "Trabalhando",
    "waiting_approval": "Aguardando aprovação",
    "done": "Concluído",
    "error": "Erro",
    "paused": "Pausado",
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text(json.dumps(default_config(), ensure_ascii=False, indent=2), encoding="utf-8")
    if not MISSIONS_FILE.exists():
        MISSIONS_FILE.write_text(json.dumps({"missions": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not NOTES_FILE.exists():
        NOTES_FILE.write_text(json.dumps({"notes": default_notes()}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not APPROVALS_FILE.exists():
        APPROVALS_FILE.write_text(json.dumps({"approvals": []}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _event(event: dict[str, Any]) -> None:
    _ensure()
    with EVENTS_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def default_config() -> dict[str, Any]:
    return {
        "enabled": True,
        "theme": "futuristic_office",
        "mode": "operation",
        "presentation_mode": True,
        "auto_refresh_seconds": 5,
        "show_agent_avatars": True,
        "show_rooms": True,
        "show_productivity": True,
        "show_approval_queue": True,
        "show_daily_notes": True,
        "show_runtime_health": True,
        "visual_style": {
            "background": "futuristic_grid_office",
            "avatar_style": "pixel_agents",
            "hall_center": True,
            "motion": "soft_pulse",
        },
        "integrations": {
            "agent_runtime": True,
            "business_teams": True,
            "channel_gateway": True,
            "n8n": True,
            "browser_automation": True,
            "cron_enterprise": True,
            "sandbox_enterprise": True,
            "framework_bridge": True,
            "erp_connector": True,
        },
    }


def default_notes() -> list[dict[str, Any]]:
    return [
        {"id": "note_1", "text": "Validar missões aguardando aprovação humana.", "status": "open"},
        {"id": "note_2", "text": "Acompanhar agentes com erro ou rotina indisponível.", "status": "open"},
        {"id": "note_3", "text": "Revisar vendas de passagens, vale-transporte e indicadores financeiros.", "status": "open"},
    ]


def status() -> dict[str, Any]:
    missions = _load(MISSIONS_FILE, {"missions": []}).get("missions", [])
    approvals = _load(APPROVALS_FILE, {"approvals": []}).get("approvals", [])
    return {
        "ok": True,
        "name": "HAL Visual Mission Control",
        "description": "Painel visual estilo escritório digital para acompanhar agentes, missões, salas, aprovações, produtividade e integrações.",
        "rooms_count": len(ROOMS),
        "agents_count": len(AGENTS),
        "missions_count": len(missions),
        "active_missions": len([m for m in missions if m.get("status") in {"working", "waiting_approval", "paused"}]),
        "approvals_pending": len([a for a in approvals if a.get("status") == "pending"]),
        "capabilities": [
            "Mapa visual futurístico dos agentes",
            "Salas por área de negócio",
            "Avatares/status dos agentes",
            "Missões ativas, concluídas, com erro e aguardando aprovação",
            "Notas do dia",
            "Fila de aprovações",
            "Indicadores de produtividade",
            "Modo apresentação para clientes",
            "Modo operação para usuários internos",
            "Integração conceitual com Agent Runtime, canais, n8n, browser, cron, sandbox, ERP e BI",
        ],
    }


def config() -> dict[str, Any]:
    return {"ok": True, "config": _load(CONFIG_FILE, default_config())}


def update_config(changes: dict[str, Any]) -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, default_config())
    cfg.update(changes or {})
    _save(CONFIG_FILE, cfg)
    _event({"event": "update_config"})
    return {"ok": True, "config": cfg, "summary": "Configuração do Mission Control atualizada."}


def rooms() -> dict[str, Any]:
    return {"ok": True, "rooms": [{"id": key, **value} for key, value in ROOMS.items()]}


def agents() -> dict[str, Any]:
    states = agent_states()
    result = []
    for key, value in AGENTS.items():
        room = ROOMS.get(value["room"], {})
        state = states.get(key, {"status": "idle", "missions": 0})
        result.append({"id": key, **value, "room_info": room, "state": state})
    return {"ok": True, "agents": result}


def agent_states() -> dict[str, Any]:
    missions = _load(MISSIONS_FILE, {"missions": []}).get("missions", [])
    states: dict[str, Any] = {key: {"status": "idle", "missions": 0, "current": ""} for key in AGENTS}
    for mission in missions:
        status_value = mission.get("status", "idle")
        for aid in mission.get("agents", []):
            st = states.setdefault(aid, {"status": "idle", "missions": 0, "current": ""})
            st["missions"] += 1
            if status_value in {"error", "waiting_approval", "working", "paused"}:
                priority = {"error": 4, "waiting_approval": 3, "working": 2, "paused": 1, "idle": 0}
                if priority.get(status_value, 0) >= priority.get(st.get("status", "idle"), 0):
                    st["status"] = status_value
                    st["current"] = mission.get("title", "")
    return states


def infer_agents(text: str, explicit_agents: list[str] | None = None) -> list[str]:
    if explicit_agents:
        return [a for a in explicit_agents if a in AGENTS] or ["hall"]
    t = (text or "").lower()
    selected = ["hall"]
    mapping = {
        "financeiro": ["financeiro", "contas", "cobrança", "cobranca", "dre", "pagamento", "vale-transporte", "vale transporte"],
        "atendimento": ["atendimento", "cliente", "whatsapp", "telegram", "e-mail", "email", "sac"],
        "ti_dba": ["oracle", "sql server", "zabbix", "grafana", "banco lento", "dba", "incidente", "servidor"],
        "dados_bi": ["power bi", "dashboard", "indicador", "sql", "mongodb", "relatório", "relatorio", "dados"],
        "operacoes": ["passagem", "passagens", "bilhetagem", "linha", "viagem", "frota", "operação", "operacao"],
        "vendas": ["vendas", "lead", "crm", "proposta", "sdr"],
        "n8n": ["n8n", "workflow", "webhook"],
        "browser": ["navegador", "playwright", "selenium", "clicar", "preencher", "screenshot"],
        "cron": ["agendar", "cron", "todo dia", "toda semana", "scheduler"],
        "sandbox": ["sandbox", "docker", "teste", "patch", "código", "codigo"],
        "framework": ["crewai", "langgraph", "mcp", "autogen", "openclaw"],
    }
    for agent, words in mapping.items():
        if any(w in t for w in words):
            selected.append(agent)
    # manter ordem e remover duplicidade
    seen = set()
    return [x for x in selected if not (x in seen or seen.add(x))]


def create_mission(
    title: str,
    objective: str,
    agents_list: list[str] | None = None,
    priority: str = "normal",
    source: str = "hall",
    requires_approval: bool = False,
    presentation: bool = False,
) -> dict[str, Any]:
    selected_agents = infer_agents(objective or title, agents_list)
    missions = _load(MISSIONS_FILE, {"missions": []})
    mid = f"mission_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    mission = {
        "id": mid,
        "title": title or "Missão HAL",
        "objective": objective or title,
        "agents": selected_agents,
        "priority": priority,
        "source": source,
        "status": "waiting_approval" if requires_approval else "working",
        "progress": 0 if requires_approval else 10,
        "requires_approval": requires_approval,
        "presentation": presentation,
        "created_at": _now(),
        "updated_at": _now(),
        "steps": build_steps(objective or title, selected_agents, requires_approval),
        "result_summary": "",
        "business_value": business_value(objective or title),
    }
    missions.setdefault("missions", []).insert(0, mission)
    _save(MISSIONS_FILE, missions)
    if requires_approval:
        add_approval(mid, f"Aprovar início da missão: {mission['title']}", "mission_start")
    _event({"event": "create_mission", "mission_id": mid, "agents": selected_agents})
    return {"ok": True, "mission": mission, "summary": "Missão criada no painel visual."}


def build_steps(objective: str, agents_list: list[str], requires_approval: bool) -> list[dict[str, Any]]:
    steps = [
        {"id": "understand_goal", "label": "Entender objetivo", "status": "done"},
        {"id": "choose_agents", "label": "Escolher agentes", "status": "done", "agents": agents_list},
        {"id": "collect_context", "label": "Coletar contexto em ERP, dados, canais ou documentos", "status": "pending"},
        {"id": "execute_tools", "label": "Executar ferramentas corretas", "status": "pending"},
        {"id": "validate_result", "label": "Validar resultado e riscos", "status": "pending"},
        {"id": "deliver_summary", "label": "Entregar resumo e próximos passos", "status": "pending"},
    ]
    if requires_approval:
        steps.insert(2, {"id": "human_approval", "label": "Aprovação humana", "status": "waiting_approval", "requires_approval": True})
    return steps


def business_value(objective: str) -> dict[str, Any]:
    t = (objective or "").lower()
    if any(x in t for x in ["passagem", "bilhetagem", "vale-transporte", "vale transporte"]):
        return {"area": "Transporte", "gain": "Acelera consulta operacional, reduz retrabalho e melhora controle de receita."}
    if any(x in t for x in ["financeiro", "cobrança", "cobranca", "contas"]):
        return {"area": "Financeiro", "gain": "Ajuda a priorizar recebíveis, reduzir atraso e padronizar análise."}
    if any(x in t for x in ["whatsapp", "atendimento", "cliente"]):
        return {"area": "Atendimento", "gain": "Reduz fila, padroniza respostas e melhora SLA."}
    if any(x in t for x in ["zabbix", "grafana", "oracle", "incidente"]):
        return {"area": "TI/DBA", "gain": "Reduz tempo de diagnóstico e melhora priorização de incidentes."}
    return {"area": "Corporativo", "gain": "Aumenta produtividade com agentes 24x7 e governança."}


def add_approval(mission_id: str, title: str, approval_type: str = "generic") -> dict[str, Any]:
    data = _load(APPROVALS_FILE, {"approvals": []})
    approval = {
        "id": f"appr_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "mission_id": mission_id,
        "title": title,
        "type": approval_type,
        "status": "pending",
        "created_at": _now(),
    }
    data.setdefault("approvals", []).insert(0, approval)
    _save(APPROVALS_FILE, data)
    _event({"event": "add_approval", "mission_id": mission_id, "approval_id": approval["id"]})
    return {"ok": True, "approval": approval}


def approve(approval_id: str) -> dict[str, Any]:
    data = _load(APPROVALS_FILE, {"approvals": []})
    changed = None
    for appr in data.get("approvals", []):
        if appr.get("id") == approval_id:
            appr["status"] = "approved"
            appr["approved_at"] = _now()
            changed = appr
            break
    if not changed:
        return {"ok": False, "summary": "Aprovação não encontrada."}
    _save(APPROVALS_FILE, data)
    # liberar missão associada
    missions = _load(MISSIONS_FILE, {"missions": []})
    for m in missions.get("missions", []):
        if m.get("id") == changed.get("mission_id") and m.get("status") == "waiting_approval":
            m["status"] = "working"
            m["progress"] = max(m.get("progress", 0), 15)
            m["updated_at"] = _now()
    _save(MISSIONS_FILE, missions)
    _event({"event": "approve", "approval_id": approval_id})
    return {"ok": True, "approval": changed, "summary": "Aprovação realizada."}


def list_approvals(limit: int = 100) -> dict[str, Any]:
    approvals = _load(APPROVALS_FILE, {"approvals": []}).get("approvals", [])
    return {"ok": True, "approvals": approvals[:max(1, min(limit, 500))], "count": len(approvals)}


def list_missions(status_filter: str = "", limit: int = 100) -> dict[str, Any]:
    missions = _load(MISSIONS_FILE, {"missions": []}).get("missions", [])
    if status_filter:
        missions = [m for m in missions if m.get("status") == status_filter]
    return {"ok": True, "missions": missions[:max(1, min(limit, 500))], "count": len(missions)}


def update_mission(mission_id: str, status_value: str = "", progress: int | None = None, result_summary: str = "") -> dict[str, Any]:
    data = _load(MISSIONS_FILE, {"missions": []})
    for mission in data.get("missions", []):
        if mission.get("id") == mission_id:
            if status_value:
                mission["status"] = status_value
            if progress is not None:
                mission["progress"] = max(0, min(100, int(progress)))
            if result_summary:
                mission["result_summary"] = result_summary
            mission["updated_at"] = _now()
            if mission.get("progress", 0) >= 100 and mission.get("status") != "error":
                mission["status"] = "done"
            _save(MISSIONS_FILE, data)
            _event({"event": "update_mission", "mission_id": mission_id, "status": mission.get("status"), "progress": mission.get("progress")})
            return {"ok": True, "mission": mission, "summary": "Missão atualizada."}
    return {"ok": False, "summary": "Missão não encontrada."}


def advance_mission(mission_id: str) -> dict[str, Any]:
    data = _load(MISSIONS_FILE, {"missions": []})
    for mission in data.get("missions", []):
        if mission.get("id") == mission_id:
            if mission.get("status") == "waiting_approval":
                return {"ok": False, "summary": "Missão aguarda aprovação humana.", "mission": mission}
            mission["progress"] = min(100, mission.get("progress", 0) + 20)
            if mission["progress"] >= 100:
                mission["status"] = "done"
                mission["result_summary"] = mission.get("result_summary") or "Missão concluída com sucesso."
            else:
                mission["status"] = "working"
            mission["updated_at"] = _now()
            # atualizar primeiro step pendente
            for step in mission.get("steps", []):
                if step.get("status") == "pending":
                    step["status"] = "done"
                    break
            _save(MISSIONS_FILE, data)
            _event({"event": "advance_mission", "mission_id": mission_id, "progress": mission["progress"]})
            return {"ok": True, "mission": mission, "summary": "Missão avançada."}
    return {"ok": False, "summary": "Missão não encontrada."}


def notes() -> dict[str, Any]:
    return {"ok": True, **_load(NOTES_FILE, {"notes": default_notes()})}


def add_note(text: str) -> dict[str, Any]:
    data = _load(NOTES_FILE, {"notes": default_notes()})
    note = {"id": f"note_{uuid.uuid4().hex[:8]}", "text": text, "status": "open", "created_at": _now()}
    data.setdefault("notes", []).insert(0, note)
    _save(NOTES_FILE, data)
    _event({"event": "add_note", "note_id": note["id"]})
    return {"ok": True, "note": note, "summary": "Nota adicionada."}


def metrics() -> dict[str, Any]:
    missions = _load(MISSIONS_FILE, {"missions": []}).get("missions", [])
    total = len(missions)
    done = len([m for m in missions if m.get("status") == "done"])
    working = len([m for m in missions if m.get("status") == "working"])
    waiting = len([m for m in missions if m.get("status") == "waiting_approval"])
    error = len([m for m in missions if m.get("status") == "error"])
    paused = len([m for m in missions if m.get("status") == "paused"])
    estimated_minutes_saved = sum(25 + len(m.get("agents", [])) * 10 for m in missions if m.get("status") == "done")
    return {
        "ok": True,
        "metrics": {
            "total": total,
            "done": done,
            "working": working,
            "waiting_approval": waiting,
            "error": error,
            "paused": paused,
            "completion_rate": round((done / total) * 100, 2) if total else 0,
            "estimated_minutes_saved": estimated_minutes_saved,
            "estimated_hours_saved": round(estimated_minutes_saved / 60, 2),
        },
    }


def visual_map() -> dict[str, Any]:
    states = agent_states()
    agent_nodes = []
    for aid, agent in AGENTS.items():
        room = ROOMS.get(agent["room"], {})
        # espalhar agentes dentro da sala
        offset = abs(hash(aid)) % 42
        agent_nodes.append(
            {
                "id": aid,
                "label": agent["label"],
                "avatar": agent["avatar"],
                "room": agent["room"],
                "x": room.get("x", 0) + (offset % 36),
                "y": room.get("y", 0) + (offset // 6) * 8,
                "status": states.get(aid, {}).get("status", "idle"),
                "status_label": STATUS_LABELS.get(states.get(aid, {}).get("status", "idle"), "Disponível"),
                "current": states.get(aid, {}).get("current", ""),
                "skills": agent["skills"],
            }
        )
    return {
        "ok": True,
        "map": {
            "width": 920,
            "height": 520,
            "theme": "futuristic_office",
            "rooms": [{"id": key, **value} for key, value in ROOMS.items()],
            "agents": agent_nodes,
        },
        "metrics": metrics()["metrics"],
        "notes": notes()["notes"],
        "approvals": list_approvals(20)["approvals"],
        "missions": list_missions(limit=20)["missions"],
    }


def presentation_snapshot() -> dict[str, Any]:
    vm = visual_map()
    return {
        "ok": True,
        "title": "HAL Visual Mission Control",
        "subtitle": "Meus agentes estão trabalhando",
        "headline": {
            "done": vm["metrics"]["done"],
            "working": vm["metrics"]["working"],
            "waiting_approval": vm["metrics"]["waiting_approval"],
            "error": vm["metrics"]["error"],
            "hours_saved": vm["metrics"]["estimated_hours_saved"],
        },
        "story": [
            "O HAL recebe o pedido do usuário.",
            "Escolhe a ferramenta correta automaticamente.",
            "Distribui a missão para agentes especializados.",
            "Mostra o trabalho acontecendo em tempo real.",
            "Pede aprovação humana em ações sensíveis.",
            "Entrega resultado, evidência e produtividade mensurável.",
        ],
        "visual": vm["map"],
        "missions": vm["missions"],
    }


def seed_demo() -> dict[str, Any]:
    demo_missions = [
        ("Analisar venda de passagens de hoje", "Verificar venda de passagens, linhas com queda e receita do dia.", ["hall", "operacoes", "dados_bi"], "working"),
        ("Vale-transporte pendente", "Listar empresas com vale-transporte pendente de pagamento e preparar mensagem.", ["hall", "financeiro", "operacoes", "atendimento"], "waiting_approval"),
        ("Alertas Oracle/Zabbix", "Verificar alertas críticos do Zabbix, Grafana e Oracle.", ["hall", "ti_dba"], "working"),
        ("Resumo executivo diário", "Gerar briefing executivo com indicadores, riscos e aprovações.", ["hall", "dados_bi"], "done"),
        ("Workflow n8n de atendimento", "Acionar workflow n8n para classificar mensagens de WhatsApp.", ["hall", "n8n", "atendimento"], "working"),
    ]
    created = []
    for title, objective, ags, st in demo_missions:
        item = create_mission(title, objective, ags, priority="normal", requires_approval=(st == "waiting_approval"), presentation=True)["mission"]
        item["status"] = st
        item["progress"] = {"done": 100, "working": 45, "waiting_approval": 10}.get(st, 0)
        created.append(item)
    # salvar ajustes
    data = _load(MISSIONS_FILE, {"missions": []})
    byid = {m["id"]: m for m in created}
    for m in data.get("missions", []):
        if m["id"] in byid:
            m.update(byid[m["id"]])
    _save(MISSIONS_FILE, data)
    return {"ok": True, "created": created, "summary": "Demo do Mission Control criada."}


def answer_for_visual_mission(message: str = "") -> str:
    return (
        "Vou usar o HAL Visual Mission Control. "
        "Ele mostra um escritório digital futurístico com agentes por área, missões em andamento, concluídas, com erro ou aguardando aprovação. "
        "É a visão executiva para demonstrar que os agentes estão trabalhando em ERP, banco de dados, canais, n8n, navegador, cron, sandbox, vendas de passagens e vale-transporte."
    )
