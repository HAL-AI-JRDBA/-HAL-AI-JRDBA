from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _slug(text: str) -> str:
    import re
    text = (text or "item").lower()
    text = re.sub(r"[^a-z0-9áéíóúãõâêôç]+", "-", text)
    text = (text.replace("á","a").replace("é","e").replace("í","i").replace("ó","o").replace("ú","u")
            .replace("ã","a").replace("õ","o").replace("â","a").replace("ê","e").replace("ô","o").replace("ç","c"))
    return re.sub(r"-+", "-", text).strip("-") or "item"


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(path: Path, event: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")

DATA_DIR = root_dir() / "data" / "agent_framework_bridge"
CONFIG_FILE = DATA_DIR / "frameworks.json"
RUNS_FILE = DATA_DIR / "bridge_runs.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"

FRAMEWORKS: dict[str, dict[str, Any]] = {
    "crewai": {"label": "CrewAI", "status": "adapter_ready", "best_for": "equipes de agentes com papéis e tarefas", "install": "pip install crewai"},
    "langgraph": {"label": "LangGraph", "status": "adapter_ready", "best_for": "grafos de estado, agentes duráveis e workflows controlados", "install": "pip install langgraph"},
    "autogen": {"label": "AutoGen", "status": "adapter_plan", "best_for": "conversas multiagentes e coordenação", "install": "pip install pyautogen"},
    "mcp": {"label": "MCP Tools", "status": "adapter_ready", "best_for": "ferramentas padronizadas conectadas a agentes", "install": "configurar servidores MCP"},
    "openclaw": {"label": "OpenClaw", "status": "external_bridge_ready", "best_for": "gateway de agentes/canais/automação", "install": "instalar OpenClaw externo quando necessário"},
    "jr_ai_native": {"label": "JR-AI Native Runtime", "status": "ready", "best_for": "runtime local nativo do HAL", "install": "incluído no projeto"},
}


def _defaults() -> dict[str, Any]:
    return {
        "enabled": True,
        "active_frameworks": ["jr_ai_native"],
        "default_framework": "jr_ai_native",
        "allow_external_frameworks": False,
        "human_approval_for_external_runs": True,
        "frameworks": {k: {"enabled": k == "jr_ai_native", **v} for k, v in FRAMEWORKS.items()},
    }


def status() -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, _defaults())
    runs = _load(RUNS_FILE, {"runs": []}).get("runs", [])
    return {
        "ok": True,
        "name": "HAL Agent Framework Bridge",
        "description": "Ponte para CrewAI, LangGraph, AutoGen, MCP, OpenClaw e runtime nativo JR-AI.",
        "frameworks_supported": len(FRAMEWORKS),
        "active_frameworks": cfg.get("active_frameworks", []),
        "runs_count": len(runs),
        "capabilities": [
            "Escolher framework por tipo de tarefa",
            "Registrar execução multiagente",
            "Gerar esqueleto de integração CrewAI/LangGraph/MCP",
            "Manter JR-AI Native Runtime como padrão local",
            "Exigir aprovação para frameworks externos",
        ],
    }


def frameworks() -> dict[str, Any]:
    return {"ok": True, "frameworks": [{"key": k, **v} for k, v in FRAMEWORKS.items()], "config": _load(CONFIG_FILE, _defaults())}


def configure_framework(framework: str, enabled: bool = True) -> dict[str, Any]:
    if framework not in FRAMEWORKS:
        return {"ok": False, "summary": "Framework não suportado.", "available": list(FRAMEWORKS)}
    cfg = _load(CONFIG_FILE, _defaults())
    cfg["frameworks"].setdefault(framework, {}).update({"enabled": enabled, **FRAMEWORKS[framework]})
    if enabled and framework not in cfg["active_frameworks"]:
        cfg["active_frameworks"].append(framework)
    if not enabled:
        cfg["active_frameworks"] = [f for f in cfg.get("active_frameworks", []) if f != framework]
    _save(CONFIG_FILE, cfg)
    _audit(AUDIT_FILE, {"event": "configure_framework", "framework": framework, "enabled": enabled})
    return {"ok": True, "config": cfg, "summary": "Framework atualizado."}


def recommend_framework(goal: str) -> dict[str, Any]:
    t = (goal or "").lower()
    if any(x in t for x in ["grafo", "estado", "checkpoint", "durável", "duravel", "workflow complexo"]):
        choice = "langgraph"
    elif any(x in t for x in ["time de agentes", "papéis", "papeis", "equipe", "crew"]):
        choice = "crewai"
    elif any(x in t for x in ["mcp", "tool", "ferramenta externa", "servidor"]):
        choice = "mcp"
    elif any(x in t for x in ["canal", "whatsapp", "telegram", "openclaw"]):
        choice = "openclaw"
    else:
        choice = "jr_ai_native"
    return {"ok": True, "recommended": choice, "framework": FRAMEWORKS[choice], "goal": goal}


def create_bridge_run(goal: str, framework: str = "", approved: bool = False) -> dict[str, Any]:
    rec = recommend_framework(goal)
    fw = framework or rec["recommended"]
    if fw not in FRAMEWORKS:
        return {"ok": False, "summary": "Framework não suportado."}
    cfg = _load(CONFIG_FILE, _defaults())
    external = fw != "jr_ai_native"
    status_value = "waiting_approval" if external and cfg.get("human_approval_for_external_runs", True) and not approved else "planned"
    run = {
        "id": f"bridge_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "goal": goal,
        "framework": fw,
        "framework_label": FRAMEWORKS[fw]["label"],
        "approved": approved,
        "status": status_value,
        "created_at": _now(),
        "skeleton": skeleton_for(fw, goal),
    }
    data = _load(RUNS_FILE, {"runs": []})
    data.setdefault("runs", []).insert(0, run)
    _save(RUNS_FILE, data)
    _audit(AUDIT_FILE, {"event": "create_bridge_run", "framework": fw, "status": status_value})
    return {"ok": True, "run": run, "summary": "Execução aguardando aprovação." if status_value == "waiting_approval" else "Execução bridge planejada."}


def list_runs(limit: int = 100) -> dict[str, Any]:
    runs = _load(RUNS_FILE, {"runs": []}).get("runs", [])
    return {"ok": True, "runs": runs[:max(1, min(limit, 500))], "count": len(runs)}


def skeleton_for(framework: str, goal: str) -> str:
    if framework == "crewai":
        return "Crew(agents=[...], tasks=[...]).kickoff()"
    if framework == "langgraph":
        return "StateGraph(State).add_node(...).add_edge(...).compile().invoke(input)"
    if framework == "mcp":
        return "Registrar MCP server, listar tools e expor ao HAL Tool Router."
    if framework == "autogen":
        return "Criar AssistantAgent/UserProxyAgent e iniciar chat multiagente."
    if framework == "openclaw":
        return "Registrar gateway/canal/ferramenta OpenClaw e mapear sessão para HAL."
    return "Usar JR-AI Agent Runtime Enterprise / Business Teams nativo."


def install_plan() -> dict[str, Any]:
    return {
        "ok": True,
        "steps": [
            "Manter JR-AI Native Runtime como padrão.",
            "Instalar CrewAI/LangGraph somente quando necessário.",
            "Isolar dependências em venv separada.",
            "Exigir aprovação humana antes de executar framework externo.",
            "Registrar logs e artefatos no Agent Runtime/Sandbox Enterprise.",
        ],
        "commands": {k: v.get("install") for k, v in FRAMEWORKS.items()},
    }


def answer_for_bridge(message: str = "") -> str:
    rec = recommend_framework(message)
    return f"Vou usar o HAL Agent Framework Bridge. Framework recomendado: {FRAMEWORKS[rec['recommended']]['label']}. Ele permite integrar CrewAI, LangGraph, AutoGen, MCP, OpenClaw ou manter o runtime nativo JR-AI."
