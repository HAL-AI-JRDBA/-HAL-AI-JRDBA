from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _slug(text: str) -> str:
    import re
    text = (text or "item").lower()
    text = re.sub(r"[^a-z0-9áéíóúãõâêôç]+", "-", text)
    text = (text.replace("á","a").replace("é","e").replace("í","i").replace("ó","o").replace("ú","u")
            .replace("ã","a").replace("õ","o").replace("â","a").replace("ê","e").replace("ô","o").replace("ç","c"))
    return re.sub(r"-+", "-", text).strip("-") or "item"


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(path: Path, event: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")

DATA_DIR = root_dir() / "data" / "channel_gateway"
CONFIG_FILE = DATA_DIR / "channels.json"
MESSAGES_FILE = DATA_DIR / "messages.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"

CHANNELS: dict[str, dict[str, Any]] = {
    "whatsapp": {
        "label": "WhatsApp Business",
        "provider_options": ["Meta WhatsApp Cloud API", "Twilio", "Z-API", "Evolution API self-hosted"],
        "status": "adapter_ready",
        "requires": ["phone_number_id", "access_token", "verify_token", "webhook_url"],
        "use_cases": ["atendimento", "cobrança com aprovação", "status de pedido", "alertas operacionais"],
    },
    "telegram": {
        "label": "Telegram Bot",
        "provider_options": ["Telegram Bot API"],
        "status": "adapter_ready",
        "requires": ["bot_token", "webhook_url opcional"],
        "use_cases": ["alertas", "comandos internos", "atendimento rápido"],
    },
    "slack": {
        "label": "Slack",
        "provider_options": ["Slack Bot App", "Incoming Webhooks"],
        "status": "adapter_ready",
        "requires": ["bot_token", "signing_secret", "channel_id"],
        "use_cases": ["TI", "dados", "alertas", "aprovações internas"],
    },
    "teams": {
        "label": "Microsoft Teams",
        "provider_options": ["Microsoft Bot Framework", "Incoming Webhooks", "Graph API"],
        "status": "adapter_ready",
        "requires": ["tenant_id", "client_id", "client_secret", "webhook_url"],
        "use_cases": ["aprovações", "comunicação corporativa", "incidentes"],
    },
    "discord": {
        "label": "Discord",
        "provider_options": ["Discord Bot", "Webhook"],
        "status": "adapter_ready",
        "requires": ["bot_token", "guild_id", "channel_id"],
        "use_cases": ["comunidades", "times técnicos", "alertas"],
    },
    "email": {
        "label": "E-mail SMTP/IMAP",
        "provider_options": ["SMTP", "IMAP", "Microsoft Graph", "Gmail API opcional"],
        "status": "adapter_ready",
        "requires": ["smtp_host", "smtp_user", "smtp_password_or_app_password"],
        "use_cases": ["relatórios", "aprovação formal", "envio de resumo"],
    },
    "webchat": {
        "label": "Web Chat Público / Widget",
        "provider_options": ["Widget local", "iframe", "PWA"],
        "status": "ready",
        "requires": ["public_route", "allowed_origins"],
        "use_cases": ["site institucional", "portal cliente", "suporte"],
    },
}


def _defaults() -> dict[str, Any]:
    return {
        "enabled": True,
        "active_channels": [],
        "channels": {
            key: {
                "enabled": False,
                "label": value["label"],
                "status": "not_configured",
                "credentials_env": {},
                "webhook_path": f"/api/channel-gateway/webhook/{key}",
                "approval_required_for_outbound": True,
                "allowed_recipients": [],
                "blocked_keywords": ["senha", "token", "cpf", "cartão", "cartao"],
            }
            for key, value in CHANNELS.items()
        },
        "routing": {
            "send_inbound_to_hall": True,
            "auto_select_tool": True,
            "human_approval_before_external_send": True,
        },
    }


def status() -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, _defaults())
    msgs = _load(MESSAGES_FILE, {"messages": []}).get("messages", [])
    return {
        "ok": True,
        "name": "HAL Channel Gateway",
        "description": "Gateway self-hosted de canais para WhatsApp, Telegram, Slack, Teams, Discord, e-mail e webchat.",
        "channels_supported": len(CHANNELS),
        "active_channels": cfg.get("active_channels", []),
        "messages_count": len(msgs),
        "capabilities": [
            "Receber mensagens de canais externos",
            "Enviar mensagens com aprovação humana",
            "Mapear canal para agente/ferramenta",
            "Registrar histórico e auditoria",
            "Usar variáveis de ambiente para credenciais",
            "Bloquear termos sensíveis e aplicar governança",
        ],
    }


def channels() -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, _defaults())
    return {"ok": True, "catalog": [{"key": k, **v} for k, v in CHANNELS.items()], "config": cfg}


def configure_channel(channel: str, enabled: bool = True, credentials_env: dict[str, str] | None = None, allowed_recipients: list[str] | None = None) -> dict[str, Any]:
    if channel not in CHANNELS:
        return {"ok": False, "summary": "Canal não suportado.", "available": list(CHANNELS)}
    cfg = _load(CONFIG_FILE, _defaults())
    entry = cfg["channels"].setdefault(channel, {})
    entry["enabled"] = enabled
    entry["status"] = "configured" if enabled else "disabled"
    entry["credentials_env"] = credentials_env or entry.get("credentials_env", {})
    entry["allowed_recipients"] = allowed_recipients or entry.get("allowed_recipients", [])
    if enabled and channel not in cfg["active_channels"]:
        cfg["active_channels"].append(channel)
    if not enabled:
        cfg["active_channels"] = [c for c in cfg.get("active_channels", []) if c != channel]
    _save(CONFIG_FILE, cfg)
    _audit(AUDIT_FILE, {"event": "configure_channel", "channel": channel, "enabled": enabled})
    return {"ok": True, "channel": channel, "config": entry, "summary": f"Canal {CHANNELS[channel]['label']} atualizado."}


def inbound_message(channel: str, sender: str, text: str, metadata: dict[str, Any] | None = None) -> dict[str, Any]:
    if channel not in CHANNELS:
        return {"ok": False, "summary": "Canal não suportado."}
    data = _load(MESSAGES_FILE, {"messages": []})
    mid = f"msg_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    item = {
        "id": mid,
        "direction": "inbound",
        "channel": channel,
        "sender": sender,
        "text": text,
        "metadata": metadata or {},
        "status": "received",
        "created_at": _now(),
        "route_to_hall": True,
    }
    data.setdefault("messages", []).insert(0, item)
    _save(MESSAGES_FILE, data)
    _audit(AUDIT_FILE, {"event": "inbound_message", "id": mid, "channel": channel})
    return {"ok": True, "message": item, "summary": "Mensagem recebida e pronta para roteamento pelo HAL."}


def outbound_message(channel: str, recipient: str, text: str, approved: bool = False, metadata: dict[str, Any] | None = None) -> dict[str, Any]:
    if channel not in CHANNELS:
        return {"ok": False, "summary": "Canal não suportado."}
    cfg = _load(CONFIG_FILE, _defaults())
    requires = cfg.get("routing", {}).get("human_approval_before_external_send", True)
    status_value = "queued_waiting_approval" if requires and not approved else "ready_to_send"
    data = _load(MESSAGES_FILE, {"messages": []})
    mid = f"out_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    item = {
        "id": mid,
        "direction": "outbound",
        "channel": channel,
        "recipient": recipient,
        "text": text,
        "metadata": metadata or {},
        "approved": approved,
        "status": status_value,
        "created_at": _now(),
        "adapter_note": "Envio real exige credenciais do canal configuradas no ambiente do cliente.",
    }
    data.setdefault("messages", []).insert(0, item)
    _save(MESSAGES_FILE, data)
    _audit(AUDIT_FILE, {"event": "outbound_message", "id": mid, "channel": channel, "status": status_value})
    return {"ok": True, "message": item, "summary": "Mensagem preparada." if approved else "Mensagem aguardando aprovação humana."}


def list_messages(channel: str = "", limit: int = 100) -> dict[str, Any]:
    msgs = _load(MESSAGES_FILE, {"messages": []}).get("messages", [])
    if channel:
        msgs = [m for m in msgs if m.get("channel") == channel]
    return {"ok": True, "messages": msgs[:max(1, min(limit, 500))], "count": len(msgs)}


def webhook_spec(channel: str = "") -> dict[str, Any]:
    selected = [channel] if channel in CHANNELS else list(CHANNELS)
    return {
        "ok": True,
        "webhooks": [
            {
                "channel": c,
                "path": f"/api/channel-gateway/webhook/{c}",
                "method": "POST",
                "payload": {"sender": "string", "text": "string", "metadata": {}},
                "hall_action": "Registrar mensagem e enviar para roteamento automático.",
            }
            for c in selected
        ],
    }


def answer_for_channel_gateway(message: str = "") -> str:
    return (
        "Vou usar o HAL Channel Gateway. "
        "Ele conecta o HAL a WhatsApp, Telegram, Slack, Microsoft Teams, Discord, e-mail e Web Chat, "
        "recebendo mensagens, roteando para a ferramenta correta e exigindo aprovação humana antes de envios externos sensíveis."
    )
