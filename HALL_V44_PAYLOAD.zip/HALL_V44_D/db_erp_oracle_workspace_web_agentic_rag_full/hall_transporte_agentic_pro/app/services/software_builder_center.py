from __future__ import annotations

import json
import re
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir

DATA_DIR = root_dir() / "data" / "software_builder_center"
PROJECTS_DIR = DATA_DIR / "generated_projects"
REQUESTS_FILE = DATA_DIR / "software_requests.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"

SOFTWARE_TERMS = [
    "software", "sistema", "aplicação", "aplicacao", "aplicativo", "app", "programa",
    "interface web", "web app", "dashboard", "painel", "frontend", "backend",
    "python", "fastapi", "flask", "streamlit", "django"
]

APP_PY = 'from fastapi import FastAPI, Form\nfrom fastapi.responses import HTMLResponse\nfrom fastapi.staticfiles import StaticFiles\nfrom pathlib import Path\nimport sqlite3\n\nBASE = Path(__file__).parent\nDB = BASE / "financas.db"\n\napp = FastAPI(title="HAL Finanças Pessoais")\napp.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")\n\ndef conn():\n    c = sqlite3.connect(DB)\n    c.row_factory = sqlite3.Row\n    return c\n\ndef init_db():\n    with conn() as c:\n        c.execute("""\n        CREATE TABLE IF NOT EXISTS lancamentos (\n            id INTEGER PRIMARY KEY AUTOINCREMENT,\n            data TEXT NOT NULL,\n            tipo TEXT NOT NULL,\n            categoria TEXT NOT NULL,\n            descricao TEXT NOT NULL,\n            valor REAL NOT NULL\n        )\n        """)\n        c.commit()\n\ninit_db()\n\n@app.get("/", response_class=HTMLResponse)\ndef home():\n    return (BASE / "templates" / "index.html").read_text(encoding="utf-8-sig")\n\n@app.get("/api/lancamentos")\ndef listar():\n    with conn() as c:\n        rows = [dict(r) for r in c.execute("SELECT * FROM lancamentos ORDER BY data DESC, id DESC").fetchall()]\n    return {"ok": True, "items": rows}\n\n@app.post("/api/lancamentos")\ndef criar(data: str = Form(...), tipo: str = Form(...), categoria: str = Form(...), descricao: str = Form(...), valor: float = Form(...)):\n    with conn() as c:\n        c.execute("INSERT INTO lancamentos(data,tipo,categoria,descricao,valor) VALUES(?,?,?,?,?)", (data, tipo, categoria, descricao, valor))\n        c.commit()\n    return {"ok": True}\n\n@app.delete("/api/lancamentos/{item_id}")\ndef excluir(item_id: int):\n    with conn() as c:\n        c.execute("DELETE FROM lancamentos WHERE id=?", (item_id,))\n        c.commit()\n    return {"ok": True}\n\n@app.get("/api/resumo")\ndef resumo():\n    with conn() as c:\n        rows = [dict(r) for r in c.execute("SELECT tipo, categoria, SUM(valor) total FROM lancamentos GROUP BY tipo, categoria").fetchall()]\n    receitas = sum(r["total"] for r in rows if r["tipo"] == "receita")\n    despesas = sum(r["total"] for r in rows if r["tipo"] == "despesa")\n    return {"ok": True, "receitas": receitas, "despesas": despesas, "saldo": receitas - despesas, "por_categoria": rows}\n'
INDEX_HTML = '<!doctype html>\n<html lang="pt-br">\n<head>\n  <meta charset="utf-8">\n  <title>HAL Finanças Pessoais</title>\n  <link rel="stylesheet" href="/static/style.css">\n</head>\n<body>\n  <main>\n    <header>\n      <h1>HAL Finanças Pessoais</h1>\n      <p>Controle local de receitas, despesas, categorias e saldo.</p>\n    </header>\n\n    <section class="cards">\n      <div><span>Receitas</span><strong id="receitas">R$ 0,00</strong></div>\n      <div><span>Despesas</span><strong id="despesas">R$ 0,00</strong></div>\n      <div><span>Saldo</span><strong id="saldo">R$ 0,00</strong></div>\n    </section>\n\n    <section class="panel">\n      <h2>Novo lançamento</h2>\n      <form id="form">\n        <input name="data" type="date" required>\n        <select name="tipo">\n          <option value="receita">Receita</option>\n          <option value="despesa">Despesa</option>\n        </select>\n        <input name="categoria" placeholder="Categoria" required>\n        <input name="descricao" placeholder="Descrição" required>\n        <input name="valor" type="number" step="0.01" placeholder="Valor" required>\n        <button>Salvar</button>\n      </form>\n    </section>\n\n    <section class="panel">\n      <h2>Lançamentos</h2>\n      <table>\n        <thead><tr><th>Data</th><th>Tipo</th><th>Categoria</th><th>Descrição</th><th>Valor</th><th></th></tr></thead>\n        <tbody id="items"></tbody>\n      </table>\n    </section>\n  </main>\n  <script src="/static/app.js"></script>\n</body>\n</html>\n'
STYLE_CSS = 'body{margin:0;background:#08111f;color:#e5eefc;font-family:Arial,sans-serif}main{max-width:1100px;margin:0 auto;padding:28px}header{background:linear-gradient(135deg,#16213e,#7f1d5a);padding:24px;border-radius:20px;margin-bottom:18px}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.cards div,.panel{background:#101b33;border:1px solid #263b65;border-radius:16px;padding:18px}.cards span{display:block;color:#9fb3d9}.cards strong{font-size:28px}form{display:grid;grid-template-columns:repeat(6,1fr);gap:10px}input,select,button{padding:12px;border-radius:10px;border:1px solid #38527f;background:#0b1325;color:#fff}button{background:#db2777;cursor:pointer;font-weight:bold}table{width:100%;border-collapse:collapse}td,th{border-bottom:1px solid #263b65;padding:10px;text-align:left}@media(max-width:800px){.cards,form{grid-template-columns:1fr}}'
APP_JS = 'const fmt = v => Number(v||0).toLocaleString(\'pt-BR\',{style:\'currency\',currency:\'BRL\'});\nasync function load(){\n  const r = await fetch(\'/api/resumo\').then(r=>r.json());\n  receitas.textContent = fmt(r.receitas);\n  despesas.textContent = fmt(r.despesas);\n  saldo.textContent = fmt(r.saldo);\n  const l = await fetch(\'/api/lancamentos\').then(r=>r.json());\n  items.innerHTML = l.items.map(i=>`<tr><td>${i.data}</td><td>${i.tipo}</td><td>${i.categoria}</td><td>${i.descricao}</td><td>${fmt(i.valor)}</td><td><button onclick="del(${i.id})">Excluir</button></td></tr>`).join(\'\');\n}\nasync function del(id){ await fetch(\'/api/lancamentos/\'+id,{method:\'DELETE\'}); load(); }\nform.onsubmit = async e => { e.preventDefault(); await fetch(\'/api/lancamentos\',{method:\'POST\',body:new FormData(form)}); form.reset(); load(); };\nload();\n'
README_PROJECT = '# HAL Finanças Pessoais\n\nSoftware local em Python com interface web para controle de finanças pessoais.\n\n## Executar\n\n```bash\npip install -r requirements.txt\npython -m uvicorn app:app --reload --host 127.0.0.1 --port 8090\n```\n\nAcesse:\n\n```text\nhttp://127.0.0.1:8090\n```\n\n## Recursos\n\n- Receitas\n- Despesas\n- Categorias\n- Saldo\n- Dashboard simples\n- Banco SQLite local\n'


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
    if not REQUESTS_FILE.exists():
        REQUESTS_FILE.write_text(json.dumps({"requests": []}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def is_software_request(message: str) -> bool:
    low = (message or "").lower()
    has_term = any(t in low for t in SOFTWARE_TERMS)
    has_action = any(x in low for x in ["quero", "preciso", "criar", "crie", "gera", "gerar", "desenvolver", "fazer", "montar"])
    return has_term and has_action


def classify_software_request(message: str) -> dict[str, Any]:
    low = (message or "").lower()
    app_type = "web"
    if "desktop" in low:
        app_type = "desktop"
    elif "mobile" in low or "celular" in low:
        app_type = "mobile"
    elif "api" in low:
        app_type = "api"

    language = "Python" if "python" in low else "Python"
    framework = "FastAPI + HTML/CSS/JS"
    if "streamlit" in low:
        framework = "Streamlit"
    elif "flask" in low:
        framework = "Flask"
    elif "django" in low:
        framework = "Django"

    domain = "geral"
    features: list[str] = []
    if any(x in low for x in ["finanças pessoais", "financas pessoais", "controle de finanças", "controle financeiro", "gastos", "despesas", "receitas"]):
        domain = "finanças pessoais"
        features = [
            "cadastro de receitas", "cadastro de despesas", "categorias", "saldo mensal",
            "metas de gasto", "dashboard por mês", "gráficos simples", "exportação CSV"
        ]

    return {
        "ok": True,
        "domain": domain,
        "app_type": app_type,
        "language": language,
        "framework": framework,
        "features": features,
        "needs_clarification": domain == "geral",
    }


def status() -> dict[str, Any]:
    _ensure()
    reqs = json.loads(REQUESTS_FILE.read_text(encoding="utf-8-sig")).get("requests", [])
    return {
        "ok": True,
        "name": "HAL Software Builder Center",
        "description": "Entende pedidos de criação de software e gera plano, arquitetura e scaffold local em Python/web.",
        "requests_count": len(reqs),
        "projects_dir": str(PROJECTS_DIR),
        "capabilities": [
            "Detectar pedido de software/app/sistema",
            "Planejar arquitetura",
            "Gerar scaffold Python com interface web",
            "Criar README e guia de execução",
            "Criar app de finanças pessoais",
            "Evitar resposta genérica tipo ponto central",
        ],
    }


def suggested_screens(domain: str) -> list[dict[str, Any]]:
    if domain == "finanças pessoais":
        return [
            {"name": "Dashboard", "fields": ["saldo atual", "receitas do mês", "despesas do mês", "economia", "gráfico por categoria"]},
            {"name": "Receitas", "fields": ["data", "descrição", "categoria", "valor", "recorrente"]},
            {"name": "Despesas", "fields": ["data", "descrição", "categoria", "valor", "forma de pagamento", "fixa/variável"]},
            {"name": "Categorias", "fields": ["nome", "tipo", "limite mensal"]},
            {"name": "Metas", "fields": ["meta de economia", "limite por categoria", "alertas"]},
            {"name": "Relatórios", "fields": ["período", "categoria", "exportar CSV"]},
        ]
    return [
        {"name": "Dashboard", "fields": ["indicadores principais", "alertas", "ações recentes"]},
        {"name": "Cadastro", "fields": ["campos principais do negócio"]},
        {"name": "Relatórios", "fields": ["filtros", "exportação"]},
    ]


def natural_answer_from_plan(message: str, cls: dict[str, Any]) -> str:
    if cls["domain"] == "finanças pessoais":
        return (
            "Perfeito — isso é um pedido claro de criação de software.\n\n"
            "Eu montaria para você um sistema local em **Python com interface web** para controle de finanças pessoais, com:\n\n"
            "1. Dashboard com saldo, receitas, despesas e economia do mês.\n"
            "2. Cadastro de receitas: salário, extras, investimentos e outros ganhos.\n"
            "3. Cadastro de despesas: moradia, alimentação, transporte, lazer, saúde e parcelas.\n"
            "4. Categorias com limite mensal.\n"
            "5. Metas de economia.\n"
            "6. Gráficos por categoria e por mês.\n"
            "7. Banco SQLite local, sem depender de nuvem.\n"
            "8. Exportação CSV para Excel.\n\n"
            "A melhor primeira versão é **FastAPI + SQLite + HTML/CSS/JavaScript**, porque roda local, é leve e depois pode evoluir para login, múltiplos usuários, mobile ou nuvem opcional.\n\n"
            "Posso gerar agora a estrutura completa desse software com os arquivos Python, tela web, banco e guia de instalação."
        )
    return (
        "Sim. Isso é pedido de desenvolvimento de software. "
        f"Eu sugiro criar uma aplicação {cls['app_type']} em {cls['language']} usando {cls['framework']}, "
        "com banco local e interface simples primeiro. Posso transformar isso em arquitetura, telas, banco de dados e código inicial."
    )


def build_plan(message: str) -> dict[str, Any]:
    cls = classify_software_request(message)
    if cls["needs_clarification"]:
        answer = (
            "Sim, consigo te ajudar a criar esse software. Para acertar o projeto, preciso só de três definições: "
            "qual problema o sistema resolve, quem vai usar e quais telas principais você quer. "
            "Se preferir, já monto uma versão inicial em Python com interface web, banco SQLite e dashboard."
        )
    else:
        answer = natural_answer_from_plan(message, cls)

    plan = {
        "id": f"sw_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "message": message,
        "classification": cls,
        "architecture": {
            "backend": cls["framework"],
            "database": "SQLite local inicialmente; pode migrar para PostgreSQL/MySQL/SQL Server/MongoDB",
            "frontend": "HTML, CSS e JavaScript em interface web responsiva",
            "run_mode": "local-first",
            "security": ["dados locais", "backup manual", "sem envio para nuvem por padrão"],
        },
        "screens": suggested_screens(cls["domain"]),
        "created_at": _now(),
    }
    save_request(plan)
    _audit({"event": "build_plan", "id": plan["id"], "domain": cls["domain"]})
    return {"ok": True, "answer": answer, "plan": plan}


def generate_personal_finance_project(project_name: str = "hall_financas_pessoais") -> dict[str, Any]:
    _ensure()
    safe = re.sub(r"[^a-zA-Z0-9_\-]+", "_", project_name or "hall_financas_pessoais").strip("_").lower()
    dest = PROJECTS_DIR / safe
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "static").mkdir(exist_ok=True)
    (dest / "templates").mkdir(exist_ok=True)
    (dest / "app.py").write_text(APP_PY, encoding="utf-8")
    (dest / "requirements.txt").write_text("fastapi\nuvicorn\njinja2\npython-multipart\n", encoding="utf-8")
    (dest / "README.md").write_text(README_PROJECT, encoding="utf-8")
    (dest / "templates/index.html").write_text(INDEX_HTML, encoding="utf-8")
    (dest / "static/style.css").write_text(STYLE_CSS, encoding="utf-8")
    (dest / "static/app.js").write_text(APP_JS, encoding="utf-8")
    (dest / "INICIAR_FINANCAS_PESSOAIS.bat").write_text('@echo off\nchcp 65001 >nul\npython -m uvicorn app:app --reload --host 127.0.0.1 --port 8090\npause\n'.replace("\n", "\r\n"), encoding="utf-8")
    _audit({"event": "generate_project", "project": safe, "path": str(dest)})
    return {
        "ok": True,
        "project_name": safe,
        "path": str(dest),
        "run": "python -m uvicorn app:app --reload --host 127.0.0.1 --port 8090",
        "url": "http://127.0.0.1:8090",
        "summary": "Projeto de finanças pessoais gerado localmente.",
    }


def save_request(plan: dict[str, Any]) -> None:
    _ensure()
    data = json.loads(REQUESTS_FILE.read_text(encoding="utf-8-sig"))
    data.setdefault("requests", []).insert(0, plan)
    data["requests"] = data["requests"][:300]
    REQUESTS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def list_requests(limit: int = 50) -> dict[str, Any]:
    _ensure()
    data = json.loads(REQUESTS_FILE.read_text(encoding="utf-8-sig"))
    return {"ok": True, "requests": data.get("requests", [])[:limit]}
