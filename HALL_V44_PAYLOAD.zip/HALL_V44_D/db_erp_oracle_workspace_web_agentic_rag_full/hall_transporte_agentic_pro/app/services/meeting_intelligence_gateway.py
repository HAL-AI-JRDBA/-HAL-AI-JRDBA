
from __future__ import annotations

import json
import re
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "meeting_intelligence_gateway"
MEETINGS_FILE = DATA_DIR / "meetings.json"
QUESTIONS_FILE = DATA_DIR / "questions.json"
MINUTES_FILE = DATA_DIR / "minutes.json"
ACTIONS_FILE = DATA_DIR / "action_items.json"
CONFIG_FILE = DATA_DIR / "config.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"


PLATFORMS: dict[str, dict[str, Any]] = {
    "teams": {
        "label": "Microsoft Teams",
        "modes": ["listener", "qa", "meeting_agent"],
        "text_channel": True,
        "voice_channel": True,
        "official_bot_path": True,
        "desktop_companion_path": True,
        "notes": "Preferir bot/Graph quando houver permissão corporativa. Para áudio bidirecional em tempo real, usar bot com mídia em tempo real ou Desktop Companion conforme política do cliente.",
        "required_env": ["TEAMS_TENANT_ID", "TEAMS_CLIENT_ID", "TEAMS_CLIENT_SECRET", "TEAMS_BOT_APP_ID", "TEAMS_BOT_PASSWORD"],
    },
    "google_meet": {
        "label": "Google Meet",
        "modes": ["listener", "qa", "meeting_agent"],
        "text_channel": True,
        "voice_channel": True,
        "official_bot_path": False,
        "desktop_companion_path": True,
        "notes": "Para tempo real, usar Desktop/Browser Companion autorizado. Para artefatos pós-reunião, usar Google Workspace/Meet APIs quando disponíveis.",
        "required_env": ["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET", "GOOGLE_WORKSPACE_DOMAIN"],
    },
    "zoom": {
        "label": "Zoom",
        "modes": ["listener", "qa", "meeting_agent"],
        "text_channel": True,
        "voice_channel": True,
        "official_bot_path": True,
        "desktop_companion_path": True,
        "notes": "Preparado para integração futura via SDK/API ou Desktop Companion.",
        "required_env": ["ZOOM_CLIENT_ID", "ZOOM_CLIENT_SECRET"],
    },
    "webex": {
        "label": "Webex",
        "modes": ["listener", "qa", "meeting_agent"],
        "text_channel": True,
        "voice_channel": True,
        "official_bot_path": True,
        "desktop_companion_path": True,
        "notes": "Preparado para integração futura via API ou Desktop Companion.",
        "required_env": ["WEBEX_BOT_TOKEN"],
    },
    "local_audio": {
        "label": "Áudio Local / Desktop Companion",
        "modes": ["listener", "qa", "meeting_agent"],
        "text_channel": False,
        "voice_channel": True,
        "official_bot_path": False,
        "desktop_companion_path": True,
        "notes": "Usa microfone/saída de áudio local, STT/TTS e permissões explícitas. Útil para qualquer ferramenta de reunião quando API de mídia não estiver disponível.",
        "required_env": ["HALL_STT_PROVIDER", "HALL_TTS_PROVIDER"],
    },
}

MEETING_MODES: dict[str, dict[str, Any]] = {
    "listener": {
        "label": "Modo Ouvinte",
        "description": "HAL escuta, transcreve, resume, identifica decisões e cria ata, sem responder automaticamente.",
        "default_voice_reply": False,
        "default_text_reply": False,
    },
    "qa": {
        "label": "Modo Perguntas e Respostas",
        "description": "Participantes fazem perguntas para o HAL, que responde por voz e/ou texto conforme configuração.",
        "default_voice_reply": True,
        "default_text_reply": True,
    },
    "meeting_agent": {
        "label": "Modo Agente de Reunião",
        "description": "HAL acompanha a reunião, responde perguntas, cria ata, decisões, tarefas, riscos e próximos passos.",
        "default_voice_reply": True,
        "default_text_reply": True,
    },
}

DEFAULT_CONFIG = {
    "enabled": True,
    "default_platform": "teams",
    "default_mode": "qa",
    "voice_response_enabled": True,
    "text_response_enabled": True,
    "meeting_chat_enabled": True,
    "require_consent_notice": True,
    "require_human_approval_for_external_send": True,
    "auto_minutes_enabled": True,
    "auto_action_items_enabled": True,
    "wake_words": ["hall", "hall ia", "jr ai", "jr-ai"],
    "question_markers": ["pergunta para o hall", "hall,", "hall ", "ia,", "assistente,"],
    "response_tone": "natural_profissional",
    "local_first": True,
    "integrations": {
        "human_conversation_gateway": True,
        "enterprise_integration_team_intelligence": True,
        "database_access_wizard": True,
        "universal_erp_connector": True,
        "reliable_web_answer": True,
        "powerbi": True,
        "zabbix": True,
        "grafana": True,
        "erp": True,
        "crm": True,
        "calendar": True,
        "teams": True,
        "google_meet": True,
    },
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for path, default in [
        (MEETINGS_FILE, {"meetings": []}),
        (QUESTIONS_FILE, {"questions": []}),
        (MINUTES_FILE, {"minutes": []}),
        (ACTIONS_FILE, {"actions": []}),
        (CONFIG_FILE, DEFAULT_CONFIG),
    ]:
        if not path.exists():
            path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def status() -> dict[str, Any]:
    meetings = _load(MEETINGS_FILE, {"meetings": []}).get("meetings", [])
    questions = _load(QUESTIONS_FILE, {"questions": []}).get("questions", [])
    minutes = _load(MINUTES_FILE, {"minutes": []}).get("minutes", [])
    actions = _load(ACTIONS_FILE, {"actions": []}).get("actions", [])
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    return {
        "ok": True,
        "name": "HAL Meeting Intelligence Gateway",
        "description": "Camada para Teams, Google Meet, Zoom/Webex futuro e áudio local: perguntas em reunião, resposta por voz/texto, ata, decisões, tarefas e consulta a sistemas corporativos.",
        "enabled": cfg.get("enabled", True),
        "platforms_supported": len(PLATFORMS),
        "modes_supported": len(MEETING_MODES),
        "meetings_count": len(meetings),
        "questions_count": len(questions),
        "minutes_count": len(minutes),
        "actions_count": len(actions),
        "capabilities": [
            "Participar de reuniões como bot ou Desktop/Browser Companion autorizado",
            "Modo Ouvinte, Perguntas e Respostas e Agente de Reunião",
            "Capturar perguntas por wake word ou marcador",
            "Responder por voz na reunião",
            "Responder por texto no chat da reunião",
            "Consultar ERP, CRM, Power BI, bancos SQL/NoSQL, Zabbix e Grafana durante a reunião",
            "Gerar ata automática",
            "Extrair decisões",
            "Criar tarefas, responsáveis e prazos",
            "Registrar histórico por reunião",
            "Exigir consentimento/transparência",
            "Exigir aprovação antes de mensagens externas ou ações sensíveis",
        ],
    }


def catalog() -> dict[str, Any]:
    return {
        "ok": True,
        "platforms": [{"key": k, **v} for k, v in PLATFORMS.items()],
        "modes": [{"key": k, **v} for k, v in MEETING_MODES.items()],
        "config": _load(CONFIG_FILE, DEFAULT_CONFIG),
    }


def update_config(changes: dict[str, Any]) -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    deep_update(cfg, changes or {})
    _save(CONFIG_FILE, cfg)
    _audit({"event": "update_config"})
    return {"ok": True, "config": cfg, "summary": "Configuração de reuniões atualizada."}


def deep_update(base: dict[str, Any], changes: dict[str, Any]) -> None:
    for k, v in changes.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            deep_update(base[k], v)
        else:
            base[k] = v


def start_meeting(
    title: str,
    platform: str = "teams",
    meeting_url: str = "",
    mode: str = "qa",
    organizer: str = "",
    participants: list[str] | None = None,
    voice_response: bool | None = None,
    text_response: bool | None = None,
    consent_confirmed: bool = False,
) -> dict[str, Any]:
    platform_key = platform if platform in PLATFORMS else "teams"
    mode_key = mode if mode in MEETING_MODES else "qa"
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    status_value = "waiting_consent" if cfg.get("require_consent_notice", True) and not consent_confirmed else "active"
    meeting = {
        "id": f"meet_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "title": title or "Reunião HAL",
        "platform": platform_key,
        "platform_label": PLATFORMS[platform_key]["label"],
        "meeting_url": meeting_url,
        "mode": mode_key,
        "mode_label": MEETING_MODES[mode_key]["label"],
        "organizer": organizer,
        "participants": participants or [],
        "voice_response": MEETING_MODES[mode_key]["default_voice_reply"] if voice_response is None else bool(voice_response),
        "text_response": MEETING_MODES[mode_key]["default_text_reply"] if text_response is None else bool(text_response),
        "consent_confirmed": consent_confirmed,
        "status": status_value,
        "created_at": _now(),
        "updated_at": _now(),
        "transcript": [],
        "decisions": [],
        "risks": [],
        "notes": [],
        "integration_plan": build_join_plan(platform_key, mode_key),
    }
    data = _load(MEETINGS_FILE, {"meetings": []})
    data.setdefault("meetings", []).insert(0, meeting)
    _save(MEETINGS_FILE, data)
    _audit({"event": "start_meeting", "meeting_id": meeting["id"], "platform": platform_key, "mode": mode_key, "status": status_value})
    return {"ok": True, "meeting": meeting, "summary": meeting_summary(meeting)}


def build_join_plan(platform: str, mode: str) -> list[dict[str, Any]]:
    p = PLATFORMS.get(platform, PLATFORMS["teams"])
    steps = [
        {"id": "confirm_consent", "label": "Avisar participantes que o HAL pode transcrever/analisar a reunião", "status": "required"},
        {"id": "join_meeting", "label": f"Entrar na reunião via {p['label']}", "status": "pending"},
        {"id": "capture_audio", "label": "Capturar áudio autorizado e converter fala em texto", "status": "pending"},
        {"id": "detect_questions", "label": "Detectar perguntas direcionadas ao HAL", "status": "pending"},
        {"id": "route_to_tools", "label": "Acionar ferramentas corretas nos bastidores", "status": "pending"},
        {"id": "reply_text", "label": "Responder por texto no chat quando habilitado", "status": "pending"},
        {"id": "reply_voice", "label": "Responder por voz quando habilitado", "status": "pending"},
        {"id": "minutes", "label": "Gerar ata, decisões e tarefas", "status": "pending"},
    ]
    if platform in {"google_meet", "local_audio"}:
        steps.insert(2, {"id": "desktop_companion", "label": "Usar Desktop/Browser Companion para áudio em tempo real", "status": "recommended"})
    if mode == "listener":
        steps = [s for s in steps if s["id"] not in {"reply_text", "reply_voice"}]
    return steps


def meeting_summary(meeting: dict[str, Any]) -> str:
    if meeting["status"] == "waiting_consent":
        return (
            f"Reunião criada para {meeting['platform_label']} em {meeting['mode_label']}, mas está aguardando consentimento/aviso aos participantes. "
            "Depois da confirmação, o HAL pode escutar perguntas, responder por voz/texto e gerar ata."
        )
    return (
        f"Reunião ativa em {meeting['platform_label']} no modo {meeting['mode_label']}. "
        "O HAL pode detectar perguntas, responder por voz/texto e registrar ata, decisões e tarefas."
    )


def confirm_consent(meeting_id: str) -> dict[str, Any]:
    data = _load(MEETINGS_FILE, {"meetings": []})
    for meeting in data.get("meetings", []):
        if meeting.get("id") == meeting_id:
            meeting["consent_confirmed"] = True
            meeting["status"] = "active"
            meeting["updated_at"] = _now()
            _save(MEETINGS_FILE, data)
            _audit({"event": "confirm_consent", "meeting_id": meeting_id})
            return {"ok": True, "meeting": meeting, "summary": "Consentimento/aviso confirmado. Reunião liberada para uso."}
    return {"ok": False, "summary": "Reunião não encontrada."}


def list_meetings(status_filter: str = "", limit: int = 100) -> dict[str, Any]:
    meetings = _load(MEETINGS_FILE, {"meetings": []}).get("meetings", [])
    if status_filter:
        meetings = [m for m in meetings if m.get("status") == status_filter]
    return {"ok": True, "meetings": meetings[:max(1, min(limit, 500))], "count": len(meetings)}


def get_meeting(meeting_id: str) -> dict[str, Any]:
    meetings = _load(MEETINGS_FILE, {"meetings": []}).get("meetings", [])
    meeting = next((m for m in meetings if m.get("id") == meeting_id), None)
    return {"ok": bool(meeting), "meeting": meeting, "summary": "Reunião encontrada." if meeting else "Reunião não encontrada."}


def add_transcript(meeting_id: str, speaker: str, text: str, timestamp: str = "") -> dict[str, Any]:
    data = _load(MEETINGS_FILE, {"meetings": []})
    entry = {"id": f"tr_{uuid.uuid4().hex[:8]}", "ts": timestamp or _now(), "speaker": speaker or "Participante", "text": text}
    for meeting in data.get("meetings", []):
        if meeting.get("id") == meeting_id:
            meeting.setdefault("transcript", []).append(entry)
            meeting["updated_at"] = _now()
            extracted = extract_decision_action(text, speaker)
            if extracted.get("decision"):
                meeting.setdefault("decisions", []).append(extracted["decision"])
            if extracted.get("risk"):
                meeting.setdefault("risks", []).append(extracted["risk"])
            _save(MEETINGS_FILE, data)
            _audit({"event": "add_transcript", "meeting_id": meeting_id, "speaker": speaker})
            if is_question_for_hall(text):
                q = ask_question(meeting_id, text, speaker=speaker, respond_voice=True, respond_text=True)
                return {"ok": True, "entry": entry, "detected_question": True, "question_result": q}
            return {"ok": True, "entry": entry, "detected_question": False}
    return {"ok": False, "summary": "Reunião não encontrada."}


def extract_decision_action(text: str, speaker: str = "") -> dict[str, Any]:
    low = (text or "").lower()
    out: dict[str, Any] = {}
    if any(x in low for x in ["decidido", "decidimos", "fica decidido", "vamos aprovar", "aprovado"]):
        out["decision"] = {"id": f"dec_{uuid.uuid4().hex[:8]}", "text": text, "speaker": speaker, "created_at": _now()}
    if any(x in low for x in ["risco", "problema", "bloqueio", "atenção", "atencao", "crítico", "critico"]):
        out["risk"] = {"id": f"risk_{uuid.uuid4().hex[:8]}", "text": text, "speaker": speaker, "created_at": _now()}
    return out


def is_question_for_hall(text: str) -> bool:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    low = (text or "").lower().strip()
    if "?" in low and any(w in low for w in cfg.get("wake_words", [])):
        return True
    if any(marker in low for marker in cfg.get("question_markers", [])):
        return True
    if any(low.startswith(w + " ") or low.startswith(w + ",") for w in cfg.get("wake_words", [])):
        return True
    return False


def normalize_meeting_question(text: str) -> str:
    cleaned = (text or "").strip()
    patterns = [r"^(hall ia|hall|jr ai|jr-ai|assistente)[,:\s]+", r"^pergunta para o hall[,:\s]+", r"^ia[,:\s]+"]
    for p in patterns:
        cleaned = re.sub(p, "", cleaned, flags=re.IGNORECASE).strip()
    return cleaned or (text or "").strip()


def ask_question(
    meeting_id: str,
    question: str,
    speaker: str = "",
    respond_voice: bool = True,
    respond_text: bool = True,
    approved: bool = False,
) -> dict[str, Any]:
    meeting_info = get_meeting(meeting_id)
    if not meeting_info.get("ok"):
        return {"ok": False, "summary": "Reunião não encontrada."}
    meeting = meeting_info["meeting"]
    if meeting.get("status") == "waiting_consent":
        return {"ok": False, "status": "waiting_consent", "summary": "A reunião ainda aguarda confirmação de consentimento/aviso aos participantes."}

    normalized = normalize_meeting_question(question)
    answer_result = route_question_to_hall(normalized, approved=approved)
    response = build_meeting_response(
        meeting,
        normalized,
        answer_result.get("answer", ""),
        respond_voice=respond_voice and meeting.get("voice_response", True),
        respond_text=respond_text and meeting.get("text_response", True),
    )
    item = {
        "id": f"q_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "meeting_id": meeting_id,
        "speaker": speaker or "Participante",
        "question": question,
        "normalized_question": normalized,
        "answer": answer_result.get("answer", ""),
        "tool_result": answer_result,
        "response": response,
        "created_at": _now(),
    }
    data = _load(QUESTIONS_FILE, {"questions": []})
    data.setdefault("questions", []).insert(0, item)
    _save(QUESTIONS_FILE, data)

    meetings = _load(MEETINGS_FILE, {"meetings": []})
    for m in meetings.get("meetings", []):
        if m.get("id") == meeting_id:
            m.setdefault("transcript", []).append({"id": f"tr_{uuid.uuid4().hex[:8]}", "ts": _now(), "speaker": speaker or "Participante", "text": question})
            m.setdefault("transcript", []).append({"id": f"tr_{uuid.uuid4().hex[:8]}", "ts": _now(), "speaker": "HAL", "text": answer_result.get("answer", "")})
            m["updated_at"] = _now()
            break
    _save(MEETINGS_FILE, meetings)
    _audit({"event": "ask_question", "meeting_id": meeting_id, "question_id": item["id"], "speaker": speaker})
    return {"ok": True, "question": item, "summary": "Pergunta respondida na reunião."}


def route_question_to_hall(question: str, approved: bool = False) -> dict[str, Any]:
    try:
        from app.services import human_conversation_gateway
        res = human_conversation_gateway.converse(question, approved=approved, run_tools=True)
        return {"ok": True, "tool": "human_conversation_gateway", "answer": res.get("answer", ""), "raw": res}
    except Exception as exc:
        return {
            "ok": False,
            "tool": "fallback",
            "answer": "Eu entendi a pergunta, mas não consegui acionar o HAL agora. Posso registrar a pergunta na ata para responder depois.",
            "error": str(exc),
        }


def build_meeting_response(meeting: dict[str, Any], question: str, answer: str, respond_voice: bool = True, respond_text: bool = True) -> dict[str, Any]:
    voice_script = make_voice_script(answer)
    text_message = make_text_message(answer)
    return {
        "voice_enabled": respond_voice,
        "text_enabled": respond_text,
        "voice_script": voice_script if respond_voice else "",
        "text_message": text_message if respond_text else "",
        "platform": meeting.get("platform"),
        "platform_label": meeting.get("platform_label"),
        "delivery_plan": [
            {"channel": "voice", "status": "prepared" if respond_voice else "disabled"},
            {"channel": "meeting_chat", "status": "prepared" if respond_text else "disabled"},
            {"channel": "hall_screen", "status": "prepared"},
        ],
        "requires_sender": "Bot oficial ou Desktop/Browser Companion precisa estar ativo para entregar voz/chat dentro da reunião.",
    }


def make_voice_script(answer: str) -> str:
    text = " ".join((answer or "").split())
    if len(text) > 900:
        text = text[:900].rsplit(" ", 1)[0] + "..."
    return text


def make_text_message(answer: str) -> str:
    text = (answer or "").strip()
    if len(text) > 1800:
        text = text[:1800].rsplit(" ", 1)[0] + "\n\n[resposta resumida para o chat]"
    return text


def list_questions(meeting_id: str = "", limit: int = 100) -> dict[str, Any]:
    items = _load(QUESTIONS_FILE, {"questions": []}).get("questions", [])
    if meeting_id:
        items = [q for q in items if q.get("meeting_id") == meeting_id]
    return {"ok": True, "questions": items[:max(1, min(limit, 500))], "count": len(items)}


def generate_minutes(meeting_id: str) -> dict[str, Any]:
    info = get_meeting(meeting_id)
    if not info.get("ok"):
        return {"ok": False, "summary": "Reunião não encontrada."}
    meeting = info["meeting"]
    transcript = meeting.get("transcript", [])
    participants = sorted(set([t.get("speaker", "") for t in transcript if t.get("speaker") and t.get("speaker") != "HAL"] + meeting.get("participants", [])))
    questions = [q for q in _load(QUESTIONS_FILE, {"questions": []}).get("questions", []) if q.get("meeting_id") == meeting_id]
    decisions = meeting.get("decisions", [])
    risks = meeting.get("risks", [])
    action_items = extract_action_items_from_transcript(transcript, meeting_id)
    minutes = {
        "id": f"min_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "meeting_id": meeting_id,
        "title": meeting.get("title", ""),
        "platform_label": meeting.get("platform_label", ""),
        "generated_at": _now(),
        "participants": participants,
        "summary": summarize_transcript(transcript),
        "questions_answered": [{"speaker": q.get("speaker"), "question": q.get("normalized_question"), "answer": q.get("answer")} for q in questions],
        "decisions": decisions,
        "risks": risks,
        "action_items": action_items,
        "next_steps": build_next_steps(action_items, risks),
    }
    data = _load(MINUTES_FILE, {"minutes": []})
    data.setdefault("minutes", []).insert(0, minutes)
    _save(MINUTES_FILE, data)
    actions_data = _load(ACTIONS_FILE, {"actions": []})
    actions_data.setdefault("actions", [])
    for a in action_items:
        actions_data["actions"].insert(0, a)
    _save(ACTIONS_FILE, actions_data)
    _audit({"event": "generate_minutes", "meeting_id": meeting_id, "minutes_id": minutes["id"]})
    return {"ok": True, "minutes": minutes, "summary": "Ata gerada com resumo, perguntas, decisões, riscos e tarefas."}


def summarize_transcript(transcript: list[dict[str, Any]]) -> str:
    if not transcript:
        return "Sem transcrição suficiente para gerar resumo."
    texts = [f"{t.get('speaker','')}: {t.get('text','')}" for t in transcript[-80:]]
    joined = " ".join(texts)
    if len(joined) > 1200:
        joined = joined[:1200].rsplit(" ", 1)[0] + "..."
    return "Resumo da reunião: " + joined


def extract_action_items_from_transcript(transcript: list[dict[str, Any]], meeting_id: str) -> list[dict[str, Any]]:
    actions: list[dict[str, Any]] = []
    patterns = ["precisa", "deve", "ficou para", "responsável", "responsavel", "tarefa", "ação", "acao", "próximo passo", "proximo passo"]
    for t in transcript:
        text = t.get("text", "")
        low = text.lower()
        if any(p in low for p in patterns):
            actions.append({
                "id": f"act_{uuid.uuid4().hex[:8]}",
                "meeting_id": meeting_id,
                "owner": infer_owner(text, t.get("speaker", "")),
                "text": text,
                "due_date": infer_due_date(text),
                "status": "open",
                "created_at": _now(),
            })
    return actions[:30]


def infer_owner(text: str, default_speaker: str = "") -> str:
    m = re.search(r"(respons[aá]vel|com|para)\s+([A-ZÁÉÍÓÚÂÊÔÃÕÇ][\wÀ-ÿ\- ]{1,40})", text or "", flags=re.IGNORECASE)
    if m:
        return m.group(2).strip()
    return default_speaker or "A definir"


def infer_due_date(text: str) -> str:
    low = (text or "").lower()
    if "hoje" in low:
        return "hoje"
    if "amanhã" in low or "amanha" in low:
        return "amanhã"
    if "semana" in low:
        return "esta semana"
    if "mês" in low or "mes" in low:
        return "este mês"
    return "a definir"


def build_next_steps(action_items: list[dict[str, Any]], risks: list[dict[str, Any]]) -> list[str]:
    steps = []
    if action_items:
        steps.append("Validar responsáveis e prazos das tarefas identificadas.")
    if risks:
        steps.append("Priorizar riscos citados na reunião e definir plano de mitigação.")
    steps.append("Enviar ata para participantes após aprovação do organizador.")
    return steps


def list_minutes(meeting_id: str = "", limit: int = 100) -> dict[str, Any]:
    minutes = _load(MINUTES_FILE, {"minutes": []}).get("minutes", [])
    if meeting_id:
        minutes = [m for m in minutes if m.get("meeting_id") == meeting_id]
    return {"ok": True, "minutes": minutes[:max(1, min(limit, 500))], "count": len(minutes)}


def list_actions(meeting_id: str = "", status_filter: str = "", limit: int = 100) -> dict[str, Any]:
    actions = _load(ACTIONS_FILE, {"actions": []}).get("actions", [])
    if meeting_id:
        actions = [a for a in actions if a.get("meeting_id") == meeting_id]
    if status_filter:
        actions = [a for a in actions if a.get("status") == status_filter]
    return {"ok": True, "actions": actions[:max(1, min(limit, 500))], "count": len(actions)}


def seed_demo() -> dict[str, Any]:
    meeting = start_meeting(
        title="Demo HAL em reunião corporativa",
        platform="teams",
        meeting_url="https://teams.microsoft.com/demo",
        mode="meeting_agent",
        organizer="Organizador Demo",
        participants=["Financeiro", "TI/DBA", "Operações", "Diretoria"],
        consent_confirmed=True,
    )["meeting"]
    add_transcript(meeting["id"], "Diretoria", "Bom dia, pessoal. Vamos avaliar vendas, alertas e pendências.")
    ask_question(meeting["id"], "HAL, verifique os alertas do Zabbix e Grafana para TI.", speaker="Diretoria")
    ask_question(meeting["id"], "HAL, consulte vendas de passagens de hoje por linha.", speaker="Financeiro")
    add_transcript(meeting["id"], "Operações", "Ficou decidido que o time de bilhetagem precisa revisar divergências até amanhã.")
    minutes = generate_minutes(meeting["id"])
    return {"ok": True, "meeting": meeting, "minutes": minutes.get("minutes"), "summary": "Demo de reunião criada."}


def answer_for_meeting(message: str = "") -> str:
    low = (message or "").lower()
    if "google" in low or "meet" in low:
        platform = "google_meet"
    elif "zoom" in low:
        platform = "zoom"
    elif "webex" in low:
        platform = "webex"
    else:
        platform = "teams"
    return (
        f"Vou usar o HAL Meeting Intelligence Gateway para {PLATFORMS[platform]['label']}. "
        "Ele permite modo ouvinte, perguntas e respostas ou agente de reunião, com resposta por voz/texto, ata, decisões, tarefas e consulta a sistemas corporativos. "
        "Para funcionar dentro da call, é preciso ativar o bot oficial quando disponível ou o Desktop/Browser Companion autorizado."
    )
