from __future__ import annotations

import json
import re
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir, load_config
from app.services import cyber_defense_shield, enterprise_productization_v13, app_factory_pro, software_builder_center, skills_multi_agent_center, executive_financial_intelligence, omnichannel_voice_text_delivery, meeting_intelligence_gateway, enterprise_integration_team_intelligence, human_conversation_gateway, database_access_wizard, industry_precision_engine, reliable_web_answer, memory
from app.services import business_teams
from app.services import saas_builder
from app.services import agent_runtime
from app.services import human_voice_assistant
from app.services import realtime_voice_engine
from app.services import channel_gateway, n8n_workflow_center, browser_automation, cron_enterprise, sandbox_enterprise, agent_framework_bridge, visual_mission_control, universal_erp_connector
from app.services import open_ai_access_center
from app.services.model_manager import OllamaClient, choose_model
from app.tools import desktop
from app.tools.transport import build_transport_sql, transport_context_prompt
from app.tools.business_domains import detect_domain, segment_prompt
from app.tools.database_platforms import detect_database, last_period_example, connection_guidance

RUNS = root_dir() / "data" / "runs"


def _ensure() -> None:
    RUNS.mkdir(parents=True, exist_ok=True)


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def norm(text: str) -> str:
    t = (text or "").lower().strip()
    replacements = {
        "utimo": "último", "ultimo": "último", "mes": "mês",
        "zabix": "zabbix", "grafa": "grafana",
        "base de dado": "base de dados", "banco de dado": "banco de dados"
    }
    for a, b in replacements.items():
        t = t.replace(a, b)
    return re.sub(r"\s+", " ", t)


def classify(message: str) -> dict[str, Any]:
    t = norm(message)
    scores = {
        "saudacao": 0.0, "open_ai_access": 0.0, "realtime_voice": 0.0, "human_voice": 0.0, "agent_runtime": 0.0, "saas_builder": 0.0, "business_teams": 0.0, "dados_negocio": 0.0, "transporte_sql": 0.0, "monitoramento": 0.0,
        "visao": 0.0, "desktop": 0.0, "memoria": 0.0,
        "conteudo": 0.0, "reuniao": 0.0, "email": 0.0,
        "codigo": 0.0, "automacao": 0.0, "chat": 0.1,
    }
    # Garantia de chaves das camadas de conversa, dados, web e automação.
    for _key in [
        "skills_multi_agent_center",
        "cyber_defense_shield",
        "enterprise_productization_v13",
        "app_factory_pro",
        "software_builder_center",
        "executive_financial_intelligence",
        "omnichannel_voice_text_delivery",
        "meeting_intelligence_gateway",
        "enterprise_integration_team_intelligence",
        "human_conversation_gateway",
        "database_access_wizard",
        "reliable_web_answer",
        "universal_erp_connector",
        "visual_mission_control",
        "channel_gateway",
        "n8n_workflow",
        "browser_automation",
        "cron_enterprise",
        "sandbox_enterprise",
        "framework_bridge",
    ]:
        scores.setdefault(_key, 0.0)

    # Garantia de chaves das camadas adicionadas dinamicamente.
    for _key in [
        "database_access_wizard",
        "reliable_web_answer",
        "universal_erp_connector",
        "visual_mission_control",
        "channel_gateway",
        "n8n_workflow",
        "browser_automation",
        "cron_enterprise",
        "sandbox_enterprise",
        "framework_bridge",
    ]:
        scores.setdefault(_key, 0.0)

    for _key in ["industry_precision_engine", "reliable_web_answer", "universal_erp_connector", "visual_mission_control", "channel_gateway", "n8n_workflow", "browser_automation", "cron_enterprise", "sandbox_enterprise", "framework_bridge"]:
        scores.setdefault(_key, 0.0)

    if t in {"oi", "olá", "ola", "bom dia", "boa tarde", "boa noite", "tudo bem"}:
        scores["saudacao"] = 1.0
    domain = detect_domain(t)
    db = detect_database(t)
    if domain.get("score", 0) > 0:
        scores["dados_negocio"] += 0.75
    if db.get("explicit"):
        scores["dados_negocio"] += 0.80
    if any(x in t for x in ["mongodb", "mongo", "sql server", "postgres", "postgresql", "mysql", "mariadb", "redis", "cassandra", "elasticsearch", "opensearch", "neo4j"]):
        scores["dados_negocio"] += 1.0
    if any(x in t for x in ["ia para todos", "open ai access", "open source", "open-source", "open weight", "open-weight", "modelos abertos", "modelo aberto", "catalogo de modelos", "catálogo de modelos", "ollama pull", "baixar modelo", "cpu gpu", "cpu ou gpu", "escolher gpu", "perfil cpu", "perfil gpu", "empresa pequena", "enterprise local", "marketplace de agentes", "funcionários digitais", "funcionarios digitais", "acesso externo seguro", "pwa", "mobile", "tablet", "roi", "calculadora de roi", "backup", "atualização automática", "atualizacao automatica", "instalador simples", "instalação simples", "instalacao simples"]):
        scores["open_ai_access"] += 5.90
    if any(x in t for x in ["qualquer segmento", "qualquer seguimento", "segmento", "setor", "indústria", "industria", "logística", "logistica", "financeiro", "contábil", "contabil", "varejo", "atacado", "saúde", "saude", "educação", "educacao", "serviços", "servicos", "manufatura", "empresa", "precisão total", "precisao total", "contas a receber", "contas a pagar", "inadimplência", "inadimplencia", "ruptura", "entregas atrasadas"]):
        scores["industry_precision_engine"] += 12.40

    if any(x in t for x in ["skill", "skills", "clawhub", "hub de skills", "multiagente", "multi agente", "agentes", "sessions_spawn", "spawn", "delegar", "colaboração", "colaboracao", "gerar imagem", "criar imagem", "imagem", "desenhe", "geração de imagens", "geracao de imagens", "softwares locais", "arquivos locais", "código", "codigo"]):
        scores["skills_multi_agent_center"] += 23.10

    if any(x in t for x in ["lovable", "zheus", "sistema inteiro", "todas as páginas", "todas as paginas", "login", "filtros", "cálculos", "calculos", "github", "deploy", "preview", "cobrança", "cobranca", "teto de custo", "white label", "saas"]):
        scores["app_factory_pro"] += 40.0
        scores["software_builder_center"] = 0.0
        scores["skills_multi_agent_center"] = 0.0 if "skills_multi_agent_center" in scores else scores.get("skills_multi_agent_center", 0.0)

    if any(x in t for x in ["software", "sistema", "aplicativo", "aplicação", "aplicacao", "interface web", "web app", "programa"]) and any(y in t for y in ["quero", "preciso", "criar", "crie", "gerar", "gera", "desenvolver", "fazer", "montar"]):
        scores["app_factory_pro"] += 35.0
        scores["software_builder_center"] = 0.0
        scores["skills_multi_agent_center"] = 0.0 if "skills_multi_agent_center" in scores else scores.get("skills_multi_agent_center", 0.0)

    if any(x in t for x in ["ransomware", "criptografar arquivos", "criptografam arquivos", "arquivos criptografados", "invasão", "invasao", "phishing", "e-mail infectado", "email infectado", "anexo infectado", "malware", "vírus", "virus", "edr", "siem", "soc", "defender", "wazuh", "proteger dados", "prevenir ataque", "prevenir invasão"]):
        scores["cyber_defense_shield"] += 55.0

    if any(x in t for x in ["aihub", "zheus", "asimov", "produto comercial", "produto final", "enterprise productization", "50 skills", "40 templates", "deploy real", "github real", "vercel", "supabase", "stripe", "frota de agentes", "agent fleet", "agentes 24/7", "quality gate global", "rag maduro", "white-label", "white label", "observabilidade", "integrações reais", "integracoes reais"]):
        scores["enterprise_productization_v13"] += 45.0

    if any(x in t for x in ["ebitda", "dre", "saúde financeira", "saude financeira", "indicadores fundamentalistas", "fundamentalistas", "fluxo de caixa", "margem", "margens", "liquidez", "endividamento", "rentabilidade", "roe", "roa", "roi", "roic", "dívida líquida", "divida liquida", "contas a pagar", "contas a receber", "inadimplência", "inadimplencia", "capital de giro", "ponto de equilíbrio", "ponto de equilibrio", "ticket médio", "ticket medio", "painel executivo", "valuation", "ev/ebitda", "lucro líquido", "lucro liquido"]):
        scores["executive_financial_intelligence"] += 22.40
        scores["industry_precision_engine"] = max(0.0, scores.get("industry_precision_engine", 0.0) - 6.0)

    if any(x in t for x in ["whatsapp", "whats", "zap", "telegram", "voz e texto", "texto e voz", "mandar por voz", "enviar por voz", "mandar resposta", "enviar resposta", "mandar no whatsapp", "enviar no whatsapp", "mandar no telegram", "enviar no telegram", "e-mail para o solicitante", "email para o solicitante", "mandar e-mail", "enviar e-mail", "mandar email", "enviar email"]):
        scores["omnichannel_voice_text_delivery"] += 8.30

    if any(x in t for x in ["google meet", "meet", "teams", "zoom", "webex", "call", "reunião", "reuniao", "videoconferência", "videoconferencia", "ata", "transcrição", "transcricao", "responder por voz", "resposta por voz", "chat da reunião", "chat da reuniao", "perguntas na reunião", "perguntas na reuniao"]):
        scores["meeting_intelligence_gateway"] += 8.10

    if any(x in t for x in ["power bi", "powerbi", "zabbix", "grafana", "crm", "teams", "slack", "agenda", "calendário", "calendario", "time", "times", "setor", "departamento", "almoxarifado", "contabilidade", "recebimentos", "bilhetagem", "agronegocio", "agronegócio", "fintech", "varejo", "atacado", "industria", "indústria", "colaboração", "colaboracao"]):
        scores["enterprise_integration_team_intelligence"] += 7.85

    if any(x in t for x in ["bom dia", "boa tarde", "boa noite", "oi", "olá", "ola", "tudo bem", "vamos conversar", "bate papo", "bater papo", "quero conversar", "me escuta"]):
        scores["human_conversation_gateway"] += 8.20

    if any(x in t for x in ["banco de dados", "base de dados", "sql", "nosql", "oracle", "sql server", "postgres", "postgresql", "mysql", "mariadb", "sqlite", "firebird", "db2", "mongodb", "mongo", "redis", "elasticsearch", "cassandra", "couchdb", "tabela", "view", "schema", "collection", "coleção", "colecao", "índice", "indice", "consultar no banco", "consultar a base", "extrair do banco", "query", "select"]):
        scores["database_access_wizard"] += 7.60

    if any(x in t for x in ["pesquisar na internet", "pesquise na internet", "pesquisa web", "fontes confiáveis", "fontes confiaveis", "informação atual", "informacao atual", "atual", "hoje", "agora", "quem é", "quem e", "qual é", "qual e", "presidente do brasil", "notícia", "noticia"]):
        scores["reliable_web_answer"] += 7.20

    if any(x in t for x in ["erp", "banco de dados", "mongodb", "oracle", "sql server", "postgres", "mysql", "firebird", "db2", "venda de passagens", "passagens", "vale-transporte", "vale transporte", "bilhetagem", "sistema legado", "programa individual"]):
        scores["universal_erp_connector"] += 6.60

    if any(x in t for x in ["mission control", "controle de missão", "controle de missao", "painel visual", "painel de agentes", "escritório digital", "escritorio digital", "agentes estão trabalhando", "agentes estao trabalhando", "mapa de agentes", "modo apresentação", "modo apresentacao", "visual mission", "salas dos agentes"]):
        scores["visual_mission_control"] += 6.40

    if any(x in t for x in ["whatsapp", "telegram", "slack", "teams", "discord", "e-mail", "email", "channel gateway", "gateway de canais", "canal externo", "webchat"]):
        scores["channel_gateway"] += 5.75
    if any(x in t for x in ["n8n", "workflow", "webhook", "automação determinística", "automacao deterministica", "fluxo no n8n"]):
        scores["n8n_workflow"] += 5.75
    if any(x in t for x in ["playwright", "selenium", "navegador", "browser automation", "clicar", "preencher campo", "screenshot", "automatizar site"]):
        scores["browser_automation"] += 5.75
    if any(x in t for x in ["cron", "agendamento", "agendar", "agende", "agenda", "scheduler", "tarefa recorrente", "serviço windows", "systemd", "todo dia", "toda semana"]):
        scores["cron_enterprise"] += 7.25
    if any(x in t for x in ["sandbox", "docker", "limite de cpu", "limite de ram", "cofre de credenciais", "logs imutáveis", "logs imutaveis", "container isolado"]):
        scores["sandbox_enterprise"] += 5.75
    if any(x in t for x in ["crewai", "langgraph", "autogen", "mcp", "framework bridge", "agent framework", "ponte de frameworks"]):
        scores["framework_bridge"] += 5.75
    if any(x in t for x in ["voz em tempo real", "real-time voice", "realtime voice", "gpt live", "gpt-live", "alexa da openai", "escuta contínua", "escuta continua", "vad", "detecção de voz", "deteccao de voz", "silêncio final", "silencio final", "transcrição parcial", "transcricao parcial", "fala ao mesmo tempo", "ouvir e falar", "barge-in real", "parar de falar quando eu falar", "microfone sempre ouvindo", "tts natural", "stt streaming"]):
        scores["realtime_voice"] += 5.80
    if any(x in t for x in ["voz natural", "voz humana", "sem sotaque", "sotaque paulista", "minha voz", "voz do usuário", "voz do usuario", "assistente pessoal", "funcionário 24x7", "funcionario 24x7", "funcionário especialista", "funcionario especialista", "atendente humanizado", "responde como humano", "conversa como humano", "avatar futurístico", "avatar futuristico", "alfred", "jave", "hall na tela", "não interromper", "nao interromper", "esperar terminar", "barge-in", "interromper resposta"]):
        scores["human_voice"] += 5.40
    if any(x in t for x in ["runtime", "agent runtime", "tarefa longa", "tarefas longas", "execução longa", "execucao longa", "checkpoint", "checkpoints", "pausar", "retomar", "cancelar job", "fila de jobs", "job", "jobs", "worker", "workers", "sandbox", "execução paralela", "execucao paralela", "agentes paralelos", "observabilidade", "métricas de produtividade", "metricas de produtividade", "scorecard", "patch", "diff", "reexecutar etapa", "aprovação dupla", "aprovacao dupla"]):
        scores["agent_runtime"] += 5.20
    if any(x in t for x in ["saas", "white label", "white-label", "marca própria", "marca propria", "domínio próprio", "dominio proprio", "assinatura mensal", "cobrança recorrente", "cobranca recorrente", "criar app", "criar aplicativo", "criar site", "crie um app", "crie um aplicativo", "crie um site", "gerar app", "gerar site", "preview ao vivo", "deploy em 1 clique", "deploy", "rollback", "versionamento", "vender como assinatura", "vender para clientes", "multi tenant", "multitenant"]):
        scores["saas_builder"] += 5.00
    if any(x in t for x in ["time de agentes", "times de agentes", "equipe de agentes", "agentes empresariais", "business team", "business teams", "time de atendimento", "time de vendas", "sdr", "jarvis executivo", "atendimento no whatsapp", "atendimento por whatsapp", "conteúdo no piloto", "conteudo no piloto", "montar um time", "crie um time", "criar um time", "equipe para", "time para", "automatize o atendimento", "atendimento automático", "atendimento automatico"]):
        scores["business_teams"] += 2.25
    if any(x in t for x in ["base de dados", "banco de dados", "database", "dados", "oracle", "sql", "sql server", "postgres", "postgresql", "mysql", "mariadb", "mongodb", "mongo", "nosql", "último mês", "última data", "contas a receber", "crc", "contas a pagar", "cpg", "arrecadação", "bilheteria", "viagens", "frota", "escala", "folha", "jurídico", "juridico", "estoque", "vendas", "pedido", "frete", "entrega", "loja", "atacado", "varejo", "contabilidade"]):
        scores["dados_negocio"] += 1.0
        if any(x in t for x in ["arrecadação", "bilheteria", "viagens", "frota", "escala", "transporte", "ônibus", "onibus"]):
            scores["transporte_sql"] += 1.0
    if any(x in t for x in ["zabbix", "grafana", "monitoramento", "alerta", "servidor", "cpu", "memória", "disco"]):
        scores["monitoramento"] += 1.0
    if any(x in t for x in ["erp", "sistema"]) and any(x in t for x in ["lento", "lentidão", "lentidao", "travando", "demorando"]):
        scores["monitoramento"] += 0.8
    if any(x in t for x in ["oracle", "banco"]) and any(x in t for x in ["zabbix", "grafana", "monitoramento"]):
        scores["monitoramento"] += 0.5
    if any(x in t for x in ["veja minha tela", "ver minha tela", "olhe minha tela", "captura", "print", "câmera", "camera", "imagem", "foto"]):
        scores["visao"] += 1.0
    if any(x in t for x in ["clique", "digite", "escreva nessa tela", "janela ativa", "crie uma pasta", "abrir site", "abra ", "mouse", "teclado", "whatsapp", "word", "excel"]):
        scores["desktop"] += 1.0
    if any(x in t for x in ["lembre", "memorize", "guarde", "salve na memória", "salve na memoria", "o que você lembra", "o que voce lembra"]):
        scores["memoria"] += 1.0
    if any(x in t for x in ["artigo", "texto", "post", "apresentação", "apresentacao", "relatório", "relatorio", "proposta"]):
        scores["conteudo"] += 0.8
    if any(x in t for x in ["reunião", "reuniao", "ata da reunião", "ata de reunião", "transcrição", "transcricao"]):
        scores["reuniao"] += 0.9
    if any(x in t for x in ["email", "e-mail", "caixa de entrada"]):
        scores["email"] += 0.9
    if any(x in t for x in ["código", "codigo", "programa", "python", "java", "api", "sistema web"]):
        scores["codigo"] += 1.0
    if any(x in t for x in ["automatizar", "automação", "automacao", "workflow", "rotina repetitiva"]):
        scores["automacao"] += 1.0

    target = max(scores.items(), key=lambda kv: kv[1])[0]
    return {"target": target, "scores": scores, "normalized": t}


def plan(message: str, approved: bool = False) -> dict[str, Any]:
    c = classify(message)
    target = c["target"]
    steps: list[dict[str, Any]] = [
        {"id": "understand", "tool": "classifier", "status": "done", "result": c},
        {"id": "memory_search", "tool": "memory", "status": "pending"},
    ]

    if target == "saudacao":
        steps.append({"id": "answer", "tool": "conversation", "status": "pending"})
    elif target == "open_ai_access":
        steps.append({"id": "detect_hardware_profile", "tool": "open_ai_access", "status": "pending"})
        steps.append({"id": "recommend_open_models", "tool": "open_ai_access", "status": "pending"})
        steps.append({"id": "prepare_ollama_download_plan", "tool": "open_ai_access", "status": "pending"})
        steps.append({"id": "enable_agent_marketplace", "tool": "open_ai_access", "status": "pending"})
        steps.append({"id": "secure_external_access", "tool": "governance", "status": "pending", "requires_approval": True})
    elif target == "industry_precision_engine":
        steps.append({"id": "classify_industry_and_intent", "tool": "industry_precision", "status": "pending"})
        steps.append({"id": "check_required_data_sources", "tool": "industry_precision", "status": "pending"})
        steps.append({"id": "route_to_segment_tool_or_ask_clarification", "tool": "industry_precision", "status": "pending"})
    elif target == "skills_multi_agent_center":
        steps.append({"id": "detect_skill_agent_or_image_need", "tool": "skills_center", "status": "pending"})
        steps.append({"id": "select_or_create_skill", "tool": "skills_center", "status": "pending"})
        steps.append({"id": "spawn_or_delegate_agents", "tool": "skills_center", "status": "pending"})
        steps.append({"id": "collaborate_and_synthesize", "tool": "skills_center", "status": "pending"})
    elif target == "app_factory_pro":
        steps.append({"id": "understand_full_app_request", "tool": "app_factory", "status": "pending"})
        steps.append({"id": "generate_login_pages_components", "tool": "app_factory", "status": "pending"})
        steps.append({"id": "generate_filters_calculations_empty_states", "tool": "app_factory", "status": "pending"})
        steps.append({"id": "generate_settings_billing_ai_cost_guard", "tool": "app_factory", "status": "pending"})
        steps.append({"id": "prepare_github_deploy_preview", "tool": "app_factory", "status": "pending"})
        steps.append({"id": "run_quality_gate", "tool": "app_factory", "status": "pending"})

    elif target == "software_builder_center":
        steps.append({"id": "identify_software_requirements", "tool": "software_builder", "status": "pending"})
        steps.append({"id": "design_architecture", "tool": "software_builder", "status": "pending"})
        steps.append({"id": "define_screens_database_and_stack", "tool": "software_builder", "status": "pending"})
        steps.append({"id": "offer_scaffold_generation", "tool": "software_builder", "status": "pending"})

    elif target == "executive_financial_intelligence":
        steps.append({"id": "identify_financial_period_and_scope", "tool": "executive_finance", "status": "pending"})
        steps.append({"id": "load_ebitda_dre_cash_margin_rules", "tool": "executive_finance", "status": "pending"})
        steps.append({"id": "query_real_financial_source", "tool": "executive_finance", "status": "pending"})
        steps.append({"id": "calculate_fundamental_indicators", "tool": "executive_finance", "status": "pending"})
        steps.append({"id": "explain_to_executives", "tool": "executive_finance", "status": "pending"})
    elif target == "omnichannel_voice_text_delivery":
        steps.append({"id": "detect_whatsapp_or_telegram", "tool": "omnichannel_delivery", "status": "pending"})
        steps.append({"id": "prepare_text_and_voice_answer", "tool": "omnichannel_delivery", "status": "pending"})
        steps.append({"id": "check_recipient_credentials_and_approval", "tool": "omnichannel_delivery", "status": "pending"})
    elif target == "meeting_intelligence_gateway":
        steps.append({"id": "identify_meeting_platform", "tool": "meeting_intelligence", "status": "pending"})
        steps.append({"id": "prepare_voice_text_qa", "tool": "meeting_intelligence", "status": "pending"})
        steps.append({"id": "prepare_minutes_actions_and_integrations", "tool": "meeting_intelligence", "status": "pending"})
    elif target == "enterprise_integration_team_intelligence":
        steps.append({"id": "identify_segment_user_or_team", "tool": "enterprise_intelligence", "status": "pending"})
        steps.append({"id": "select_tools_and_department_agents", "tool": "enterprise_intelligence", "status": "pending"})
        steps.append({"id": "prepare_team_calendar_and_task_plan", "tool": "enterprise_intelligence", "status": "pending"})
    elif target == "human_conversation_gateway":
        steps.append({"id": "understand_natural_message", "tool": "human_conversation", "status": "pending"})
        steps.append({"id": "reply_or_route_without_buttons", "tool": "human_conversation", "status": "pending"})
    elif target == "database_access_wizard":
        steps.append({"id": "identify_database_or_connection", "tool": "database_access", "status": "pending"})
        steps.append({"id": "ask_required_data_details", "tool": "database_access", "status": "pending"})
        steps.append({"id": "create_safe_query_plan", "tool": "database_access", "status": "pending"})
    elif target == "reliable_web_answer":
        steps.append({"id": "normalize_user_question", "tool": "reliable_web", "status": "pending"})
        steps.append({"id": "search_trusted_sources", "tool": "reliable_web", "status": "pending"})
        steps.append({"id": "synthesize_direct_answer", "tool": "reliable_web", "status": "pending"})
    elif target == "universal_erp_connector":
        steps.append({"id": "detect_erp_or_application", "tool": "universal_erp", "status": "pending"})
        steps.append({"id": "create_safe_query_plan", "tool": "universal_erp", "status": "pending"})
        steps.append({"id": "apply_read_only_and_approval_policy", "tool": "governance", "status": "pending", "requires_approval": True})
    elif target == "visual_mission_control":
        steps.append({"id": "create_visual_mission", "tool": "visual_mission", "status": "pending"})
        steps.append({"id": "assign_agents_to_rooms", "tool": "visual_mission", "status": "pending"})
        steps.append({"id": "show_status_metrics_and_approvals", "tool": "visual_mission", "status": "pending"})
    elif target == "channel_gateway":
        steps.append({"id": "configure_or_select_channel", "tool": "channel_gateway", "status": "pending"})
        steps.append({"id": "apply_external_message_governance", "tool": "governance", "status": "pending", "requires_approval": True})
    elif target == "n8n_workflow":
        steps.append({"id": "map_intent_to_workflow", "tool": "n8n", "status": "pending"})
        steps.append({"id": "prepare_webhook_api_execution", "tool": "n8n", "status": "pending"})
    elif target == "browser_automation":
        steps.append({"id": "create_isolated_browser_profile", "tool": "browser_automation", "status": "pending"})
        steps.append({"id": "plan_browser_actions", "tool": "browser_automation", "status": "pending"})
    elif target == "cron_enterprise":
        steps.append({"id": "create_scheduled_job", "tool": "cron_enterprise", "status": "pending"})
        steps.append({"id": "configure_retry_and_delivery", "tool": "cron_enterprise", "status": "pending"})
    elif target == "sandbox_enterprise":
        steps.append({"id": "create_docker_sandbox_plan", "tool": "sandbox_enterprise", "status": "pending"})
        steps.append({"id": "apply_limits_and_secret_policy", "tool": "sandbox_enterprise", "status": "pending"})
    elif target == "framework_bridge":
        steps.append({"id": "recommend_agent_framework", "tool": "framework_bridge", "status": "pending"})
        steps.append({"id": "create_bridge_run", "tool": "framework_bridge", "status": "pending"})
    elif target == "realtime_voice":
        steps.append({"id": "start_realtime_voice_session", "tool": "realtime_voice", "status": "pending"})
        steps.append({"id": "apply_vad_turn_taking", "tool": "voice_runtime", "status": "pending"})
        steps.append({"id": "enable_barge_in", "tool": "voice_runtime", "status": "pending"})
        steps.append({"id": "route_final_transcript", "tool": "hall_router", "status": "pending"})
    elif target == "human_voice":
        steps.append({"id": "load_human_voice_profile", "tool": "human_voice", "status": "pending"})
        steps.append({"id": "select_persona_or_employee_role", "tool": "human_voice", "status": "pending"})
        steps.append({"id": "apply_turn_taking_policy", "tool": "voice_runtime", "status": "pending"})
        steps.append({"id": "route_to_correct_tool", "tool": "hall_router", "status": "pending"})
    elif target == "agent_runtime":
        steps.append({"id": "create_persistent_job", "tool": "agent_runtime", "status": "pending"})
        steps.append({"id": "plan_checkpoints", "tool": "agent_runtime", "status": "pending"})
        steps.append({"id": "assign_parallel_agents", "tool": "agent_runtime", "status": "pending"})
        steps.append({"id": "security_and_observability", "tool": "governance", "status": "pending", "requires_approval": True})
    elif target == "saas_builder":
        steps.append({"id": "detect_app_type", "tool": "saas_builder", "status": "pending"})
        steps.append({"id": "white_label_config", "tool": "saas_builder", "status": "pending"})
        steps.append({"id": "generate_project_plan", "tool": "saas_builder", "status": "pending"})
        steps.append({"id": "approval_policy", "tool": "governance", "status": "pending", "requires_approval": True})
    elif target == "business_teams":
        steps.append({"id": "choose_team_template", "tool": "business_teams", "status": "pending"})
        steps.append({"id": "assemble_agents", "tool": "business_teams", "status": "pending"})
        steps.append({"id": "approval_policy", "tool": "governance", "status": "pending", "requires_approval": True})
    elif target == "dados_negocio":
        steps.append({"id": "detect_segment", "tool": "business_domain", "status": "pending"})
        steps.append({"id": "detect_database", "tool": "database_platform", "status": "pending"})
        steps.append({"id": "prepare_query_or_guidance", "tool": "multi_database", "status": "pending"})
        steps.append({"id": "verify_context", "tool": "verifier", "status": "pending"})
    elif target == "transporte_sql":
        steps.append({"id": "prepare_sql", "tool": "transport_sql", "status": "pending"})
        steps.append({"id": "verify_sql_context", "tool": "verifier", "status": "pending"})
    elif target == "visao":
        steps.append({"id": "request_capture", "tool": "vision", "status": "pending"})
    elif target == "desktop":
        steps.append({"id": "desktop_action", "tool": "desktop", "status": "pending", "requires_approval": True})
    elif target == "memoria":
        steps.append({"id": "memory_write_or_read", "tool": "memory", "status": "pending"})
    elif target == "monitoramento":
        steps.append({"id": "diagnostic_plan", "tool": "monitoring_transport", "status": "pending"})
        steps.append({"id": "llm_reasoning", "tool": "ollama_or_fallback", "status": "pending"})
        steps.append({"id": "verify_answer", "tool": "verifier", "status": "pending"})
    elif target in {"codigo", "conteudo", "reuniao", "email", "automacao"}:
        steps.append({"id": "llm_reasoning", "tool": "ollama_or_fallback", "status": "pending"})
        steps.append({"id": "verify_answer", "tool": "verifier", "status": "pending"})
    else:
        steps.append({"id": "llm_chat", "tool": "ollama_or_fallback", "status": "pending"})

    return {
        "ok": True,
        "run_id": f"run_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "message": message,
        "classification": c,
        "steps": steps,
        "requires_approval": any(s.get("requires_approval") for s in steps),
        "approved": approved,
    }


def execute_plan(p: dict[str, Any]) -> dict[str, Any]:
    message = p["message"]
    approved = bool(p.get("approved"))
    target = p["classification"]["target"]
    memory_result = memory.search(message, limit=8)
    remembered = memory.maybe_remember(message)
    tool_results: dict[str, Any] = {"memory_context": memory_result, "remembered": remembered}
    answer = ""

    if target == "saudacao":
        answer = (
            "Olá! Pode falar comigo naturalmente. Eu atendo diferentes segmentos — Transporte, Logística, Financeiro/Contábil, Varejo, Atacado e outros. "
            "Também trabalho com bancos relacionais e NoSQL, como Oracle, SQL Server, PostgreSQL, MySQL, MariaDB, MongoDB, Redis, Cassandra, Elasticsearch/OpenSearch e Neo4j."
        )

    elif target == "memoria":
        if remembered.get("ok"):
            answer = "Pronto, memorizei isso localmente. Vou usar essa informação quando ela ajudar na conversa."
        else:
            rows = memory_result.get("rows", [])
            answer = "Estas são as memórias relacionadas:\n" + "\n".join(f"- {r['text']}" for r in rows) if rows else "Não encontrei memórias relacionadas."

    elif target == "open_ai_access":
        recommendation = open_ai_access_center.recommend_stack(use_case=message)
        tool_results["open_ai_access"] = recommendation
        answer = open_ai_access_center.answer_for_open_access(message)
        answer += (
            "\n\nPreparei uma recomendação inicial de perfil, modelos locais, comandos Ollama, marketplace de agentes, ROI, acesso seguro e atualização/backup. "
            "Use a aba Open AI Access Center para escolher CPU/GPU, habilitar agentes e gerar plano de implantação."
        )

    elif target == "industry_precision_engine":
        ipe_result = industry_precision_engine.answer(message, approved=approved)
        tool_results["industry_precision_engine"] = ipe_result
        answer = ipe_result.get("answer", "")
        if ipe_result.get("clarification_question"):
            answer += "\n\nPergunta necessária para precisão: " + ipe_result.get("clarification_question", "")

    elif target == "skills_multi_agent_center":
        skills_result = skills_multi_agent_center.guided_answer(message, approved=approved)
        tool_results["skills_multi_agent_center"] = skills_result
        answer = skills_result.get("answer", skills_result.get("summary", skills_multi_agent_center.answer_for_skills(message)))

    elif target == "cyber_defense_shield":
        cy_result = {
            "status": cyber_defense_shield.status(),
            "guard_plan": cyber_defense_shield.ransomware_guard_plan(),
            "posture": cyber_defense_shield.security_posture(),
            "backup": cyber_defense_shield.backup_readiness(),
        }
        tool_results["cyber_defense_shield"] = cy_result
        answer = cyber_defense_shield.natural_answer(message)

    elif target == "enterprise_productization_v13":
        ep_result = {
            "status": enterprise_productization_v13.status(),
            "health": enterprise_productization_v13.platform_health(),
            "skills": enterprise_productization_v13.skills_library(seed=False),
            "templates": enterprise_productization_v13.template_bank(),
            "integrations": enterprise_productization_v13.integration_status(),
        }
        tool_results["enterprise_productization_v13"] = ep_result
        answer = enterprise_productization_v13.answer_for_enterprise_productization(message)

    elif target == "app_factory_pro":
        app_result = app_factory_pro.blueprint_from_prompt(message)
        tool_results["app_factory_pro"] = app_result
        answer = app_result.get("answer", "")

    elif target == "software_builder_center":
        sw_result = software_builder_center.build_plan(message)
        tool_results["software_builder_center"] = sw_result
        answer = sw_result.get("answer", "")

    elif target == "executive_financial_intelligence":
        exec_fin_result = executive_financial_intelligence.guided_answer(message, approved=approved)
        tool_results["executive_financial_intelligence"] = exec_fin_result
        answer = exec_fin_result.get("answer", "")

    elif target == "omnichannel_voice_text_delivery":
        omni_result = {"ok": True, "answer": omnichannel_voice_text_delivery.answer_for_omnichannel(message), "status": omnichannel_voice_text_delivery.status()}
        tool_results["omnichannel_voice_text_delivery"] = omni_result
        answer = omni_result.get("answer", "")

    elif target == "meeting_intelligence_gateway":
        meeting_result = {"ok": True, "answer": meeting_intelligence_gateway.answer_for_meeting(message), "status": meeting_intelligence_gateway.status()}
        tool_results["meeting_intelligence_gateway"] = meeting_result
        answer = meeting_result.get("answer", "")

    elif target == "enterprise_integration_team_intelligence":
        ent_result = enterprise_integration_team_intelligence.guided_answer(message, approved=approved)
        tool_results["enterprise_integration_team_intelligence"] = ent_result
        answer = ent_result.get("answer", "")

    elif target == "human_conversation_gateway":
        hconv_result = human_conversation_gateway.converse(message, approved=approved, run_tools=True)
        tool_results["human_conversation_gateway"] = hconv_result
        answer = hconv_result.get("answer", "")

    elif target == "database_access_wizard":
        db_result = database_access_wizard.guided_answer(message, approved=approved)
        tool_results["database_access_wizard"] = db_result
        answer = db_result.get("answer", "Preciso confirmar qual banco de dados devo acessar e quais informações você precisa.")

    elif target == "reliable_web_answer":
        web_result = reliable_web_answer.answer_question(message, approved=approved)
        tool_results["reliable_web_answer"] = web_result
        answer = web_result.get("answer", "")
        sources = web_result.get("sources", [])[:3]
        if sources:
            answer += "\n\nFontes verificadas:\n" + "\n".join([f"- {s.get('title','Fonte')}: {s.get('url','')}" for s in sources])

    elif target == "universal_erp_connector":
        plan = universal_erp_connector.create_query_plan(message, approved=approved)
        tool_results["universal_erp_connector"] = plan
        answer = universal_erp_connector.answer_for_erp(message)

    elif target == "visual_mission_control":
        mission = visual_mission_control.create_mission(
            title="Missão criada pelo HAL",
            objective=message,
            source="orchestrator",
            requires_approval=not approved,
            presentation=True,
        )
        tool_results["visual_mission_control"] = mission
        answer = visual_mission_control.answer_for_visual_mission(message)

    elif target == "channel_gateway":
        st = channel_gateway.status()
        tool_results["channel_gateway"] = st
        answer = channel_gateway.answer_for_channel_gateway(message)

    elif target == "n8n_workflow":
        st = n8n_workflow_center.status()
        intent = n8n_workflow_center.map_intent(message)
        tool_results["n8n_workflow"] = {"status": st, "intent": intent}
        answer = n8n_workflow_center.answer_for_n8n(message)

    elif target == "browser_automation":
        st = browser_automation.status()
        tool_results["browser_automation"] = st
        answer = browser_automation.answer_for_browser(message)

    elif target == "cron_enterprise":
        st = cron_enterprise.status()
        tool_results["cron_enterprise"] = st
        answer = cron_enterprise.answer_for_cron(message)

    elif target == "sandbox_enterprise":
        st = sandbox_enterprise.status()
        tool_results["sandbox_enterprise"] = st
        answer = sandbox_enterprise.answer_for_sandbox(message)

    elif target == "framework_bridge":
        st = agent_framework_bridge.status()
        rec = agent_framework_bridge.recommend_framework(message)
        tool_results["framework_bridge"] = {"status": st, "recommendation": rec}
        answer = agent_framework_bridge.answer_for_bridge(message)

    elif target == "realtime_voice":
        session = realtime_voice_engine.start_session(mode="assistant", channel="web")
        tool_results["realtime_voice"] = session
        answer = realtime_voice_engine.answer_for_realtime_voice(message)
        answer += (
            "\n\nSessão de voz em tempo real preparada. "
            "No navegador, o HAL passa a escutar continuamente, aguardar silêncio final, permitir interrupção natural e enviar a transcrição final para a ferramenta correta."
        )

    elif target == "human_voice":
        hv = human_voice_assistant.human_answer(message)
        tool_results["human_voice"] = hv
        answer = hv.get("answer") or hv.get("greeting") or human_voice_assistant.answer_for_human_voice(message)
        answer += (
            "\n\nA camada Human Voice Assistant 24x7 está preparada para voz pt-BR paulista/neutra, voz própria autorizada, "
            "avatar futurístico, modo assistente pessoal e funcionário especialista por área."
        )

    elif target == "agent_runtime":
        runtime_job = agent_runtime.create_job(objective=message, requires_approval=True)
        tool_results["agent_runtime"] = runtime_job
        job = runtime_job.get("job", {})
        answer = agent_runtime.answer_for_runtime(
            objective=message,
            job_type=job.get("job_type", ""),
        )
        answer += (
            "\n\nJob criado na fila persistente do Agent Runtime Enterprise. "
            "Você pode iniciar, aprovar, avançar etapas, pausar, retomar, cancelar, reexecutar etapas, gerar scorecard e acompanhar métricas/observabilidade."
        )

    elif target == "saas_builder":
        project_plan = saas_builder.create_project(idea=message)
        tool_results["saas_builder"] = project_plan
        project = project_plan.get("project", {})
        answer = saas_builder.answer_for_saas_builder(
            idea=message,
            template=project.get("template_key", ""),
            database=project.get("database", {}).get("key", ""),
            segment=project.get("segment", {}).get("key", ""),
        )
        answer += (
            "\n\nProjeto criado no catálogo do SaaS Builder. "
            "O próximo passo é clicar em Gerar Código para criar o fonte inicial, preview local, Dockerfile, plano de deploy, versionamento e rollback."
        )

    elif target == "business_teams":
        team_plan = business_teams.create_team(goal=message, approval_required=True)
        tool_results["business_team"] = team_plan
        team = team_plan.get("team", {})
        answer = business_teams.answer_for_business_teams(
            goal=message,
            template=team.get("template_key", ""),
            segment=team.get("segment", {}).get("key", ""),
            database=team.get("database", {}).get("key", ""),
        )
        answer += (
            "\n\nPlano inicial criado com "
            f"{len(team.get('agents', []))} agentes e {len(team.get('workflow', []))} etapas. "
            "Posso simular a execução agora ou enviar ações sensíveis para a fila de aprovação."
        )

    elif target == "dados_negocio":
        domain = detect_domain(message)
        db = detect_database(message)
        tool_results["business_domain"] = domain
        tool_results["database"] = db
        needs_period = any(x in norm(message) for x in ["último mês", "ultima data", "última data", "último periodo", "último período", "base de dados", "maior data"])
        if needs_period:
            example = last_period_example(db["key"], "sua_tabela_ou_collection")
            answer = (
                f"Identifiquei o segmento {domain['label']} e o banco {db['label']} ({db['family']}). "
                "Para descobrir o último período, preciso do nome real da tabela/collection e do campo de data. "
                "Segue um exemplo inicial adaptado ao banco informado:\n\n"
                f"{example}\n\n"
                "Se você não souber a tabela, use o Mapa ERP/Metadados ou peça: 'HAL, localize a tabela e o campo de data nos metadados'."
            )
        else:
            guide = connection_guidance(db["key"])
            tmsg = norm(message)
            sample = ""
            if ("contas a receber" in tmsg or "crc" in tmsg or "receber vencid" in tmsg) and db["key"] in {"sqlserver", "oracle", "postgresql", "mysql", "mariadb"}:
                if db["key"] == "sqlserver":
                    sample = """\n\nExemplo inicial em SQL Server:\nSELECT TOP 50\n    CLIENTE_ID,\n    NOME_CLIENTE,\n    COUNT(*) AS QTDE_TITULOS,\n    SUM(VALOR_ABERTO) AS VALOR_TOTAL_ABERTO,\n    MIN(DATA_VENCIMENTO) AS VENCIMENTO_MAIS_ANTIGO\nFROM dbo.CONTAS_RECEBER\nWHERE STATUS = 'ABERTO'\n  AND DATA_VENCIMENTO < CAST(GETDATE() AS date)\nGROUP BY CLIENTE_ID, NOME_CLIENTE\nORDER BY VALOR_TOTAL_ABERTO DESC;"""
                elif db["key"] == "oracle":
                    sample = """\n\nExemplo inicial em Oracle:\nSELECT\n    CLIENTE_ID, NOME_CLIENTE, COUNT(*) QTDE_TITULOS,\n    SUM(VALOR_ABERTO) VALOR_TOTAL_ABERTO,\n    MIN(DATA_VENCIMENTO) VENCIMENTO_MAIS_ANTIGO\nFROM CONTAS_RECEBER\nWHERE STATUS = 'ABERTO'\n  AND DATA_VENCIMENTO < TRUNC(SYSDATE)\nGROUP BY CLIENTE_ID, NOME_CLIENTE\nORDER BY VALOR_TOTAL_ABERTO DESC;"""
                else:
                    sample = """\n\nExemplo inicial SQL:\nSELECT\n    cliente_id, nome_cliente, COUNT(*) AS qtde_titulos,\n    SUM(valor_aberto) AS valor_total_aberto,\n    MIN(data_vencimento) AS vencimento_mais_antigo\nFROM contas_receber\nWHERE status = 'ABERTO'\n  AND data_vencimento < CURRENT_DATE\nGROUP BY cliente_id, nome_cliente\nORDER BY valor_total_aberto DESC;"""
            elif "venda" in tmsg and db["key"] == "mongodb":
                sample = """\n\nExemplo inicial em MongoDB para vendas por dia/produto:\ndb.vendas.aggregate([\n  { $match: { data_venda: { $gte: ISODate('2026-01-01') } } },\n  { $group: {\n      _id: { dia: { $dateToString: { format: '%Y-%m-%d', date: '$data_venda' } }, produto: '$produto_id' },\n      valor_total: { $sum: '$valor_total' },\n      qtde: { $sum: '$quantidade' }\n  } },\n  { $sort: { valor_total: -1 } },\n  { $limit: 50 }\n])"""
            elif ("entrega" in tmsg or "atrasad" in tmsg) and db["key"] in {"postgresql", "sqlserver", "mysql", "mariadb", "oracle"}:
                sample = """\n\nExemplo inicial para entregas atrasadas:\nSELECT\n    pedido_id, cliente_id, data_prevista, data_entrega, status, transportadora\nFROM entregas\nWHERE status NOT IN ('ENTREGUE', 'CANCELADO')\n  AND data_prevista < CURRENT_DATE\nORDER BY data_prevista ASC;"""
            answer = (
                f"Entendi. Detectei o segmento {domain['label']} e o banco {db['label']} ({db['family']}). "
                f"Posso gerar consultas, análises, dashboards, automações e integrações. Driver sugerido: {guide['driver_hint']}. "
                "Quando faltar tabela, collection, índice ou campo de data, vou pedir esse detalhe antes de executar. "
                "Para prosseguir, posso consultar, integrar, migrar, monitorar, criar dashboard, gerar SQL/agregação NoSQL ou automatizar processo."
                f"{sample}"
            )

    elif target == "transporte_sql":
        sql = build_transport_sql(message)
        tool_results["transport_sql"] = sql
        if sql.get("needs_clarification"):
            answer = sql.get("question")
        else:
            answer = (
                f"Entendi. Para o módulo {sql.get('module')}, eu preparei uma consulta inicial segura. "
                "Antes de executar no Oracle real, valide nomes de tabela/campo pelos metadados do ERP.\n\n"
                f"{sql.get('sql')}\n\n"
                f"Observação: {sql.get('notes', '')}"
            )

    elif target == "visao":
        answer = (
            "Consigo analisar a tela/câmera. Clique em Capturar Tela ou Câmera e depois em Analisar Imagem. "
            "Com Ollama Vision ativo, eu descrevo o conteúdo visual; sem ele, salvo a captura e informo os próximos passos."
        )

    elif target == "desktop":
        action = infer_desktop_action(message)
        tool_results["desktop_action"] = action
        if action.get("action") in {"screenshot", "camera"}:
            res = desktop.execute(action["action"], action.get("payload", {}), approved=True)
            tool_results["desktop_result"] = res
            answer = res.get("summary", "Ação de desktop processada.")
        elif not approved:
            answer = (
                "Esse comando controla o computador. Por segurança, marque 'Aprovar ações no computador' e confirme. "
                f"A ação planejada foi: {action.get('action')}."
            )
        else:
            res = desktop.execute(action["action"], action.get("payload", {}), approved=True)
            tool_results["desktop_result"] = res
            answer = res.get("summary", "Ação de desktop executada.")

    else:
        answer = llm_or_fallback(message, target, memory_result)

    verification = verify_answer(message, target, answer, tool_results)
    if not verification.get("ok"):
        answer = verification.get("corrected_answer", answer)

    # Entrega omnichannel automática se o pedido mencionou WhatsApp/Telegram.
    try:
        if answer:
            omni_auto = omnichannel_voice_text_delivery.deliver_if_requested(message, answer, approved=approved, source="orchestrator_auto")
            if omni_auto and not omni_auto.get("skipped"):
                tool_results["omnichannel_delivery"] = omni_auto
    except Exception as exc:
        tool_results["omnichannel_delivery"] = {"ok": False, "error": str(exc)}

    result = {
        "ok": True,
        "run_id": p["run_id"],
        "answer": answer,
        "target": target,
        "plan": p,
        "tool_results": tool_results,
        "verification": verification,
        "model_status": model_runtime_status(),
        "created_at": _now(),
    }
    save_run(result)
    return result


def infer_desktop_action(message: str) -> dict[str, Any]:
    t = norm(message)
    if "câmera" in t or "camera" in t:
        return {"action": "camera", "payload": {}}
    if any(x in t for x in ["print", "captura", "veja minha tela", "ver minha tela"]):
        return {"action": "screenshot", "payload": {}}
    if "digite" in t or "escreva" in t:
        text = message
        for marker in ["digite", "escreva nessa tela", "escreva"]:
            idx = t.find(marker)
            if idx >= 0:
                text = message[idx + len(marker):].strip(" :.-")
                break
        return {"action": "type_text", "payload": {"text": text or message}}
    if "crie uma pasta" in t:
        return {"action": "create_folder", "payload": {"name": "Relatorios_Transporte"}}
    if "abra" in t or "abrir" in t:
        return {"action": "open_url", "payload": {"url": message}}
    return {"action": "create_note", "payload": {"text": message}}


def llm_or_fallback(message: str, target: str, memory_result: dict[str, Any]) -> str:
    cfg = load_config()
    ollama_enabled = cfg.get("ollama", {}).get("enabled", False)
    context_lines = [r.get("text", "") for r in memory_result.get("rows", [])[:5]]
    system = (
        "Você é HAL, um assistente local multi-segmento para empresas. "
        "Atende Transporte, Logística, Financeiro/Contábil, Varejo, Atacado/Distribuição e outros segmentos. "
        "Converse em português brasileiro, de forma humana, objetiva e educada. "
        "Sempre que faltar contexto, faça uma pergunta de esclarecimento antes de agir. "
        + segment_prompt() + "\n" + transport_context_prompt()
    )
    if context_lines:
        system += "\nMemórias úteis:\n" + "\n".join(f"- {x}" for x in context_lines)

    if ollama_enabled:
        choice = choose_model(intent="coding" if target == "codigo" else "chat")
        client = OllamaClient()
        if client.available():
            res = client.chat(
                [{"role": "system", "content": system}, {"role": "user", "content": message}],
                model=choice.name,
                temperature=0.2,
            )
            if res.get("ok") and res.get("content"):
                return res["content"]

    # Deterministic fallback
    if target == "monitoramento":
        return (
            "Vou tratar isso como diagnóstico operacional. Verifique primeiro: serviços de bilheteria/arrecadação, Oracle, rede da garagem, Zabbix/Grafana, CPU/memória/disco e filas de integração. "
            "Se você compartilhar a tela ou conectar os dados reais, eu priorizo os alertas por impacto operacional."
        )
    if target == "codigo":
        return "Posso criar o projeto/código, mas preciso do tipo de sistema, linguagem, banco e principais telas/regras."
    if target == "conteudo":
        return "Posso criar o conteúdo. Para transporte, recomendo destacar redução de custos, previsibilidade, monitoramento, arrecadação, frota, escala e BI executivo."
    if target == "reuniao":
        return "Envie a transcrição ou ata da reunião. Eu retorno resumo, decisões, pendências, responsáveis e próximos passos."
    if target == "email":
        return "Cole o e-mail ou deixe a janela ativa. Eu preparo uma resposta educada e só envio/digito com aprovação."
    if target == "automacao":
        return "Vou planejar a automação em etapas: entrada, validação, sistema destino, execução, conferência e aprovação humana para ações sensíveis."
    return "Entendi. Vou te ajudar passo a passo e perguntar o que faltar antes de executar qualquer ação."


def verify_answer(message: str, target: str, answer: str, tool_results: dict[str, Any]) -> dict[str, Any]:
    if target == "transporte_sql":
        sql = tool_results.get("transport_sql", {})
        if sql.get("needs_clarification") and "módulo" not in answer.lower():
            return {
                "ok": False,
                "corrected_answer": "Preciso saber de qual módulo do transporte você quer consultar: arrecadação, bilheteria, viagens, frota, manutenção, escala, financeiro, CRC, CPG, folha ou jurídico."
            }
    if target == "dados_negocio" and "segmento" not in answer.lower() and "banco" not in answer.lower() and "mongodb" not in answer.lower() and "sql server" not in answer.lower():
        return {"ok": False, "corrected_answer": "Preciso confirmar o segmento de negócio e o banco de dados antes de gerar uma solução confiável."}
    if target == "desktop" and "aprovação" not in answer.lower() and tool_results.get("desktop_action", {}).get("action") not in {"screenshot", "camera"}:
        return {"ok": False, "corrected_answer": "Essa ação controla o computador e exige aprovação humana antes de executar."}
    return {"ok": True, "summary": "Resposta verificada."}


def model_runtime_status() -> dict[str, Any]:
    client = OllamaClient()
    return {
        "ollama_online": client.available(),
        "choice_chat": choose_model("chat").__dict__,
        "choice_vision": choose_model("vision", has_image=True).__dict__,
    }


def save_run(data: dict[str, Any]) -> None:
    _ensure()
    path = RUNS / f"{data['run_id']}.json"
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def run(message: str, approved: bool = False) -> dict[str, Any]:
    p = plan(message, approved=approved)
    return execute_plan(p)
