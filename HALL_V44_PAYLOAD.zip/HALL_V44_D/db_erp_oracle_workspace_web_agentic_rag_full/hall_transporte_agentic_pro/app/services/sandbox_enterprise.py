from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _slug(text: str) -> str:
    import re
    text = (text or "item").lower()
    text = re.sub(r"[^a-z0-9áéíóúãõâêôç]+", "-", text)
    text = (text.replace("á","a").replace("é","e").replace("í","i").replace("ó","o").replace("ú","u")
            .replace("ã","a").replace("õ","o").replace("â","a").replace("ê","e").replace("ô","o").replace("ç","c"))
    return re.sub(r"-+", "-", text).strip("-") or "item"


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(path: Path, event: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")

DATA_DIR = root_dir() / "data" / "sandbox_enterprise"
SANDBOXES_FILE = DATA_DIR / "sandboxes.json"
SECRETS_FILE = DATA_DIR / "secrets_registry.json"
AUDIT_FILE = DATA_DIR / "audit_immutable.jsonl"
SANDBOX_ROOT = DATA_DIR / "sandboxes"

DEFAULT_LIMITS = {
    "cpu_quota": "1-2 cores",
    "memory": "2g",
    "timeout_seconds": 300,
    "network": "disabled_by_default",
    "disk": "1g",
    "read_only_root": True,
    "no_privileged": True,
}


def status() -> dict[str, Any]:
    sandboxes = _load(SANDBOXES_FILE, {"sandboxes": []}).get("sandboxes", [])
    secrets = _load(SECRETS_FILE, {"secrets": []}).get("secrets", [])
    return {
        "ok": True,
        "name": "HAL Sandbox Enterprise",
        "description": "Sandbox de execução com Docker/isolamento, limites, rede controlada, logs imutáveis e cofre de credenciais.",
        "sandboxes_count": len(sandboxes),
        "secrets_registered": len(secrets),
        "capabilities": [
            "Sandbox Docker por agente/job",
            "Limite de CPU/RAM/disco/timeout",
            "Rede bloqueada por padrão",
            "Pasta isolada por execução",
            "Logs imutáveis em JSONL",
            "Registro seguro de segredos por nome de variável",
            "Política read-only default",
            "Aprovação humana antes de ações críticas",
        ],
    }


def create_sandbox(name: str, purpose: str, agent: str = "hall", network: str = "disabled", memory: str = "2g", timeout_seconds: int = 300) -> dict[str, Any]:
    _ensure_dir(SANDBOX_ROOT)
    data = _load(SANDBOXES_FILE, {"sandboxes": []})
    sid = f"sbox_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    path = SANDBOX_ROOT / sid
    path.mkdir(parents=True, exist_ok=True)
    item = {
        "id": sid,
        "name": name,
        "purpose": purpose,
        "agent": agent,
        "path": str(path.relative_to(root_dir())),
        "engine": "docker_preferred",
        "limits": {**DEFAULT_LIMITS, "memory": memory, "timeout_seconds": timeout_seconds, "network": network},
        "status": "created",
        "created_at": _now(),
        "docker_hint": docker_hint(sid, memory, network),
    }
    data.setdefault("sandboxes", []).insert(0, item)
    _save(SANDBOXES_FILE, data)
    _audit(AUDIT_FILE, {"event": "create_sandbox", "sandbox_id": sid, "agent": agent})
    return {"ok": True, "sandbox": item, "summary": "Sandbox enterprise criado."}


def docker_hint(name: str, memory: str, network: str) -> str:
    net = "none" if network in {"disabled", "none"} else "bridge"
    return f"docker run --rm --network={net} --memory={memory} --cpus=1.5 --read-only --name {name} jr-ai-sandbox:latest"


def list_sandboxes(limit: int = 100) -> dict[str, Any]:
    sandboxes = _load(SANDBOXES_FILE, {"sandboxes": []}).get("sandboxes", [])
    return {"ok": True, "sandboxes": sandboxes[:max(1, min(limit, 500))], "count": len(sandboxes)}


def register_secret(name: str, env_var: str, scope: str = "global", description: str = "") -> dict[str, Any]:
    data = _load(SECRETS_FILE, {"secrets": []})
    item = {
        "id": f"secret_{_slug(name)}_{uuid.uuid4().hex[:4]}",
        "name": name,
        "env_var": env_var,
        "scope": scope,
        "description": description,
        "status": "registered_name_only",
        "created_at": _now(),
        "note": "O valor real deve ficar no .env/cofre local; nunca gravar token no JSON.",
    }
    data.setdefault("secrets", []).insert(0, item)
    _save(SECRETS_FILE, data)
    _audit(AUDIT_FILE, {"event": "register_secret", "name": name, "scope": scope})
    return {"ok": True, "secret": item, "summary": "Segredo registrado por referência."}


def list_secrets(limit: int = 100) -> dict[str, Any]:
    secrets = _load(SECRETS_FILE, {"secrets": []}).get("secrets", [])
    return {"ok": True, "secrets": secrets[:max(1, min(limit, 500))], "count": len(secrets)}


def policy() -> dict[str, Any]:
    return {
        "ok": True,
        "limits": DEFAULT_LIMITS,
        "blocked_commands": ["rm -rf /", "format", "diskpart", "net user", "curl | sh", "wget | sh", "powershell -enc"],
        "approval_required_for": ["network_enable", "file_write_outside_sandbox", "database_write", "external_message", "production_deploy", "secret_access"],
        "recommended": ["Docker rootless", "AppArmor/SELinux", "read-only filesystem", "network none", "resource limits", "immutable audit logs"],
    }


def execution_plan(command: str, sandbox_id: str = "", approved: bool = False) -> dict[str, Any]:
    risky = any(x in command.lower() for x in ["delete", "drop", "format", "rm -rf", "curl", "wget", "deploy", "senha", "token"])
    status_value = "waiting_approval" if risky and not approved else "ready"
    plan = {
        "id": f"execplan_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "sandbox_id": sandbox_id,
        "command": command,
        "status": status_value,
        "approved": approved,
        "limits": DEFAULT_LIMITS,
        "created_at": _now(),
    }
    _audit(AUDIT_FILE, {"event": "execution_plan", "status": status_value, "sandbox_id": sandbox_id})
    return {"ok": True, "plan": plan, "summary": "Plano aguardando aprovação." if status_value == "waiting_approval" else "Plano pronto."}


def install_plan() -> dict[str, Any]:
    return {
        "ok": True,
        "docker": [
            "Instalar Docker ou Docker Desktop",
            "Criar imagem jr-ai-sandbox com usuário sem privilégio",
            "Executar containers com --network=none por padrão",
            "Aplicar --memory, --cpus, --read-only e timeout externo",
        ],
        "secrets": [
            "Usar .env local ou cofre corporativo",
            "Registrar apenas nomes das variáveis",
            "Nunca gravar valores em logs",
        ],
        "audit": [
            "Usar audit_immutable.jsonl",
            "Enviar cópia para storage WORM/backup",
            "Assinar logs em produção, se necessário",
        ],
    }


def answer_for_sandbox(message: str = "") -> str:
    return "Vou usar o HAL Sandbox Enterprise para executar tarefas em ambiente isolado, com Docker, limites de CPU/RAM/rede, logs imutáveis, cofre de credenciais e aprovação antes de ações críticas."
