from __future__ import annotations

import json
import os
import re
import time
import uuid
import urllib.request
from pathlib import Path
from typing import Any

from app.core.config import root_dir

try:
    from services.language_manager import DEFAULT_LANGUAGE, normalize_language, response_instruction
except Exception:
    DEFAULT_LANGUAGE = "pt-BR"
    def normalize_language(value):
        return str(value or DEFAULT_LANGUAGE)
    def response_instruction(value):
        return "Responda no idioma preferido do usuário, de forma natural e profissional."



DATA_DIR = root_dir() / "data" / "human_conversation_gateway"
SESSIONS_FILE = DATA_DIR / "sessions.json"
MEMORY_FILE = DATA_DIR / "conversation_memory.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"
USERS_DIR = DATA_DIR / "users"


def _safe_user_key(user_id: str = "") -> str:
    key = re.sub(r"[^a-zA-Z0-9_.-]+", "_", str(user_id or "legacy").strip())
    return key[:96] or "legacy"


def _session_file(user_id: str = "") -> Path:
    if not user_id:
        return SESSIONS_FILE
    root = USERS_DIR / _safe_user_key(user_id)
    root.mkdir(parents=True, exist_ok=True)
    path = root / "sessions.json"
    if not path.exists():
        path.write_text(json.dumps({"sessions": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def _memory_file(user_id: str = "") -> Path:
    if not user_id:
        return MEMORY_FILE
    root = USERS_DIR / _safe_user_key(user_id)
    root.mkdir(parents=True, exist_ok=True)
    path = root / "conversation_memory.json"
    if not path.exists():
        path.write_text(json.dumps({"facts": [], "preferences": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


# Palavras e sinais usados só para roteamento inicial. A resposta final deve ser natural,
# não uma frase pronta.
SMALL_TALK_PATTERNS = {
    "greeting": ["bom dia", "boa tarde", "boa noite", "oi", "olá", "ola", "e aí", "e ai", "tudo bem", "beleza", "salve", "hello", "hi", "good morning", "good afternoon", "good evening", "hola", "buenos días", "buenos dias", "buenas tardes", "你好", "您好", "早上好", "こんにちは", "おはよう", "こんばんは"],
    "thanks": ["obrigado", "obrigada", "valeu", "agradeço", "agradeco", "thanks", "thank you", "gracias", "谢谢", "多谢", "ありがとう", "ありがとうございます"],
    "farewell": ["tchau", "até mais", "ate mais", "falou", "até logo", "ate logo", "bye", "goodbye", "see you", "adiós", "adios", "hasta luego", "再见", "再見", "さようなら", "またね"],
    "chitchat": ["conversar", "conversa comigo", "converse comigo", "fala comigo", "fale comigo", "comigo", "bate papo", "bater papo", "me escuta", "quero falar", "vamos conversar", "quero conversar"],
}

BUSINESS_PATTERNS = {
    "skills_center": [
        "skill", "skills", "clawhub", "hub de skills", "multiagente", "multi agente", "agentes", "sessions_spawn", "spawn", "delegar", "colaboração", "colaboracao", "gerar imagem", "criar imagem", "imagem", "desenhe", "geração de imagens", "geracao de imagens", "softwares locais", "arquivos locais", "código", "codigo"
    ],
    "executive_finance": [
        "ebitda", "dre", "saúde financeira", "saude financeira", "indicadores fundamentalistas", "fundamentalistas", "fluxo de caixa", "margem", "margens", "liquidez", "endividamento", "rentabilidade", "roe", "roa", "roi", "roic", "dívida líquida", "divida liquida", "contas a pagar", "contas a receber", "inadimplência", "inadimplencia", "capital de giro", "ponto de equilíbrio", "ponto de equilibrio", "ticket médio", "ticket medio", "diretoria", "gestor financeiro", "painel executivo", "valuation", "ev/ebitda", "lucro líquido", "lucro liquido", "cash flow", "margin", "liquidity", "debt", "profitability", "financial health", "accounts payable", "accounts receivable", "flujo de caja", "margen", "endeudamiento", "rentabilidad", "salud financiera", "现金流", "利润率", "流动性", "财务", "収益性", "財務", "キャッシュフロー"
    ],
    "omnichannel": [
        "whatsapp", "whats", "zap", "telegram", "voz e texto", "texto e voz",
        "mandar por voz", "enviar por voz", "mandar resposta", "enviar resposta",
        "mandar no whatsapp", "enviar no whatsapp", "mandar no telegram", "enviar no telegram",
        "e-mail para o solicitante", "email para o solicitante", "mandar e-mail", "enviar e-mail",
        "mandar email", "enviar email", "responder por e-mail", "responder por email",
        "solicitante", "requerente"
    ],
    "meeting": [
        "teams", "google meet", "meet", "zoom", "webex", "call", "reunião", "reuniao",
        "videoconferência", "videoconferencia", "ata", "transcrição", "transcricao",
        "responder por voz", "resposta por voz", "chat da reunião", "chat da reuniao",
        "perguntas na reunião", "perguntas na reuniao"
    ],
    "enterprise": [
        "power bi", "powerbi", "zabbix", "grafana", "crm", "teams", "slack", "agenda",
        "calendário", "calendario", "time", "times", "setor", "departamento",
        "almoxarifado", "contabilidade", "recebimentos", "bilhetagem", "agronegocio",
        "agronegócio", "fintech", "varejo", "atacado", "industria", "indústria",
        "ferramenta de colaboração", "colaboração", "colaboracao"
    ],
    "database": [
        "banco de dados", "base de dados", "database", "base de datos", "数据库", "データベース", "sql", "nosql", "oracle", "sql server",
        "postgres", "postgresql", "mysql", "mariadb", "sqlite", "firebird", "db2",
        "mongodb", "mongo", "redis", "elasticsearch", "cassandra", "couchdb",
        "tabela", "table", "tabla", "表", "テーブル", "view", "schema", "collection", "coleção", "colecao", "query", "consulta", "查询", "クエリ", "select"
    ],
    "erp": [
        "erp", "sistema", "system", "sistema legado", "legacy system", "venda de passagens", "passagens",
        "vale-transporte", "vale transporte", "bilhetagem", "financeiro", "financial", "accounting", "contábil",
        "contabil", "contabilidad", "payroll", "nómina", "recaudación", "estoque", "inventory", "inventario", "crm", "folha", "fiscal",
        "会计", "人力资源", "工资", "库存", "收费", "会計", "人事", "給与", "在庫", "運賃"
    ],
    "automation": [
        "n8n", "workflow", "automação", "automacao", "agendar", "cron", "robô", "robo",
        "browser", "navegador", "playwright", "selenium"
    ],
    "web": [
        "pesquise", "pesquisar", "internet", "notícia", "noticia", "atual", "hoje", "agora",
        "presidente", "cotação", "cotacao", "últimas notícias", "ultimas noticias"
    ],
    "mission": [
        "mission control", "controle de missão", "controle de missao", "painel visual",
        "agentes trabalhando", "meus agentes", "missão", "missao"
    ],
}

EDUCATION_TERMS = [
    "meu filho", "criança", "crianca", "aluno", "escola", "faculdade", "universidade",
    "ensinar", "aprender", "teach", "learn", "school", "student", "equation",
    "enseñar", "aprender", "escuela", "estudiante", "ecuación", "数学", "学习", "学校", "学生", "方程",
    "学ぶ", "学校", "学生", "方程式", "matemática", "matematica", "equação",
    "equacao", "história", "historia", "geografia", "educação física", "educacao fisica",
    "física", "fisica", "biologia", "química", "quimica", "redação", "redacao"
]

PERSONAL_SUPPORT_TERMS = [
    "estou cansado", "estou cansada", "estou preocupado", "estou preocupada",
    "estou triste", "desabafar", "ninguém resolve", "ninguem resolve",
    "estou sobrecarregado", "estou sobrecarregada", "não aguento", "nao aguento",
    "ansioso", "ansiosa", "me ajuda"
]

SENSITIVE_ACTIONS = [
    "cancelar", "baixar", "reembolsar", "alterar", "excluir", "deletar", "enviar cobrança",
    "enviar cobranca", "bloquear", "desbloquear", "update", "delete", "insert", "drop",
    "mandar mensagem", "enviar whatsapp", "enviar e-mail", "enviar email", "enviar no telegram"
]


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not SESSIONS_FILE.exists():
        SESSIONS_FILE.write_text(json.dumps({"sessions": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not MEMORY_FILE.exists():
        MEMORY_FILE.write_text(json.dumps({"facts": [], "preferences": []}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _hour() -> int:
    return int(time.strftime("%H"))


def _period_greeting() -> str:
    h = _hour()
    if 5 <= h < 12:
        return "bom dia"
    if 12 <= h < 18:
        return "boa tarde"
    return "boa noite"


def normalize(text: str) -> str:
    return " ".join((text or "").strip().split())


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def status(user_id: str = "") -> dict[str, Any]:
    sessions = _load(_session_file(user_id), {"sessions": []}).get("sessions", [])
    return {
        "ok": True,
        "name": "HAL Human Conversation Gateway V29",
        "description": "Camada de conversa natural V29: especialistas trabalham nos bastidores, o modelo CHAT/DIALOG sintetiza a resposta final e o Conversation Intelligence aplica anti-repetição semântica, Parrot Score, estado e goal tracking.",
        "sessions_count": len(sessions),
        "private_workspace": bool(user_id),
        "workspace_user_id": str(user_id or ""),
        "model_health": local_model_health(),
        "capabilities": [
            "Bate-papo natural e contextual",
            "Não repetir semanticamente a mesma solicitação ou frase mecânica",
            "Parrot Score com bloqueio/rewrite de respostas repetitivas",
            "Entender quando o usuário diz 'isso' usando o histórico",
            "Fazer perguntas de esclarecimento coerentes",
            "Explicar assuntos para leigos, crianças, escolas, faculdades e empresas",
            "Usar Ollama/modelo local quando disponível",
            "Acionar ferramentas nos bastidores quando necessário",
            "Responder com tom cordial, humano, objetivo e profissional",
            "Manter aprovação humana para ações sensíveis",
        ],
    }


def start_session(channel: str = "web", user_name: str = "", user_id: str = "") -> dict[str, Any]:
    sessions_path = _session_file(user_id)
    sessions = _load(sessions_path, {"sessions": []})
    sid = f"hconv_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    session = {
        "id": sid,
        "channel": channel,
        "user_name": user_name,
        "created_at": _now(),
        "updated_at": _now(),
        "turns": [],
        "summary": "",
        "tone": "natural_profissional",
    }
    sessions.setdefault("sessions", []).insert(0, session)
    _save(sessions_path, sessions)
    _audit({"event": "start_session", "session_id": sid, "channel": channel, "user_id": user_id})
    return {"ok": True, "session": session}


def _last_session(user_id: str = "") -> dict[str, Any] | None:
    sessions = _load(_session_file(user_id), {"sessions": []}).get("sessions", [])
    return sessions[0] if sessions else None


def _get_session(session_id: str = "", user_id: str = "") -> dict[str, Any]:
    sessions = _load(_session_file(user_id), {"sessions": []}).get("sessions", [])
    if session_id:
        for s in sessions:
            if s.get("id") == session_id:
                return s
    if sessions:
        return sessions[0]
    return start_session(user_id=user_id)["session"]


def _save_turn(session_id: str, user_message: str, assistant_message: str, classification: dict[str, Any], tool_result: dict[str, Any] | None = None, user_id: str = "") -> None:
    sessions_path = _session_file(user_id)
    sessions = _load(sessions_path, {"sessions": []})
    for session in sessions.get("sessions", []):
        if session.get("id") == session_id:
            session.setdefault("turns", []).append(
                {
                    "ts": _now(),
                    "user": user_message,
                    "assistant": assistant_message,
                    "classification": classification,
                    "tool_result": tool_result or {},
                }
            )
            session["updated_at"] = _now()
            session["summary"] = summarize_session(session.get("turns", []))
            break
    _save(sessions_path, sessions)


def add_external_context(session_id: str, source: str, content: str, user_id: str = "") -> dict[str, Any]:
    """Adds trusted local context (e.g. Screen Assist diagnosis) to the conversation history.

    The content is stored as contextual output, not as a user instruction, so follow-up
    turns such as "faça isso" can refer to the latest screen diagnosis.
    """
    if not session_id or not content:
        return {"ok": False, "error": "session_id and content are required"}
    sessions_path = _session_file(user_id)
    sessions = _load(sessions_path, {"sessions": []})
    target = None
    for session in sessions.get("sessions", []):
        if session.get("id") == session_id:
            target = session
            break
    if target is None:
        return {"ok": False, "error": "session not found"}
    target.setdefault("turns", []).append({
        "ts": _now(),
        "user": f"[Contexto externo local: {source}]",
        "assistant": normalize(content),
        "classification": {"intent": "external_context", "source": source},
        "tool_result": {"source": source, "context_only": True},
    })
    target["turns"] = target["turns"][-40:]
    target["updated_at"] = _now()
    target["summary"] = summarize_session(target.get("turns", []))
    _save(sessions_path, sessions)
    _audit({"event": "external_context", "session_id": session_id, "source": source, "user_id": user_id})
    return {"ok": True, "session_id": session_id, "source": source}


def summarize_session(turns: list[dict[str, Any]]) -> str:
    if not turns:
        return ""
    bits = []
    for t in turns[-6:]:
        u = normalize(t.get("user", ""))
        if u:
            bits.append(u[:120])
    return " | ".join(bits)


def last_assistant_message(session: dict[str, Any]) -> str:
    for turn in reversed(session.get("turns", [])):
        a = normalize(turn.get("assistant", ""))
        if a:
            return a
    return ""


def last_meaningful_user_message(session: dict[str, Any], skip_current: str = "") -> str:
    skip = normalize(skip_current).lower()
    for turn in reversed(session.get("turns", [])):
        u = normalize(turn.get("user", ""))
        if not u:
            continue
        lu = u.lower()
        if skip and lu == skip:
            continue
        if is_contextless_followup(u):
            continue
        return u
    return ""




TOPIC_KEYWORDS = {
    "food_lunch": [
        "almoço", "almoco", "jantar", "cardápio", "cardapio", "restaurante", "comida", "refeição", "refeicao",
        "dieta", "prato", "lanche", "marmita", "menu", "comer"
    ],
    "science_space": [
        "buraco negro", "buracos negros", "horizonte de eventos", "horizonte dos eventos", "singularidade",
        "cosmologia", "astronomia", "relatividade", "gravidade", "galáxia", "galaxia", "estrela", "planeta",
        "universo", "espaço", "espaco", "física", "fisica"
    ],
    "education": [
        "ensina", "ensinar", "aula", "prova", "estudar", "estudo", "criança", "crianca",
        "filho", "aluno", "escola", "faculdade", "universidade"
    ],
    "business_finance": [
        "ebitda", "dre", "fluxo de caixa", "financeiro", "contábil", "contabil", "indicador",
        "indicadores", "margem", "liquidez", "endividamento", "rentabilidade", "roic"
    ],
    "database": [
        "banco de dados", "sql", "nosql", "mongodb", "oracle", "postgres", "mysql", "sql server", "query", "select"
    ],
    "personal": [
        "sinto", "preocupado", "preocupada", "cansado", "cansada", "ansioso", "ansiosa", "desabafar",
        "triste", "feliz", "medo", "família", "familia"
    ],
}



CONVERSATION_REPAIR_TERMS = [
    "não está me ouvindo", "nao esta me ouvindo", "não me ouviu", "nao me ouviu",
    "não ouviu", "nao ouviu", "você não ouviu", "voce nao ouviu",
    "você não entendeu", "voce nao entendeu", "não entendeu", "nao entendeu",
    "não é isso", "nao e isso", "não foi isso", "nao foi isso",
    "respondeu errado", "resposta errada", "fora do assunto", "truncou",
    "pergunta truncada", "cortou minha pergunta", "não captou", "nao captou",
    "não está conversando", "nao esta conversando", "não está batendo papo",
    "nao esta batendo papo", "não respondeu", "nao respondeu",
    "não está me respondendo", "nao esta me respondendo", "não está interagindo",
    "nao esta interagindo", "está repetindo", "esta repetindo", "papagaio"
]



SOFTWARE_BUILDER_TERMS = [
    "software", "sistema", "aplicação", "aplicacao", "aplicativo", "app", "programa",
    "interface web", "web app", "dashboard", "painel web", "python", "fastapi", "flask",
    "streamlit", "django", "criar um software", "crie um software", "desenvolver um software",
]




ENTERPRISE_PRODUCTIZATION_TERMS = [
    "aihub", "zheus", "asimov", "produto comercial", "produto final", "estabilidade comercial",
    "enterprise productization", "productization", "biblioteca de 50", "50 skills", "40 templates",
    "deploy real", "deploy de verdade", "github real", "vercel", "supabase", "stripe",
    "fleet", "frota de agentes", "agent fleet", "agentes 24/7", "24/7", "knowledge center",
    "rag maduro", "white-label", "white label", "modo venda", "gestão de clientes", "gestao de clientes",
    "painel de saúde", "painel de saude", "quality gate global", "testes automáticos", "testes automaticos",
    "integrações reais", "integracoes reais", "observabilidade", "monitoramento da plataforma"
]



CYBER_DEFENSE_TERMS = [
    "invasão", "invasao", "invadir", "vazamento", "roubo de dados", "exfiltração", "exfiltracao",
    "ransomware", "criptografar arquivos", "criptografia de arquivos", "criptografam arquivos",
    "arquivos criptografados", "servidores", "desktop", "phishing", "e-mail infectado", "email infectado",
    "anexo infectado", "malware", "vírus", "virus", "trojan", "ataque", "cibersegurança", "ciberseguranca",
    "cyber", "edr", "siem", "defender", "wazuh", "soc", "backup imutável", "backup imutavel",
    "segurança da informação", "seguranca da informacao", "detectar ameaça", "detectar ameaca",
    "prevenir ataque", "prevenir invasão", "prevenir invasao", "proteger dados", "proteger arquivos"
]


def is_cyber_defense_request(message: str) -> bool:
    low = normalize(message).lower()
    return any(t in low for t in CYBER_DEFENSE_TERMS)


def cyber_defense_answer(message: str, session: dict[str, Any]) -> str:
    try:
        from app.services import cyber_defense_shield
        return cyber_defense_shield.natural_answer(message)
    except Exception:
        return (
            "Sim — isso precisa ser tratado como defesa cibernética contra invasão, phishing, malware e ransomware. "
            "A camada correta deve monitorar anexos de e-mail, alteração em massa de arquivos, canários em pastas críticas, "
            "backup, EDR/SIEM, logs e acionar playbook de resposta com aprovação humana."
        )



def is_enterprise_productization_request(message: str) -> bool:
    low = normalize(message).lower()
    if any(t in low for t in ENTERPRISE_PRODUCTIZATION_TERMS):
        return True
    return all(x in low for x in ["produto", "comercial", "robusto"]) or all(x in low for x in ["vender", "white", "label"])


def enterprise_productization_answer(message: str, session: dict[str, Any]) -> str:
    try:
        from app.services import enterprise_productization_v13
        return enterprise_productization_v13.answer_for_enterprise_productization(message)
    except Exception:
        return (
            "Isso entra na camada Enterprise Productization: saúde da plataforma, testes automáticos, biblioteca de Skills, templates, "
            "integrações, deploy assistido, quality gate, frota de agentes, Knowledge/RAG e white-label."
        )



def is_app_factory_request(message: str) -> bool:
    low = normalize(message).lower()
    app_terms = [
        "software", "sistema", "app", "aplicativo", "plataforma", "interface web", "web app",
        "lovable", "zheus", "código fonte", "codigo fonte", "projeto completo", "sistema inteiro"
    ]
    full_terms = [
        "login", "todas as páginas", "todas as paginas", "componentes", "filtros", "cálculos", "calculos",
        "estado vazio", "configurações", "configuracoes", "cobrança", "cobranca", "cobrança falhou",
        "teto de custo", "custo de ia", "github", "deploy", "preview", "white label", "saas", "assinatura"
    ]
    actions = ["quero", "preciso", "crie", "criar", "gerar", "gere", "desenvolver", "fazer", "montar", "adicionar", "contemple"]
    # V12: criação de software agora deve ir para App Factory Pro, pois gera sistema completo.
    return any(a in low for a in actions) and (any(t in low for t in app_terms) or any(t in low for t in full_terms))


def app_factory_answer(message: str, session: dict[str, Any]) -> str:
    try:
        from app.services import app_factory_pro
        res = app_factory_pro.blueprint_from_prompt(message)
        return res.get("answer", "")
    except Exception:
        return (
            "Perfeito — isso é criação de sistema completo. Vou tratar pelo HAL App Factory Pro: "
            "login, páginas, componentes, filtros reais, cálculos, estado vazio, configurações, cobrança falhou, teto de custo de IA, GitHub, deploy, preview, white-label e quality gate."
        )

def is_software_builder_request(message: str) -> bool:
    low = normalize(message).lower()
    has_term = any(t in low for t in SOFTWARE_BUILDER_TERMS)
    has_action = any(x in low for x in ["quero", "preciso", "criar", "crie", "gera", "gerar", "desenvolver", "fazer", "montar"])
    return has_term and has_action


def software_builder_answer(message: str, session: dict[str, Any]) -> str:
    try:
        from app.services import software_builder_center
        res = software_builder_center.build_plan(message)
        return res.get("answer", "")
    except Exception:
        if "finan" in normalize(message).lower():
            return (
                "Perfeito — isso é um pedido de criação de software. Eu montaria um sistema em Python com interface web para controle de finanças pessoais, "
                "com cadastro de receitas, despesas, categorias, saldo mensal, metas, dashboard e banco SQLite local. "
                "A arquitetura inicial ideal é FastAPI + SQLite + HTML/CSS/JavaScript. "
                "Posso gerar a estrutura completa do projeto com tela, backend, banco e guia de instalação."
            )
        return (
            "Sim, consigo transformar isso em um projeto de software. Vou pensar em telas, banco de dados, backend, frontend e guia de execução. "
            "Me diga se prefere Python/FastAPI, Flask, Django ou Streamlit."
        )


def is_conversation_repair(message: str) -> bool:
    low = normalize(message).lower()
    return any(t in low for t in CONVERSATION_REPAIR_TERMS)


def conversation_repair_answer(message: str, session: dict[str, Any], user_name: str = "") -> str:
    low = normalize(message).lower()
    previous = last_meaningful_user_message(session, skip_current=message)
    prefix = f"{user_name}, " if user_name else ""

    if any(x in low for x in ["não está me ouvindo", "nao esta me ouvindo", "não me ouviu", "nao me ouviu", "não ouviu", "nao ouviu", "não captou", "nao captou", "truncou", "cortou minha pergunta"]):
        return (
            f"{prefix}você tem razão em chamar a atenção. "
            "Se a sua frase apareceu escrita aqui, então eu recebi o texto; o problema é que a captação de voz ou a interpretação pode estar chegando incompleta. "
            "Vou fazer assim: a partir de agora, vou tratar sua próxima fala como uma pergunta completa, sem tentar adivinhar ferramenta antes de entender o sentido.\n\n"
            "Repita a pergunta inteira do jeito mais natural possível, ou digite ela completa aqui. "
            "Eu vou responder primeiro no bate-papo e só depois, se precisar, uso alguma ferramenta nos bastidores."
        )

    if any(x in low for x in ["não entendeu", "nao entendeu", "não é isso", "nao e isso", "não foi isso", "nao foi isso", "respondeu errado", "fora do assunto"]):
        return (
            f"{prefix}boa correção. Eu saí do caminho. "
            "Vou abandonar a interpretação anterior e seguir pelo que você disser agora, sem ficar preso no assunto passado.\n\n"
            "Me diga de novo a pergunta principal em uma frase. "
            "Se quiser, comece com: “HAL, o assunto agora é...” que eu troco de contexto imediatamente."
        )

    if any(x in low for x in ["não está conversando", "nao esta conversando", "não está batendo papo", "nao esta batendo papo", "não está interagindo", "nao esta interagindo", "papagaio", "está repetindo", "esta repetindo"]):
        return (
            f"{prefix}entendi. O comportamento certo não é eu empurrar módulo nem repetir frase pronta. "
            "O certo é conversar com você: responder, acompanhar o assunto, perceber quando você muda de tema e perguntar só o necessário.\n\n"
            "Vamos fazer um teste limpo agora. Me pergunte qualquer coisa — pode ser empresa, almoço, ciência, estudo, vida pessoal ou uma ideia solta — e eu respondo direto, sem abrir painel."
        )

    return (
        f"{prefix}ok, vamos reparar a conversa. "
        "Eu vou desconsiderar a interpretação anterior e responder a próxima pergunta diretamente. "
        "Pode mandar a pergunta completa."
    )



def topic_signature(message: str) -> str:
    low = normalize(message).lower()
    if re.search(r"\bora-?\d{3,6}\b", low):
        return "database"
    for topic, words in TOPIC_KEYWORDS.items():
        if any(w in low for w in words):
            return topic
    # Perguntas explicativas abertas
    if re.search(r"(?i)\b(o que|oque|como|por que|porque|explique|explica|qual|quem|quando|onde)\b", message or ""):
        return "open_knowledge"
    return "general_chat"


def last_topic_signature(session: dict[str, Any]) -> str:
    for turn in reversed(session.get("turns", [])):
        u = normalize(turn.get("user", ""))
        if u and not is_tiny_utterance(u) and not is_live_chat_request(u):
            return topic_signature(u)
    return ""


def is_topic_switch(message: str, session: dict[str, Any]) -> bool:
    current = topic_signature(message)
    previous = last_topic_signature(session)
    if not previous or current in {"general_chat"}:
        return False
    if previous == current:
        return False
    # Nova pergunta clara de outro domínio deve abandonar o contexto anterior.
    if current in {"food_lunch", "science_space", "business_finance", "database", "personal", "open_knowledge"}:
        return True
    return False


def normalize_transcribed_question(message: str) -> str:
    """Remove duplicações comuns de STT e preserva a pergunta completa."""
    text = normalize(message)
    if not text:
        return text
    # Remove repetições exatas do começo: "Hall Hall", "me explica me explica"
    words = text.split()
    cleaned = []
    for w in words:
        if cleaned and w.lower() == cleaned[-1].lower() and len(w) > 2:
            continue
        cleaned.append(w)
    text = " ".join(cleaned)
    # Corrige alguns termos frequentes de voz em português.
    replacements = {
        "horizonte dos eventos": "horizonte de eventos",
        "buracos negro": "buracos negros",
        "buraco negros": "buracos negros",
        "cardapio": "cardápio",
        "almoco": "almoço",
    }
    low = text.lower()
    for a, b in replacements.items():
        low = low.replace(a, b)
    # Preservar caixa simples.
    return low.strip()


def food_lunch_answer(message: str, session: dict[str, Any]) -> str:
    low = normalize(message).lower()
    if "cardápio" in low or "cardapio" in low or "menu" in low:
        return (
            "Claro. Para um almoço equilibrado e fácil, eu montaria um cardápio assim:\n\n"
            "Entrada: salada simples com folhas, tomate e cenoura.\n"
            "Prato principal: arroz, feijão, frango grelhado ou peixe, e legumes refogados.\n"
            "Opção mais leve: omelete com legumes, salada e uma porção pequena de arroz ou batata.\n"
            "Sobremesa: fruta ou iogurte.\n"
            "Bebida: água ou suco natural sem exagerar no açúcar.\n\n"
            "Se for para empresa, dá para transformar isso em cardápio semanal com opções econômicas, saudáveis e fáceis de preparar. "
            "Você quer um cardápio caseiro, corporativo, fitness ou mais simples para o dia a dia?"
        )
    return (
        "Para almoço, eu pensaria em algo que equilibre praticidade, energia e custo. "
        "Uma boa base é: proteína, carboidrato, legume/verdura e algo leve para fechar. "
        "Você quer recomendação para comer fora, marmita, cardápio de empresa ou algo saudável?"
    )


def science_space_answer(message: str, session: dict[str, Any]) -> str:
    low = normalize(message).lower()
    if "buraco negro" in low or "buracos negros" in low or "horizonte" in low:
        return (
            "Sim — mudando totalmente de assunto agora: buracos negros.\n\n"
            "Um **buraco negro** é uma região do espaço onde a gravidade é tão intensa que, depois de certo limite, nada consegue escapar — nem mesmo a luz.\n\n"
            "Esse limite é chamado de **horizonte de eventos**. Pense nele como uma espécie de “fronteira sem volta”. "
            "Do lado de fora, ainda é possível escapar se houver energia suficiente. Do lado de dentro, qualquer caminho possível aponta para mais perto do buraco negro.\n\n"
            "Isso não quer dizer que o buraco negro seja um aspirador cósmico puxando tudo ao redor sem parar. "
            "Se o Sol virasse um buraco negro com a mesma massa, por exemplo, a Terra continuaria orbitando praticamente do mesmo jeito — só ficaríamos sem luz e calor.\n\n"
            "O ponto mais misterioso é a **singularidade**, que é onde nossas teorias atuais deixam de explicar bem o que acontece. "
            "A relatividade geral prevê uma concentração extrema, mas a física quântica provavelmente precisa entrar nessa história.\n\n"
            "Quer que eu explique isso como se fosse para uma criança, para um leigo adulto ou num nível mais técnico de física?"
        )
    return (
        "Esse é um assunto de astronomia/física. Posso explicar de forma simples: a ideia central é entender gravidade, espaço-tempo e luz. "
        "Qual parte você quer primeiro: buracos negros, horizonte de eventos, singularidade ou relatividade?"
    )


def open_domain_fallback_answer(message: str, session: dict[str, Any], classification: dict[str, Any]) -> str:
    topic = topic_signature(message)
    if topic == "food_lunch":
        return food_lunch_answer(message, session)
    if topic == "science_space":
        return science_space_answer(message, session)
    return ""


def is_live_chat_request(message: str) -> bool:
    low = normalize(message).lower()
    compact = re.sub(r"[^\wáàâãéêíóôõúç ]+", "", low).strip()
    direct = {
        "comigo", "conversa comigo", "converse comigo", "fala comigo", "fale comigo",
        "vamos conversar", "bate papo", "bater papo", "quero conversar", "quero bater papo",
        "fica comigo", "continue comigo", "estou aqui", "vc conversa comigo", "você conversa comigo",
        "voce conversa comigo"
    }
    if compact in direct:
        return True
    return any(x in compact for x in [
        "conversa comigo", "converse comigo", "fala comigo", "fale comigo",
        "vamos conversar", "quero conversar", "bater papo", "bate papo"
    ])


def is_tiny_utterance(message: str) -> bool:
    low = normalize(message).lower()
    if not low:
        return True
    return len(low.split()) <= 3 and not re.search(r"\d|sql|erp|ebitda|dre|whatsapp|telegram|email|e-mail|banco|power", low)


def live_chat_answer(message: str, session: dict[str, Any], user_name: str = "") -> str:
    """Fallback conversacional vivo para quando não há modelo local ou a fala veio curta."""
    low = normalize(message).lower()
    previous = last_meaningful_user_message(session, skip_current=message)
    name = f", {user_name}" if user_name else ""

    if is_live_chat_request(message):
        return (
            f"Claro{name}. Estou aqui com você. "
            "Pode falar do jeito que vier: trabalho, empresa, uma ideia solta, algo pessoal, estudo, preocupação ou só conversa mesmo. "
            "Eu vou acompanhar o assunto e, quando faltar contexto, vou te perguntar só o necessário. "
            "Me conta: o que está passando pela sua cabeça agora?"
        )

    if low in {"sim", "pode", "ok", "certo", "isso", "exato", "perfeito"}:
        if previous:
            return (
                f"Perfeito. Vou continuar pelo que você disse antes: “{previous}”. "
                "Me dá só o próximo detalhe para eu avançar: você quer que eu explique, organize em plano, consulte dados ou escreva uma mensagem?"
            )
        return (
            "Perfeito. Pode mandar o assunto. Eu continuo com você sem precisar escolher ferramenta ou aba."
        )

    if is_tiny_utterance(message):
        return (
            "Estou ouvindo. Essa frase veio muito curta, então vou puxar do jeito certo: "
            "você quer conversar sobre algo pessoal, uma decisão de trabalho, um problema da empresa, estudo ou uma ideia que quer organizar?"
        )

    # Se a mensagem é aberta mas não tem ferramenta óbvia.
    return (
        "Certo, vamos conversar sobre isso. "
        "Me conta um pouco mais do contexto: o que aconteceu, ou qual é a dúvida principal? "
        "Eu respondo em cima do que você trouxer, sem te jogar para outra tela."
    )



def is_contextless_followup(message: str) -> bool:
    low = normalize(message).lower()
    contextless = [
        "ação prática", "acao pratica", "transforma isso", "transforme isso",
        "faz isso", "faça isso", "pode ser", "sim", "isso", "ok", "certo",
        "eu quero que você transforma isso", "eu quero que voce transforma isso",
        "eu quero que você transforme isso", "eu quero que voce transforme isso",
    ]
    return len(low.split()) <= 12 and any(x in low for x in contextless)


def classify_message(message: str, session: dict[str, Any] | None = None) -> dict[str, Any]:
    text = normalize(message)
    low = text.lower()
    scores = {
        "conversation_repair": 0.0,
        "cyber_defense": 0.0,
        "enterprise_productization": 0.0,
        "app_factory": 0.0,
        "software_builder": 0.0,
        "small_talk": 0.0,
        "food_lunch": 0.0,
        "science_space": 0.0,
        "personal_support": 0.0,
        "education": 0.0,
        "knowledge": 0.0,
        "business": 0.0,
        "skills_center": 0.0,
        "executive_finance": 0.0,
        "omnichannel": 0.0,
        "meeting": 0.0,
        "enterprise": 0.0,
        "database": 0.0,
        "erp": 0.0,
        "automation": 0.0,
        "web": 0.0,
        "mission": 0.0,
        "sensitive": 0.0,
        "needs_clarification": 0.0,
        "contextual_followup": 0.0,
    }

    for terms in SMALL_TALK_PATTERNS.values():
        if any(t in low for t in terms):
            scores["small_talk"] += 2.0

    if is_conversation_repair(text):
        scores["conversation_repair"] += 12.0
        scores["small_talk"] += 2.0
        scores["needs_clarification"] = 0.0

    if is_cyber_defense_request(text):
        scores["cyber_defense"] += 20.0
        scores["web"] = 0.0
        scores["skills_center"] = 0.0
        scores["needs_clarification"] = 0.0

    if is_app_factory_request(text):
        scores["app_factory"] += 22.0
        scores["software_builder"] = 0.0
        scores["skills_center"] = 0.0
        scores["web"] = 0.0
        scores["needs_clarification"] = 0.0

    if is_enterprise_productization_request(text):
        scores["enterprise_productization"] += 18.0
        scores["app_factory"] += 2.0
        scores["skills_center"] += 1.0
        scores["needs_clarification"] = 0.0

    if is_software_builder_request(text):
        scores["software_builder"] += 14.0
        scores["skills_center"] = 0.0
        scores["web"] = 0.0
        scores["needs_clarification"] = 0.0

    for area, terms in BUSINESS_PATTERNS.items():
        if any(t in low for t in terms):
            scores["business"] += 2.0
            scores[area] += 4.0

    # V30: códigos ORA-nnnnn são intenção Oracle/database mesmo quando o usuário só diz "explique o erro".
    if re.search(r"\bora-?\d{3,6}\b", low):
        scores["database"] += 14.0
        scores["business"] += 2.0
        scores["needs_clarification"] = 0.0

    if is_conversation_repair(text):
        scores["skills_center"] = 0.0
        scores["web"] = 0.0
        scores["business"] = min(scores.get("business", 0.0), 0.5)

    if any(t in low for t in EDUCATION_TERMS):
        scores["education"] += 4.0

    sig = topic_signature(text)
    if sig == "food_lunch":
        scores["food_lunch"] += 5.0
        scores["knowledge"] += 1.0
    elif sig == "science_space":
        scores["science_space"] += 6.0
        scores["knowledge"] += 2.0

    if any(t in low for t in PERSONAL_SUPPORT_TERMS):
        scores["personal_support"] += 4.0
    if is_live_chat_request(text):
        scores["small_talk"] += 9.0
        scores["needs_clarification"] = 0.0


    if any(t in low for t in SENSITIVE_ACTIONS):
        scores["sensitive"] += 4.0
        scores["business"] += 1.0

    # Perguntas e convites conversacionais abertos devem cair em knowledge/chat,
    # nunca em conversation_repair por empate de pontuação.
    questionish = bool(re.search(
        r"\?|^(como|qual|quais|quem|quanto|quantas|quando|onde|por que|porque|"
        r"me explica|explique|explica|o que|oque|me fala|fale sobre|fala sobre|"
        r"me conte|conte me|me diga|diga me|o que voce|o que você)\b",
        low,
    ))
    if questionish:
        scores["knowledge"] += 1.5
        if scores["business"] < 2 and scores["education"] < 2:
            scores["small_talk"] += 0.4

    if is_contextless_followup(text):
        scores["contextual_followup"] += 5.0
        scores["needs_clarification"] += 1.0

    if len(low.split()) < 4 and scores["small_talk"] == 0 and scores["business"] == 0:
        scores["needs_clarification"] += 1.2

    # Prioridades: se pediu canal/reunião/banco etc., vai para ferramenta.
    ordered = [
        "conversation_repair", "cyber_defense", "enterprise_productization", "app_factory", "software_builder",
        "skills_center", "executive_finance", "omnichannel", "meeting", "database", "erp", "enterprise", "automation", "mission",
        "science_space", "food_lunch", "education", "personal_support", "web", "knowledge", "small_talk"
    ]
    best_score = max((scores.get(k, 0.0) for k in ordered), default=0.0)
    if best_score <= 0.0:
        # V25.1: não use a primeira intenção da lista como desempate implícito.
        # Frases normais sem marcador especializado são conversa/conhecimento geral.
        if topic_signature(text) == "open_knowledge" or len(low.split()) >= 4:
            intent = "knowledge"
        else:
            intent = "small_talk"
    else:
        intent = max(ordered, key=lambda k: scores.get(k, 0.0))

    # Se é só follow-up sem assunto, tratar como contextual_followup.
    if scores["contextual_followup"] >= 5 and scores[intent] < 4:
        intent = "contextual_followup"

    sig_final = topic_signature(text)
    if is_conversation_repair(text):
        intent = "conversation_repair"
    elif is_cyber_defense_request(text):
        intent = "cyber_defense"
    elif is_enterprise_productization_request(text):
        intent = "enterprise_productization"
    elif is_app_factory_request(text):
        intent = "app_factory"
    elif is_software_builder_request(text):
        intent = "software_builder"
    elif sig_final == "science_space":
        intent = "science_space"
    elif sig_final == "food_lunch":
        intent = "food_lunch"
    elif is_live_chat_request(text):
        intent = "small_talk"
    elif is_tiny_utterance(text) and scores["business"] == 0 and scores["education"] == 0 and scores["personal_support"] == 0:
        intent = "small_talk"

    if scores["sensitive"] >= 4:
        policy = "approval_required"
    else:
        policy = "safe"

    return {
        "ok": True,
        "message": text,
        "intent": intent,
        "scores": scores,
        "policy": policy,
        "tone": "natural_profissional",
        "topic_signature": topic_signature(text),
        "topic_switched": is_topic_switch(text, session or {}) if session else False,
        "should_route_tool": intent in {"software_builder", "skills_center", "executive_finance", "omnichannel", "meeting", "database", "erp", "enterprise", "automation", "web", "mission"},
    }


def build_history(session: dict[str, Any], limit: int = 8) -> str:
    lines = []
    for t in session.get("turns", [])[-limit:]:
        u = normalize(t.get("user", ""))
        a = normalize(t.get("assistant", ""))
        if u:
            lines.append(f"Usuário: {u}")
        if a:
            lines.append(f"HAL: {a[:700]}")
    return "\n".join(lines)


def _timeout_for_role(role: str) -> float:
    """Timeout por papel. Em CPU, o primeiro carregamento pode levar dezenas de segundos."""
    role = (role or "dialog").lower()
    env_map = {
        "chat": "HALL_DIALOG_TIMEOUT",
        "dialog": "HALL_DIALOG_TIMEOUT",
        "fast": "HALL_FAST_TIMEOUT",
        "sql": "HALL_SQL_TIMEOUT",
        "fast_code": "HALL_FAST_CODE_TIMEOUT",
        "code": "HALL_CODE_TIMEOUT",
        "deep_code": "HALL_DEEP_CODE_TIMEOUT",
        "vision": "HALL_VISION_TIMEOUT",
    }
    defaults = {
        "chat": 120,
        "dialog": 120,
        "fast": 60,
        "sql": 120,
        "fast_code": 120,
        "code": 180,
        "deep_code": 240,
        "vision": 180,
    }
    env_name = env_map.get(role, "HALL_DIALOG_TIMEOUT")
    try:
        return float(os.getenv(env_name, str(defaults.get(role, 120))))
    except Exception:
        return float(defaults.get(role, 120))


def call_local_llm(message: str, session: dict[str, Any], classification: dict[str, Any], tool_context: dict[str, Any] | None = None, language: str = DEFAULT_LANGUAGE) -> str:
    """Gera a RESPOSTA FINAL do HAL usando o modelo conversacional.

    O Multi-Model Router pode escolher um especialista (SQL/CODE/VISION) para a tarefa,
    porém especialistas não devem conversar diretamente com o usuário. O resultado da
    ferramenta/especialista entra como contexto e o CHAT/DIALOG sintetiza a resposta final.
    """
    ollama_url = os.getenv("OLLAMA_URL", "http://127.0.0.1:11435")
    dialog_model = os.getenv("HALL_DIALOG_MODEL") or os.getenv("HALL_MODEL_CHAT") or os.getenv("OLLAMA_MODEL") or "qwen2.5:7b"
    specialist_role = "chat"
    specialist_model = dialog_model
    specialist_reason = "conversa geral"

    try:
        from app.services import multi_model_router
        selected = multi_model_router.route_model(message, intent=str(classification.get("intent") or ""))
        specialist_role = selected.get("role") or "chat"
        specialist_model = selected.get("model") or dialog_model
        specialist_reason = selected.get("reason") or ""
        # A resposta final SEMPRE volta pelo cérebro conversacional.
        dialog_model = multi_model_router.model_for("dialog") or multi_model_router.model_for("chat") or dialog_model
        ollama_url = multi_model_router.ollama_url()
    except Exception as exc:
        _audit({"event": "router_selection_error", "error": str(exc)})

    language = normalize_language(language)
    language_instruction = response_instruction(language)
    grounding_contract = ""
    try:
        from services import conversation_grounding_v30 as grounding_v30
        grounding_contract = grounding_v30.build_turn_contract(message, classification, session.get("turns", []))
    except Exception:
        grounding_contract = "A pergunta atual é a fonte principal de verdade. Responda ao que foi perguntado sem mudar para outro assunto."
    system = (
        "Você é o HAL, assistente principal da plataforma JR-AI/AJDS. "
        f"Idioma obrigatório da resposta: {language}. {language_instruction} "
        "Respeite o idioma escolhido pelo usuário mesmo que ferramentas internas retornem conteúdo em outro idioma. "
        "Sua função nesta etapa é SINTETIZAR a resposta final ao usuário. "
        "Modelos especialistas e ferramentas trabalham nos bastidores; nunca finja ser SQLCoder, coder ou outra ferramenta. "
        "Responda ao que foi perguntado, use o histórico, e use resultados técnicos fornecidos como contexto. "
        "Não invente dados. Quando uma informação real depender de banco, arquivo, internet ou sistema não consultado, diga exatamente o que falta. "
        "Não transforme toda pergunta em formulário e não responda com frases genéricas. "
        "Nunca repita semanticamente a mesma solicitação só porque um workflow está aguardando um campo. Use o histórico e mude de estratégia quando a conversa travar. "
        "Se o contexto trouxer conversation_quality_guard, trate sua instruction como restrição obrigatória da resposta final. "
        "Quando houver SQL/código no contexto, explique o resultado e preserve blocos técnicos úteis. "
        "Quando for educação, adapte a explicação ao nível do usuário. "
        "Quando for negócio, seja prático e orientado a decisão. "
        "Nunca sugira piada, humor ou mudança aleatória de assunto se o usuário não pediu isso. "
        "Se a fala parecer ambígua ou truncada, faça uma única pergunta curta de confirmação em vez de adivinhar. "
        + "\n\n" + grounding_contract
    )

    tool_text = ""
    if tool_context:
        try:
            tool_text = json.dumps(tool_context, ensure_ascii=False, indent=2)[:9000]
        except Exception:
            tool_text = str(tool_context)[:9000]

    prompt = (
        f"{system}\n\n"
        f"Histórico recente:\n{build_history(session)}\n\n"
        f"Intenção detectada: {classification.get('intent')}\n"
        f"Especialista sugerido pelo router: {specialist_role} / {specialist_model} ({specialist_reason})\n"
        f"Modelo que deve produzir a resposta final: dialog / {dialog_model}\n\n"
        f"Resultado de ferramenta/especialista, se houver:\n{tool_text}\n\n"
        f"Pergunta atual do usuário:\n{message}\n\n"
        "Entregue agora a resposta final útil ao usuário. Não descreva o roteamento interno, salvo se houver falha técnica."
    )

    timeout = _timeout_for_role("dialog")
    keep_alive = os.getenv("HALL_CHAT_KEEP_ALIVE", "15m")
    strict_grounding = bool(isinstance(tool_context, dict) and tool_context.get("intent_grounding_guard"))
    default_temperature = "0.18" if strict_grounding else "0.30"
    payload = json.dumps({
        "model": dialog_model,
        "prompt": prompt,
        "stream": False,
        "keep_alive": keep_alive,
        "options": {
            "temperature": float(os.getenv("HALL_CHAT_TEMPERATURE_STRICT" if strict_grounding else "HALL_CHAT_TEMPERATURE", default_temperature)),
            "top_p": 0.9,
            "num_ctx": int(os.getenv("HALL_CHAT_NUM_CTX", "4096")),
            "num_predict": int(os.getenv("HALL_CHAT_MAX_TOKENS", "900")),
        },
    }).encode("utf-8")

    started = time.time()
    runtime = {
        "ok": False,
        "final_role": "dialog",
        "final_model": dialog_model,
        "specialist_role": specialist_role,
        "specialist_model": specialist_model,
        "specialist_reason": specialist_reason,
        "ollama_url": ollama_url,
        "timeout_s": timeout,
        "keep_alive": keep_alive,
        "language": language,
    }

    try:
        req = urllib.request.Request(
            f"{ollama_url.rstrip('/')}/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
        data = json.loads(raw)
        ans = normalize(data.get("response", ""))
        runtime.update({
            "ok": bool(ans),
            "elapsed_s": round(time.time() - started, 3),
            "done_reason": data.get("done_reason", ""),
            "eval_count": data.get("eval_count"),
            "prompt_eval_count": data.get("prompt_eval_count"),
        })
        session["_llm_runtime"] = runtime
        _audit({"event": "dialog_generate", **runtime})
        if ans and len(ans) > 2:
            return ans
        runtime["error"] = "Ollama retornou resposta vazia"
        session["_llm_runtime"] = runtime
        _audit({"event": "dialog_empty", **runtime})
    except Exception as exc:
        runtime.update({"elapsed_s": round(time.time() - started, 3), "error": f"{type(exc).__name__}: {exc}"})
        session["_llm_runtime"] = runtime
        _audit({"event": "dialog_generate_error", **runtime})
        return ""
    return ""


def translate_answer(text: str, language: str = DEFAULT_LANGUAGE) -> str:
    """Traduz/localiza uma resposta pronta para o idioma escolhido pelo usuário.

    Usada principalmente quando um módulo técnico legado produz conteúdo em português.
    Mantém blocos de código, SQL, JSON, URLs e identificadores técnicos intactos.
    Se a tradução falhar, devolve o texto original para não interromper o fluxo.
    """
    source = str(text or "").strip()
    language = normalize_language(language)
    if not source or language == DEFAULT_LANGUAGE:
        return source

    try:
        from services.language_manager import language_meta
        meta = language_meta(language)
        target_name = str(meta.get("native_label") or meta.get("label") or language)
    except Exception:
        target_name = language

    ollama_url = os.getenv("OLLAMA_URL", "http://127.0.0.1:11435")
    dialog_model = os.getenv("HALL_DIALOG_MODEL") or os.getenv("HALL_MODEL_CHAT") or os.getenv("OLLAMA_MODEL") or "qwen2.5:7b"
    try:
        from app.services import multi_model_router
        dialog_model = multi_model_router.model_for("dialog") or multi_model_router.model_for("chat") or dialog_model
        ollama_url = multi_model_router.ollama_url()
    except Exception:
        pass

    prompt = (
        "Você é a camada de localização do HAL. "
        f"Converta a resposta abaixo para {target_name} ({language}). "
        "Preserve exatamente blocos de código, SQL, nomes de tabelas/colunas, JSON keys, URLs, nomes de produtos e comandos. "
        "Não acrescente comentários, explicações sobre a tradução nem altere o significado técnico. "
        "Retorne somente a resposta localizada.\n\n"
        f"RESPOSTA ORIGINAL:\n{source}"
    )
    timeout = _timeout_for_role("dialog")
    payload = json.dumps({
        "model": dialog_model,
        "prompt": prompt,
        "stream": False,
        "keep_alive": os.getenv("HALL_CHAT_KEEP_ALIVE", "15m"),
        "options": {
            "temperature": 0.1,
            "top_p": 0.9,
            "num_ctx": int(os.getenv("HALL_CHAT_NUM_CTX", "4096")),
            "num_predict": int(os.getenv("HALL_TRANSLATION_MAX_TOKENS", "1200")),
        },
    }).encode("utf-8")
    started = time.time()
    try:
        req = urllib.request.Request(
            f"{ollama_url.rstrip('/')}/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
        data = json.loads(raw)
        translated = normalize(data.get("response", ""))
        _audit({
            "event": "translate_answer",
            "ok": bool(translated),
            "language": language,
            "model": dialog_model,
            "elapsed_s": round(time.time() - started, 3),
        })
        return translated if translated else source
    except Exception as exc:
        _audit({
            "event": "translate_answer_error",
            "ok": False,
            "language": language,
            "model": dialog_model,
            "elapsed_s": round(time.time() - started, 3),
            "error": f"{type(exc).__name__}: {exc}",
        })
        return source


def local_model_health() -> dict[str, Any]:
    try:
        from app.services import multi_model_router
        st = multi_model_router.status(test=False)
        chat_model = multi_model_router.model_for("chat")
        return {
            "ok": st.get("ok", False),
            "url": st.get("ollama_url"),
            "model": chat_model,
            "models": st.get("installed_models", []),
            "model_available": any(r.get("role") == "chat" and r.get("installed") for r in st.get("roles", [])),
            "multi_model": st,
        }
    except Exception as exc:
        ollama_url = os.getenv("OLLAMA_URL", "http://127.0.0.1:11435")
        model = os.getenv("HALL_DIALOG_MODEL") or os.getenv("OLLAMA_MODEL") or os.getenv("HALL_WEB_SUMMARY_MODEL") or "qwen2.5:7b"
        try:
            req = urllib.request.Request(f"{ollama_url.rstrip('/')}/api/tags", method="GET")
            with urllib.request.urlopen(req, timeout=3) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
            data = json.loads(raw)
            names = [m.get("name", "") for m in data.get("models", [])]
            return {"ok": True, "url": ollama_url, "model": model, "models": names, "model_available": any(n == model or n.startswith(model + ":") for n in names)}
        except Exception as exc2:
            return {"ok": False, "url": ollama_url, "model": model, "error": str(exc2), "model_available": False}


def natural_small_talk(message: str, user_name: str = "", session: dict[str, Any] | None = None) -> str:
    low = normalize(message).lower()
    greet = _period_greeting()
    name = f", {user_name}" if user_name else ""

    if any(x in low for x in ["bom dia", "boa tarde", "boa noite", "oi", "olá", "ola", "tudo bem"]):
        return (
            f"{greet.capitalize()}{name}! Estou por aqui. "
            "Pode falar comigo do jeito normal: pergunta rápida, problema do trabalho, estudo, reunião, agenda ou até uma conversa mais aberta. "
            "O que você quer resolver agora?"
        )

    if any(x in low for x in ["obrigado", "obrigada", "valeu"]):
        return "Imagina. Pode mandar a próxima — eu acompanho o raciocínio com você."

    if any(x in low for x in ["tchau", "até mais", "ate mais", "falou"]):
        return "Combinado. Quando precisar, é só me chamar."

    if is_live_chat_request(message) or "conversar" in low or "bate papo" in low or "bater papo" in low:
        return live_chat_answer(message, session or {}, user_name=user_name)

    if is_tiny_utterance(message):
        return live_chat_answer(message, session or {}, user_name=user_name)

    return generate_general_fallback(message, session or {}, {"intent": "small_talk"})


def contextual_followup_answer(message: str, session: dict[str, Any]) -> str:
    if is_topic_switch(message, session):
        od = open_domain_fallback_answer(message, session, {"intent": topic_signature(message)})
        if od:
            return od
    previous = last_meaningful_user_message(session, skip_current=message)
    low = normalize(message).lower()

    if previous:
        return (
            f"Perfeito. Vou transformar isso em ação prática com base no que você trouxe antes: “{previous}”.\n\n"
            "Para eu não sair chutando, preciso fechar três pontos rápidos:\n"
            "1. Qual resultado você quer no final: relatório, automação, mensagem, tarefa, consulta em sistema ou plano de ação?\n"
            "2. Qual fonte devo usar: conversa, ERP, banco de dados, Power BI, internet, arquivo ou algum sistema específico?\n"
            "3. Quem é o destinatário ou responsável por essa ação?\n\n"
            "Se você responder só com essas três informações, eu já monto o próximo passo."
        )

    # Caso do print: ele não tem assunto suficiente. Não repetir a mesma pergunta; avançar a conversa.
    if "ação prática" in low or "acao pratica" in low or "transform" in low:
        last_a = last_assistant_message(session).lower()
        if "qual é o tema" in last_a or "qual assunto" in last_a or "ficou sem contexto" in last_a:
            return (
                "Sim, pode. Só falta você me dizer o **tema** dessa ação. "
                "Por exemplo: é uma ação comercial, financeira, de banco de dados, reunião, estudo, atendimento ou automação?\n\n"
                "Se quiser responder rápido, mande assim:\n"
                "**Tema:** vender a IA\n"
                "**Resultado:** plano de ação de 7 dias\n"
                "**Destino:** apresentação para cliente\n\n"
                "Com isso eu já transformo em algo prático."
            )
        return (
            "Pode ser sim — mas eu preciso saber *qual assunto* você quer transformar em ação prática. "
            "Do jeito que chegou para mim, ficou sem contexto.\n\n"
            "Me diga assim, por exemplo:\n"
            "“HAL, transforme a ideia de vender a IA em um plano comercial de 7 dias”, ou\n"
            "“HAL, transforme essa dúvida sobre banco de dados em uma consulta SQL”, ou\n"
            "“HAL, transforme essa conversa da reunião em tarefas para o financeiro”.\n\n"
            "Qual é o tema ou objetivo da ação?"
        )

    return (
        "Entendi. Só falta o contexto principal. "
        "Você quer transformar *o quê* em ação prática: uma conversa, uma reunião, um problema da empresa, uma pergunta de estudo ou uma mensagem para alguém?"
    )


def natural_personal_support(message: str, session: dict[str, Any]) -> str:
    low = normalize(message).lower()
    if any(x in low for x in ["ninguém resolve", "ninguem resolve", "cansado", "cansada", "sobrecarregado", "sobrecarregada"]):
        return (
            "Entendi. Parece que tem coisa demais caindo no seu colo. "
            "Vamos fazer do jeito simples: me diga qual é o problema que mais está te consumindo agora. "
            "Eu posso só te ouvir primeiro, ou posso organizar isso em prioridades e próximos passos."
        )
    if "desabafar" in low:
        return (
            "Pode desabafar. Vou te acompanhar com calma. "
            "O que aconteceu exatamente — foi algo de trabalho, família, pressão financeira ou só aquele acúmulo de tudo ao mesmo tempo?"
        )
    return (
        "Estou te ouvindo. Me conta em uma frase o que está pesando mais agora. "
        "Depois disso eu posso ajudar a separar emoção, fatos e próximos passos."
    )


def natural_education_answer(message: str, session: dict[str, Any]) -> str:
    low = normalize(message).lower()
    if "equação" in low or "equacao" in low or "primeiro grau" in low:
        return (
            "Claro. Vou explicar bem simples, como para uma criança de 11 anos.\n\n"
            "Uma equação de primeiro grau é uma continha com uma letra escondendo um número. "
            "Essa letra normalmente é o **x**.\n\n"
            "Exemplo:\n\n"
            "x + 3 = 8\n\n"
            "Isso quer dizer: “qual número, somado com 3, dá 8?”\n\n"
            "A resposta é 5, porque:\n\n"
            "5 + 3 = 8\n\n"
            "Então:\n\n"
            "x = 5\n\n"
            "Um jeito fácil de pensar é como uma balança: o lado esquerdo e o lado direito precisam ficar equilibrados. "
            "Quando queremos descobrir o x, fazemos o caminho contrário. Se o 3 está somando, ele passa para o outro lado subtraindo:\n\n"
            "x + 3 = 8\n"
            "x = 8 - 3\n"
            "x = 5\n\n"
            "Agora me diga: você quer que eu faça mais um exemplo junto com ele, bem devagar?"
        )
    return (
        "Claro. Eu posso explicar isso de um jeito simples e por etapas. "
        "Antes: é para criança, adolescente, faculdade ou adulto leigo? Assim eu ajusto o exemplo e a velocidade da explicação."
    )


def generate_general_fallback(message: str, session: dict[str, Any], classification: dict[str, Any]) -> str:
    text = normalize(message)
    low = text.lower()

    if not text:
        return "Pode falar. Estou ouvindo."

    if is_live_chat_request(text) or is_tiny_utterance(text):
        return live_chat_answer(text, session)

    od = open_domain_fallback_answer(text, session, classification)
    if od:
        return od

    if is_contextless_followup(text):
        return contextual_followup_answer(text, session)

    # Respostas simples para pedidos curtos comuns.
    if len(text.split()) <= 3 and not re.search(r"\?", text):
        return (
            "Entendi. Me dá só um pouco mais de contexto para eu responder direito. "
            "Você está falando de trabalho, estudo, reunião, mensagem, banco de dados ou algo pessoal?"
        )

    # Tenta modelo local. Se houver Ollama, isso deixa o HAL muito menos mecânico.
    llm = call_local_llm(text, session, classification)
    if llm:
        return llm

    if classification.get("intent") == "education":
        return natural_education_answer(text, session)

    if re.search(r"(?i)\b(o que|oque|como|por que|porque|qual|quem|quando|onde|me explica|explique)\b", text):
        health = local_model_health()
        if not health.get("ok") or not health.get("model_available"):
            return (
                "Eu consigo conversar sobre isso, mas neste momento o modelo local de diálogo não respondeu. "
                "Para perguntas abertas de qualquer assunto, eu preciso do Ollama/modelo local ativo. "
                f"Modelo esperado: {health.get('model')}. "
                "Enquanto isso, posso te ajudar em perguntas guiadas de empresa, banco, ERP, finanças, estudos e ferramentas. "
                "Quer que eu responda com uma explicação simples ou quer que eu verifique o modelo local primeiro?"
            )
        return (
            "Vou responder isso de forma direta. Se você quiser, depois eu aprofundo ou transformo em passo a passo."
        )

    health = local_model_health()
    if not health.get("ok") or not health.get("model_available"):
        return (
            "Estou com você. Mesmo sem o modelo local responder agora, consigo continuar a conversa de forma guiada. "
            "Me diga o assunto principal: é algo pessoal, profissional, empresarial, estudo ou uma ideia que você quer organizar?"
        )

    return (
        "Certo, vamos continuar. Me conta o contexto e eu respondo em cima dele, sem mudar de tela."
    )


def natural_business_intro(message: str, classification: dict[str, Any], session: dict[str, Any]) -> str:
    intent = classification.get("intent")
    if classification.get("policy") == "approval_required":
        safety = "Como pode envolver ação sensível, eu preparo o plano, mas só executo depois da sua aprovação."
    else:
        safety = "Vou trabalhar em modo seguro e te perguntar só o que estiver faltando."

    if intent == "cyber_defense":
        return (
            "Isso é segurança defensiva contra invasão, phishing, malware e ransomware. Vou tratar com monitoramento, canários, baseline, e-mail seguro, backup, EDR/SIEM e playbook de resposta."
        )

    if intent == "enterprise_productization":
        return (
            "Isso é evolução de produto comercial/enterprise. Vou tratar com saúde da plataforma, integrações, testes, skills, templates, deploy, fleet de agentes, RAG e white-label."
        )

    if intent == "app_factory":
        return (
            "Isso é criação de sistema completo. Vou usar o HAL App Factory Pro para gerar arquitetura, login, páginas, filtros, cálculos, estado vazio, billing, custo de IA, GitHub, deploy, preview e quality gate."
        )

    if intent == "software_builder":
        return (
            "Isso é desenvolvimento de software. Vou tratar como projeto técnico: requisitos, telas, banco de dados, backend, frontend e código inicial."
        )

    if intent == "skills_center":
        return (
            "Entendi. Isso envolve Skills, agentes, colaboração multiagente, criação de imagem, hub local ou delegação de tarefas. "
            "Vou tratar pelo HAL Skills & Multi-Agent Center, mantendo tudo local-first, com auditoria e aprovação em ações sensíveis."
        )

    if intent == "executive_finance":
        return (
            "Entendi. Essa é uma análise executiva financeira. "
            "Vou tratar como indicadores fundamentalistas: EBITDA, DRE, fluxo de caixa, margens, liquidez, endividamento, rentabilidade e saúde financeira. "
            "Eu não vou inventar números; vou usar fonte real cadastrada ou pedir a fonte correta."
        )

    if intent == "omnichannel":
        return (
            "Entendi. Você quer entregar a resposta por WhatsApp, Telegram ou e-mail, em texto e/ou voz. "
            "Eu preparo a mensagem e o roteiro de voz; para envio real, preciso de destinatário, credenciais e aprovação quando for externo. "
            f"{safety}"
        )
    if intent == "meeting":
        return (
            "Entendi. Isso envolve reunião ou call. "
            "Eu posso atuar como assistente de reunião: escutar perguntas autorizadas, responder por voz/texto, gerar ata, decisões e tarefas. "
            f"{safety}"
        )
    if intent == "enterprise":
        return (
            "Entendi. Isso é uma demanda corporativa envolvendo setor, time, ferramenta ou agenda. "
            "Vou identificar o segmento, o setor responsável e as ferramentas prováveis antes de propor a ação. "
            f"{safety}"
        )
    if intent == "database":
        return (
            "Certo, isso depende de base de dados. "
            "Antes de consultar, preciso saber qual conexão usar, quais dados você quer, período/filtros e formato do resultado. "
            f"{safety}"
        )
    if intent == "erp":
        return (
            "Entendi, isso parece envolver ERP ou sistema da empresa. "
            "Vou identificar se a fonte é banco, API, relatório, arquivo ou tela do sistema, sem inventar dados. "
            f"{safety}"
        )
    if intent == "automation":
        return (
            "Beleza, isso tem cara de automação. "
            "Vou separar se é n8n, navegador, agendamento, canal de mensagem ou rotina interna. "
            f"{safety}"
        )
    if intent == "web":
        return (
            "Boa. Isso parece depender de informação atual ou externa. "
            "Eu devo pesquisar em fontes confiáveis e separar fato de análise."
        )
    if intent == "mission":
        return (
            "Perfeito. Vou tratar como missão para agentes: objetivo, responsáveis, status, riscos e aprovação quando necessário."
        )
    return generate_general_fallback(message, session, classification)


def converse(message: str, session_id: str = "", user_name: str = "", approved: bool = False, run_tools: bool = True, language: str = DEFAULT_LANGUAGE, user_id: str = "") -> dict[str, Any]:
    _ensure()
    session = _get_session(session_id, user_id=user_id)
    session_id = session["id"]
    language = normalize_language(language)
    session["language"] = language
    text = normalize_transcribed_question(message)

    classification = classify_message(text, session)
    intent = classification["intent"]
    answer = ""
    tool_result: dict[str, Any] = {}

    if intent == "contextual_followup":
        answer = (call_local_llm(text, session, classification, language=language) if language != DEFAULT_LANGUAGE else "") or contextual_followup_answer(text, session)

    elif intent == "conversation_repair":
        # V25.1: reparo só ocorre quando termos explícitos acionaram essa intenção.
        # Mesmo em pt-BR, tenta primeiro uma resposta contextual do modelo local.
        answer = call_local_llm(text, session, classification, language=language) or conversation_repair_answer(text, session, user_name=user_name)

    elif intent == "small_talk":
        # Bate-papo vivo: se o modelo local estiver disponível, usa; se não, continua natural.
        llm = call_local_llm(text, session, classification, language=language)
        answer = llm or natural_small_talk(text, user_name=user_name, session=session)

    elif intent == "personal_support":
        llm = call_local_llm(text, session, classification, language=language)
        answer = llm or natural_personal_support(text, session)

    elif intent == "food_lunch":
        llm = call_local_llm(text, session, classification, language=language)
        answer = llm or food_lunch_answer(text, session)

    elif intent == "science_space":
        llm = call_local_llm(text, session, classification, language=language)
        answer = llm or science_space_answer(text, session)

    elif intent == "education":
        llm = call_local_llm(text, session, classification, language=language)
        answer = llm or natural_education_answer(text, session)

    elif intent == "knowledge":
        answer = call_local_llm(text, session, classification, language=language) or open_domain_fallback_answer(text, session, classification) or generate_general_fallback(text, session, classification)

    elif intent == "cyber_defense":
        tool_result = route_tool(text, intent, approved) if run_tools else {}
        answer = call_local_llm(text, session, classification, tool_context=tool_result, language=language) or (tool_result.get("answer") if tool_result else "") or cyber_defense_answer(text, session)

    elif intent == "enterprise_productization":
        tool_result = route_tool(text, intent, approved) if run_tools else {}
        answer = call_local_llm(text, session, classification, tool_context=tool_result, language=language) or (tool_result.get("answer") if tool_result else "") or enterprise_productization_answer(text, session)

    elif intent == "app_factory":
        tool_result = route_tool(text, intent, approved) if run_tools else {}
        answer = call_local_llm(text, session, classification, tool_context=tool_result, language=language) or (tool_result.get("answer") if tool_result else "") or app_factory_answer(text, session)

    elif intent == "software_builder":
        tool_result = route_tool(text, intent, approved) if run_tools else {}
        answer = call_local_llm(text, session, classification, tool_context=tool_result, language=language) or (tool_result.get("answer") if tool_result else "") or software_builder_answer(text, session)

    elif classification.get("should_route_tool") and run_tools:
        tool_result = route_tool(text, intent, approved)
        # Primeiro tenta transformar o resultado da ferramenta em uma conversa natural.
        llm = call_local_llm(text, session, classification, tool_context=tool_result, language=language)
        if llm:
            answer = llm
        else:
            intro = natural_business_intro(text, classification, session)
            tool_answer = normalize(tool_result.get("answer", ""))
            if tool_answer:
                if tool_answer.lower().startswith(intro[:50].lower()):
                    answer = tool_answer
                else:
                    answer = f"{intro}\n\n{tool_answer}"
            else:
                answer = intro

    else:
        answer = call_local_llm(text, session, classification, language=language) or generate_general_fallback(text, session, classification)

    answer = ensure_dialogue_quality(answer, text, session, classification)

    # HAL V29 Conversation Intelligence: semantic anti-parrot gate.
    conversation_intelligence: dict[str, Any] = {}
    try:
        from services import conversation_intelligence_v29 as ci
        conversation_intelligence = ci.analyze_candidate(text, answer, session.get("turns", []), session_id=(f"{user_id}:{session_id}" if user_id else session_id))
        if conversation_intelligence.get("should_rewrite"):
            guard_instruction = ci.rewrite_instruction(conversation_intelligence)
            retry_context = dict(tool_result or {})
            retry_context["conversation_quality_guard"] = {
                "instruction": guard_instruction,
                "parrot_score": conversation_intelligence.get("parrot_score"),
                "goal": conversation_intelligence.get("goal"),
                "sentiment": conversation_intelligence.get("sentiment"),
            }
            retry = call_local_llm(text, session, classification, tool_context=retry_context, language=language)
            if retry:
                retry = ensure_dialogue_quality(retry, text, session, classification)
                retry_analysis = ci.analyze_candidate(text, retry, session.get("turns", []), session_id=(f"{user_id}:{session_id}" if user_id else session_id))
                if not retry_analysis.get("should_rewrite"):
                    answer = retry
                    conversation_intelligence = retry_analysis
                    conversation_intelligence["rewrite_applied"] = True
                else:
                    answer = ci.deterministic_repair(text, retry, retry_analysis)
                    conversation_intelligence = retry_analysis
                    conversation_intelligence["rewrite_applied"] = True
                    conversation_intelligence["fallback_repair"] = True
            else:
                answer = ci.deterministic_repair(text, answer, conversation_intelligence)
                conversation_intelligence["rewrite_applied"] = True
                conversation_intelligence["fallback_repair"] = True
    except Exception as exc:
        conversation_intelligence = {"ok": False, "error": str(exc)}

    # HAL V30 Intent Grounding: current question wins over stale context or random model drift.
    conversation_grounding: dict[str, Any] = {}
    try:
        from services import conversation_grounding_v30 as grounding_v30
        conversation_grounding = grounding_v30.analyze_candidate(text, answer, classification, session.get("turns", []))
        if conversation_grounding.get("should_rewrite"):
            retry_context = dict(tool_result or {})
            retry_context["intent_grounding_guard"] = {
                "instruction": grounding_v30.rewrite_instruction(conversation_grounding),
                "reasons": conversation_grounding.get("reasons"),
                "current_question": text,
            }
            retry = call_local_llm(text, session, classification, tool_context=retry_context, language=language)
            if retry:
                retry = ensure_dialogue_quality(retry, text, session, classification)
                retry_analysis = grounding_v30.analyze_candidate(text, retry, classification, session.get("turns", []))
                if not retry_analysis.get("should_rewrite"):
                    answer = retry
                    conversation_grounding = retry_analysis
                    conversation_grounding["rewrite_applied"] = True
                else:
                    answer = grounding_v30.deterministic_repair(text, classification, retry_analysis)
                    conversation_grounding = retry_analysis
                    conversation_grounding["rewrite_applied"] = True
                    conversation_grounding["fallback_repair"] = True
            else:
                answer = grounding_v30.deterministic_repair(text, classification, conversation_grounding)
                conversation_grounding["rewrite_applied"] = True
                conversation_grounding["fallback_repair"] = True
    except Exception as exc:
        conversation_grounding = {"ok": False, "error": str(exc)}

    _save_turn(session_id, text, answer, classification, tool_result, user_id=user_id)
    _audit({"event": "converse", "session_id": session_id, "intent": intent, "language": language, "parrot_score": conversation_intelligence.get("parrot_score"), "grounding_reasons": conversation_grounding.get("reasons", [])})
    return {
        "ok": True,
        "session_id": session_id,
        "classification": classification,
        "answer": answer,
        "language": language,
        "tool_result": tool_result,
        "conversation_intelligence": conversation_intelligence,
        "conversation_grounding": conversation_grounding,
        "model_runtime": session.get("_llm_runtime", {}),
        "ui": {
            "requires_button": False,
            "open_panel_automatically": False,
            "target_panel": "",
            "suggested_panel": tool_result.get("target_panel", ""),
            "interaction_mode": "conversation_first_tools_in_background",
        },
    }



def ensure_dialogue_quality(answer: str, message: str, session: dict[str, Any], classification: dict[str, Any]) -> str:
    """Evita resposta papagaio e melhora o tom final antes de devolver ao usuário."""
    ans = normalize(answer)
    low_ans = ans.lower()
    msg = normalize(message)
    low_msg = msg.lower()
    last_a = last_assistant_message(session).lower() if session else ""

    generic_phrases = [
        "entendi. me conta um pouco mais",
        "você quer só conversar sobre isso ou quer que eu transforme",
        "voce quer só conversar sobre isso ou quer que eu transforme",
        "voce quer so conversar sobre isso ou quer que eu transforme",
        "me conte um pouco mais para eu te ajudar melhor",
    ]

    repeated = bool(ans and last_a and ans.lower() == last_a)
    generic = any(p in low_ans for p in generic_phrases)

    if is_cyber_defense_request(msg) and ("ponto central" in low_ans or "qual é o assunto e qual resultado" in low_ans or repeated):
        return cyber_defense_answer(msg, session)

    if is_enterprise_productization_request(msg) and ("ponto central" in low_ans or "qual é o assunto e qual resultado" in low_ans or repeated):
        return enterprise_productization_answer(msg, session)

    if is_app_factory_request(msg) and ("ponto central" in low_ans or "qual é o assunto e qual resultado" in low_ans or repeated):
        return app_factory_answer(msg, session)

    if is_software_builder_request(msg) and ("ponto central" in low_ans or "qual é o assunto e qual resultado" in low_ans or repeated):
        return software_builder_answer(msg, session)

    if (generic or repeated or "me diga só o ponto central" in low_ans or "qual é o assunto e qual resultado" in low_ans) and (is_live_chat_request(msg) or is_tiny_utterance(msg)):
        return live_chat_answer(msg, session)

    if not ans or generic or repeated:
        # Se for uma pergunta, responda como conversa, não como formulário.
        if re.search(r"\?", msg) or re.search(r"(?i)^(como|qual|quais|quem|quando|onde|por que|porque|me explica|explique|o que|oque)\b", msg):
            if "presidente do brasil" in low_msg or ("presidente" in low_msg and "brasil" in low_msg):
                return (
                    "Você está perguntando quem é o presidente do Brasil atualmente. "
                    "Essa é informação atual, então o caminho correto é eu pesquisar em fonte confiável antes de afirmar. "
                    "Se a pesquisa web estiver habilitada no seu ambiente, eu consulto e te devolvo a resposta com a fonte. "
                    "Se não estiver, eu te aviso que falta configurar a pesquisa."
                )
            return (
                "Entendi a pergunta. Vou responder de forma direta, mas preciso de uma precisão: "
                "você quer uma explicação simples, uma resposta técnica ou uma orientação prática para executar algo?"
            )

        if is_contextless_followup(msg):
            return contextual_followup_answer(msg, session)

        return (
            "Entendi. Vou seguir com você de forma mais objetiva. "
            "Me diga só o ponto central: qual é o assunto e qual resultado você quer no final?"
        )

    # Se estiver muito burocrático, suavizar.
    if low_ans.startswith("entendi.") and len(ans) < 90 and classification.get("intent") not in {"small_talk", "personal_support"}:
        return ans + " Me diga a fonte ou o detalhe que falta e eu continuo a partir daí."

    return ans



def route_tool(message: str, intent: str, approved: bool = False) -> dict[str, Any]:
    try:
        if intent == "cyber_defense":
            from app.services import cyber_defense_shield
            return {
                "ok": True,
                "tool": "cyber_defense_shield",
                "target_panel": "cyberDefensePanel",
                "answer": cyber_defense_shield.natural_answer(message),
                "raw": {
                    "status": cyber_defense_shield.status(),
                    "guard_plan": cyber_defense_shield.ransomware_guard_plan(),
                    "posture": cyber_defense_shield.security_posture(),
                },
            }

        if intent == "enterprise_productization":
            from app.services import enterprise_productization_v13
            return {
                "ok": True,
                "tool": "enterprise_productization_v13",
                "target_panel": "enterpriseProductizationPanel",
                "answer": enterprise_productization_v13.answer_for_enterprise_productization(message),
                "raw": enterprise_productization_v13.status(),
            }

        if intent == "app_factory":
            from app.services import app_factory_pro
            res = app_factory_pro.blueprint_from_prompt(message)
            return {
                "ok": True,
                "tool": "app_factory_pro",
                "target_panel": "appFactoryPanel",
                "answer": res.get("answer", ""),
                "raw": res,
            }

        if intent == "software_builder":
            from app.services import software_builder_center
            res = software_builder_center.build_plan(message)
            return {
                "ok": True,
                "tool": "software_builder_center",
                "target_panel": "softwareBuilderPanel",
                "answer": res.get("answer", ""),
                "raw": res,
            }

        if intent == "skills_center":
            from app.services import skills_multi_agent_center
            res = skills_multi_agent_center.guided_answer(message, approved=approved)
            return {
                "ok": True,
                "tool": "skills_multi_agent_center",
                "target_panel": "skillsCenterPanel",
                "answer": res.get("answer", res.get("summary", skills_multi_agent_center.answer_for_skills(message))),
                "raw": res,
            }

        if intent == "executive_finance":
            from app.services import executive_financial_intelligence
            res = executive_financial_intelligence.guided_answer(message, approved=approved)
            return {
                "ok": True,
                "tool": "executive_financial_intelligence",
                "target_panel": "executiveFinancePanel",
                "answer": res.get("answer", ""),
                "raw": res,
            }

        if intent == "omnichannel":
            from app.services import omnichannel_voice_text_delivery
            return {
                "ok": True,
                "tool": "omnichannel_voice_text_delivery",
                "target_panel": "omnichannelDeliveryPanel",
                "answer": omnichannel_voice_text_delivery.answer_for_omnichannel(message),
                "raw": omnichannel_voice_text_delivery.status(),
            }

        if intent == "meeting":
            from app.services import meeting_intelligence_gateway
            return {
                "ok": True,
                "tool": "meeting_intelligence_gateway",
                "target_panel": "meetingIntelligencePanel",
                "answer": meeting_intelligence_gateway.answer_for_meeting(message),
                "raw": meeting_intelligence_gateway.status(),
            }

        if intent == "enterprise":
            from app.services import enterprise_integration_team_intelligence
            res = enterprise_integration_team_intelligence.guided_answer(message, approved=approved)
            return {
                "ok": True,
                "tool": "enterprise_integration_team_intelligence",
                "target_panel": "enterpriseIntelligencePanel",
                "answer": res.get("answer", ""),
                "raw": res,
            }

        if intent == "database":
            from app.services import database_access_wizard
            res = database_access_wizard.guided_answer(message, approved=approved)
            return {
                "ok": True,
                "tool": "database_access_wizard",
                "target_panel": "databaseAccessPanel",
                "answer": res.get("answer", ""),
                "raw": res,
            }

        if intent == "erp":
            from app.services import database_access_wizard, universal_erp_connector
            db_res = database_access_wizard.guided_answer(message, approved=approved)
            erp_res = universal_erp_connector.create_query_plan(message, approved=approved)
            return {
                "ok": True,
                "tool": "database_access_wizard+universal_erp_connector",
                "target_panel": "databaseAccessPanel",
                "answer": db_res.get("answer", "") or erp_res.get("summary", ""),
                "raw": {"database": db_res, "erp": erp_res},
            }

        if intent == "web":
            from app.services import reliable_web_answer
            res = reliable_web_answer.answer_question(message, approved=True)
            text = res.get("answer", "")
            sources = res.get("sources", [])[:3]
            if sources:
                text += "\n\nFontes verificadas:\n" + "\n".join([f"- {s.get('title','Fonte')}: {s.get('url','')}" for s in sources])
            return {"ok": True, "tool": "reliable_web_answer", "target_panel": "reliableWebPanel", "answer": text, "raw": res}

        if intent == "mission":
            from app.services import visual_mission_control
            res = visual_mission_control.create_mission(
                title="Missão criada pelo HAL",
                objective=message,
                source="human_conversation",
                requires_approval=not approved,
                presentation=True,
            )
            return {
                "ok": True,
                "tool": "visual_mission_control",
                "target_panel": "visualMissionPanel",
                "answer": "Criei a missão no painel visual. Vou acompanhar status, responsáveis e pontos que exigem aprovação.",
                "raw": res,
            }

        if intent == "automation":
            low = message.lower()
            if "n8n" in low or "workflow" in low or "webhook" in low:
                from app.services import n8n_workflow_center
                return {"ok": True, "tool": "n8n_workflow_center", "target_panel": "openClawEnterprisePanel", "answer": n8n_workflow_center.answer_for_n8n(message)}
            if "navegador" in low or "browser" in low or "playwright" in low or "selenium" in low:
                from app.services import browser_automation
                return {"ok": True, "tool": "browser_automation", "target_panel": "openClawEnterprisePanel", "answer": browser_automation.answer_for_browser(message)}
            if "agendar" in low or "cron" in low or "todo dia" in low:
                from app.services import cron_enterprise
                return {"ok": True, "tool": "cron_enterprise", "target_panel": "openClawEnterprisePanel", "answer": cron_enterprise.answer_for_cron(message)}
            if any(x in low for x in ["whatsapp", "telegram", "slack", "teams", "discord", "email", "e-mail"]):
                from app.services import channel_gateway
                return {"ok": True, "tool": "channel_gateway", "target_panel": "openClawEnterprisePanel", "answer": channel_gateway.answer_for_channel_gateway(message)}
            return {"ok": True, "tool": "automation_router", "target_panel": "openClawEnterprisePanel", "answer": "Entendi a automação. Ela é de n8n, navegador, agendamento, canal de mensagem ou processo interno?"}

        return {"ok": True, "tool": "natural_dialogue", "answer": ""}

    except Exception as exc:
        return {
            "ok": False,
            "tool": intent,
            "answer": "Eu entendi o pedido, mas encontrei uma falha ao acionar a ferramenta. Me diga qual fonte ou sistema devo usar e eu continuo por outro caminho.",
            "error": str(exc),
        }


def list_sessions(limit: int = 50, user_id: str = "") -> dict[str, Any]:
    sessions = _load(_session_file(user_id), {"sessions": []}).get("sessions", [])
    return {"ok": True, "sessions": sessions[:max(1, min(limit, 200))], "count": len(sessions), "private_workspace": bool(user_id)}


def set_preference(key: str, value: str, user_id: str = "") -> dict[str, Any]:
    memory_path = _memory_file(user_id)
    memory = _load(memory_path, {"facts": [], "preferences": []})
    memory.setdefault("preferences", []).append({"key": key, "value": value, "updated_at": _now()})
    _save(memory_path, memory)
    _audit({"event": "set_preference", "key": key, "user_id": user_id})
    return {"ok": True, "summary": "Preferência de conversa salva.", "preferences": memory["preferences"]}


def conversation_policy() -> dict[str, Any]:
    return {
        "ok": True,
        "policy": {
            "no_buttons_required": True,
            "default_behavior": "conversa natural primeiro, ferramenta nos bastidores quando necessário",
            "dialogue_brain": "v29_semantic_contextual_anti_parrot",
            "uses_local_llm_when_available": True,
            "tone": "cordial, objetivo, humano, didático, profissional e natural",
            "never_do": [
                "repetir a mesma resposta genérica",
                "responder como papagaio",
                "obrigar usuário a escolher aba",
                "inventar resultado sem fonte",
                "executar ação sensível sem aprovação",
            ],
            "always_do": [
                "usar histórico da sessão e fatos já conhecidos",
                "medir repetição semântica antes de responder",
                "fazer pergunta de esclarecimento real quando faltar contexto",
                "responder em linguagem simples quando o usuário for leigo",
                "acionar ferramenta certa automaticamente",
                "perguntar apenas o necessário para avançar",
            ],
        },
    }
