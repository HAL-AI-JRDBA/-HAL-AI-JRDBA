from __future__ import annotations

import json
import os
import subprocess
import tempfile
import time
import uuid
import wave
from pathlib import Path
from typing import Any

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "local_stt_fallback"
AUDIO_DIR = DATA_DIR / "audio"
AUDIT_FILE = DATA_DIR / "audit.jsonl"
CONFIG_FILE = DATA_DIR / "config.json"

DEFAULT_CONFIG = {
    "enabled": True,
    "preferred_engine": "auto",
    "language": "pt",
    "model_size": "base",
    "device": "auto",
    "compute_type": "auto",
    "max_audio_seconds": 45,
    "keep_audio_files": False,
    "fallback_message": "Não consegui transcrever sua voz. Pode repetir ou digitar a pergunta?",
    "install_notes": {
        "faster_whisper": "pip install faster-whisper",
        "openai_whisper": "pip install openai-whisper",
        "ffmpeg": "necessário para alguns formatos; WebM geralmente funciona melhor com faster-whisper/ffmpeg disponível"
    }
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text(json.dumps(DEFAULT_CONFIG, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def _load_config() -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else DEFAULT_CONFIG
    except Exception:
        return DEFAULT_CONFIG.copy()


def status() -> dict[str, Any]:
    cfg = _load_config()
    engines = []
    faster_ok = False
    whisper_ok = False
    try:
        import faster_whisper  # type: ignore
        faster_ok = True
        engines.append("faster-whisper")
    except Exception:
        pass
    try:
        import whisper  # type: ignore
        whisper_ok = True
        engines.append("openai-whisper")
    except Exception:
        pass

    ffmpeg_ok = False
    try:
        subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True, timeout=5)
        ffmpeg_ok = True
    except Exception:
        pass

    return {
        "ok": True,
        "name": "HAL Local STT Fallback",
        "description": "Transcrição local alternativa quando o Web Speech do navegador retorna no-speech.",
        "enabled": cfg.get("enabled", True),
        "engines_available": engines,
        "faster_whisper_available": faster_ok,
        "openai_whisper_available": whisper_ok,
        "ffmpeg_available": ffmpeg_ok,
        "ready": faster_ok or whisper_ok,
        "config": cfg,
        "recommendation": "Instale faster-whisper para transcrição local robusta: pip install faster-whisper",
    }


def save_audio(data: bytes, suffix: str = ".webm") -> Path:
    _ensure()
    suffix = suffix if suffix.startswith(".") else "." + suffix
    path = AUDIO_DIR / f"voice_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}{suffix}"
    path.write_bytes(data)
    return path


def transcribe_file(path: str | Path, language: str = "pt") -> dict[str, Any]:
    _ensure()
    cfg = _load_config()
    p = Path(path)
    if not p.exists():
        return {"ok": False, "text": "", "error": "Arquivo de áudio não encontrado."}

    result = transcribe_with_faster_whisper(p, language or cfg.get("language", "pt"))
    if result.get("ok"):
        cleanup_audio(p, cfg)
        _audit({"event": "transcribe", "engine": "faster-whisper", "ok": True, "chars": len(result.get("text", ""))})
        return result

    fallback_error = result.get("error", "")
    result2 = transcribe_with_openai_whisper(p, language or cfg.get("language", "pt"))
    if result2.get("ok"):
        cleanup_audio(p, cfg)
        _audit({"event": "transcribe", "engine": "openai-whisper", "ok": True, "chars": len(result2.get("text", ""))})
        return result2

    _audit({"event": "transcribe", "ok": False, "error": fallback_error or result2.get("error", "")})
    cleanup_audio(p, cfg)
    return {
        "ok": False,
        "text": "",
        "error": result2.get("error") or fallback_error or "Nenhum motor STT local disponível.",
        "status": status(),
    }


def transcribe_with_faster_whisper(path: Path, language: str = "pt") -> dict[str, Any]:
    try:
        from faster_whisper import WhisperModel  # type: ignore
    except Exception as exc:
        return {"ok": False, "text": "", "error": f"faster-whisper não instalado: {exc}"}

    cfg = _load_config()
    model_size = os.getenv("HALL_STT_MODEL") or cfg.get("model_size", "base")
    device = os.getenv("HALL_STT_DEVICE") or cfg.get("device", "auto")
    compute_type = os.getenv("HALL_STT_COMPUTE_TYPE") or cfg.get("compute_type", "auto")

    kwargs: dict[str, Any] = {}
    if device and device != "auto":
        kwargs["device"] = device
    if compute_type and compute_type != "auto":
        kwargs["compute_type"] = compute_type

    try:
        model = WhisperModel(model_size, **kwargs)
        segments, info = model.transcribe(str(path), language=language, vad_filter=True)
        text = " ".join(seg.text.strip() for seg in segments if seg.text and seg.text.strip()).strip()
        return {
            "ok": bool(text),
            "text": text,
            "engine": "faster-whisper",
            "language": getattr(info, "language", language),
            "duration": getattr(info, "duration", None),
            "error": "" if text else "Áudio recebido, mas nenhum texto foi reconhecido.",
        }
    except Exception as exc:
        return {"ok": False, "text": "", "engine": "faster-whisper", "error": str(exc)}


def transcribe_with_openai_whisper(path: Path, language: str = "pt") -> dict[str, Any]:
    try:
        import whisper  # type: ignore
    except Exception as exc:
        return {"ok": False, "text": "", "error": f"openai-whisper não instalado: {exc}"}

    cfg = _load_config()
    model_size = os.getenv("HALL_STT_MODEL") or cfg.get("model_size", "base")
    try:
        model = whisper.load_model(model_size)
        res = model.transcribe(str(path), language=language, fp16=False)
        text = (res.get("text") or "").strip()
        return {
            "ok": bool(text),
            "text": text,
            "engine": "openai-whisper",
            "language": res.get("language", language),
            "error": "" if text else "Áudio recebido, mas nenhum texto foi reconhecido.",
        }
    except Exception as exc:
        return {"ok": False, "text": "", "engine": "openai-whisper", "error": str(exc)}


def cleanup_audio(path: Path, cfg: dict[str, Any]) -> None:
    if cfg.get("keep_audio_files", False):
        return
    try:
        path.unlink(missing_ok=True)
    except Exception:
        pass


def configure(changes: dict[str, Any]) -> dict[str, Any]:
    cfg = _load_config()
    for k, v in (changes or {}).items():
        cfg[k] = v
    CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True, "config": cfg}
