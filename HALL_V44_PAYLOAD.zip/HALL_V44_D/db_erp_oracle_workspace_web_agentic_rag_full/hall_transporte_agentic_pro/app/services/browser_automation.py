from __future__ import annotations

import json
import threading
import time
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from app.core.config import root_dir


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(path: Path, event: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


DATA_DIR = root_dir() / "data" / "browser_automation"
SESSIONS_FILE = DATA_DIR / "browser_sessions.json"
ACTIONS_FILE = DATA_DIR / "actions.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"
PROFILES_DIR = DATA_DIR / "profiles"
SCREENSHOTS_DIR = DATA_DIR / "screenshots"
DOWNLOADS_DIR = DATA_DIR / "downloads"

DEFAULT_POLICY = {
    "enabled": True,
    "engine": "playwright",
    "headless_default": False,
    "approval_required_before_submit": True,
    "approval_required_before_download": True,
    "approval_required_before_login": True,
    "approval_required_before_send": True,
    "allowed_domains": [],
    "blocked_domains": ["internetbanking", "gov.br/receita", "web.whatsapp.com/send"],
    "max_steps_per_session": 50,
    "timeout_seconds": 60,
    "profile_isolation": True,
    "host_shell_access": False,
    "desktop_control": False,
}

# Runtime Playwright é mantido dentro do processo do backend. Nenhum shell/desktop
# irrestrito é exposto por esta camada.
_RUNTIME_LOCK = threading.RLock()
_RUNTIME: dict[str, dict[str, Any]] = {}


def _playwright_available() -> tuple[bool, str]:
    try:
        import playwright  # noqa: F401
        return True, ""
    except Exception as exc:
        return False, str(exc)


def _session_row(session_id: str) -> dict[str, Any]:
    rows = _load(SESSIONS_FILE, {"sessions": []}).get("sessions", [])
    for row in rows:
        if row.get("id") == session_id:
            return row
    raise KeyError(f"Sessão de navegador não encontrada: {session_id}")


def _update_session(session_id: str, patch: dict[str, Any]) -> dict[str, Any]:
    data = _load(SESSIONS_FILE, {"sessions": []})
    rows = data.setdefault("sessions", [])
    for i, row in enumerate(rows):
        if row.get("id") == session_id:
            rows[i] = {**row, **patch, "updated_at": _now()}
            _save(SESSIONS_FILE, data)
            return rows[i]
    raise KeyError(f"Sessão de navegador não encontrada: {session_id}")


def _normalize_host(url: str) -> str:
    try:
        return (urlparse(url).hostname or "").lower().strip(".")
    except Exception:
        return ""


def _domain_allowed(url: str, session: dict[str, Any]) -> tuple[bool, str]:
    host = _normalize_host(url)
    low = (url or "").lower()
    if not host:
        return False, "URL inválida ou sem hostname."
    for token in DEFAULT_POLICY["blocked_domains"]:
        if token.lower() in low:
            return False, f"Domínio/rota bloqueado pela política: {token}"
    allow = list(session.get("allowed_domains") or DEFAULT_POLICY.get("allowed_domains") or [])
    if not allow:
        return True, ""
    for item in allow:
        item = str(item).lower().strip().lstrip(".")
        if host == item or host.endswith("." + item):
            return True, ""
    return False, f"Domínio {host} não está na allowlist desta sessão."


def _ensure_runtime(session_id: str) -> dict[str, Any]:
    with _RUNTIME_LOCK:
        existing = _RUNTIME.get(session_id)
        if existing and existing.get("page"):
            return existing
        ok, err = _playwright_available()
        if not ok:
            raise RuntimeError("Playwright não instalado. Execute INSTALAR_HALL_OPENCLAW_COMPLETION_V26_1.bat. " + err)
        from playwright.sync_api import sync_playwright

        session = _session_row(session_id)
        _ensure_dir(PROFILES_DIR)
        _ensure_dir(SCREENSHOTS_DIR)
        _ensure_dir(DOWNLOADS_DIR)
        profile_path = root_dir() / str(session.get("profile_path") or (PROFILES_DIR / session_id).relative_to(root_dir()))
        profile_path.mkdir(parents=True, exist_ok=True)
        pw = sync_playwright().start()
        context = pw.chromium.launch_persistent_context(
            user_data_dir=str(profile_path),
            headless=bool(session.get("headless", False)),
            accept_downloads=True,
        )
        page = context.pages[0] if context.pages else context.new_page()
        page.set_default_timeout(int(DEFAULT_POLICY["timeout_seconds"] * 1000))
        runtime = {"pw": pw, "context": context, "page": page, "started_at": _now()}
        _RUNTIME[session_id] = runtime
        _update_session(session_id, {"status": "running"})
        return runtime


def _requires_approval(action: str) -> bool:
    return action.lower().strip() in {"submit", "login", "download", "payment", "delete", "send", "upload"}


def status() -> dict[str, Any]:
    _ensure_dir(PROFILES_DIR)
    _ensure_dir(SCREENSHOTS_DIR)
    ok, err = _playwright_available()
    sessions = _load(SESSIONS_FILE, {"sessions": []}).get("sessions", [])
    actions = _load(ACTIONS_FILE, {"actions": []}).get("actions", [])
    return {
        "ok": True,
        "name": "HAL Browser Automation V26.1",
        "mode": "real_playwright_executor",
        "playwright_available": ok,
        "playwright_error": err if not ok else "",
        "runtime_sessions": list(_RUNTIME.keys()),
        "sessions_count": len(sessions),
        "actions_count": len(actions),
        "capabilities": [
            "Chromium real via Playwright",
            "Contexto persistente e perfil isolado por sessão",
            "Abrir URL com allowlist/blocklist",
            "Ler DOM/texto",
            "Clique, fill, press, hover, select, check/uncheck",
            "Screenshot real",
            "Download controlado",
            "Aprovação humana antes de submit/login/send/upload/download",
            "Auditoria e histórico",
            "Sem shell irrestrito e sem controle irrestrito do Windows",
        ],
        "policy": DEFAULT_POLICY,
    }


def policy() -> dict[str, Any]:
    return {"ok": True, "policy": DEFAULT_POLICY}


def create_session(name: str = "Navegação HAL", headless: bool = False, allowed_domains: list[str] | None = None) -> dict[str, Any]:
    _ensure_dir(PROFILES_DIR)
    data = _load(SESSIONS_FILE, {"sessions": []})
    sid = f"browser_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    profile_path = PROFILES_DIR / sid
    profile_path.mkdir(parents=True, exist_ok=True)
    session = {
        "id": sid,
        "name": name,
        "engine": "playwright",
        "headless": bool(headless),
        "profile_path": str(profile_path.relative_to(root_dir())),
        "allowed_domains": list(allowed_domains or []),
        "status": "created",
        "current_url": "",
        "created_at": _now(),
        "updated_at": _now(),
    }
    data.setdefault("sessions", []).insert(0, session)
    _save(SESSIONS_FILE, data)
    _audit(AUDIT_FILE, {"event": "create_session", "session_id": sid})
    return {"ok": True, "session": session, "summary": "Sessão de navegador isolada criada."}


def list_sessions(limit: int = 100) -> dict[str, Any]:
    sessions = _load(SESSIONS_FILE, {"sessions": []}).get("sessions", [])
    return {"ok": True, "sessions": sessions[:max(1, min(limit, 500))], "count": len(sessions)}


def _write_action(item: dict[str, Any]) -> None:
    data = _load(ACTIONS_FILE, {"actions": []})
    data.setdefault("actions", []).insert(0, item)
    data["actions"] = data["actions"][:3000]
    _save(ACTIONS_FILE, data)
    _audit(AUDIT_FILE, {"event": "browser_action", "session_id": item.get("session_id"), "action": item.get("action"), "status": item.get("status")})


def execute_action(session_id: str, action: str, target: str = "", value: str = "", approved: bool = False) -> dict[str, Any]:
    action = (action or "").strip().lower()
    session = _session_row(session_id)
    item = {
        "id": f"ba_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "session_id": session_id,
        "action": action,
        "target": target,
        "value": "***" if action in {"login", "password"} and value else value,
        "approved": bool(approved),
        "created_at": _now(),
        "playwright_hint": to_playwright_hint(action, target, "***" if action in {"login", "password"} else value),
    }
    if _requires_approval(action) and not approved:
        item["status"] = "waiting_approval"
        _write_action(item)
        return {"ok": False, "requires_approval": True, "action": item, "summary": "Ação sensível aguardando aprovação humana."}
    try:
        rt = _ensure_runtime(session_id)
        page = rt["page"]
        result: dict[str, Any] = {}
        if action == "open":
            allowed, reason = _domain_allowed(target, session)
            if not allowed:
                raise PermissionError(reason)
            response = page.goto(target, wait_until="domcontentloaded")
            result = {"url": page.url, "title": page.title(), "http_status": getattr(response, "status", None)}
            _update_session(session_id, {"current_url": page.url})
        elif action == "read":
            selector = target or "body"
            txt = page.locator(selector).inner_text(timeout=int(DEFAULT_POLICY["timeout_seconds"] * 1000))
            result = {"url": page.url, "title": page.title(), "text": txt[:50000]}
        elif action == "click":
            page.locator(target).click()
            result = {"url": page.url, "title": page.title()}
        elif action == "fill":
            page.locator(target).fill(value)
            result = {"filled": True, "target": target}
        elif action in {"submit", "login", "send"}:
            page.locator(target).click()
            page.wait_for_load_state("domcontentloaded", timeout=int(DEFAULT_POLICY["timeout_seconds"] * 1000))
            result = {"url": page.url, "title": page.title()}
        elif action == "press":
            page.locator(target or "body").press(value or "Enter")
            result = {"pressed": value or "Enter"}
        elif action == "hover":
            page.locator(target).hover()
            result = {"hovered": True}
        elif action == "select":
            selected = page.locator(target).select_option(value)
            result = {"selected": selected}
        elif action == "check":
            page.locator(target).check()
            result = {"checked": True}
        elif action == "uncheck":
            page.locator(target).uncheck()
            result = {"checked": False}
        elif action == "wait":
            page.wait_for_timeout(max(0, min(int(float(value or 1) * 1000), 30000)))
            result = {"waited_seconds": float(value or 1)}
        elif action == "screenshot":
            path = SCREENSHOTS_DIR / f"{session_id}_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:4]}.png"
            page.screenshot(path=str(path), full_page=True)
            result = {"screenshot": str(path.relative_to(root_dir())), "url": page.url}
        elif action == "download":
            with page.expect_download() as info:
                page.locator(target).click()
            download = info.value
            suggested = download.suggested_filename
            out = DOWNLOADS_DIR / f"{uuid.uuid4().hex[:8]}_{suggested}"
            download.save_as(str(out))
            result = {"download": str(out.relative_to(root_dir())), "suggested_filename": suggested}
        else:
            raise ValueError(f"Ação de browser não suportada: {action}")
        item["status"] = "done"
        item["result"] = result
        _write_action(item)
        return {"ok": True, "executed": True, "action": item, "result": result}
    except Exception as exc:
        item["status"] = "error"
        item["error"] = str(exc)
        _write_action(item)
        return {"ok": False, "executed": False, "action": item, "error": str(exc)}


def record_action(session_id: str, action: str, target: str = "", value: str = "", approved: bool = False) -> dict[str, Any]:
    """Compatibilidade V26: o endpoint antigo agora executa de verdade."""
    return execute_action(session_id, action, target, value, approved)


def close_session(session_id: str) -> dict[str, Any]:
    with _RUNTIME_LOCK:
        rt = _RUNTIME.pop(session_id, None)
        if rt:
            try:
                rt["context"].close()
            finally:
                try:
                    rt["pw"].stop()
                except Exception:
                    pass
        try:
            session = _update_session(session_id, {"status": "closed"})
        except Exception:
            session = {"id": session_id, "status": "closed"}
        _audit(AUDIT_FILE, {"event": "close_session", "session_id": session_id})
        return {"ok": True, "session": session}


def to_playwright_hint(action: str, target: str, value: str) -> str:
    if action == "open":
        return f"page.goto({target!r})"
    if action == "click":
        return f"page.locator({target!r}).click()"
    if action == "fill":
        return f"page.locator({target!r}).fill({value!r})"
    if action == "screenshot":
        return "page.screenshot(path='screenshot.png', full_page=True)"
    if action == "read":
        return f"page.locator({(target or 'body')!r}).inner_text()"
    if action in {"submit", "login", "send", "download"}:
        return f"# aprovação necessária; page.locator({target!r}).click()"
    return f"# ação {action} em {target}"


def action_plan(url: str, goal: str) -> dict[str, Any]:
    steps = [
        {"action": "open", "target": url, "requires_approval": False},
        {"action": "read", "target": "body", "requires_approval": False},
        {"action": "screenshot", "target": "page", "requires_approval": False},
        {"action": "analyze", "target": goal, "requires_approval": False},
    ]
    if any(x in goal.lower() for x in ["preencher", "enviar", "login", "baixar", "comprar", "excluir", "upload"]):
        steps.append({"action": "submit", "target": "confirmar ação sensível", "requires_approval": True})
    return {"ok": True, "url": url, "goal": goal, "steps": steps, "policy": DEFAULT_POLICY, "executor": "playwright_real"}


def list_actions(session_id: str = "", limit: int = 100) -> dict[str, Any]:
    actions = _load(ACTIONS_FILE, {"actions": []}).get("actions", [])
    if session_id:
        actions = [a for a in actions if a.get("session_id") == session_id]
    return {"ok": True, "actions": actions[:max(1, min(limit, 500))], "count": len(actions)}


def install_plan() -> dict[str, Any]:
    return {
        "ok": True,
        "playwright": [
            "python -m pip install playwright",
            "python -m playwright install chromium",
            "usar perfil isolado em data/browser_automation/profiles/<session_id>",
        ],
        "security": [
            "Sem shell irrestrito",
            "Sem controle irrestrito do Windows",
            "Allowlist/blocklist de domínio",
            "Aprovação antes de submit/login/send/upload/download",
            "Perfis isolados e auditoria de ações",
        ],
    }


def answer_for_browser(message: str = "") -> str:
    return "Vou usar o HAL Browser Automation V26.1 com Chromium real/Playwright, perfil isolado, leitura do DOM, clique, preenchimento, screenshot e aprovação antes de ações sensíveis. O acesso irrestrito ao Windows permanece bloqueado."
