from __future__ import annotations

import json
import re
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "enterprise_integration_team_intelligence"
TOOLS_FILE = DATA_DIR / "tools.json"
TEAMS_FILE = DATA_DIR / "teams.json"
USERS_FILE = DATA_DIR / "users.json"
AGENDAS_FILE = DATA_DIR / "agendas.json"
TASKS_FILE = DATA_DIR / "tasks.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"


SEGMENTS: dict[str, dict[str, Any]] = {
    "transporte_passageiros": {
        "label": "Transporte de Passageiros / Rodoviário / Urbano",
        "keywords": ["passagem", "bilhetagem", "vale-transporte", "linha", "viagem", "ônibus", "onibus", "frota"],
        "departments": ["bilhetagem", "operações", "financeiro", "atendimento", "manutenção", "ti_dba"],
    },
    "logistica": {
        "label": "Logística / Transportes de Carga",
        "keywords": ["entrega", "frete", "cte", "manifesto", "rota", "armazém", "warehouse"],
        "departments": ["operações", "almoxarifado", "financeiro", "atendimento", "comercial"],
    },
    "financeiro_contabil": {
        "label": "Financeiro / Contábil / Escritórios",
        "keywords": ["contas a receber", "contabilidade", "fiscal", "boleto", "cobrança", "dre", "balancete"],
        "departments": ["financeiro", "contabilidade", "recebimentos", "fiscal", "diretoria"],
    },
    "varejo_atacado": {
        "label": "Varejo / Atacado / Mercados",
        "keywords": ["estoque", "produto", "loja", "sku", "ruptura", "pdv", "mercado", "atacado", "varejo"],
        "departments": ["compras", "almoxarifado", "vendas", "financeiro", "logística", "atendimento"],
    },
    "industria": {
        "label": "Indústria / Manufatura",
        "keywords": ["produção", "producao", "op", "lote", "manufatura", "qualidade", "chão de fábrica"],
        "departments": ["produção", "qualidade", "almoxarifado", "manutenção", "engenharia", "financeiro"],
    },
    "agronegocio": {
        "label": "Agronegócio",
        "keywords": ["safra", "fazenda", "grãos", "graos", "insumo", "colheita", "agro", "gado"],
        "departments": ["operações", "compras", "almoxarifado", "financeiro", "comercial", "logística"],
    },
    "bancos_fintechs": {
        "label": "Bancos / Fintechs / Serviços Financeiros",
        "keywords": ["banco", "fintech", "conta digital", "pix", "risco", "crédito", "credito", "compliance"],
        "departments": ["financeiro", "riscos", "compliance", "atendimento", "dados_bi", "ti_dba"],
    },
    "saude": {
        "label": "Saúde / Clínicas / Hospitais",
        "keywords": ["paciente", "consulta", "prontuário", "convenio", "convênio", "clínica", "hospital"],
        "departments": ["atendimento", "faturamento", "agenda", "financeiro", "ti_dba"],
    },
    "educacao": {
        "label": "Educação",
        "keywords": ["aluno", "matrícula", "matricula", "turma", "nota", "curso", "professor"],
        "departments": ["secretaria", "financeiro", "coordenação", "atendimento", "ti_dba"],
    },
    "generico": {
        "label": "Qualquer Empresa / Corporativo",
        "keywords": ["empresa", "setor", "time", "usuário", "usuario", "departamento"],
        "departments": ["diretoria", "financeiro", "contabilidade", "recebimentos", "almoxarifado", "comercial", "atendimento", "ti_dba", "dados_bi"],
    },
}

TOOL_CATALOG: dict[str, dict[str, Any]] = {
    "powerbi": {
        "label": "Power BI",
        "category": "bi",
        "keywords": ["powerbi", "power bi", "dashboard", "relatório bi", "relatorio bi", "indicador"],
        "capabilities": ["listar workspaces", "atualizar dataset", "consultar relatório", "gerar resumo executivo", "detectar indicador crítico"],
        "auth": ["TENANT_ID", "CLIENT_ID", "CLIENT_SECRET", "WORKSPACE_ID"],
        "safe_policy": "Consulta e resumo permitidos. Publicação/refresh crítico exige aprovação conforme política da empresa.",
    },
    "zabbix": {
        "label": "Zabbix",
        "category": "monitoring",
        "keywords": ["zabbix", "alerta", "host", "trigger", "monitoramento"],
        "capabilities": ["consultar alertas", "listar hosts críticos", "resumir incidentes", "correlacionar com Grafana"],
        "auth": ["URL", "API_TOKEN"],
        "safe_policy": "Leitura por padrão. Ações corretivas exigem aprovação.",
    },
    "grafana": {
        "label": "Grafana",
        "category": "monitoring",
        "keywords": ["grafana", "dashboard grafana", "painel", "métrica", "metrica", "observabilidade"],
        "capabilities": ["consultar dashboards", "ler métricas", "abrir painel", "gerar resumo operacional"],
        "auth": ["URL", "API_TOKEN"],
        "safe_policy": "Leitura por padrão. Alterar dashboard/alerta exige aprovação.",
    },
    "erp": {
        "label": "ERP",
        "category": "erp",
        "keywords": ["erp", "sistema de gestão", "sistema de gestao", "sap", "totvs", "senior", "omie", "protheus"],
        "capabilities": ["consultar dados", "mapear módulos", "criar plano de integração", "acionar Database Access Wizard"],
        "auth": ["DB/API/FILE/RPA conforme sistema"],
        "safe_policy": "Somente leitura por padrão. Escrita, baixa, cancelamento, reembolso e envio externo exigem aprovação.",
    },
    "crm": {
        "label": "CRM",
        "category": "crm",
        "keywords": ["crm", "lead", "oportunidade", "funil", "vendas", "cliente"],
        "capabilities": ["consultar leads", "resumir oportunidades", "agendar follow-up", "preparar proposta", "registrar atividade com aprovação"],
        "auth": ["API_TOKEN", "BASE_URL"],
        "safe_policy": "Leitura e rascunhos permitidos. Envio externo ou alteração de oportunidade exige aprovação.",
    },
    "whatsapp": {
        "label": "WhatsApp",
        "category": "channel",
        "keywords": ["whatsapp", "zap"],
        "capabilities": ["receber mensagem", "preparar resposta", "enviar com aprovação", "notificar setor"],
        "auth": ["WHATSAPP_TOKEN", "PHONE_NUMBER_ID"],
        "safe_policy": "Envio externo exige aprovação humana, salvo fluxos previamente autorizados.",
    },
    "telegram": {
        "label": "Telegram",
        "category": "channel",
        "keywords": ["telegram"],
        "capabilities": ["receber mensagem", "responder usuário", "notificar time", "operar bot"],
        "auth": ["TELEGRAM_BOT_TOKEN"],
        "safe_policy": "Envio externo exige aprovação ou política de automação.",
    },
    "teams": {
        "label": "Microsoft Teams",
        "category": "collaboration",
        "keywords": ["teams", "microsoft teams"],
        "capabilities": ["enviar mensagem de canal", "resumir conversa", "criar tarefa", "notificar aprovação", "acompanhar time"],
        "auth": ["TENANT_ID", "CLIENT_ID", "CLIENT_SECRET"],
        "safe_policy": "Mensagens e alterações exigem aprovação/política do setor.",
    },
    "slack": {
        "label": "Slack",
        "category": "collaboration",
        "keywords": ["slack"],
        "capabilities": ["resumir canal", "notificar equipe", "criar thread", "acompanhar incidentes"],
        "auth": ["SLACK_BOT_TOKEN"],
        "safe_policy": "Mensagens externas/canais sensíveis exigem aprovação.",
    },
    "email": {
        "label": "E-mail",
        "category": "channel",
        "keywords": ["e-mail", "email", "gmail", "outlook"],
        "capabilities": ["ler caixa", "preparar resposta", "resumir thread", "enviar com aprovação", "acompanhar cobrança"],
        "auth": ["SMTP/IMAP/OAUTH"],
        "safe_policy": "Envio externo exige aprovação.",
    },
    "calendar": {
        "label": "Calendário / Agenda",
        "category": "calendar",
        "keywords": ["agenda", "calendário", "calendario", "reunião", "reuniao", "compromisso"],
        "capabilities": ["consultar agenda", "sugerir horário", "criar compromisso", "agenda de time", "agenda pessoal"],
        "auth": ["OAUTH/CALENDAR_TOKEN"],
        "safe_policy": "Criar/alterar/cancelar compromisso exige confirmação do usuário ou política do time.",
    },
    "n8n": {
        "label": "n8n",
        "category": "automation",
        "keywords": ["n8n", "workflow", "webhook", "automação", "automacao"],
        "capabilities": ["acionar workflow", "receber callback", "orquestrar integrações", "executar rotina"],
        "auth": ["N8N_API_KEY", "N8N_BASE_URL"],
        "safe_policy": "Workflows críticos exigem aprovação.",
    },
    "database": {
        "label": "Bancos SQL/NoSQL",
        "category": "data",
        "keywords": ["banco de dados", "sql", "nosql", "oracle", "mongodb", "postgres", "sql server"],
        "capabilities": ["perguntar conexão", "montar plano de consulta", "gerar SQL/pseudo-query", "consultar com segurança"],
        "auth": ["ENV por conexão"],
        "safe_policy": "Somente leitura por padrão. Escrita bloqueada sem aprovação.",
    },
}

DEPARTMENT_TEMPLATES: dict[str, dict[str, Any]] = {
    "financeiro": {
        "label": "Financeiro",
        "agent": "Agente Financeiro",
        "goals": ["contas a receber", "contas a pagar", "cobrança", "fluxo de caixa", "DRE"],
        "tools": ["erp", "database", "powerbi", "email", "whatsapp", "calendar"],
        "calendar_policy": "Agenda de cobrança, fechamento, conciliação e reuniões financeiras.",
    },
    "contabilidade": {
        "label": "Contabilidade",
        "agent": "Agente Contábil",
        "goals": ["balancete", "fiscal", "conciliação", "obrigações", "relatórios"],
        "tools": ["erp", "database", "powerbi", "email", "calendar"],
        "calendar_policy": "Prazos fiscais, fechamentos e entregas.",
    },
    "recebimentos": {
        "label": "Recebimentos",
        "agent": "Agente Recebimentos",
        "goals": ["baixas", "inadimplência", "cobrança", "retornos bancários", "conciliação"],
        "tools": ["erp", "database", "crm", "whatsapp", "email", "calendar"],
        "calendar_policy": "Agenda de cobranças e acompanhamento de pendências.",
    },
    "almoxarifado": {
        "label": "Almoxarifado / Estoque",
        "agent": "Agente Almoxarifado",
        "goals": ["estoque", "ruptura", "requisição", "inventário", "compras"],
        "tools": ["erp", "database", "powerbi", "teams", "calendar"],
        "calendar_policy": "Inventários, recebimentos, contagens e alertas de ruptura.",
    },
    "bilhetagem": {
        "label": "Bilhetagem / Vale-Transporte",
        "agent": "Agente Bilhetagem",
        "goals": ["venda de passagens", "vale-transporte", "arrecadação", "recargas", "divergências"],
        "tools": ["erp", "database", "powerbi", "whatsapp", "teams", "calendar"],
        "calendar_policy": "Fechamento de bilhetagem, conciliações e pendências de vale-transporte.",
    },
    "ti_dba": {
        "label": "TI / DBA",
        "agent": "Agente TI/DBA",
        "goals": ["monitoramento", "incidentes", "performance", "banco de dados", "segurança"],
        "tools": ["zabbix", "grafana", "database", "teams", "slack", "n8n", "calendar"],
        "calendar_policy": "Janelas de manutenção, plantões, incidentes e mudanças.",
    },
    "dados_bi": {
        "label": "Dados / BI",
        "agent": "Agente Dados/BI",
        "goals": ["indicadores", "dashboards", "relatórios", "modelagem", "qualidade dos dados"],
        "tools": ["powerbi", "database", "erp", "grafana", "calendar"],
        "calendar_policy": "Atualizações de BI, entrega de relatórios e revisões de indicadores.",
    },
    "comercial": {
        "label": "Comercial / Vendas",
        "agent": "Agente Comercial",
        "goals": ["leads", "propostas", "CRM", "follow-up", "campanhas"],
        "tools": ["crm", "whatsapp", "telegram", "email", "calendar", "powerbi"],
        "calendar_policy": "Follow-ups, reuniões comerciais e pipeline.",
    },
    "atendimento": {
        "label": "Atendimento / SAC",
        "agent": "Agente Atendimento",
        "goals": ["mensagens", "tickets", "SLA", "triagem", "escalonamento"],
        "tools": ["whatsapp", "telegram", "teams", "slack", "email", "crm", "calendar"],
        "calendar_policy": "Escalas, retorno ao cliente e reuniões de atendimento.",
    },
    "diretoria": {
        "label": "Diretoria / Executivo",
        "agent": "Agente Executivo",
        "goals": ["resumo executivo", "risco", "prioridades", "resultados", "agenda"],
        "tools": ["powerbi", "erp", "crm", "zabbix", "grafana", "calendar", "teams"],
        "calendar_policy": "Agenda executiva, reuniões estratégicas e aprovações.",
    },
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for path, default in [
        (TOOLS_FILE, {"tools": []}),
        (TEAMS_FILE, {"teams": []}),
        (USERS_FILE, {"users": []}),
        (AGENDAS_FILE, {"agendas": []}),
        (TASKS_FILE, {"tasks": []}),
    ]:
        if not path.exists():
            path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def status() -> dict[str, Any]:
    tools = _load(TOOLS_FILE, {"tools": []}).get("tools", [])
    teams = _load(TEAMS_FILE, {"teams": []}).get("teams", [])
    users = _load(USERS_FILE, {"users": []}).get("users", [])
    tasks = _load(TASKS_FILE, {"tasks": []}).get("tasks", [])
    return {
        "ok": True,
        "name": "HAL Enterprise Integration & Team Intelligence",
        "description": "Camada corporativa para integrar ferramentas, criar times/agentes por setor, agendas pessoais/departamentais e colaboração multiagente em qualquer segmento.",
        "segments_supported": len(SEGMENTS),
        "tools_supported": len(TOOL_CATALOG),
        "department_templates": len(DEPARTMENT_TEMPLATES),
        "registered_tools": len(tools),
        "teams_count": len(teams),
        "users_count": len(users),
        "tasks_count": len(tasks),
        "capabilities": [
            "Integração com Power BI, Zabbix, Grafana, ERP, CRM, WhatsApp, Telegram, Teams, Slack, e-mail, calendários, n8n e bancos SQL/NoSQL",
            "Times multiagentes por setor",
            "Agenda por usuário, setor ou time",
            "Trabalho pessoal ou corporativo",
            "Roteamento por segmento e departamento",
            "Planejamento de tarefas com ferramenta correta",
            "Aprovação para ações sensíveis",
            "Atendimento a transporte, logística, financeiro, varejo/atacado, indústria, agro, bancos, fintechs, saúde, educação e qualquer empresa",
            "Entrada pela conversa natural do HAL sem botões obrigatórios",
        ],
    }


def catalog() -> dict[str, Any]:
    return {
        "ok": True,
        "segments": [{"key": k, **v} for k, v in SEGMENTS.items()],
        "tools": [{"key": k, **v} for k, v in TOOL_CATALOG.items()],
        "departments": [{"key": k, **v} for k, v in DEPARTMENT_TEMPLATES.items()],
    }


def register_tool(tool_key: str, name: str = "", env_prefix: str = "", owner_team: str = "", enabled: bool = True) -> dict[str, Any]:
    key = (tool_key or "").lower().strip()
    if key not in TOOL_CATALOG:
        return {"ok": False, "summary": "Ferramenta não suportada no catálogo.", "available": list(TOOL_CATALOG)}
    data = _load(TOOLS_FILE, {"tools": []})
    item = {
        "id": f"tool_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "tool_key": key,
        "name": name or TOOL_CATALOG[key]["label"],
        "category": TOOL_CATALOG[key]["category"],
        "env_prefix": env_prefix or f"HALL_{key.upper()}",
        "owner_team": owner_team,
        "enabled": enabled,
        "status": "registered",
        "required_env": [f"{env_prefix or 'HALL_' + key.upper()}_{x}" for x in TOOL_CATALOG[key]["auth"]],
        "capabilities": TOOL_CATALOG[key]["capabilities"],
        "safe_policy": TOOL_CATALOG[key]["safe_policy"],
        "created_at": _now(),
    }
    data.setdefault("tools", []).insert(0, item)
    _save(TOOLS_FILE, data)
    _audit({"event": "register_tool", "tool_key": key, "tool_id": item["id"]})
    return {"ok": True, "tool": item, "summary": f"Ferramenta {item['name']} registrada."}


def list_tools(category: str = "", limit: int = 100) -> dict[str, Any]:
    tools = _load(TOOLS_FILE, {"tools": []}).get("tools", [])
    if category:
        tools = [t for t in tools if t.get("category") == category]
    return {"ok": True, "tools": tools[:max(1, min(limit, 500))], "count": len(tools)}


def create_team(department_key: str, segment_key: str = "generico", name: str = "", users: list[str] | None = None, autonomy_level: int = 2) -> dict[str, Any]:
    dept = DEPARTMENT_TEMPLATES.get(department_key)
    if not dept:
        return {"ok": False, "summary": "Departamento não suportado.", "available": list(DEPARTMENT_TEMPLATES)}
    segment = SEGMENTS.get(segment_key, SEGMENTS["generico"])
    data = _load(TEAMS_FILE, {"teams": []})
    team = {
        "id": f"team_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "name": name or dept["label"],
        "department_key": department_key,
        "segment_key": segment_key,
        "segment_label": segment["label"],
        "agent": dept["agent"],
        "goals": dept["goals"],
        "tools": dept["tools"],
        "users": users or [],
        "autonomy_level": max(0, min(int(autonomy_level), 5)),
        "calendar_policy": dept["calendar_policy"],
        "approval_policy": approval_policy_for_level(autonomy_level),
        "created_at": _now(),
    }
    data.setdefault("teams", []).insert(0, team)
    _save(TEAMS_FILE, data)
    ensure_team_agenda(team)
    _audit({"event": "create_team", "team_id": team["id"], "department": department_key})
    return {"ok": True, "team": team, "summary": "Time multiagente criado."}


def approval_policy_for_level(level: int) -> dict[str, Any]:
    level = max(0, min(int(level), 5))
    return {
        "level": level,
        "description": [
            "Nível 0: só responde e orienta.",
            "Nível 1: sugere ações.",
            "Nível 2: executa consultas seguras.",
            "Nível 3: prepara ações e pede aprovação.",
            "Nível 4: executa rotinas agendadas autorizadas.",
            "Nível 5: opera 24x7 com supervisão, logs e auditoria.",
        ][level],
        "requires_approval_for": [
            "envio externo",
            "alteração em ERP/CRM",
            "baixa financeira",
            "cancelamento",
            "reembolso",
            "alteração de agenda de terceiros",
            "mudança em monitoramento/alertas",
            "publicação ou atualização crítica",
        ],
    }


def ensure_team_agenda(team: dict[str, Any]) -> dict[str, Any]:
    agendas = _load(AGENDAS_FILE, {"agendas": []})
    agenda = {
        "id": f"agenda_{team['id']}",
        "type": "team",
        "owner_id": team["id"],
        "owner_name": team["name"],
        "policy": team["calendar_policy"],
        "items": [],
        "created_at": _now(),
    }
    existing = next((a for a in agendas.get("agendas", []) if a.get("id") == agenda["id"]), None)
    if not existing:
        agendas.setdefault("agendas", []).insert(0, agenda)
        _save(AGENDAS_FILE, agendas)
    return agenda


def register_user(name: str, department_key: str = "", role: str = "", preferred_channels: list[str] | None = None, personal_mode: bool = True) -> dict[str, Any]:
    data = _load(USERS_FILE, {"users": []})
    user = {
        "id": f"user_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "name": name,
        "department_key": department_key,
        "role": role,
        "preferred_channels": preferred_channels or ["teams", "whatsapp", "email"],
        "personal_mode": personal_mode,
        "created_at": _now(),
        "assistant_scope": ["agenda", "mensagens", "tarefas", "relatórios", "resumos", "aprovações"],
    }
    data.setdefault("users", []).insert(0, user)
    _save(USERS_FILE, data)
    ensure_user_agenda(user)
    _audit({"event": "register_user", "user_id": user["id"]})
    return {"ok": True, "user": user, "summary": "Usuário registrado com agenda pessoal."}


def ensure_user_agenda(user: dict[str, Any]) -> dict[str, Any]:
    agendas = _load(AGENDAS_FILE, {"agendas": []})
    agenda = {
        "id": f"agenda_{user['id']}",
        "type": "personal",
        "owner_id": user["id"],
        "owner_name": user["name"],
        "policy": "Agenda pessoal: compromissos, follow-ups, lembretes e tarefas. Alterações exigem confirmação.",
        "items": [],
        "created_at": _now(),
    }
    existing = next((a for a in agendas.get("agendas", []) if a.get("id") == agenda["id"]), None)
    if not existing:
        agendas.setdefault("agendas", []).insert(0, agenda)
        _save(AGENDAS_FILE, agendas)
    return agenda


def list_teams(limit: int = 100) -> dict[str, Any]:
    teams = _load(TEAMS_FILE, {"teams": []}).get("teams", [])
    return {"ok": True, "teams": teams[:max(1, min(limit, 500))], "count": len(teams)}


def list_users(limit: int = 100) -> dict[str, Any]:
    users = _load(USERS_FILE, {"users": []}).get("users", [])
    return {"ok": True, "users": users[:max(1, min(limit, 500))], "count": len(users)}


def list_agendas(owner_type: str = "", limit: int = 100) -> dict[str, Any]:
    agendas = _load(AGENDAS_FILE, {"agendas": []}).get("agendas", [])
    if owner_type:
        agendas = [a for a in agendas if a.get("type") == owner_type]
    return {"ok": True, "agendas": agendas[:max(1, min(limit, 500))], "count": len(agendas)}


def infer_segment(message: str) -> str:
    low = (message or "").lower()
    for key, seg in SEGMENTS.items():
        if any(k in low for k in seg["keywords"]):
            return key
    return "generico"


def infer_department(message: str) -> str:
    low = (message or "").lower()
    for key, dept in DEPARTMENT_TEMPLATES.items():
        if key in low or any(g in low for g in dept["goals"]) or dept["label"].lower() in low:
            return key
    if any(x in low for x in ["almoxarifado", "estoque", "inventário", "inventario"]):
        return "almoxarifado"
    if any(x in low for x in ["recebimento", "recebimentos", "contas a receber"]):
        return "recebimentos"
    if any(x in low for x in ["bilhetagem", "passagem", "vale-transporte"]):
        return "bilhetagem"
    if any(x in low for x in ["zabbix", "grafana", "banco", "servidor", "incidente"]):
        return "ti_dba"
    return "diretoria"


def infer_tools(message: str, department_key: str = "") -> list[str]:
    low = (message or "").lower()
    selected = []
    for key, tool in TOOL_CATALOG.items():
        if any(k in low for k in tool["keywords"]):
            selected.append(key)
    if department_key and department_key in DEPARTMENT_TEMPLATES:
        for tool in DEPARTMENT_TEMPLATES[department_key]["tools"]:
            if tool not in selected:
                selected.append(tool)
    return selected or ["erp", "database", "calendar"]


def create_task_from_message(message: str, user_id: str = "", team_id: str = "", approved: bool = False) -> dict[str, Any]:
    segment_key = infer_segment(message)
    dept_key = infer_department(message)
    tools = infer_tools(message, dept_key)
    sensitive = is_sensitive(message)

    task = {
        "id": f"task_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "message": message,
        "segment_key": segment_key,
        "segment_label": SEGMENTS[segment_key]["label"],
        "department_key": dept_key,
        "department_label": DEPARTMENT_TEMPLATES[dept_key]["label"],
        "agent": DEPARTMENT_TEMPLATES[dept_key]["agent"],
        "tools": tools,
        "user_id": user_id,
        "team_id": team_id,
        "status": "waiting_approval" if sensitive and not approved else "planned",
        "approved": approved,
        "sensitive": sensitive,
        "created_at": _now(),
        "plan": build_task_plan(message, dept_key, tools, sensitive),
        "next_question": next_question_for_task(message, tools),
    }
    data = _load(TASKS_FILE, {"tasks": []})
    data.setdefault("tasks", []).insert(0, task)
    _save(TASKS_FILE, data)
    _audit({"event": "create_task", "task_id": task["id"], "department": dept_key, "tools": tools})
    return {"ok": True, "task": task, "answer": answer_for_task(task)}


def is_sensitive(message: str) -> bool:
    low = (message or "").lower()
    return any(x in low for x in [
        "enviar", "mandar", "alterar", "excluir", "cancelar", "baixar", "reembolsar",
        "bloquear", "desbloquear", "publicar", "atualizar dataset", "mudar alerta",
        "criar reunião", "criar reuniao", "agendar reunião", "agendar reuniao"
    ])


def build_task_plan(message: str, dept_key: str, tools: list[str], sensitive: bool) -> list[dict[str, Any]]:
    steps = [
        {"id": "understand_user_or_team", "label": "Identificar usuário, setor ou time responsável", "status": "pending"},
        {"id": "choose_department_agent", "label": f"Acionar {DEPARTMENT_TEMPLATES[dept_key]['agent']}", "status": "pending"},
        {"id": "select_tools", "label": "Selecionar ferramentas: " + ", ".join(TOOL_CATALOG[t]["label"] for t in tools if t in TOOL_CATALOG), "status": "pending"},
        {"id": "confirm_data_source", "label": "Confirmar fonte de dados, canal ou agenda", "status": "pending"},
        {"id": "execute_or_prepare", "label": "Executar consulta segura ou preparar ação", "status": "pending"},
        {"id": "deliver_result", "label": "Entregar resposta no formato adequado", "status": "pending"},
    ]
    if sensitive:
        steps.insert(4, {"id": "human_approval", "label": "Solicitar aprovação humana antes de ação sensível", "status": "waiting_approval", "requires_approval": True})
    return steps


def next_question_for_task(message: str, tools: list[str]) -> str:
    low = (message or "").lower()
    if "calendar" in tools or "agenda" in low:
        return "Essa agenda é pessoal, do setor ou de um time específico? Qual usuário/time devo considerar?"
    if "database" in tools or "erp" in tools:
        return "Qual sistema, banco, ERP, CRM ou fonte devo acessar para responder com precisão?"
    if any(t in tools for t in ["whatsapp", "telegram", "teams", "slack", "email"]):
        return "Qual canal devo usar e a mensagem deve ser apenas preparada ou enviada após sua aprovação?"
    if any(t in tools for t in ["powerbi", "zabbix", "grafana"]):
        return "Qual workspace, dashboard, host, alerta ou painel devo consultar?"
    return "Qual resultado você espera: resumo, tarefa, relatório, mensagem, agenda ou automação?"


def answer_for_task(task: dict[str, Any]) -> str:
    tools = ", ".join(TOOL_CATALOG[t]["label"] for t in task["tools"] if t in TOOL_CATALOG)
    base = (
        f"Entendi. Vou tratar isso como uma demanda de {task['department_label']} no segmento {task['segment_label']}. "
        f"O agente responsável será {task['agent']} e as ferramentas prováveis são: {tools}."
    )
    if task["sensitive"] and task["status"] == "waiting_approval":
        base += " Como pode envolver ação sensível, eu preparo tudo, mas só executo depois da sua aprovação."
    base += f"\n\nPara fazer com precisão: {task['next_question']}"
    return base


def list_tasks(limit: int = 100) -> dict[str, Any]:
    tasks = _load(TASKS_FILE, {"tasks": []}).get("tasks", [])
    return {"ok": True, "tasks": tasks[:max(1, min(limit, 500))], "count": len(tasks)}


def seed_enterprise() -> dict[str, Any]:
    created_tools = []
    for key in ["powerbi", "zabbix", "grafana", "erp", "crm", "whatsapp", "telegram", "teams", "email", "calendar", "n8n", "database"]:
        created_tools.append(register_tool(key, owner_team="corporativo")["tool"])
    created_teams = []
    for dept in ["diretoria", "financeiro", "contabilidade", "recebimentos", "almoxarifado", "bilhetagem", "ti_dba", "dados_bi", "comercial", "atendimento"]:
        created_teams.append(create_team(dept, "generico", autonomy_level=2)["team"])
    return {
        "ok": True,
        "tools": created_tools,
        "teams": created_teams,
        "summary": "Ambiente corporativo demo criado com ferramentas, times multiagentes e agendas.",
    }


def guided_answer(message: str, approved: bool = False) -> dict[str, Any]:
    result = create_task_from_message(message, approved=approved)
    return {
        "ok": True,
        "answer": result["answer"],
        "task": result["task"],
        "summary": "Demanda interpretada com inteligência de setor, usuário/time e ferramenta.",
    }


def answer_for_enterprise(message: str = "") -> str:
    return guided_answer(message).get("answer", "Vou usar a camada HAL Enterprise Integration & Team Intelligence.")
