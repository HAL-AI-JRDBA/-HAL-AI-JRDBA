from __future__ import annotations

import json
import os
import platform
import subprocess
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "enterprise_productization_v13"
SKILLS_DIR = DATA_DIR / "skills_library"
KNOWLEDGE_DIR = DATA_DIR / "knowledge_center"
FLEET_FILE = DATA_DIR / "agent_fleet_tasks.json"
WHITE_LABEL_FILE = DATA_DIR / "white_label_config.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"


INTEGRATIONS = [
    {"id": "github", "name": "GitHub", "env": ["GITHUB_TOKEN", "GITHUB_OWNER"], "purpose": "repos, commit, push, versionamento"},
    {"id": "vercel", "name": "Vercel", "env": ["VERCEL_TOKEN", "VERCEL_ORG_ID", "VERCEL_PROJECT_ID"], "purpose": "deploy web"},
    {"id": "supabase", "name": "Supabase", "env": ["SUPABASE_URL", "SUPABASE_SERVICE_KEY"], "purpose": "banco/postgres/auth/storage"},
    {"id": "stripe", "name": "Stripe", "env": ["STRIPE_SECRET_KEY", "STRIPE_WEBHOOK_SECRET"], "purpose": "assinaturas, cobrança, cobrança falhou"},
    {"id": "whatsapp", "name": "WhatsApp", "env": ["WHATSAPP_TOKEN", "WHATSAPP_PHONE_ID"], "purpose": "mensagens texto/voz"},
    {"id": "telegram", "name": "Telegram", "env": ["TELEGRAM_BOT_TOKEN"], "purpose": "bot e notificações"},
    {"id": "gmail", "name": "Gmail", "env": ["GOOGLE_APPLICATION_CREDENTIALS", "GMAIL_SENDER"], "purpose": "envio/leitura de e-mail"},
    {"id": "google_workspace", "name": "Google Workspace", "env": ["GOOGLE_APPLICATION_CREDENTIALS"], "purpose": "agenda, drive, gmail"},
    {"id": "slack", "name": "Slack", "env": ["SLACK_BOT_TOKEN", "SLACK_SIGNING_SECRET"], "purpose": "colaboração"},
    {"id": "discord", "name": "Discord", "env": ["DISCORD_BOT_TOKEN"], "purpose": "comunidade e agentes"},
    {"id": "n8n", "name": "n8n", "env": ["N8N_BASE_URL", "N8N_API_KEY"], "purpose": "workflows"},
    {"id": "notion", "name": "Notion", "env": ["NOTION_TOKEN"], "purpose": "bases e documentos"},
    {"id": "trello", "name": "Trello", "env": ["TRELLO_KEY", "TRELLO_TOKEN"], "purpose": "quadros e tarefas"},
    {"id": "linear", "name": "Linear", "env": ["LINEAR_API_KEY"], "purpose": "issues/produto"},
    {"id": "figma", "name": "Figma", "env": ["FIGMA_TOKEN"], "purpose": "design/briefing"},
    {"id": "openai", "name": "OpenAI API opcional", "env": ["OPENAI_API_KEY"], "purpose": "modelo cloud opcional"},
    {"id": "ollama", "name": "Ollama local", "env": ["OLLAMA_URL", "OLLAMA_MODEL"], "purpose": "modelo local"},
    {"id": "zabbix", "name": "Zabbix", "env": ["ZABBIX_URL", "ZABBIX_TOKEN"], "purpose": "monitoramento"},
    {"id": "grafana", "name": "Grafana", "env": ["GRAFANA_URL", "GRAFANA_TOKEN"], "purpose": "dashboards"},
    {"id": "powerbi", "name": "Power BI", "env": ["POWERBI_TENANT_ID", "POWERBI_CLIENT_ID", "POWERBI_CLIENT_SECRET"], "purpose": "BI corporativo"},
]


SKILL_CATEGORIES = {
    "marketing": [
        "briefing_de_campanha", "copy_para_anuncio", "calendario_editorial", "seo_basico", "analise_de_concorrentes",
        "criativo_para_rede_social", "landing_page_copy", "email_marketing", "segmentacao_de_publico", "analise_de_metricas"
    ],
    "vendas": [
        "qualificacao_de_leads", "followup_comercial", "proposta_comercial", "roteiro_de_reuniao", "crm_update",
        "recuperacao_de_oportunidade", "script_de_whatsapp", "objection_handling", "pipeline_forecast", "pos_venda"
    ],
    "atendimento": [
        "triagem_de_chamado", "resposta_humanizada", "base_de_conhecimento", "resumo_de_ticket", "classificacao_de_sentimento",
        "sla_alert", "handoff_humano", "faq_generator", "customer_success_checkin", "nps_analysis"
    ],
    "financeiro": [
        "dre_resumo", "fluxo_de_caixa", "contas_a_pagar", "contas_a_receber", "inadimplencia",
        "ebitda", "margem_liquidez", "budget_vs_realizado", "cobranca_falhou", "teto_custo_ia"
    ],
    "operacoes": [
        "monitoramento_estoque", "reposicao_com_aprovacao", "roteirizacao", "analise_sla_operacional", "checklist_rotina",
        "incidente_operacional", "almoxarifado", "bilhetagem", "logistica_entrega", "manutencao_preventiva"
    ],
    "rh_juridico_ti": [
        "triagem_curriculo", "descricao_de_vaga", "onboarding", "politica_interna", "contrato_basico",
        "lgpd_checklist", "suporte_ti", "inventario_ti", "controle_de_acessos", "relatorio_auditoria"
    ],
}


APP_TEMPLATES = [
    "financas_pessoais", "crm_vendas", "clinica_saude", "loja_varejo", "escola_cursos",
    "transporte_logistica", "estoque_almoxarifado", "helpdesk", "area_de_membros", "agendamento",
    "dashboard_executivo", "erp_financeiro", "contabilidade", "rh_recrutamento", "juridico_contratos",
    "imobiliaria", "delivery", "restaurante_cardapio", "oficina_mecanica", "academia",
    "agronegocio_safra", "industria_chao_de_fabrica", "banco_fintech", "seguros", "condominio",
    "hotel_pousada", "eventos", "igreja_ong", "consultoria", "marketing_agency",
    "marketplace", "ecommerce_b2b", "controle_frota", "vale_transporte", "venda_passagens",
    "farmacia", "laboratorio", "petshop", "barbearia_salao", "gestao_projetos",
    "notas_fiscais", "compras_suprimentos", "orcamentos", "assinaturas_saas", "portal_cliente",
]


AGENT_FLEET = [
    {"id": "agent_ceo", "name": "Agente Executivo", "area": "diretoria", "mission": "síntese executiva, prioridades, riscos e decisões"},
    {"id": "agent_cfo", "name": "Agente Financeiro", "area": "financeiro", "mission": "DRE, caixa, EBITDA, cobrança, custo de IA"},
    {"id": "agent_sales", "name": "Agente Comercial", "area": "vendas", "mission": "leads, CRM, follow-up, propostas"},
    {"id": "agent_marketing", "name": "Agente Marketing", "area": "marketing", "mission": "campanhas, copy, funil, conteúdo"},
    {"id": "agent_ops", "name": "Agente Operações", "area": "operações", "mission": "rotinas, SLA, estoque, logística"},
    {"id": "agent_support", "name": "Agente Atendimento", "area": "atendimento", "mission": "tickets, FAQ, resposta humanizada"},
    {"id": "agent_hr", "name": "Agente RH", "area": "rh", "mission": "vagas, triagem, onboarding"},
    {"id": "agent_legal", "name": "Agente Jurídico", "area": "jurídico", "mission": "contratos, LGPD, políticas"},
    {"id": "agent_it", "name": "Agente TI", "area": "ti", "mission": "acessos, incidentes, infraestrutura"},
    {"id": "agent_bi", "name": "Agente Dados/BI", "area": "dados", "mission": "consultas, dashboards, Power BI, Grafana"},
    {"id": "agent_app_factory", "name": "Agente App Factory", "area": "produto", "mission": "criar sistemas completos, testar, preparar deploy"},
    {"id": "agent_rag", "name": "Agente Knowledge/RAG", "area": "conhecimento", "mission": "indexar documentos, responder com fontes"},
]


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    KNOWLEDGE_DIR.mkdir(parents=True, exist_ok=True)
    if not FLEET_FILE.exists():
        FLEET_FILE.write_text(json.dumps({"tasks": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not WHITE_LABEL_FILE.exists():
        WHITE_LABEL_FILE.write_text(json.dumps({
            "brand": "AJDS",
            "product_name": "HAL",
            "white_label_enabled": True,
            "client_portal_enabled": True,
            "plans": [
                {"id": "pilot", "name": "Piloto", "monthly_price": 0, "ia_cost_limit": 150},
                {"id": "business", "name": "Business", "monthly_price": 1490, "ia_cost_limit": 750},
                {"id": "enterprise", "name": "Enterprise", "monthly_price": 4990, "ia_cost_limit": 2500},
            ],
            "billing_alerts": {"failed_payment": True, "cost_ceiling": True, "human_approval_required": True},
        }, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def _cmd_ok(cmd: list[str], timeout: int = 5) -> dict[str, Any]:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return {"ok": p.returncode == 0, "returncode": p.returncode, "stdout": (p.stdout or "")[:1000], "stderr": (p.stderr or "")[:1000]}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}


def integration_status() -> dict[str, Any]:
    items = []
    for it in INTEGRATIONS:
        configured = [k for k in it["env"] if os.getenv(k)]
        missing = [k for k in it["env"] if not os.getenv(k)]
        items.append({**it, "configured": bool(configured) and not missing, "configured_env": configured, "missing_env": missing})
    return {"ok": True, "integrations": items, "configured_count": sum(1 for x in items if x["configured"]), "total": len(items)}


def platform_health() -> dict[str, Any]:
    _ensure()
    checks: dict[str, Any] = {}
    checks["python"] = {"ok": True, "version": platform.python_version(), "platform": platform.platform()}
    checks["ollama"] = _cmd_ok(["ollama", "list"], timeout=6)
    checks["git"] = _cmd_ok(["git", "--version"], timeout=5)
    checks["docker"] = _cmd_ok(["docker", "--version"], timeout=5)
    try:
        from app.services import local_stt_fallback
        checks["stt"] = local_stt_fallback.status()
    except Exception as exc:
        checks["stt"] = {"ok": False, "error": str(exc)}
    try:
        from app.services import app_factory_pro
        checks["app_factory"] = app_factory_pro.status()
    except Exception as exc:
        checks["app_factory"] = {"ok": False, "error": str(exc)}
    try:
        from app.services import human_conversation_gateway
        checks["conversation"] = human_conversation_gateway.status()
    except Exception as exc:
        checks["conversation"] = {"ok": False, "error": str(exc)}
    integrations = integration_status()
    ok_count = sum(1 for v in checks.values() if isinstance(v, dict) and v.get("ok"))
    return {
        "ok": True,
        "name": "HAL Enterprise Productization V13",
        "summary": "Observabilidade, catálogo, integrações, qualidade, frota de agentes, RAG, white-label e deploy assistido.",
        "checks": checks,
        "integrations": integrations,
        "score": round((ok_count / max(1, len(checks))) * 100, 2),
        "data_dir": str(DATA_DIR),
    }


def status() -> dict[str, Any]:
    health = platform_health()
    return {
        "ok": True,
        "version": "13.0",
        "name": "HAL Enterprise Productization V13",
        "health_score": health["score"],
        "capabilities": [
            "Painel de saúde da plataforma",
            "Roteador com testes automáticos",
            "Biblioteca de 60 Skills",
            "App Factory com 45 templates",
            "Catálogo de integrações reais configuráveis",
            "Deploy assistido local/Docker/VPS/Vercel/Supabase",
            "Quality Gate global",
            "Agent Fleet Manager 24/7",
            "Knowledge/RAG Center local",
            "Modo venda white-label",
        ],
    }


def skills_library(seed: bool = False) -> dict[str, Any]:
    _ensure()
    skills = []
    for category, names in SKILL_CATEGORIES.items():
        for name in names:
            skill = {
                "id": f"{category}.{name}",
                "category": category,
                "name": name.replace("_", " ").title(),
                "format": "markdown",
                "risk": "approval_required" if any(x in name for x in ["cobranca", "reposicao", "controle_de_acessos"]) else "low",
                "local_first": True,
            }
            skills.append(skill)
            if seed:
                path = SKILLS_DIR / f"{skill['id'].replace('.', '__')}.md"
                path.write_text(
                    f"# {skill['name']}\n\nCategoria: {category}\n\nObjetivo: executar a rotina `{name}` com auditoria, contexto empresarial e aprovação quando necessário.\n\n## Entradas\n\n- Pedido do usuário\n- Fonte de dados autorizada\n- Política de aprovação\n\n## Saída\n\n- Resposta natural\n- Ação proposta\n- Log de auditoria\n",
                    encoding="utf-8",
                )
    return {"ok": True, "count": len(skills), "skills": skills, "seeded": seed, "skills_dir": str(SKILLS_DIR)}


def template_bank() -> dict[str, Any]:
    templates = []
    for i, tid in enumerate(APP_TEMPLATES, 1):
        templates.append({
            "id": tid,
            "name": tid.replace("_", " ").title(),
            "features": ["login", "dashboard", "crud", "filtros", "cálculos", "estado vazio", "configurações", "exportação CSV"],
            "quality_gate": ["navegação", "filtros", "cálculos", "estado vazio", "formulários"],
            "white_label": True,
            "deploy": ["local", "docker", "vps", "vercel/supabase opcional"],
            "rank": i,
        })
    return {"ok": True, "count": len(templates), "templates": templates}


def router_test_suite(run: bool = True) -> dict[str, Any]:
    cases = [
        ("Eu quero um software para controlar minhas finanças pessoais", "app_factory"),
        ("Crie um sistema completo com login, filtros e deploy", "app_factory"),
        ("Acredito que você não está me ouvindo", "conversation_repair"),
        ("Agora me explica buracos negros e horizonte de eventos", "science_space"),
        ("Me recomenda um cardápio para almoço", "food_lunch"),
        ("Qual é o EBITDA da empresa?", "executive_finance"),
        ("Consulte o MongoDB de vendas", "database"),
        ("Envie essa resposta por WhatsApp", "omnichannel"),
        ("Crie uma skill de follow-up comercial", "skills_center"),
        ("Configure agentes 24/7 para vendas e financeiro", "enterprise_productization"),
    ]
    results = []
    if run:
        try:
            from app.services import human_conversation_gateway
            for prompt, expected in cases:
                r = human_conversation_gateway.converse(prompt, run_tools=True)
                got = r.get("classification", {}).get("intent")
                results.append({"prompt": prompt, "expected": expected, "got": got, "ok": got == expected or (expected == "app_factory" and got in {"app_factory", "software_builder"})})
        except Exception as exc:
            results.append({"ok": False, "error": str(exc)})
    else:
        results = [{"prompt": p, "expected": e, "ok": None} for p, e in cases]
    passed = sum(1 for r in results if r.get("ok") is True)
    return {"ok": True, "passed": passed, "total": len(results), "score": round(passed / max(1, len(results)) * 100, 2), "results": results}


def global_quality_gate() -> dict[str, Any]:
    _ensure()
    checks = []
    health = platform_health()
    checks.append({"name": "platform_health", "ok": health["score"] >= 40, "score": health["score"]})
    rt = router_test_suite(run=True)
    checks.append({"name": "router_tests", "ok": rt["score"] >= 70, "score": rt["score"], "details": rt["results"]})
    skills = skills_library(seed=False)
    checks.append({"name": "skills_library_50_plus", "ok": skills["count"] >= 50, "count": skills["count"]})
    templates = template_bank()
    checks.append({"name": "template_bank_40_plus", "ok": templates["count"] >= 40, "count": templates["count"]})
    integrations = integration_status()
    checks.append({"name": "integration_catalog_20_plus", "ok": integrations["total"] >= 20, "configured": integrations["configured_count"], "total": integrations["total"]})
    try:
        from app.services import app_factory_pro
        generated = app_factory_pro.generate_app("Sistema de teste com login, filtros, cálculos e estado vazio", app_name="quality_gate_v13", template_id="financas_pessoais")
        qg = app_factory_pro.run_quality_gate(generated.get("path", ""))
        checks.append({"name": "generated_app_quality_gate", "ok": bool(qg.get("ok")), "details": qg})
    except Exception as exc:
        checks.append({"name": "generated_app_quality_gate", "ok": False, "error": str(exc)})

    passed = sum(1 for c in checks if c.get("ok") is True)
    return {"ok": True, "passed": passed, "total": len(checks), "score": round(passed / max(1, len(checks)) * 100, 2), "checks": checks}


def fleet_status() -> dict[str, Any]:
    _ensure()
    data = json.loads(FLEET_FILE.read_text(encoding="utf-8-sig"))
    tasks = data.get("tasks", [])
    return {
        "ok": True,
        "agents": AGENT_FLEET,
        "agents_count": len(AGENT_FLEET),
        "tasks": tasks[:100],
        "tasks_count": len(tasks),
        "pending_approval": [t for t in tasks if t.get("status") == "awaiting_approval"],
    }


def create_fleet_task(agent_id: str, instruction: str, schedule: str = "", approval_required: bool = True) -> dict[str, Any]:
    _ensure()
    data = json.loads(FLEET_FILE.read_text(encoding="utf-8-sig"))
    task = {
        "id": f"task_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "agent_id": agent_id,
        "instruction": instruction,
        "schedule": schedule,
        "approval_required": approval_required,
        "status": "awaiting_approval" if approval_required else "queued",
        "created_at": _now(),
        "audit": [],
    }
    data.setdefault("tasks", []).insert(0, task)
    FLEET_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    _audit({"event": "create_fleet_task", "task_id": task["id"], "agent_id": agent_id})
    return {"ok": True, "task": task}


def approve_fleet_task(task_id: str, approved: bool = True) -> dict[str, Any]:
    _ensure()
    data = json.loads(FLEET_FILE.read_text(encoding="utf-8-sig"))
    for task in data.get("tasks", []):
        if task.get("id") == task_id:
            task["status"] = "queued" if approved else "rejected"
            task.setdefault("audit", []).append({"ts": _now(), "approved": approved})
            FLEET_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            _audit({"event": "approve_fleet_task", "task_id": task_id, "approved": approved})
            return {"ok": True, "task": task}
    return {"ok": False, "error": "task_not_found", "task_id": task_id}


def ingest_knowledge(title: str, text: str, source: str = "manual") -> dict[str, Any]:
    _ensure()
    doc_id = f"doc_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    path = KNOWLEDGE_DIR / f"{doc_id}.json"
    words = [w.strip(".,;:!?()[]{}").lower() for w in (text or "").split()]
    doc = {"id": doc_id, "title": title, "text": text, "source": source, "created_at": _now(), "tokens": len(words)}
    path.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    _audit({"event": "ingest_knowledge", "doc_id": doc_id, "title": title})
    return {"ok": True, "doc": doc, "path": str(path)}


def list_knowledge() -> dict[str, Any]:
    _ensure()
    docs = []
    for p in sorted(KNOWLEDGE_DIR.glob("*.json"), reverse=True):
        try:
            d = json.loads(p.read_text(encoding="utf-8-sig"))
            docs.append({k: d.get(k) for k in ["id", "title", "source", "created_at", "tokens"]})
        except Exception:
            pass
    return {"ok": True, "count": len(docs), "docs": docs}


def search_knowledge(query: str, limit: int = 10) -> dict[str, Any]:
    _ensure()
    qwords = set(w.strip(".,;:!?()[]{}").lower() for w in (query or "").split() if len(w) > 2)
    hits = []
    for p in KNOWLEDGE_DIR.glob("*.json"):
        try:
            d = json.loads(p.read_text(encoding="utf-8-sig"))
            text = (d.get("title", "") + " " + d.get("text", "")).lower()
            score = sum(1 for w in qwords if w in text)
            if score:
                hits.append({"score": score, "id": d.get("id"), "title": d.get("title"), "source": d.get("source"), "excerpt": d.get("text", "")[:500]})
        except Exception:
            pass
    hits.sort(key=lambda x: x["score"], reverse=True)
    return {"ok": True, "query": query, "hits": hits[:limit]}


def white_label_config(changes: dict[str, Any] | None = None) -> dict[str, Any]:
    _ensure()
    cfg = json.loads(WHITE_LABEL_FILE.read_text(encoding="utf-8-sig"))
    if changes:
        cfg.update(changes)
        WHITE_LABEL_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        _audit({"event": "white_label_config_update", "changes": changes})
    return {"ok": True, "config": cfg}


def deploy_plan(target: str = "local", app_path: str = "") -> dict[str, Any]:
    target = (target or "local").lower()
    common = ["rodar quality gate", "validar variáveis de ambiente", "gerar backup", "registrar auditoria"]
    plans = {
        "local": common + ["executar BAT/uvicorn local", "abrir preview local"],
        "docker": common + ["docker build", "docker compose up -d", "healthcheck HTTP"],
        "vps": common + ["copiar artefatos", "subir Docker/serviço systemd", "configurar proxy/SSL"],
        "vercel": common + ["validar VERCEL_TOKEN", "criar projeto", "deploy", "registrar URL"],
        "supabase": common + ["validar SUPABASE_URL", "migrar schema", "configurar storage/auth"],
    }
    return {
        "ok": True,
        "target": target,
        "app_path": app_path,
        "steps": plans.get(target, plans["local"]),
        "ready_to_execute": False,
        "reason": "Plano gerado. Execução real exige credenciais e aprovação explícita.",
    }


def github_manifest(repo_name: str, app_path: str = "", private: bool = True) -> dict[str, Any]:
    return {
        "ok": True,
        "repo_name": repo_name,
        "app_path": app_path,
        "private": private,
        "requires_env": ["GITHUB_TOKEN", "GITHUB_OWNER"],
        "commands": [
            "git init",
            "git add .",
            "git commit -m \"initial app generated by HAL\"",
            "gh repo create <owner>/<repo> --private --source=. --push",
        ],
        "ready_to_execute": bool(os.getenv("GITHUB_TOKEN") and os.getenv("GITHUB_OWNER")),
    }


def answer_for_enterprise_productization(message: str = "") -> str:
    return (
        "Perfeito. Isso entra na camada HAL Enterprise Productization V13. "
        "Ela transforma o projeto em produto comercial mais robusto: saúde da plataforma, testes automáticos de roteamento, "
        "biblioteca de 60 Skills, App Factory com 45 templates, integrações configuráveis, deploy assistido, quality gate global, "
        "frota de agentes 24/7, Knowledge/RAG Center e modo venda white-label com planos, limites de custo e alertas de cobrança."
    )
