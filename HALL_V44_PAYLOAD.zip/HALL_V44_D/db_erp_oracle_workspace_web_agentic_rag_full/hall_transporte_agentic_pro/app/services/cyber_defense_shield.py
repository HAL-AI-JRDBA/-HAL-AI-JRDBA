from __future__ import annotations

import hashlib
import json
import math
import os
import re
import time
import uuid
import zipfile
from pathlib import Path
from typing import Any

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "cyber_defense_shield"
QUARANTINE_DIR = DATA_DIR / "quarantine"
BASELINE_FILE = DATA_DIR / "file_baseline.json"
CONFIG_FILE = DATA_DIR / "config.json"
ALERTS_FILE = DATA_DIR / "alerts.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"

RANSOMWARE_EXTENSIONS = {
    ".locked", ".encrypted", ".crypted", ".crypt", ".enc", ".lock", ".pay", ".payme", ".ransom",
    ".ryuk", ".lockbit", ".blackcat", ".akira", ".play", ".conti", ".revil", ".wannacry", ".wcry"
}

DANGEROUS_ATTACHMENT_EXTENSIONS = {
    ".exe", ".scr", ".pif", ".bat", ".cmd", ".com", ".js", ".jse", ".vbs", ".vbe", ".ps1",
    ".hta", ".msi", ".dll", ".lnk", ".iso", ".img", ".jar", ".reg"
}

MACRO_ATTACHMENT_EXTENSIONS = {".docm", ".xlsm", ".pptm", ".xlam", ".dotm"}
ARCHIVE_EXTENSIONS = {".zip", ".rar", ".7z", ".gz", ".tar", ".iso", ".img"}

DEFAULT_CONFIG = {
    "enabled": True,
    "mode": "defensive_monitoring_only",
    "monitored_paths": [],
    "backup_paths": [],
    "quarantine_path": str(QUARANTINE_DIR),
    "canary_enabled": True,
    "canary_filename": ".hall_canary_do_not_modify.txt",
    "max_files_per_scan": 5000,
    "ransomware_extensions": sorted(RANSOMWARE_EXTENSIONS),
    "rapid_change_threshold": 100,
    "high_entropy_threshold": 7.2,
    "email_attachment_policy": {
        "block_dangerous_executables": True,
        "flag_macros": True,
        "flag_archives": True,
        "quarantine_unknown_executable": True,
    },
    "network_policy": {
        "recommend_segmentation": True,
        "recommend_disable_unnecessary_rdp": True,
        "recommend_mfa": True,
        "recommend_least_privilege": True,
    },
    "response_policy": {
        "auto_isolate_host": False,
        "require_human_approval": True,
        "never_delete_files_automatically": True,
        "never_execute_untrusted_attachment": True,
    },
    "integrations": {
        "microsoft_defender": {"enabled": False, "env": ["DEFENDER_TENANT_ID", "DEFENDER_CLIENT_ID", "DEFENDER_CLIENT_SECRET"]},
        "windows_event_log": {"enabled": True, "env": []},
        "sysmon": {"enabled": False, "env": []},
        "wazuh": {"enabled": False, "env": ["WAZUH_URL", "WAZUH_TOKEN"]},
        "elastic": {"enabled": False, "env": ["ELASTIC_URL", "ELASTIC_API_KEY"]},
        "splunk": {"enabled": False, "env": ["SPLUNK_URL", "SPLUNK_TOKEN"]},
        "sentinelone": {"enabled": False, "env": ["SENTINELONE_URL", "SENTINELONE_TOKEN"]},
        "crowdstrike": {"enabled": False, "env": ["CROWDSTRIKE_CLIENT_ID", "CROWDSTRIKE_CLIENT_SECRET"]},
        "virustotal": {"enabled": False, "env": ["VIRUSTOTAL_API_KEY"]},
        "zabbix": {"enabled": False, "env": ["ZABBIX_URL", "ZABBIX_TOKEN"]},
        "grafana": {"enabled": False, "env": ["GRAFANA_URL", "GRAFANA_TOKEN"]},
        "email_gateway": {"enabled": False, "env": ["EMAIL_SECURITY_GATEWAY_URL", "EMAIL_SECURITY_GATEWAY_TOKEN"]},
    }
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    QUARANTINE_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text(json.dumps(DEFAULT_CONFIG, ensure_ascii=False, indent=2), encoding="utf-8")
    if not ALERTS_FILE.exists():
        ALERTS_FILE.write_text(json.dumps({"alerts": []}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def load_config() -> dict[str, Any]:
    _ensure()
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8-sig"))
    except Exception:
        return DEFAULT_CONFIG.copy()


def configure(changes: dict[str, Any] | None = None) -> dict[str, Any]:
    cfg = load_config()
    for k, v in (changes or {}).items():
        cfg[k] = v
    CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    _audit({"event": "configure", "changes": changes or {}})
    return {"ok": True, "config": cfg}


def status() -> dict[str, Any]:
    cfg = load_config()
    integrations = integration_status()
    return {
        "ok": True,
        "name": "HAL Cyber Defense & Ransomware Shield V14",
        "description": "Camada defensiva para reduzir risco de invasão, phishing, malware e ransomware em servidores/desktops.",
        "mode": cfg.get("mode"),
        "enabled": cfg.get("enabled", True),
        "monitored_paths_count": len(cfg.get("monitored_paths", [])),
        "backup_paths_count": len(cfg.get("backup_paths", [])),
        "integrations_configured": integrations["configured_count"],
        "integrations_total": integrations["total"],
        "capabilities": [
            "triagem defensiva de anexos de e-mail",
            "detecção de extensões típicas de ransomware",
            "canary files para alerta de criptografia/alteração indevida",
            "baseline e comparação de arquivos",
            "detecção de alterações em massa",
            "alertas e playbooks de resposta",
            "verificação de prontidão de backup",
            "catálogo de integrações EDR/SIEM/monitoramento",
            "recomendações de segmentação, MFA e menor privilégio",
            "sem execução de anexos e sem ações destrutivas automáticas",
        ],
    }


def integration_status() -> dict[str, Any]:
    cfg = load_config()
    integrations = cfg.get("integrations", DEFAULT_CONFIG["integrations"])
    items = []
    for iid, meta in integrations.items():
        envs = meta.get("env", [])
        configured_env = [e for e in envs if os.getenv(e)]
        missing = [e for e in envs if not os.getenv(e)]
        configured = bool(meta.get("enabled")) and not missing
        items.append({
            "id": iid,
            "enabled": bool(meta.get("enabled")),
            "configured": configured,
            "configured_env": configured_env,
            "missing_env": missing,
        })
    return {"ok": True, "items": items, "configured_count": sum(1 for i in items if i["configured"]), "total": len(items)}


def _file_hash(path: Path, max_bytes: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        remaining = max_bytes
        while remaining > 0:
            chunk = f.read(min(65536, remaining))
            if not chunk:
                break
            h.update(chunk)
            remaining -= len(chunk)
    return h.hexdigest()


def _entropy(path: Path, max_bytes: int = 128 * 1024) -> float:
    try:
        data = path.read_bytes()[:max_bytes]
    except Exception:
        return 0.0
    if not data:
        return 0.0
    counts = [0] * 256
    for b in data:
        counts[b] += 1
    ent = 0.0
    n = len(data)
    for c in counts:
        if c:
            p = c / n
            ent -= p * math.log2(p)
    return round(ent, 3)


def _iter_files(paths: list[str], max_files: int = 5000):
    seen = 0
    for raw in paths:
        base = Path(raw).expanduser()
        if not base.exists():
            continue
        if base.is_file():
            yield base
            seen += 1
        else:
            for p in base.rglob("*"):
                if seen >= max_files:
                    return
                if p.is_file():
                    yield p
                    seen += 1


def deploy_canaries(paths: list[str] | None = None) -> dict[str, Any]:
    cfg = load_config()
    paths = paths or cfg.get("monitored_paths", [])
    canary_name = cfg.get("canary_filename", ".hall_canary_do_not_modify.txt")
    created = []
    errors = []
    for raw in paths:
        base = Path(raw).expanduser()
        try:
            if base.exists() and base.is_dir():
                c = base / canary_name
                if not c.exists():
                    c.write_text("HAL CANARY FILE - do not modify. Used for ransomware/integrity monitoring.\n", encoding="utf-8")
                created.append(str(c))
        except Exception as exc:
            errors.append({"path": raw, "error": str(exc)})
    _audit({"event": "deploy_canaries", "created": len(created), "errors": errors})
    return {"ok": True, "created": created, "errors": errors}


def create_baseline(paths: list[str] | None = None) -> dict[str, Any]:
    cfg = load_config()
    paths = paths or cfg.get("monitored_paths", [])
    max_files = int(cfg.get("max_files_per_scan", 5000))
    records = {}
    for p in _iter_files(paths, max_files=max_files):
        try:
            st = p.stat()
            records[str(p)] = {"size": st.st_size, "mtime": st.st_mtime, "ext": p.suffix.lower(), "hash": _file_hash(p)}
        except Exception:
            pass
    baseline = {"created_at": _now(), "paths": paths, "files": records}
    BASELINE_FILE.write_text(json.dumps(baseline, ensure_ascii=False, indent=2), encoding="utf-8")
    _audit({"event": "create_baseline", "files": len(records)})
    return {"ok": True, "files": len(records), "baseline_file": str(BASELINE_FILE)}


def scan_files(paths: list[str] | None = None) -> dict[str, Any]:
    cfg = load_config()
    paths = paths or cfg.get("monitored_paths", [])
    max_files = int(cfg.get("max_files_per_scan", 5000))
    ransomware_exts = set(str(x).lower() for x in cfg.get("ransomware_extensions", sorted(RANSOMWARE_EXTENSIONS)))
    high_entropy_threshold = float(cfg.get("high_entropy_threshold", 7.2))
    findings = []
    scanned = 0
    for p in _iter_files(paths, max_files=max_files):
        scanned += 1
        reasons = []
        ext = p.suffix.lower()
        if ext in ransomware_exts:
            reasons.append(f"extensão suspeita de ransomware: {ext}")
        name_low = p.name.lower()
        if any(x in name_low for x in ["readme", "decrypt", "restore", "ransom", "how_to_decrypt"]):
            reasons.append("nome se parece com nota de resgate/recuperação")
        try:
            if p.stat().st_size > 0 and ext not in {".jpg", ".png", ".zip", ".7z", ".gz", ".mp4", ".pdf"}:
                ent = _entropy(p)
                if ent >= high_entropy_threshold:
                    reasons.append(f"entropia alta ({ent}) em arquivo não esperado")
        except Exception:
            pass
        if reasons:
            findings.append({"path": str(p), "reasons": reasons, "severity": "high" if ext in ransomware_exts else "medium"})

    comparison = compare_baseline(paths)
    if comparison.get("rapid_change_detected"):
        findings.append({
            "path": "baseline",
            "reasons": [f"alteração em massa detectada: {comparison.get('changed_count')} arquivos alterados/novos/removidos"],
            "severity": "critical",
        })

    alert = None
    if findings:
        alert = add_alert("ransomware_or_integrity_suspicion", "high" if len(findings) < 5 else "critical", findings[:50])
    return {"ok": True, "scanned": scanned, "findings": findings[:500], "findings_count": len(findings), "baseline": comparison, "alert": alert}


def compare_baseline(paths: list[str] | None = None) -> dict[str, Any]:
    cfg = load_config()
    threshold = int(cfg.get("rapid_change_threshold", 100))
    if not BASELINE_FILE.exists():
        return {"ok": False, "error": "baseline_not_found", "rapid_change_detected": False}
    try:
        baseline = json.loads(BASELINE_FILE.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        return {"ok": False, "error": str(exc), "rapid_change_detected": False}
    old = baseline.get("files", {})
    paths = paths or baseline.get("paths", []) or cfg.get("monitored_paths", [])
    now = {}
    for p in _iter_files(paths, max_files=int(cfg.get("max_files_per_scan", 5000))):
        try:
            st = p.stat()
            now[str(p)] = {"size": st.st_size, "mtime": st.st_mtime, "ext": p.suffix.lower()}
        except Exception:
            pass
    removed = [p for p in old if p not in now]
    added = [p for p in now if p not in old]
    changed = []
    for p, meta in now.items():
        if p in old and (meta.get("size") != old[p].get("size") or abs(meta.get("mtime", 0) - old[p].get("mtime", 0)) > 1):
            changed.append(p)
    changed_count = len(removed) + len(added) + len(changed)
    return {
        "ok": True,
        "baseline_created_at": baseline.get("created_at"),
        "removed_count": len(removed),
        "added_count": len(added),
        "changed_count": changed_count,
        "rapid_change_detected": changed_count >= threshold,
        "sample": {"removed": removed[:10], "added": added[:10], "changed": changed[:10]},
    }


def analyze_email(payload: dict[str, Any]) -> dict[str, Any]:
    subject = str(payload.get("subject", ""))
    sender = str(payload.get("sender", ""))
    body = str(payload.get("body", ""))
    attachments = payload.get("attachments", []) or []
    reasons = []
    risk = 0

    text = f"{subject} {sender} {body}".lower()
    if any(x in text for x in ["urgente", "boleto", "fatura", "senha", "bloqueio", "pix", "pagamento vencido", "clique aqui", "atualizar cadastro"]):
        risk += 15
        reasons.append("linguagem típica de engenharia social/phishing")
    if re.search(r"https?://[^\s]+", text) and any(x in text for x in ["login", "senha", "atualizar", "validar", "bloqueio"]):
        risk += 20
        reasons.append("link com pedido de login/validação")

    attachment_results = []
    for att in attachments:
        name = str(att.get("filename") or att.get("name") or "")
        ext = Path(name).suffix.lower()
        a_reasons = []
        a_risk = 0
        if ext in DANGEROUS_ATTACHMENT_EXTENSIONS:
            a_risk += 50
            a_reasons.append(f"anexo executável/script perigoso: {ext}")
        if ext in MACRO_ATTACHMENT_EXTENSIONS:
            a_risk += 35
            a_reasons.append(f"documento com macro: {ext}")
        if ext in ARCHIVE_EXTENSIONS:
            a_risk += 20
            a_reasons.append(f"arquivo compactado/imagem que pode ocultar payload: {ext}")
        if re.search(r"\.(pdf|docx|xlsx)\.(exe|scr|js|vbs|ps1)$", name.lower()):
            a_risk += 60
            a_reasons.append("dupla extensão tentando se passar por documento")
        risk += a_risk
        attachment_results.append({"filename": name, "ext": ext, "risk": a_risk, "reasons": a_reasons})

    risk = min(risk, 100)
    if risk >= 70:
        action = "bloquear/quarentenar e acionar segurança"
        severity = "critical"
    elif risk >= 40:
        action = "quarentenar e revisar manualmente"
        severity = "high"
    elif risk >= 20:
        action = "alertar usuário e validar origem"
        severity = "medium"
    else:
        action = "permitir com cautela"
        severity = "low"

    result = {
        "ok": True,
        "risk_score": risk,
        "severity": severity,
        "recommended_action": action,
        "reasons": reasons,
        "attachments": attachment_results,
        "sender": sender,
        "subject": subject,
    }
    if risk >= 40:
        result["alert"] = add_alert("suspicious_email_attachment", severity, result)
    _audit({"event": "analyze_email", "risk": risk, "subject": subject})
    return result


def backup_readiness() -> dict[str, Any]:
    cfg = load_config()
    paths = cfg.get("backup_paths", [])
    items = []
    for raw in paths:
        p = Path(raw).expanduser()
        items.append({"path": raw, "exists": p.exists(), "is_dir": p.is_dir() if p.exists() else False})
    score = 20
    if paths:
        score += 30
    if any(x.get("exists") for x in items):
        score += 20
    if cfg.get("response_policy", {}).get("never_delete_files_automatically", True):
        score += 10
    if cfg.get("network_policy", {}).get("recommend_segmentation", True):
        score += 10
    score = min(score, 100)
    return {
        "ok": True,
        "score": score,
        "backup_paths": items,
        "recommendations": [
            "manter backup offline ou imutável",
            "testar restauração regularmente",
            "separar credenciais de backup das credenciais de usuários comuns",
            "monitorar alteração em massa de arquivos de backup",
            "não manter o único backup montado permanentemente na mesma rede",
        ],
    }


def security_posture() -> dict[str, Any]:
    cfg = load_config()
    checks = [
        {"control": "MFA em e-mail/VPN/administradores", "status": "recommended", "priority": "critical"},
        {"control": "EDR/Antivírus gerenciado em endpoints e servidores", "status": "recommended", "priority": "critical"},
        {"control": "Backup offline/imutável e restauração testada", "status": "check", "priority": "critical", "score": backup_readiness()["score"]},
        {"control": "Segmentação de rede e menor privilégio", "status": "recommended", "priority": "high"},
        {"control": "Bloqueio de macros e anexos executáveis por e-mail", "status": "configured_in_hall_policy", "priority": "high"},
        {"control": "Logs centralizados/SIEM", "status": "recommended", "priority": "high"},
        {"control": "Canary files e baseline de integridade", "status": "available", "priority": "medium"},
        {"control": "Plano de resposta a incidente", "status": "available", "priority": "critical"},
    ]
    return {"ok": True, "checks": checks, "integrations": integration_status(), "config": cfg}


def incident_playbook(scenario: str = "ransomware") -> dict[str, Any]:
    steps = [
        "Não desligar todos os equipamentos sem orientação; preservar evidências quando possível.",
        "Isolar máquinas suspeitas da rede de forma controlada.",
        "Bloquear credenciais comprometidas e sessões ativas.",
        "Interromper compartilhamentos afetados e acessos laterais.",
        "Acionar equipe de TI/segurança, diretoria e jurídico/LGPD conforme impacto.",
        "Identificar paciente zero: e-mail, anexo, RDP/VPN, credencial, vulnerabilidade ou terceiro.",
        "Verificar backups offline/imutáveis antes de qualquer restauração.",
        "Coletar logs de endpoint, servidor, e-mail, firewall, VPN e AD.",
        "Não pagar resgate sem avaliação executiva, jurídica e técnica.",
        "Restaurar de ambiente limpo e corrigir causa raiz antes de reconectar.",
    ]
    return {"ok": True, "scenario": scenario, "approval_required": True, "steps": steps}


def add_alert(alert_type: str, severity: str, evidence: Any) -> dict[str, Any]:
    _ensure()
    data = json.loads(ALERTS_FILE.read_text(encoding="utf-8-sig"))
    alert = {
        "id": f"alert_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "type": alert_type,
        "severity": severity,
        "evidence": evidence,
        "created_at": _now(),
        "status": "open",
    }
    data.setdefault("alerts", []).insert(0, alert)
    data["alerts"] = data["alerts"][:1000]
    ALERTS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    _audit({"event": "alert", "type": alert_type, "severity": severity, "alert_id": alert["id"]})
    return alert


def alerts(limit: int = 100) -> dict[str, Any]:
    _ensure()
    data = json.loads(ALERTS_FILE.read_text(encoding="utf-8-sig"))
    return {"ok": True, "alerts": data.get("alerts", [])[:limit]}


def ransomware_guard_plan() -> dict[str, Any]:
    return {
        "ok": True,
        "layers": [
            {"name": "E-mail", "actions": ["triagem de anexos", "bloqueio de executáveis/scripts", "alerta de macro", "quarentena"]},
            {"name": "Endpoint", "actions": ["EDR/antivírus", "canary files", "baseline", "detecção de alteração em massa"]},
            {"name": "Servidor", "actions": ["monitorar compartilhamentos", "menor privilégio", "logs", "backup imutável"]},
            {"name": "Rede", "actions": ["segmentação", "bloquear lateral movement", "RDP/VPN com MFA"]},
            {"name": "Resposta", "actions": ["playbook", "aprovação humana", "isolamento controlado", "restauração limpa"]},
        ],
        "limitations": [
            "não existe garantia absoluta contra invasão",
            "ações reais de isolamento/bloqueio dependem de EDR, firewall, SIEM ou permissões administrativas",
            "o agente não executa anexos nem remove arquivos automaticamente",
        ],
    }


def natural_answer(message: str = "") -> str:
    return (
        "Sim — isso precisa entrar como uma camada de defesa cibernética, não como uma função comum. "
        "Eu adicionaria o HAL Cyber Defense & Ransomware Shield para monitorar e-mails/anexos suspeitos, "
        "criar canários em pastas críticas, comparar baseline de arquivos, detectar alterações em massa, "
        "checar prontidão de backup, integrar com EDR/SIEM/Defender/Wazuh/Zabbix/Grafana e acionar um playbook de resposta. "
        "Ele ajuda a reduzir muito o risco de invasão e ransomware, mas não pode prometer 100% de bloqueio: para agir de verdade na rede, "
        "precisa de permissões, integrações de segurança e política de aprovação humana."
    )
