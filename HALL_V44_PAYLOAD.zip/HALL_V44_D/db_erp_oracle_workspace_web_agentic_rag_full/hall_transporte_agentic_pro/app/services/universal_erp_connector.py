from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "universal_erp_connector"
CONNECTIONS_FILE = DATA_DIR / "connections.json"
MAPPINGS_FILE = DATA_DIR / "mappings.json"
QUERIES_FILE = DATA_DIR / "query_plans.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"

DATABASES: dict[str, dict[str, Any]] = {
    "oracle": {"label": "Oracle", "driver": "oracledb/cx_Oracle", "type": "relational"},
    "sqlserver": {"label": "SQL Server", "driver": "pyodbc/pymssql", "type": "relational"},
    "postgresql": {"label": "PostgreSQL", "driver": "psycopg/asyncpg", "type": "relational"},
    "mysql": {"label": "MySQL", "driver": "pymysql/mysqlclient", "type": "relational"},
    "mariadb": {"label": "MariaDB", "driver": "mariadb/pymysql", "type": "relational"},
    "sqlite": {"label": "SQLite", "driver": "sqlite3", "type": "relational"},
    "firebird": {"label": "Firebird", "driver": "fdb/firebird-driver", "type": "relational"},
    "db2": {"label": "IBM DB2", "driver": "ibm_db", "type": "relational"},
    "mongodb": {"label": "MongoDB", "driver": "pymongo", "type": "nosql"},
    "redis": {"label": "Redis", "driver": "redis", "type": "nosql"},
    "elasticsearch": {"label": "Elasticsearch", "driver": "elasticsearch", "type": "search/nosql"},
    "cassandra": {"label": "Cassandra", "driver": "cassandra-driver", "type": "nosql"},
    "couchdb": {"label": "CouchDB", "driver": "requests/cloudant", "type": "nosql"},
    "opensearch": {"label": "OpenSearch", "driver": "opensearch-py", "type": "search/nosql"},
    "neo4j": {"label": "Neo4j", "driver": "neo4j", "type": "graph"},
    "generic_sql": {"label": "Generic SQL", "driver": "ODBC/JDBC/SQLAlchemy", "type": "relational/generic"},
    "generic_rest": {"label": "Generic DB REST/API", "driver": "HTTP/REST", "type": "api/generic"},
}

CONNECTOR_TYPES: dict[str, dict[str, Any]] = {
    "database": {"label": "Banco de dados direto", "security": "read_only_default"},
    "api_rest": {"label": "API REST", "security": "token_env_var"},
    "api_soap": {"label": "API SOAP", "security": "wsdl_credentials_env_var"},
    "graphql": {"label": "GraphQL", "security": "token_env_var"},
    "file": {"label": "Arquivos CSV/Excel/XML/JSON/CNAB/TXT", "security": "folder_allowlist"},
    "browser_rpa": {"label": "Sistema sem API por Browser/RPA", "security": "browser_automation_approval"},
    "n8n": {"label": "Workflow n8n", "security": "approval_for_critical_workflows"},
    "custom": {"label": "Conector customizado", "security": "case_by_case"},
}

TRANSPORT_TEMPLATES: dict[str, dict[str, Any]] = {
    "ticket_sales": {
        "label": "Venda de Passagens",
        "entities": ["passagem", "viagem", "linha", "agência", "cliente", "forma_pagamento", "cancelamento", "reembolso"],
        "questions": [
            "Quantas passagens foram vendidas hoje?",
            "Qual linha teve queda de vendas?",
            "Qual agência vendeu mais?",
            "Quais passagens foram canceladas?",
            "Qual ocupação por viagem?",
        ],
        "default_actions": ["consultar", "resumir", "comparar", "alertar"],
        "write_actions_require_approval": ["cancelar", "reembolsar", "alterar passagem"],
    },
    "fare_voucher": {
        "label": "Vale-Transporte",
        "entities": ["empresa", "beneficiário", "cartão", "pedido", "recarga", "pagamento", "pendência"],
        "questions": [
            "Quais empresas estão com pedido de vale-transporte pendente?",
            "Quais recargas deram divergência?",
            "Qual total vendido por empresa?",
            "Quais cartões estão bloqueados?",
            "Quais pedidos precisam de cobrança?",
        ],
        "default_actions": ["consultar", "conciliar", "resumir", "preparar mensagem"],
        "write_actions_require_approval": ["enviar cobrança", "baixar pagamento", "alterar crédito", "bloquear cartão"],
    },
    "ticketing": {
        "label": "Bilhetagem / Arrecadação",
        "entities": ["validador", "cartão", "linha", "veículo", "arrecadação", "integração", "gratuidade"],
        "questions": [
            "Qual arrecadação por linha?",
            "Houve queda em algum veículo?",
            "Quais integrações tiveram divergência?",
            "Qual volume de gratuidades?",
            "Qual total por período?",
        ],
        "default_actions": ["consultar", "conciliar", "comparar", "alertar"],
        "write_actions_require_approval": ["reprocessar", "corrigir lançamento", "exportar dados pessoais"],
    },
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not CONNECTIONS_FILE.exists():
        CONNECTIONS_FILE.write_text(json.dumps({"connections": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not MAPPINGS_FILE.exists():
        MAPPINGS_FILE.write_text(json.dumps({"mappings": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not QUERIES_FILE.exists():
        QUERIES_FILE.write_text(json.dumps({"plans": []}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def status() -> dict[str, Any]:
    connections = _load(CONNECTIONS_FILE, {"connections": []}).get("connections", [])
    mappings = _load(MAPPINGS_FILE, {"mappings": []}).get("mappings", [])
    plans = _load(QUERIES_FILE, {"plans": []}).get("plans", [])
    return {
        "ok": True,
        "name": "HAL Universal ERP & Application Connector",
        "description": "Camada universal para conectar ERP, bancos relacionais/NoSQL, APIs, arquivos, n8n, navegador/RPA e sistemas individuais como venda de passagens e vale-transporte.",
        "supported_databases": len(DATABASES),
        "connector_types": len(CONNECTOR_TYPES),
        "transport_templates": len(TRANSPORT_TEMPLATES),
        "connections_count": len(connections),
        "mappings_count": len(mappings),
        "query_plans_count": len(plans),
        "capabilities": [
            "Cadastrar ERP por banco, API, arquivo, n8n, browser/RPA ou conector customizado",
            "Suportar Oracle, SQL Server, PostgreSQL, MySQL, MariaDB, SQLite, Firebird, Db2, MongoDB, Redis, Elasticsearch/OpenSearch, Cassandra, CouchDB, Neo4j e fallback genérico",
            "Mapear entidades de negócio para tabelas, coleções, endpoints, arquivos ou telas",
            "Criar planos de consulta seguros somente leitura por padrão",
            "Gerar templates para venda de passagens, vale-transporte e bilhetagem",
            "Integrar sistemas legados sem API via Browser Automation",
            "Exigir aprovação humana para escrita, cancelamento, cobrança, reembolso, baixa e envio externo",
        ],
    }


def catalog() -> dict[str, Any]:
    return {
        "ok": True,
        "databases": [{"key": k, **v} for k, v in DATABASES.items()],
        "connector_types": [{"key": k, **v} for k, v in CONNECTOR_TYPES.items()],
        "transport_templates": [{"key": k, **v} for k, v in TRANSPORT_TEMPLATES.items()],
    }


def register_connection(
    name: str,
    connector_type: str,
    database: str = "",
    system_name: str = "",
    env_prefix: str = "",
    readonly: bool = True,
    description: str = "",
) -> dict[str, Any]:
    if connector_type not in CONNECTOR_TYPES:
        return {"ok": False, "summary": "Tipo de conector não suportado.", "available": list(CONNECTOR_TYPES)}
    if database and database not in DATABASES:
        return {"ok": False, "summary": "Banco não suportado no catálogo.", "available": list(DATABASES)}
    data = _load(CONNECTIONS_FILE, {"connections": []})
    cid = f"conn_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    item = {
        "id": cid,
        "name": name,
        "connector_type": connector_type,
        "connector_label": CONNECTOR_TYPES[connector_type]["label"],
        "database": database,
        "database_label": DATABASES.get(database, {}).get("label", ""),
        "system_name": system_name or name,
        "env_prefix": env_prefix or f"HALL_{name.upper().replace(' ', '_')}",
        "readonly": readonly,
        "description": description,
        "status": "registered",
        "created_at": _now(),
        "security": {
            "read_only_default": True,
            "write_requires_approval": True,
            "external_send_requires_approval": True,
            "credentials_in_env_only": True,
        },
    }
    data.setdefault("connections", []).insert(0, item)
    _save(CONNECTIONS_FILE, data)
    _audit({"event": "register_connection", "connection_id": cid})
    return {"ok": True, "connection": item, "summary": "Conexão registrada."}


def list_connections(limit: int = 100) -> dict[str, Any]:
    items = _load(CONNECTIONS_FILE, {"connections": []}).get("connections", [])
    return {"ok": True, "connections": items[:max(1, min(limit, 500))], "count": len(items)}


def register_mapping(
    connection_id: str,
    business_entity: str,
    physical_target: str,
    fields: list[dict[str, Any]] | None = None,
    access_method: str = "read",
    notes: str = "",
) -> dict[str, Any]:
    data = _load(MAPPINGS_FILE, {"mappings": []})
    mid = f"map_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    mapping = {
        "id": mid,
        "connection_id": connection_id,
        "business_entity": business_entity,
        "physical_target": physical_target,
        "fields": fields or [],
        "access_method": access_method,
        "notes": notes,
        "status": "mapped",
        "created_at": _now(),
    }
    data.setdefault("mappings", []).insert(0, mapping)
    _save(MAPPINGS_FILE, data)
    _audit({"event": "register_mapping", "mapping_id": mid, "entity": business_entity})
    return {"ok": True, "mapping": mapping, "summary": "Mapeamento registrado."}


def list_mappings(limit: int = 100) -> dict[str, Any]:
    items = _load(MAPPINGS_FILE, {"mappings": []}).get("mappings", [])
    return {"ok": True, "mappings": items[:max(1, min(limit, 500))], "count": len(items)}


def infer_domain(question: str) -> dict[str, Any]:
    t = (question or "").lower()
    if any(x in t for x in ["passagem", "passagens", "linha", "viagem", "agência", "agencia", "ocupação", "ocupacao"]):
        return {"domain": "ticket_sales", **TRANSPORT_TEMPLATES["ticket_sales"]}
    if any(x in t for x in ["vale-transporte", "vale transporte", "recarga", "cartão", "cartao", "beneficiário", "beneficiario"]):
        return {"domain": "fare_voucher", **TRANSPORT_TEMPLATES["fare_voucher"]}
    if any(x in t for x in ["bilhetagem", "arrecadação", "arrecadacao", "validador", "gratuidade"]):
        return {"domain": "ticketing", **TRANSPORT_TEMPLATES["ticketing"]}
    return {"domain": "generic_erp", "label": "ERP / Sistema Corporativo", "entities": [], "questions": [], "default_actions": ["consultar", "resumir"], "write_actions_require_approval": ["alterar", "enviar", "baixar", "cancelar"]}


def create_query_plan(question: str, connection_id: str = "", approved: bool = False) -> dict[str, Any]:
    domain = infer_domain(question)
    risky_words = ["cancelar", "alterar", "reembolsar", "baixar", "enviar", "bloquear", "corrigir", "reprocessar"]
    risky = any(x in (question or "").lower() for x in risky_words)
    status_value = "waiting_approval" if risky and not approved else "ready_readonly"
    plan = {
        "id": f"qplan_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "question": question,
        "connection_id": connection_id,
        "domain": domain,
        "status": status_value,
        "approved": approved,
        "readonly": not risky,
        "created_at": _now(),
        "steps": [
            "Identificar entidade de negócio",
            "Selecionar conexão ERP/banco/API/arquivo/tela",
            "Validar permissão somente leitura",
            "Montar consulta ou plano de automação",
            "Executar somente se credenciais/conector estiverem configurados",
            "Retornar resposta resumida e evidência",
        ],
        "safe_sql_hint": sql_hint(domain["domain"]),
        "approval_required_for": domain.get("write_actions_require_approval", []),
    }
    data = _load(QUERIES_FILE, {"plans": []})
    data.setdefault("plans", []).insert(0, plan)
    _save(QUERIES_FILE, data)
    _audit({"event": "create_query_plan", "plan_id": plan["id"], "status": status_value})
    return {"ok": True, "plan": plan, "summary": "Plano de consulta criado."}


def sql_hint(domain: str) -> str:
    if domain == "ticket_sales":
        return "SELECT linha, COUNT(*) passagens, SUM(valor) receita FROM vendas_passagens WHERE data_venda = CURRENT_DATE GROUP BY linha;"
    if domain == "fare_voucher":
        return "SELECT empresa, COUNT(*) pedidos, SUM(valor) total FROM pedidos_vale_transporte WHERE status_pagamento = 'PENDENTE' GROUP BY empresa;"
    if domain == "ticketing":
        return "SELECT linha, veiculo, SUM(valor) arrecadacao FROM bilhetagem WHERE data_movimento = CURRENT_DATE GROUP BY linha, veiculo;"
    return "-- Consulta gerada após mapear entidade/tabela/campo no ERP Mapping Studio."


def list_query_plans(limit: int = 100) -> dict[str, Any]:
    items = _load(QUERIES_FILE, {"plans": []}).get("plans", [])
    return {"ok": True, "plans": items[:max(1, min(limit, 500))], "count": len(items)}


def seed_transport_pack() -> dict[str, Any]:
    conn = register_connection(
        name="ERP Transporte Demo",
        connector_type="database",
        database="oracle",
        system_name="ERP / Venda de Passagens / Vale-Transporte",
        env_prefix="ERP_TRANSPORTE",
        readonly=True,
        description="Conexão demo para transporte, bilhetagem, venda de passagens e vale-transporte.",
    )["connection"]
    mappings = [
        register_mapping(conn["id"], "venda_passagens", "VENDAS_PASSAGENS", [{"name": "linha"}, {"name": "data_venda"}, {"name": "valor"}])["mapping"],
        register_mapping(conn["id"], "vale_transporte", "PEDIDOS_VALE_TRANSPORTE", [{"name": "empresa"}, {"name": "status_pagamento"}, {"name": "valor"}])["mapping"],
        register_mapping(conn["id"], "bilhetagem", "MOVIMENTO_BILHETAGEM", [{"name": "linha"}, {"name": "veiculo"}, {"name": "valor"}])["mapping"],
    ]
    return {"ok": True, "connection": conn, "mappings": mappings, "summary": "Pack de Transporte/Bilhetagem/Vale-Transporte criado."}


def safe_action_policy() -> dict[str, Any]:
    return {
        "ok": True,
        "default": "read_only",
        "allowed_without_approval": ["consultar", "resumir", "comparar", "gerar relatório local", "criar plano"],
        "requires_human_approval": [
            "alterar dados",
            "cancelar passagem",
            "reembolsar",
            "baixar pagamento",
            "enviar cobrança",
            "bloquear cartão",
            "executar update/delete/insert",
            "exportar dados pessoais",
            "enviar mensagem externa",
        ],
        "credential_policy": "Credenciais apenas em variáveis de ambiente/cofre local; nunca gravar senha/token em JSON ou log.",
    }


def answer_for_erp(message: str = "") -> str:
    domain = infer_domain(message)
    return (
        f"Vou usar o HAL Universal ERP & Application Connector. "
        f"Detectei o contexto {domain['label']}. "
        "Essa camada conecta ERP, bancos relacionais/NoSQL, APIs, arquivos, n8n, navegador/RPA e sistemas individuais, "
        "sempre em modo somente leitura por padrão e com aprovação humana para ações sensíveis."
    )
