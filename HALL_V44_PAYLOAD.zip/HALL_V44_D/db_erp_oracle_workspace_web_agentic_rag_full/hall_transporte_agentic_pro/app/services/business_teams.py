from __future__ import annotations

import json
import re
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir, load_config
from app.tools.business_domains import detect_domain, domain_options
from app.tools.database_platforms import detect_database, database_options


DATA_DIR = root_dir() / "data" / "business_teams"
TEAMS_FILE = DATA_DIR / "teams.json"
APPROVAL_FILE = DATA_DIR / "approvals.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"


AGENT_CATALOG: dict[str, dict[str, Any]] = {
    "ceo_agent": {
        "label": "CEO Agent / Orquestrador",
        "mission": "Entender objetivo, montar o time, delegar tarefas, consolidar resultado e pedir aprovação.",
        "tools": ["roteador", "memória", "modelos locais", "fila de aprovação"],
        "risk": "medium",
    },
    "governance_agent": {
        "label": "Agente de Governança",
        "mission": "Validar LGPD, segurança, risco operacional, auditoria e necessidade de aprovação humana.",
        "tools": ["aprovação", "auditoria", "políticas"],
        "risk": "high",
    },
    "service_agent": {
        "label": "Agente de Atendimento",
        "mission": "Atender clientes, classificar dúvidas, abrir solicitações e encaminhar casos sensíveis.",
        "tools": ["web chat", "WhatsApp", "Telegram", "RAG", "CRM"],
        "risk": "medium",
    },
    "sdr_sales_agent": {
        "label": "Agente SDR / Vendas",
        "mission": "Qualificar leads, identificar oportunidades, preparar proposta e sugerir follow-up.",
        "tools": ["CRM", "e-mail", "WhatsApp", "memória da empresa"],
        "risk": "medium",
    },
    "content_agent": {
        "label": "Agente de Conteúdo",
        "mission": "Gerar posts, artigos, campanhas, roteiros, e-mails e materiais comerciais.",
        "tools": ["editor", "calendário editorial", "aprovação"],
        "risk": "low",
    },
    "finance_agent": {
        "label": "Agente Financeiro / Contábil",
        "mission": "Analisar CRC, CPG, fluxo de caixa, DRE, inadimplência, fiscal e contábil.",
        "tools": ["SQL/NoSQL", "BI", "Power BI", "planilhas"],
        "risk": "high",
    },
    "operations_agent": {
        "label": "Agente de Operações",
        "mission": "Atuar no processo principal do segmento: transporte, logística, varejo, atacado ou operação genérica.",
        "tools": ["ERP", "monitoramento", "dashboards", "metadados"],
        "risk": "medium",
    },
    "data_bi_agent": {
        "label": "Agente de Dados / BI",
        "mission": "Consultar bancos relacionais/NoSQL, criar indicadores, preparar dashboards e validar dados.",
        "tools": ["Oracle", "SQL Server", "PostgreSQL", "MySQL", "MariaDB", "MongoDB", "Power BI"],
        "risk": "medium",
    },
    "automation_agent": {
        "label": "Agente de Automação",
        "mission": "Executar tarefas repetitivas, integrar sistemas, criar notas, acionar desktop e canais externos com aprovação.",
        "tools": ["desktop", "webhooks", "n8n", "scripts locais"],
        "risk": "high",
    },
    "executive_jarvis_agent": {
        "label": "Jarvis Executivo Pessoal",
        "mission": "Acompanhar prioridades do executivo, organizar tarefas, preparar briefings e sugerir decisões.",
        "tools": ["memória", "agenda", "e-mail", "BI", "tarefas"],
        "risk": "medium",
    },
}


TEAM_TEMPLATES: dict[str, dict[str, Any]] = {
    "atendimento": {
        "label": "Time de Atendimento",
        "description": "Triagem, resposta ao cliente, consulta à base de conhecimento e escalonamento.",
        "agents": ["ceo_agent", "service_agent", "operations_agent", "governance_agent"],
        "channels": ["webchat", "whatsapp", "telegram", "email"],
        "approval_policy": "Aprovar respostas sensíveis, promessas comerciais, reclamações críticas e dados pessoais.",
        "examples": [
            "Atender clientes no WhatsApp e classificar solicitações.",
            "Responder dúvidas usando base de conhecimento.",
            "Encaminhar reclamações críticas para humano.",
        ],
    },
    "vendas_sdr": {
        "label": "Time de Vendas / SDR",
        "description": "Captação, qualificação de leads, proposta e follow-up.",
        "agents": ["ceo_agent", "sdr_sales_agent", "content_agent", "data_bi_agent", "governance_agent"],
        "channels": ["webchat", "whatsapp", "telegram", "email"],
        "approval_policy": "Aprovar envio de proposta, desconto, negociação e mensagens externas.",
        "examples": [
            "Qualificar leads B2B.",
            "Preparar proposta comercial por segmento.",
            "Sugerir próximos contatos.",
        ],
    },
    "conteudo": {
        "label": "Time de Conteúdo",
        "description": "Calendário editorial, posts, roteiros, e-mails, artigos e campanhas.",
        "agents": ["ceo_agent", "content_agent", "sdr_sales_agent", "governance_agent"],
        "channels": ["web", "email", "linkedin", "instagram"],
        "approval_policy": "Aprovar todo conteúdo antes de publicar.",
        "examples": [
            "Gerar calendário semanal de posts.",
            "Criar campanha para varejo, logística ou financeiro.",
            "Criar roteiro para vídeo institucional.",
        ],
    },
    "financeiro": {
        "label": "Time Financeiro / Contábil",
        "description": "Análise de CRC, CPG, DRE, fluxo de caixa, inadimplência, fiscal e contábil.",
        "agents": ["ceo_agent", "finance_agent", "data_bi_agent", "automation_agent", "governance_agent"],
        "channels": ["web", "email", "bi"],
        "approval_policy": "Aprovar cobrança, alteração de dados, envio externo e qualquer escrita em ERP/banco.",
        "examples": [
            "Priorizar contas a receber vencidas.",
            "Gerar DRE gerencial.",
            "Automatizar relatório financeiro diário.",
        ],
    },
    "operacoes": {
        "label": "Time Operacional",
        "description": "Operação central do segmento: transporte, logística, varejo, atacado ou operação genérica.",
        "agents": ["ceo_agent", "operations_agent", "data_bi_agent", "automation_agent", "governance_agent"],
        "channels": ["web", "zabbix", "grafana", "powerbi"],
        "approval_policy": "Aprovar intervenção operacional, scripts, mudanças em produção e comunicações sensíveis.",
        "examples": [
            "Monitorar entregas atrasadas.",
            "Analisar frota, bilheteria ou estoque.",
            "Priorizar alertas de operação.",
        ],
    },
    "dados_bi": {
        "label": "Time de Dados / BI",
        "description": "Consultas em bancos relacionais/NoSQL, indicadores, dashboards e qualidade de dados.",
        "agents": ["ceo_agent", "data_bi_agent", "operations_agent", "finance_agent", "governance_agent"],
        "channels": ["web", "powerbi", "grafana"],
        "approval_policy": "Aprovar consultas pesadas, exportações, compartilhamento de dados e escritas.",
        "examples": [
            "Gerar indicadores no MongoDB.",
            "Criar SQL para SQL Server ou Oracle.",
            "Preparar dashboard executivo.",
        ],
    },
    "automacao": {
        "label": "Time de Automação",
        "description": "Automatiza rotinas repetitivas, integra sistemas, arquivos, e-mails, desktop e APIs.",
        "agents": ["ceo_agent", "automation_agent", "data_bi_agent", "operations_agent", "governance_agent"],
        "channels": ["desktop", "webhooks", "email", "telegram", "whatsapp"],
        "approval_policy": "Toda ação que altera arquivo, banco, ERP, e-mail ou canal externo exige aprovação.",
        "examples": [
            "Atualizar relatório diário.",
            "Criar rotina de cobrança com revisão.",
            "Integrar dados de ERP e BI.",
        ],
    },
    "executivo": {
        "label": "Jarvis Executivo Pessoal",
        "description": "Organiza prioridades, tarefas, briefings, indicadores e decisões para diretoria.",
        "agents": ["ceo_agent", "executive_jarvis_agent", "data_bi_agent", "finance_agent", "governance_agent"],
        "channels": ["web", "email", "telegram", "whatsapp"],
        "approval_policy": "Aprovar envio de mensagens, decisões sensíveis e acesso a dados restritos.",
        "examples": [
            "Gerar briefing diário da empresa.",
            "Resumo de indicadores por segmento.",
            "Listar decisões pendentes de aprovação.",
        ],
    },
    "personalizado": {
        "label": "Time Personalizado",
        "description": "Monta agentes sob medida conforme objetivo, segmento, banco, canal e nível de risco.",
        "agents": ["ceo_agent", "data_bi_agent", "automation_agent", "governance_agent"],
        "channels": ["web"],
        "approval_policy": "Definir política de aprovação conforme risco do processo.",
        "examples": [
            "Criar time para um processo específico.",
            "Misturar atendimento, dados e automação.",
            "Criar fluxo por segmento e banco.",
        ],
    },
}


CHANNELS: dict[str, dict[str, Any]] = {
    "webchat": {"label": "Web Chat", "status": "ready", "adapter": "nativo", "notes": "Canal web local da plataforma."},
    "whatsapp": {"label": "WhatsApp", "status": "adapter_ready", "adapter": "Evolution API / WAHA / Meta Cloud API", "notes": "Requer configuração externa e credenciais."},
    "telegram": {"label": "Telegram", "status": "adapter_ready", "adapter": "Telegram Bot API", "notes": "Requer token do bot."},
    "discord": {"label": "Discord", "status": "adapter_ready", "adapter": "Discord Bot", "notes": "Requer app/bot Discord."},
    "email": {"label": "E-mail", "status": "adapter_ready", "adapter": "IMAP/SMTP", "notes": "Requer servidor, usuário e senha/app password."},
    "imessage": {"label": "iMessage", "status": "conceptual", "adapter": "macOS bridge", "notes": "Depende de ambiente Apple/macOS."},
    "desktop": {"label": "Desktop Local", "status": "ready_when_dependencies_installed", "adapter": "pyautogui/mss/opencv", "notes": "Controle local com aprovação humana."},
    "powerbi": {"label": "Power BI", "status": "configured_in_platform", "adapter": "Power BI module", "notes": "Integração com dashboards e análises."},
    "zabbix": {"label": "Zabbix", "status": "configured_in_platform", "adapter": "Zabbix API", "notes": "Monitoramento e alertas."},
    "grafana": {"label": "Grafana", "status": "configured_in_platform", "adapter": "Grafana API", "notes": "Dashboards e painéis."},
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not TEAMS_FILE.exists():
        TEAMS_FILE.write_text(json.dumps({"teams": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not APPROVAL_FILE.exists():
        APPROVAL_FILE.write_text(json.dumps({"items": []}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def _load_json(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save_json(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def status() -> dict[str, Any]:
    teams = _load_json(TEAMS_FILE, {"teams": []}).get("teams", [])
    approvals = _load_json(APPROVAL_FILE, {"items": []}).get("items", [])
    return {
        "ok": True,
        "name": "HAL Business Teams",
        "description": "Times empresariais de agentes com CEO Agent, especialistas, canais, aprovação humana, auditoria e operação multi-segmento.",
        "templates_count": len(TEAM_TEMPLATES),
        "agents_count": len(AGENT_CATALOG),
        "channels_count": len(CHANNELS),
        "teams_count": len(teams),
        "pending_approvals": len([a for a in approvals if a.get("status") == "pending"]),
        "capabilities": [
            "Criar times por objetivo de negócio",
            "Templates: atendimento, vendas/SDR, conteúdo, financeiro, operações, dados/BI, automação e executivo",
            "Roteamento por segmento e banco de dados",
            "Fila de aprovação humana",
            "Conectores preparados para WhatsApp, Telegram, Discord, E-mail e Web Chat",
            "Auditoria local das decisões",
            "Estimativa de esforço/infraestrutura",
            "Modo no-code para criar times",
        ],
    }


def templates() -> dict[str, Any]:
    return {"ok": True, "templates": [{"key": k, **v} for k, v in TEAM_TEMPLATES.items()]}


def agents() -> dict[str, Any]:
    return {"ok": True, "agents": [{"key": k, **v} for k, v in AGENT_CATALOG.items()]}


def channels() -> dict[str, Any]:
    return {"ok": True, "channels": [{"key": k, **v} for k, v in CHANNELS.items()]}


def choose_template(goal: str, requested_template: str = "") -> str:
    if requested_template and requested_template in TEAM_TEMPLATES:
        return requested_template
    t = (goal or "").lower()
    rules = [
        ("atendimento", ["atendimento", "cliente", "suporte", "reclamação", "reclamacao", "whatsapp"]),
        ("vendas_sdr", ["venda", "sdr", "lead", "proposta", "comercial", "funil"]),
        ("conteudo", ["conteúdo", "conteudo", "post", "campanha", "artigo", "roteiro", "marketing"]),
        ("financeiro", ["financeiro", "contábil", "contabil", "crc", "cpg", "cobrança", "cobranca", "dre", "fluxo de caixa"]),
        ("operacoes", ["operação", "operacao", "logística", "logistica", "transporte", "entrega", "frota", "estoque", "loja"]),
        ("dados_bi", ["bi", "dashboard", "indicador", "relatório", "relatorio", "dados", "mongodb", "sql", "banco"]),
        ("automacao", ["automatizar", "automação", "automacao", "rotina", "workflow", "processo repetitivo"]),
        ("executivo", ["executivo", "diretoria", "ceo", "briefing", "prioridade"]),
    ]
    scores: list[tuple[int, str]] = []
    for key, terms in rules:
        score = sum(1 for term in terms if term in t)
        if score:
            scores.append((score, key))
    if not scores:
        return "personalizado"
    scores.sort(reverse=True)
    return scores[0][1]


def _build_workflow(goal: str, template_key: str, segment: dict[str, Any], db: dict[str, Any], channels_req: list[str]) -> list[dict[str, Any]]:
    template = TEAM_TEMPLATES[template_key]
    return [
        {
            "step": 1,
            "name": "Entender objetivo",
            "owner": "ceo_agent",
            "description": f"Interpretar o pedido, confirmar segmento {segment.get('label')} e objetivo de negócio.",
            "status": "planned",
        },
        {
            "step": 2,
            "name": "Montar contexto",
            "owner": "data_bi_agent",
            "description": f"Identificar fontes de dados, banco {db.get('label')} e módulos necessários.",
            "status": "planned",
        },
        {
            "step": 3,
            "name": "Delegar aos especialistas",
            "owner": "ceo_agent",
            "description": "Distribuir tarefas aos agentes selecionados: " + ", ".join(template.get("agents", [])),
            "status": "planned",
        },
        {
            "step": 4,
            "name": "Executar simulação segura",
            "owner": "automation_agent" if "automation_agent" in template.get("agents", []) else "operations_agent",
            "description": "Preparar respostas, consultas, dashboards ou automações sem alterar sistemas reais.",
            "status": "planned",
        },
        {
            "step": 5,
            "name": "Verificar risco e qualidade",
            "owner": "governance_agent",
            "description": "Checar LGPD, risco, dados sensíveis, impacto operacional e necessidade de aprovação.",
            "status": "planned",
        },
        {
            "step": 6,
            "name": "Aprovação humana",
            "owner": "governance_agent",
            "description": "Enviar para fila de aprovação se envolver cliente, e-mail, canal externo, escrita em banco/ERP ou ação de desktop.",
            "status": "waiting_approval",
        },
        {
            "step": 7,
            "name": "Execução controlada",
            "owner": "ceo_agent",
            "description": "Após aprovação, executar nos canais: " + ", ".join(channels_req or template.get("channels", [])),
            "status": "blocked_until_approved",
        },
    ]


def create_team(goal: str, segment: str = "", database: str = "", template: str = "", channels_req: list[str] | None = None, company: str = "", approval_required: bool = True) -> dict[str, Any]:
    _ensure()
    channels_req = channels_req or []
    template_key = choose_template(goal, template)
    tpl = TEAM_TEMPLATES[template_key]
    seg = detect_domain((segment or "") + " " + goal)
    db = detect_database((database or "") + " " + goal)
    team_id = f"team_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    team = {
        "id": team_id,
        "name": f"{tpl['label']} - {seg['label']}",
        "goal": goal,
        "company": company or "Empresa não informada",
        "segment": seg,
        "database": db,
        "template_key": template_key,
        "template": tpl,
        "agents": [{"key": a, **AGENT_CATALOG[a]} for a in tpl.get("agents", []) if a in AGENT_CATALOG],
        "channels": [CHANNELS.get(c, {"key": c, "label": c, "status": "custom"}) | {"key": c} for c in (channels_req or tpl.get("channels", []))],
        "workflow": _build_workflow(goal, template_key, seg, db, channels_req),
        "approval_required": approval_required,
        "approval_policy": tpl.get("approval_policy"),
        "status": "planned",
        "created_at": _now(),
        "updated_at": _now(),
        "metrics": estimate_impact(template_key, seg.get("key", "generico")),
    }
    data = _load_json(TEAMS_FILE, {"teams": []})
    data.setdefault("teams", []).insert(0, team)
    _save_json(TEAMS_FILE, data)
    _audit({"event": "create_team", "team_id": team_id, "template": template_key})
    return {"ok": True, "team": team, "summary": f"Time criado: {team['name']}."}


def list_teams(limit: int = 50) -> dict[str, Any]:
    data = _load_json(TEAMS_FILE, {"teams": []})
    return {"ok": True, "teams": data.get("teams", [])[:max(1, min(limit, 200))], "count": len(data.get("teams", []))}


def get_team(team_id: str) -> dict[str, Any]:
    for team in _load_json(TEAMS_FILE, {"teams": []}).get("teams", []):
        if team.get("id") == team_id:
            return {"ok": True, "team": team}
    return {"ok": False, "summary": "Time não encontrado."}


def run_team(goal: str, team_id: str = "", approved: bool = False, channel: str = "webchat") -> dict[str, Any]:
    if team_id:
        found = get_team(team_id)
        if not found.get("ok"):
            return found
        team = found["team"]
    else:
        team = create_team(goal, channels_req=[channel]).get("team")

    requires_approval = bool(team.get("approval_required", True))
    actions = delegate_tasks(goal or team.get("goal", ""), team)
    approval_item = None
    if requires_approval and not approved:
        approval_item = enqueue_approval(
            title=f"Executar {team.get('name')}",
            description=f"Aprovar execução do time para o objetivo: {goal or team.get('goal')}",
            payload={"team_id": team.get("id"), "goal": goal or team.get("goal"), "actions": actions},
            risk="medium_high",
        )
        summary = "Plano pronto. Execução enviada para aprovação humana antes de acionar canais ou alterar sistemas."
    else:
        summary = "Time executado em modo controlado. Ações reais foram simuladas/registradas conforme política local."

    _audit({"event": "run_team", "team_id": team.get("id"), "approved": approved, "actions": len(actions)})
    return {
        "ok": True,
        "team": team,
        "delegation": actions,
        "requires_approval": requires_approval and not approved,
        "approval": approval_item,
        "summary": summary,
    }


def delegate_tasks(goal: str, team: dict[str, Any]) -> list[dict[str, Any]]:
    actions = []
    for ag in team.get("agents", []):
        key = ag.get("key")
        if key == "ceo_agent":
            actions.append({"agent": key, "task": "Consolidar objetivo, contexto, prioridade, riscos e próximos passos.", "status": "planned"})
        elif key == "service_agent":
            actions.append({"agent": key, "task": "Preparar resposta ao cliente, triagem e classificação de intenção.", "status": "planned"})
        elif key == "sdr_sales_agent":
            actions.append({"agent": key, "task": "Qualificar oportunidade, perguntas de descoberta e proposta inicial.", "status": "planned"})
        elif key == "content_agent":
            actions.append({"agent": key, "task": "Criar conteúdo/campanha/roteiro alinhado ao segmento.", "status": "planned"})
        elif key == "finance_agent":
            actions.append({"agent": key, "task": "Analisar indicadores financeiros, CRC/CPG/DRE/fluxo e riscos.", "status": "planned"})
        elif key == "operations_agent":
            actions.append({"agent": key, "task": "Analisar operação do segmento, gargalos e impactos no cliente.", "status": "planned"})
        elif key == "data_bi_agent":
            actions.append({"agent": key, "task": "Localizar fontes de dados, banco, tabelas/collections e indicadores.", "status": "planned"})
        elif key == "automation_agent":
            actions.append({"agent": key, "task": "Montar fluxo automatizado e separar passos que exigem aprovação.", "status": "planned"})
        elif key == "governance_agent":
            actions.append({"agent": key, "task": "Verificar LGPD, segurança, risco, auditoria e aprovação humana.", "status": "planned"})
        elif key == "executive_jarvis_agent":
            actions.append({"agent": key, "task": "Gerar briefing executivo, prioridades e decisões pendentes.", "status": "planned"})
    return actions


def enqueue_approval(title: str, description: str, payload: dict[str, Any], risk: str = "medium") -> dict[str, Any]:
    data = _load_json(APPROVAL_FILE, {"items": []})
    item = {
        "id": f"appr_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "title": title,
        "description": description,
        "payload": payload,
        "risk": risk,
        "status": "pending",
        "created_at": _now(),
        "updated_at": _now(),
    }
    data.setdefault("items", []).insert(0, item)
    _save_json(APPROVAL_FILE, data)
    _audit({"event": "enqueue_approval", "approval_id": item["id"], "risk": risk})
    return item


def list_approvals(status_filter: str = "pending", limit: int = 100) -> dict[str, Any]:
    data = _load_json(APPROVAL_FILE, {"items": []})
    rows = data.get("items", [])
    if status_filter:
        rows = [r for r in rows if r.get("status") == status_filter]
    return {"ok": True, "approvals": rows[:max(1, min(limit, 300))], "count": len(rows)}


def decide_approval(approval_id: str, decision: str, reviewer: str = "humano") -> dict[str, Any]:
    data = _load_json(APPROVAL_FILE, {"items": []})
    for item in data.get("items", []):
        if item.get("id") == approval_id:
            item["status"] = "approved" if decision == "approve" else "rejected"
            item["reviewer"] = reviewer
            item["reviewed_at"] = _now()
            item["updated_at"] = _now()
            _save_json(APPROVAL_FILE, data)
            _audit({"event": "decide_approval", "approval_id": approval_id, "decision": decision})
            return {"ok": True, "approval": item, "summary": "Aprovação atualizada."}
    return {"ok": False, "summary": "Aprovação não encontrada."}


def estimate_impact(template_key: str, segment_key: str = "generico") -> dict[str, Any]:
    base = {
        "time_saved_hours_month": 20,
        "automation_level": "médio",
        "human_review_needed": True,
        "cost_notes": "Usando Ollama/local, custo principal é infraestrutura CPU/GPU; APIs externas são opcionais.",
    }
    if template_key in {"atendimento", "vendas_sdr"}:
        base.update({"time_saved_hours_month": 35, "automation_level": "médio/alto"})
    elif template_key in {"financeiro", "dados_bi", "automacao"}:
        base.update({"time_saved_hours_month": 45, "automation_level": "alto com aprovação"})
    elif template_key == "executivo":
        base.update({"time_saved_hours_month": 25, "automation_level": "médio"})
    if segment_key in {"logistica", "transporte"}:
        base["business_gain"] = "redução de atrasos, melhor priorização operacional e menos retrabalho."
    elif segment_key in {"varejo", "atacado"}:
        base["business_gain"] = "melhor atendimento, vendas, estoque e priorização comercial."
    elif segment_key == "financeiro_contabil":
        base["business_gain"] = "mais controle de caixa, inadimplência, DRE e obrigações."
    else:
        base["business_gain"] = "ganho de produtividade e padronização de processos."
    return base


def no_code_spec() -> dict[str, Any]:
    return {
        "ok": True,
        "fields": [
            {"name": "goal", "label": "Objetivo do time", "type": "textarea", "required": True},
            {"name": "segment", "label": "Segmento", "type": "select", "options": [s["label"] for s in domain_options()]},
            {"name": "database", "label": "Banco de dados", "type": "select", "options": [d["label"] for d in database_options()]},
            {"name": "template", "label": "Template do time", "type": "select", "options": [t["label"] for t in templates()["templates"]]},
            {"name": "channels", "label": "Canais", "type": "multiselect", "options": [c["label"] for c in channels()["channels"]]},
            {"name": "approval_required", "label": "Exigir aprovação humana", "type": "checkbox", "default": True},
        ],
        "flow": [
            "Definir objetivo",
            "Escolher segmento/banco/canais",
            "Montar time",
            "Gerar plano",
            "Simular execução",
            "Enviar para aprovação",
            "Executar controlado",
            "Auditar resultado",
        ],
    }


def answer_for_business_teams(goal: str, template: str = "", segment: str = "", database: str = "") -> str:
    tpl_key = choose_template(goal, template)
    seg = detect_domain((segment or "") + " " + goal)
    db = detect_database((database or "") + " " + goal)
    tpl = TEAM_TEMPLATES[tpl_key]
    agents_labels = [AGENT_CATALOG[a]["label"] for a in tpl.get("agents", []) if a in AGENT_CATALOG]
    return (
        f"Vou montar um {tpl['label']} para o segmento {seg['label']}, usando contexto de banco {db['label']} quando necessário. "
        f"O time terá: {', '.join(agents_labels)}. "
        "Antes de acionar canais externos, enviar mensagens, alterar dados ou executar automações, eu coloco a ação na fila de aprovação humana."
    )
