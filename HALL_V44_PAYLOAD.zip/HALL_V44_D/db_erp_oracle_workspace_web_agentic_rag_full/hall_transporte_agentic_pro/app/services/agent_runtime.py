from __future__ import annotations

import json
import time
import uuid
import re
from pathlib import Path
from typing import Any

from app.core.config import root_dir
from app.tools.business_domains import detect_domain
from app.tools.database_platforms import detect_database

try:
    from services.hall_safety import HallSafetySupervisor, SafetyAction
except Exception:
    HallSafetySupervisor = None
    SafetyAction = None


DATA_DIR = root_dir() / "data" / "agent_runtime"
JOBS_FILE = DATA_DIR / "jobs.json"
METRICS_FILE = DATA_DIR / "metrics.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"
SANDBOX_DIR = DATA_DIR / "sandboxes"
_SAFETY_SUPERVISOR = None


def _safety_supervisor():
    global _SAFETY_SUPERVISOR
    if HallSafetySupervisor is None:
        return None
    if _SAFETY_SUPERVISOR is None:
        _SAFETY_SUPERVISOR = HallSafetySupervisor(root_dir().parent)
    return _SAFETY_SUPERVISOR


RUNTIME_AGENTS: dict[str, dict[str, Any]] = {
    "ceo_agent": {
        "label": "CEO Agent / Orquestrador",
        "role": "Quebra objetivos grandes em etapas, escolhe agentes, consolida respostas e decide próximos passos.",
        "tools": ["planner", "router", "memory", "approval_queue"],
        "risk": "medium",
    },
    "planner_agent": {
        "label": "Agente Planejador",
        "role": "Transforma uma demanda longa em plano, subtarefas, checkpoints, dependências e critérios de aceite.",
        "tools": ["task_graph", "checkpoints", "timeline"],
        "risk": "low",
    },
    "executor_agent": {
        "label": "Agente Executor",
        "role": "Executa etapas de trabalho, registra saídas, cria artefatos e marca progresso.",
        "tools": ["job_runner", "files", "desktop_optional"],
        "risk": "medium",
    },
    "coder_agent": {
        "label": "Agente de Código",
        "role": "Gera, revisa, corrige e refatora código; cria patches e prepara diffs.",
        "tools": ["sandbox", "git", "tests", "diff"],
        "risk": "high",
    },
    "tester_agent": {
        "label": "Agente de Testes / TDD",
        "role": "Cria cenários, testes unitários, testes funcionais, smoke tests e relatório de qualidade.",
        "tools": ["pytest", "node_check", "compileall", "test_report"],
        "risk": "medium",
    },
    "data_agent": {
        "label": "Agente de Dados",
        "role": "Consulta metadados, bancos relacionais/NoSQL, SQL Copilot, BI, ERD e qualidade dos dados.",
        "tools": ["sql", "nosql", "metadata", "bi"],
        "risk": "medium",
    },
    "ops_agent": {
        "label": "Agente de Operações",
        "role": "Interpreta monitoramento, Zabbix, Grafana, Power BI, alertas e impacto operacional.",
        "tools": ["zabbix", "grafana", "prometheus", "powerbi"],
        "risk": "medium",
    },
    "security_agent": {
        "label": "Agente de Segurança / Governança",
        "role": "Valida risco, LGPD, RBAC, segregação, aprovação humana, logs e permissões.",
        "tools": ["policy", "approval", "audit", "rbac"],
        "risk": "high",
    },
    "evaluator_agent": {
        "label": "Agente Avaliador",
        "role": "Compara antes/depois, mede qualidade, tempo economizado, sucesso, falhas e retrabalho.",
        "tools": ["agent_evaluation", "metrics", "scorecard"],
        "risk": "low",
    },
}


JOB_TYPES: dict[str, dict[str, Any]] = {
    "long_task": {
        "label": "Tarefa longa",
        "description": "Tarefa de vários passos, com checkpoint, retomada e medição de progresso.",
        "default_agents": ["ceo_agent", "planner_agent", "executor_agent", "security_agent", "evaluator_agent"],
    },
    "parallel_agents": {
        "label": "Execução paralela por agentes",
        "description": "Divide o objetivo em subtarefas executáveis por agentes diferentes e consolida a resposta.",
        "default_agents": ["ceo_agent", "planner_agent", "executor_agent", "data_agent", "ops_agent", "security_agent", "evaluator_agent"],
    },
    "code_sandbox": {
        "label": "Sandbox de código",
        "description": "Geração/correção de código com ambiente isolado, testes, logs, diff e rollback.",
        "default_agents": ["ceo_agent", "coder_agent", "tester_agent", "security_agent", "evaluator_agent"],
    },
    "enterprise_workflow": {
        "label": "Workflow corporativo",
        "description": "Processo empresarial com governança, aprovação, métricas e integração a módulos da JR-AI.",
        "default_agents": ["ceo_agent", "planner_agent", "data_agent", "ops_agent", "executor_agent", "security_agent", "evaluator_agent"],
    },
    "monitoring_response": {
        "label": "Resposta a incidente",
        "description": "Analisa alertas, prioriza incidentes, recomenda ações e acompanha resolução.",
        "default_agents": ["ceo_agent", "ops_agent", "data_agent", "security_agent", "evaluator_agent"],
    },
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    SANDBOX_DIR.mkdir(parents=True, exist_ok=True)
    if not JOBS_FILE.exists():
        JOBS_FILE.write_text(json.dumps({"jobs": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not METRICS_FILE.exists():
        METRICS_FILE.write_text(json.dumps(default_metrics(), ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def default_metrics() -> dict[str, Any]:
    return {
        "total_jobs": 0,
        "completed_jobs": 0,
        "failed_jobs": 0,
        "cancelled_jobs": 0,
        "paused_jobs": 0,
        "estimated_human_hours_saved": 0.0,
        "approval_rate": 0.0,
        "success_rate": 0.0,
        "average_quality_score": 0.0,
        "by_type": {},
        "by_segment": {},
        "by_agent": {},
        "last_updated": _now(),
    }


def status() -> dict[str, Any]:
    jobs = _load(JOBS_FILE, {"jobs": []}).get("jobs", [])
    metrics = compute_metrics()
    return {
        "ok": True,
        "name": "HAL Agent Runtime Enterprise",
        "description": "Runtime corporativo para tarefas longas, execução paralela de agentes, sandbox, testes, checkpoints, observabilidade, métricas e governança.",
        "jobs_count": len(jobs),
        "running_jobs": len([j for j in jobs if j.get("status") == "running"]),
        "paused_jobs": len([j for j in jobs if j.get("status") == "paused"]),
        "waiting_approval": len([j for j in jobs if j.get("status") == "waiting_approval"]),
        "agents_count": len(RUNTIME_AGENTS),
        "job_types_count": len(JOB_TYPES),
        "metrics": metrics,
        "capabilities": [
            "Fila de jobs persistente local",
            "Tarefas longas com checkpoints",
            "Pausar, retomar, cancelar e reexecutar etapas",
            "Plano de execução paralela por agentes",
            "Sandbox de código com testes e relatório",
            "Geração de diff/patch conceitual",
            "Métricas de produtividade, sucesso, qualidade e economia de tempo",
            "Observabilidade dos agentes",
            "Governança, RBAC, aprovação e auditoria",
        ],
    }


def agents() -> dict[str, Any]:
    return {"ok": True, "agents": [{"key": k, **v} for k, v in RUNTIME_AGENTS.items()]}


def job_types() -> dict[str, Any]:
    return {"ok": True, "job_types": [{"key": k, **v} for k, v in JOB_TYPES.items()]}


def infer_job_type(objective: str, explicit: str = "") -> str:
    if explicit and explicit in JOB_TYPES:
        return explicit
    t = (objective or "").lower()
    if any(x in t for x in ["código", "codigo", "teste", "debug", "erro", "build", "patch", "diff", "rollback", "sistema", "app", "site", "saas"]):
        return "code_sandbox"
    if any(x in t for x in ["zabbix", "grafana", "alerta", "incidente", "monitoramento", "indisponibilidade"]):
        return "monitoring_response"
    if any(x in t for x in ["paralelo", "vários agentes", "varios agentes", "time de agentes", "business teams", "equipe"]):
        return "parallel_agents"
    if any(x in t for x in ["workflow", "processo", "aprovação", "aprovacao", "operacional", "financeiro", "contábil", "contabil"]):
        return "enterprise_workflow"
    return "long_task"


def _step_template(job_type: str, objective: str, selected_agents: list[str]) -> list[dict[str, Any]]:
    base = [
        {"id": "understand_objective", "name": "Entender objetivo", "agent": "ceo_agent", "status": "pending", "progress": 0, "requires_approval": False},
        {"id": "create_plan", "name": "Criar plano e critérios de aceite", "agent": "planner_agent", "status": "pending", "progress": 0, "requires_approval": False},
        {"id": "collect_context", "name": "Coletar contexto, dados e ferramentas", "agent": "data_agent", "status": "pending", "progress": 0, "requires_approval": False},
    ]
    if job_type == "code_sandbox":
        base.extend([
            {"id": "prepare_sandbox", "name": "Preparar sandbox isolado", "agent": "coder_agent", "status": "pending", "progress": 0, "requires_approval": False},
            {"id": "generate_or_patch_code", "name": "Gerar código ou patch/diff", "agent": "coder_agent", "status": "pending", "progress": 0, "requires_approval": False},
            {"id": "run_tests", "name": "Executar testes automáticos", "agent": "tester_agent", "status": "pending", "progress": 0, "requires_approval": False},
            {"id": "quality_review", "name": "Code review e relatório de qualidade", "agent": "tester_agent", "status": "pending", "progress": 0, "requires_approval": False},
        ])
    elif job_type == "parallel_agents":
        for ag in selected_agents:
            if ag not in {"ceo_agent", "planner_agent", "security_agent", "evaluator_agent"}:
                base.append({"id": f"parallel_{ag}", "name": f"Executar subtarefa paralela: {RUNTIME_AGENTS.get(ag, {}).get('label', ag)}", "agent": ag, "status": "pending", "progress": 0, "requires_approval": False})
        base.append({"id": "merge_results", "name": "Consolidar resultados dos agentes", "agent": "ceo_agent", "status": "pending", "progress": 0, "requires_approval": False})
    elif job_type == "monitoring_response":
        base.extend([
            {"id": "read_alerts", "name": "Ler alertas e severidades", "agent": "ops_agent", "status": "pending", "progress": 0, "requires_approval": False},
            {"id": "prioritize_incidents", "name": "Priorizar incidentes e impacto", "agent": "ops_agent", "status": "pending", "progress": 0, "requires_approval": False},
            {"id": "recommend_actions", "name": "Recomendar ações corretivas", "agent": "ceo_agent", "status": "pending", "progress": 0, "requires_approval": True},
        ])
    else:
        base.extend([
            {"id": "execute_work", "name": "Executar trabalho com checkpoints", "agent": "executor_agent", "status": "pending", "progress": 0, "requires_approval": False},
            {"id": "validate_result", "name": "Validar resultado parcial", "agent": "evaluator_agent", "status": "pending", "progress": 0, "requires_approval": False},
        ])
    base.extend([
        {"id": "security_governance", "name": "Validar segurança, LGPD, RBAC e aprovação", "agent": "security_agent", "status": "pending", "progress": 0, "requires_approval": True},
        {"id": "final_evaluation", "name": "Avaliação final e métricas", "agent": "evaluator_agent", "status": "pending", "progress": 0, "requires_approval": False},
    ])
    return base


def create_job(
    objective: str,
    job_type: str = "",
    priority: str = "normal",
    agents: list[str] | None = None,
    segment: str = "",
    database: str = "",
    requires_approval: bool = True,
    estimated_human_minutes: int = 60,
    project: str = "",
) -> dict[str, Any]:
    _ensure()
    inferred_type = infer_job_type(objective, job_type)
    default_agents = JOB_TYPES[inferred_type]["default_agents"]
    selected_agents = [a for a in (agents or default_agents) if a in RUNTIME_AGENTS]
    if not selected_agents:
        selected_agents = default_agents
    seg = detect_domain((segment or "") + " " + objective)
    db = detect_database((database or "") + " " + objective)
    job_id = f"job_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    job = {
        "id": job_id,
        "objective": objective,
        "job_type": inferred_type,
        "job_type_label": JOB_TYPES[inferred_type]["label"],
        "priority": priority,
        "project": project,
        "segment": seg,
        "database": db,
        "agents": [{"key": a, **RUNTIME_AGENTS[a]} for a in selected_agents],
        "steps": _step_template(inferred_type, objective, selected_agents),
        "checkpoints": [],
        "logs": [],
        "artifacts": [],
        "sandbox": sandbox_plan(job_id, objective, inferred_type),
        "security_policy": security_policy(),
        "metrics": {
            "estimated_human_minutes": estimated_human_minutes,
            "runtime_minutes": 0,
            "quality_score": 0,
            "progress": 0,
            "tokens_estimated": 0,
            "requires_approval": requires_approval,
        },
        "status": "queued",
        "created_at": _now(),
        "updated_at": _now(),
    }
    data = _load(JOBS_FILE, {"jobs": []})
    data.setdefault("jobs", []).insert(0, job)
    _save(JOBS_FILE, data)
    _audit({"event": "create_job", "job_id": job_id, "type": inferred_type})
    return {"ok": True, "job": job, "summary": f"Job criado na fila: {job['job_type_label']}."}


def list_jobs(status_filter: str = "", limit: int = 100) -> dict[str, Any]:
    jobs = _load(JOBS_FILE, {"jobs": []}).get("jobs", [])
    if status_filter:
        jobs = [j for j in jobs if j.get("status") == status_filter]
    return {"ok": True, "jobs": jobs[:max(1, min(limit, 500))], "count": len(jobs)}


def get_job(job_id: str) -> dict[str, Any]:
    for j in _load(JOBS_FILE, {"jobs": []}).get("jobs", []):
        if j.get("id") == job_id:
            return {"ok": True, "job": j}
    return {"ok": False, "summary": "Job não encontrado."}


def _update_job(job: dict[str, Any]) -> None:
    data = _load(JOBS_FILE, {"jobs": []})
    rows = data.get("jobs", [])
    for i, item in enumerate(rows):
        if item.get("id") == job.get("id"):
            rows[i] = job
            data["jobs"] = rows
            _save(JOBS_FILE, data)
            return


def _log(job: dict[str, Any], message: str, level: str = "info") -> None:
    job.setdefault("logs", []).append({"ts": _now(), "level": level, "message": message})


def start_job(job_id: str, approved: bool = False) -> dict[str, Any]:
    found = get_job(job_id)
    if not found.get("ok"):
        return found
    job = found["job"]
    sup = _safety_supervisor()
    if sup is not None and SafetyAction is not None:
        guard = sup.preflight(SafetyAction(agent_id="agent_runtime", action="agent_job_start", tool="hall_agent_runtime", operation="start_job", resource=job_id, objective=str(job.get("objective") or job.get("name") or ""), args={"job_type": job.get("job_type"), "agents": [a.get("key") for a in job.get("agents", []) if isinstance(a, dict)]}, run_id=job_id, human_approved=approved, actor="agent_runtime", actor_role="agent"))
        if not guard.get("allowed"):
            job["status"] = "waiting_approval" if guard.get("requires_approval") else "blocked"
            job["safety"] = guard
            _log(job, str(guard.get("reason") or "Bloqueado pelo HAL Safety Supervisor."), "warning")
            _update_job(job)
            _audit({"event": "safety_block", "job_id": job_id, "safety": guard})
            return {"ok": False, "job": job, "blocked_by_safety": True, "requires_approval": bool(guard.get("requires_approval")), "safety": guard, "summary": guard.get("reason")}
    if job["metrics"].get("requires_approval") and not approved:
        job["status"] = "waiting_approval"
        _log(job, "Job aguardando aprovação humana antes da execução.", "warning")
    else:
        job["status"] = "running"
        _log(job, "Job iniciado pelo Agent Runtime Enterprise.", "info")
        add_checkpoint(job, "start", "Execução iniciada.", persist=False)
    job["updated_at"] = _now()
    _update_job(job)
    _audit({"event": "start_job", "job_id": job_id, "approved": approved})
    return {"ok": True, "job": job, "summary": "Job iniciado." if job["status"] == "running" else "Job aguardando aprovação humana."}


def approve_and_start(job_id: str) -> dict[str, Any]:
    return start_job(job_id, approved=True)


def advance_job(job_id: str, steps_to_advance: int = 1) -> dict[str, Any]:
    # V36: the legacy progress tracker has no registered executor. It must not
    # manufacture delivery, checkpoints or a quality score.
    found = get_job(job_id)
    if not found.get("ok"):
        return found
    job = found["job"]
    return {"ok": False, "job": job, "advanced_steps": 0,
            "requires_real_executor": True,
            "summary": "Este fluxo antigo registra planejamento. Execute a missão no Console Autonomia V36 (/autonomy); somente ferramentas com evidência podem concluir etapas."}


def run_to_completion(job_id: str, approved: bool = False) -> dict[str, Any]:
    started = start_job(job_id, approved=approved)
    if not started.get("ok"):
        return started
    job = started["job"]
    if job.get("status") == "waiting_approval":
        return started
    pending = len([s for s in job.get("steps", []) if s.get("status") != "completed"])
    return advance_job(job_id, max(1, pending))


def pause_job(job_id: str) -> dict[str, Any]:
    found = get_job(job_id)
    if not found.get("ok"):
        return found
    job = found["job"]
    job["status"] = "paused"
    _log(job, "Job pausado pelo usuário.")
    add_checkpoint(job, "paused", "Ponto de retomada criado antes da pausa.", persist=False)
    job["updated_at"] = _now()
    _update_job(job)
    _audit({"event": "pause_job", "job_id": job_id})
    return {"ok": True, "job": job, "summary": "Job pausado."}


def resume_job(job_id: str) -> dict[str, Any]:
    found = get_job(job_id)
    if not found.get("ok"):
        return found
    job = found["job"]
    job["status"] = "running"
    _log(job, "Job retomado a partir do último checkpoint.")
    job["updated_at"] = _now()
    _update_job(job)
    _audit({"event": "resume_job", "job_id": job_id})
    return {"ok": True, "job": job, "summary": "Job retomado."}


def cancel_job(job_id: str, reason: str = "") -> dict[str, Any]:
    found = get_job(job_id)
    if not found.get("ok"):
        return found
    job = found["job"]
    job["status"] = "cancelled"
    _log(job, f"Job cancelado. Motivo: {reason or 'não informado'}", "warning")
    job["updated_at"] = _now()
    _update_job(job)
    _audit({"event": "cancel_job", "job_id": job_id, "reason": reason})
    return {"ok": True, "job": job, "summary": "Job cancelado."}


def retry_step(job_id: str, step_id: str = "") -> dict[str, Any]:
    found = get_job(job_id)
    if not found.get("ok"):
        return found
    job = found["job"]
    target = None
    for step in job.get("steps", []):
        if (step_id and step.get("id") == step_id) or (not step_id and step.get("status") in {"failed", "running"}):
            target = step
            break
    if not target:
        return {"ok": False, "job": job, "summary": "Etapa para reexecução não encontrada."}
    target["status"] = "pending"
    target["progress"] = 0
    target["retry_count"] = target.get("retry_count", 0) + 1
    job["status"] = "running"
    _log(job, f"Etapa marcada para reexecução: {target['name']}.")
    job["updated_at"] = _now()
    _update_job(job)
    _audit({"event": "retry_step", "job_id": job_id, "step_id": target.get("id")})
    return {"ok": True, "job": job, "summary": "Etapa marcada para reexecução."}


def add_checkpoint(job: dict[str, Any] | str, checkpoint_type: str, summary: str, persist: bool = True) -> dict[str, Any]:
    if isinstance(job, str):
        found = get_job(job)
        if not found.get("ok"):
            return found
        job = found["job"]
    item = {
        "id": f"chk_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "type": checkpoint_type,
        "summary": summary,
        "created_at": _now(),
        "progress": job.get("metrics", {}).get("progress", 0),
    }
    job.setdefault("checkpoints", []).insert(0, item)
    if persist:
        job["updated_at"] = _now()
        _update_job(job)
        _audit({"event": "checkpoint", "job_id": job.get("id"), "checkpoint": item["id"]})
    return {"ok": True, "checkpoint": item, "job": job}


def update_progress(job: dict[str, Any]) -> None:
    steps = job.get("steps", [])
    if not steps:
        job.setdefault("metrics", {})["progress"] = 0
        return
    completed = len([s for s in steps if s.get("status") == "completed"])
    job.setdefault("metrics", {})["progress"] = int((completed / len(steps)) * 100)
    job["metrics"]["runtime_minutes"] = max(1, int(completed * 3))


def sandbox_plan(job_id: str, objective: str, job_type: str) -> dict[str, Any]:
    path = SANDBOX_DIR / job_id
    return {
        "enabled": job_type == "code_sandbox",
        "path": str(path.relative_to(root_dir())),
        "isolation": "local_folder",
        "commands_allowed": ["python -m compileall", "pytest", "node --check", "npm test"],
        "commands_blocked": ["rm -rf /", "format", "diskpart", "net user", "curl unknown shell pipe"],
        "notes": "Sandbox lógico/local. Para produção, usar container Docker sem privilégios, timeout, limites de CPU/RAM e rede controlada.",
    }


def security_policy() -> dict[str, Any]:
    return {
        "read_only_default": True,
        "human_approval_required_for": [
            "escrita em banco/ERP",
            "envio de e-mail/mensagem externa",
            "ações de desktop",
            "deploy em produção",
            "alteração de arquivo do cliente",
            "uso de credenciais",
            "integração com pagamentos",
        ],
        "rbac": {
            "admin": ["all"],
            "ti": ["read", "execute_sandbox", "approve_low_medium"],
            "negocio": ["read", "request_jobs", "approve_own_area"],
            "auditor": ["read_logs", "read_metrics"],
        },
        "lgpd": "Não expor dados pessoais em prompts, logs ou relatórios sem base legal e mascaramento quando necessário.",
        "secrets": "Credenciais devem ficar em .env/cofre local; nunca gravar token em logs.",
    }


def observability() -> dict[str, Any]:
    jobs = _load(JOBS_FILE, {"jobs": []}).get("jobs", [])
    return {
        "ok": True,
        "queues": {
            "queued": len([j for j in jobs if j.get("status") == "queued"]),
            "running": len([j for j in jobs if j.get("status") == "running"]),
            "paused": len([j for j in jobs if j.get("status") == "paused"]),
            "waiting_approval": len([j for j in jobs if j.get("status") == "waiting_approval"]),
            "completed": len([j for j in jobs if j.get("status") == "completed"]),
            "cancelled": len([j for j in jobs if j.get("status") == "cancelled"]),
        },
        "agents": agent_load(),
        "latest_jobs": jobs[:10],
        "prometheus_like_metrics": prometheus_metrics_text(),
    }


def agent_load() -> dict[str, Any]:
    jobs = _load(JOBS_FILE, {"jobs": []}).get("jobs", [])
    load = {k: {"label": v["label"], "assigned_steps": 0, "completed_steps": 0} for k, v in RUNTIME_AGENTS.items()}
    for job in jobs:
        for step in job.get("steps", []):
            ag = step.get("agent")
            if ag in load:
                load[ag]["assigned_steps"] += 1
                if step.get("status") == "completed":
                    load[ag]["completed_steps"] += 1
    return load


def compute_metrics() -> dict[str, Any]:
    jobs = _load(JOBS_FILE, {"jobs": []}).get("jobs", [])
    metrics = default_metrics()
    metrics["total_jobs"] = len(jobs)
    metrics["completed_jobs"] = len([j for j in jobs if j.get("status") == "completed"])
    metrics["failed_jobs"] = len([j for j in jobs if j.get("status") == "failed"])
    metrics["cancelled_jobs"] = len([j for j in jobs if j.get("status") == "cancelled"])
    metrics["paused_jobs"] = len([j for j in jobs if j.get("status") == "paused"])
    metrics["estimated_human_hours_saved"] = round(sum(j.get("metrics", {}).get("estimated_human_minutes", 0) for j in jobs if j.get("status") == "completed") / 60, 2)
    approvals = [j for j in jobs if j.get("metrics", {}).get("requires_approval")]
    metrics["approval_rate"] = round((len(approvals) / len(jobs)) * 100, 2) if jobs else 0
    metrics["success_rate"] = round((metrics["completed_jobs"] / len(jobs)) * 100, 2) if jobs else 0
    quality_scores = [j.get("metrics", {}).get("quality_score", 0) for j in jobs if j.get("metrics", {}).get("quality_score", 0)]
    metrics["average_quality_score"] = round(sum(quality_scores) / len(quality_scores), 2) if quality_scores else 0
    for j in jobs:
        t = j.get("job_type", "unknown")
        metrics["by_type"][t] = metrics["by_type"].get(t, 0) + 1
        s = j.get("segment", {}).get("key", "generico")
        metrics["by_segment"][s] = metrics["by_segment"].get(s, 0) + 1
        for ag in j.get("agents", []):
            key = ag.get("key")
            metrics["by_agent"][key] = metrics["by_agent"].get(key, 0) + 1
    metrics["last_updated"] = _now()
    _save(METRICS_FILE, metrics)
    return metrics


def prometheus_metrics_text() -> str:
    m = compute_metrics()
    lines = [
        "# HELP hall_agent_runtime_jobs_total Total de jobs do Agent Runtime",
        "# TYPE hall_agent_runtime_jobs_total gauge",
        f"hall_agent_runtime_jobs_total {m['total_jobs']}",
        "# HELP hall_agent_runtime_jobs_completed Jobs concluídos",
        "# TYPE hall_agent_runtime_jobs_completed gauge",
        f"hall_agent_runtime_jobs_completed {m['completed_jobs']}",
        "# HELP hall_agent_runtime_success_rate Taxa de sucesso percentual",
        "# TYPE hall_agent_runtime_success_rate gauge",
        f"hall_agent_runtime_success_rate {m['success_rate']}",
        "# HELP hall_agent_runtime_estimated_hours_saved Horas humanas estimadas economizadas",
        "# TYPE hall_agent_runtime_estimated_hours_saved gauge",
        f"hall_agent_runtime_estimated_hours_saved {m['estimated_human_hours_saved']}",
    ]
    return "\n".join(lines) + "\n"


def scorecard(job_id: str) -> dict[str, Any]:
    found = get_job(job_id)
    if not found.get("ok"):
        return found
    job = found["job"]
    progress = job.get("metrics", {}).get("progress", 0)
    completed_steps = len([s for s in job.get("steps", []) if s.get("status") == "completed"])
    total_steps = len(job.get("steps", []))
    risk = "alto" if any(s.get("requires_approval") for s in job.get("steps", [])) else "baixo"
    score = min(100, int(progress * 0.75 + completed_steps * 3))
    return {
        "ok": True,
        "job_id": job_id,
        "scorecard": {
            "progress": progress,
            "completed_steps": completed_steps,
            "total_steps": total_steps,
            "quality_score": job.get("metrics", {}).get("quality_score", score),
            "risk": risk,
            "estimated_human_minutes": job.get("metrics", {}).get("estimated_human_minutes", 0),
            "runtime_minutes": job.get("metrics", {}).get("runtime_minutes", 0),
            "recommendation": "Aprovar execução controlada se o contexto estiver completo." if risk == "alto" else "Pode seguir em modo assistido.",
        },
    }


def answer_for_runtime(objective: str, job_type: str = "") -> str:
    inferred = infer_job_type(objective, job_type)
    seg = detect_domain(objective)
    db = detect_database(objective)
    agents_labels = [RUNTIME_AGENTS[a]["label"] for a in JOB_TYPES[inferred]["default_agents"]]
    return (
        f"Vou usar o HAL Agent Runtime Enterprise. Detectei a tarefa como {JOB_TYPES[inferred]['label']}, "
        f"segmento {seg['label']} e banco/contexto {db['label']}. "
        f"O runtime vai criar fila persistente, plano com checkpoints, agentes responsáveis, observabilidade, métricas, "
        f"política de segurança e aprovação humana quando houver risco. Agentes envolvidos: {', '.join(agents_labels)}."
    )


def no_code_spec() -> dict[str, Any]:
    return {
        "ok": True,
        "fields": [
            {"name": "objective", "label": "Objetivo da tarefa longa", "type": "textarea", "required": True},
            {"name": "job_type", "label": "Tipo de execução", "type": "select", "options": [j["label"] for j in job_types()["job_types"]]},
            {"name": "priority", "label": "Prioridade", "type": "select", "options": ["low", "normal", "high", "critical"]},
            {"name": "segment", "label": "Segmento", "type": "text"},
            {"name": "database", "label": "Banco/contexto", "type": "text"},
            {"name": "approval", "label": "Exigir aprovação humana", "type": "checkbox", "default": True},
        ],
        "flow": [
            "Criar job",
            "Aguardar aprovação quando necessário",
            "Iniciar execução",
            "Avançar etapas",
            "Registrar checkpoints",
            "Pausar/retomar/cancelar quando necessário",
            "Reexecutar etapa com erro",
            "Gerar scorecard",
            "Medir produtividade",
            "Auditar tudo localmente",
        ],
    }


MODEL_RECOMMENDATIONS: dict[str, dict[str, Any]] = {
    "conversation_router": {
        "label": "HAL Conversa / Roteamento",
        "cpu": ["gemma:2b/4b quantizado", "qwen2.5:3b/7b quantizado"],
        "gpu_8_16gb": ["gemma4:12b quantizado", "qwen2.5:14b quantizado"],
        "gpu_24gb_plus": ["qwen2.5:32b", "llama 70b quantizado quando disponível"],
        "notes": "Modelo geral precisa entender intenção, contexto empresarial e escolher ferramenta correta.",
    },
    "code_dev_saas": {
        "label": "Dev Studio / Codex Local / SaaS Builder",
        "cpu": ["qwen2.5-coder:7b quantizado"],
        "gpu_8_16gb": ["qwen2.5-coder:14b", "deepseek-coder-v2-lite"],
        "gpu_24gb_plus": ["qwen3-coder", "deepseek-coder-v2", "qwen2.5-coder:32b"],
        "notes": "Priorizar modelos coder para patch/diff, testes, revisão técnica e geração de sistemas.",
    },
    "vision": {
        "label": "Visão de Tela / Câmera / Dashboards",
        "cpu": ["llava:7b quantizado para protótipo"],
        "gpu_8_16gb": ["qwen-vl quantizado", "gemma multimodal quando disponível"],
        "gpu_24gb_plus": ["qwen-vl maior", "modelos multimodais recentes locais"],
        "notes": "LLaVA serve como fallback; visão de tela corporativa exige OCR, leitura de gráficos e análise de UI.",
    },
    "rag_embeddings": {
        "label": "RAG / Documentos",
        "cpu": ["bge-m3", "nomic-embed-text", "mxbai-embed-large"],
        "gpu_8_16gb": ["bge-m3 + reranker local"],
        "gpu_24gb_plus": ["embeddings + reranker + contexto longo"],
        "notes": "Melhorar com reranker, citações por trecho, versão da base e controle de fontes.",
    },
    "voice": {
        "label": "Voz Natural",
        "cpu": ["faster-whisper small/base para STT", "piper para TTS leve"],
        "gpu_8_16gb": ["faster-whisper medium", "Coqui XTTS/F5-TTS/OpenVoice"],
        "gpu_24gb_plus": ["Whisper large-v3 local", "TTS neural com voz customizada"],
        "notes": "Para voz paulista/natural, usar áudio autorizado do usuário e TTS local avançado.",
    },
    "sql_dba": {
        "label": "SQL / DBA / Dados",
        "cpu": ["qwen2.5-coder:7b + modelo geral pequeno"],
        "gpu_8_16gb": ["qwen2.5-coder:14b + gemma4:12b"],
        "gpu_24gb_plus": ["qwen3-coder/deepseek-coder-v2 + modelo geral forte"],
        "notes": "Obrigatório validar SQL, usar usuário read-only e aprovação para escrita.",
    },
}


def model_advisor(task: str = "", has_gpu: bool = False, vram_gb: int = 0, cpu_only: bool = True) -> dict[str, Any]:
    tier = "cpu"
    if has_gpu and not cpu_only:
        tier = "gpu_24gb_plus" if vram_gb >= 24 else "gpu_8_16gb"
    recommendations = []
    t = (task or "").lower()
    selected_keys = []
    if any(x in t for x in ["código", "codigo", "dev", "saas", "app", "site", "debug", "teste", "patch"]):
        selected_keys.append("code_dev_saas")
    if any(x in t for x in ["visão", "visao", "tela", "camera", "dashboard", "imagem"]):
        selected_keys.append("vision")
    if any(x in t for x in ["documento", "rag", "pdf", "manual", "norma"]):
        selected_keys.append("rag_embeddings")
    if any(x in t for x in ["voz", "audio", "áudio", "fala", "tts", "stt"]):
        selected_keys.append("voice")
    if any(x in t for x in ["sql", "banco", "dba", "oracle", "mongodb", "postgres", "mysql"]):
        selected_keys.append("sql_dba")
    if not selected_keys:
        selected_keys = list(MODEL_RECOMMENDATIONS.keys())
    for key in selected_keys:
        item = MODEL_RECOMMENDATIONS[key]
        recommendations.append({
            "key": key,
            "label": item["label"],
            "recommended_models": item[tier],
            "tier": tier,
            "notes": item["notes"],
        })
    return {
        "ok": True,
        "hardware": {"cpu_only": cpu_only, "has_gpu": has_gpu, "vram_gb": vram_gb, "tier": tier},
        "task": task,
        "recommendations": recommendations,
        "policy": "Local/open-source/open-weight por padrão; API externa somente opcional e autorizada pelo cliente.",
    }
