from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _slug(text: str) -> str:
    import re
    text = (text or "item").lower()
    text = re.sub(r"[^a-z0-9áéíóúãõâêôç]+", "-", text)
    text = (text.replace("á","a").replace("é","e").replace("í","i").replace("ó","o").replace("ú","u")
            .replace("ã","a").replace("õ","o").replace("â","a").replace("ê","e").replace("ô","o").replace("ç","c"))
    return re.sub(r"-+", "-", text).strip("-") or "item"


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(path: Path, event: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")

DATA_DIR = root_dir() / "data" / "n8n_workflow_center"
CONFIG_FILE = DATA_DIR / "config.json"
WORKFLOWS_FILE = DATA_DIR / "workflows.json"
EXECUTIONS_FILE = DATA_DIR / "executions.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"

TEMPLATES: dict[str, dict[str, Any]] = {
    "lead_sdr": {"label": "Lead para SDR", "trigger": "webhook", "steps": ["receber lead", "qualificar", "enviar ao CRM", "notificar vendedor"]},
    "zabbix_incident": {"label": "Incidente Zabbix", "trigger": "zabbix_alert", "steps": ["receber alerta", "classificar severidade", "avisar Teams/Slack", "abrir chamado"]},
    "financial_daily": {"label": "Relatório Financeiro Diário", "trigger": "cron", "steps": ["consultar dados", "gerar resumo", "enviar aprovação", "distribuir relatório"]},
    "customer_support": {"label": "Atendimento ao Cliente", "trigger": "whatsapp", "steps": ["receber mensagem", "consultar RAG", "classificar", "responder/escalar"]},
    "powerbi_refresh": {"label": "Atualizar Power BI", "trigger": "schedule", "steps": ["validar base", "acionar refresh", "confirmar status", "avisar time"]},
}


def _defaults() -> dict[str, Any]:
    return {
        "enabled": True,
        "n8n_base_url": "http://127.0.0.1:5678",
        "api_key_env": "N8N_API_KEY",
        "webhook_base_url": "http://127.0.0.1:8000/api/n8n/callback",
        "approval_required_for_execute": True,
        "allow_create_workflows": False,
        "allowed_workflow_ids": [],
        "timeout_seconds": 120,
    }


def status() -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, _defaults())
    workflows = _load(WORKFLOWS_FILE, {"workflows": []}).get("workflows", [])
    executions = _load(EXECUTIONS_FILE, {"executions": []}).get("executions", [])
    return {
        "ok": True,
        "name": "HAL n8n Workflow Center",
        "description": "Centro de integração real com n8n por API/webhook, mapeando intenções do HAL para workflows determinísticos.",
        "base_url": cfg.get("n8n_base_url"),
        "workflows_count": len(workflows),
        "executions_count": len(executions),
        "templates": len(TEMPLATES),
        "capabilities": [
            "Cadastrar URL e token do n8n",
            "Registrar workflows existentes",
            "Acionar workflow via webhook/API",
            "Receber callback do n8n",
            "Mapear intenção do usuário para workflow",
            "Exigir aprovação humana para workflows críticos",
            "Usar templates por área",
        ],
    }


def configure(base_url: str, api_key_env: str = "N8N_API_KEY", approval_required: bool = True) -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, _defaults())
    cfg["n8n_base_url"] = base_url.rstrip("/")
    cfg["api_key_env"] = api_key_env
    cfg["approval_required_for_execute"] = approval_required
    _save(CONFIG_FILE, cfg)
    _audit(AUDIT_FILE, {"event": "configure", "base_url": cfg["n8n_base_url"]})
    return {"ok": True, "config": cfg, "summary": "Configuração n8n atualizada."}


def templates() -> dict[str, Any]:
    return {"ok": True, "templates": [{"key": k, **v} for k, v in TEMPLATES.items()]}


def register_workflow(name: str, workflow_id: str = "", webhook_url: str = "", intent_keywords: list[str] | None = None, critical: bool = True) -> dict[str, Any]:
    data = _load(WORKFLOWS_FILE, {"workflows": []})
    wid = workflow_id or f"wf_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    wf = {
        "id": wid,
        "name": name,
        "webhook_url": webhook_url,
        "intent_keywords": intent_keywords or [],
        "critical": critical,
        "status": "registered",
        "created_at": _now(),
    }
    data.setdefault("workflows", []).insert(0, wf)
    _save(WORKFLOWS_FILE, data)
    _audit(AUDIT_FILE, {"event": "register_workflow", "workflow_id": wid})
    return {"ok": True, "workflow": wf, "summary": "Workflow registrado."}


def list_workflows(limit: int = 100) -> dict[str, Any]:
    workflows = _load(WORKFLOWS_FILE, {"workflows": []}).get("workflows", [])
    return {"ok": True, "workflows": workflows[:max(1, min(limit, 500))], "count": len(workflows)}


def execute_workflow(workflow_id: str, payload: dict[str, Any] | None = None, approved: bool = False) -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, _defaults())
    workflows = _load(WORKFLOWS_FILE, {"workflows": []}).get("workflows", [])
    wf = next((w for w in workflows if w.get("id") == workflow_id), None)
    if not wf:
        return {"ok": False, "summary": "Workflow não encontrado."}
    requires = cfg.get("approval_required_for_execute", True) or wf.get("critical", True)
    status_value = "waiting_approval" if requires and not approved else "ready_to_execute"
    ex = {
        "id": f"exec_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "workflow_id": workflow_id,
        "workflow_name": wf.get("name"),
        "payload": payload or {},
        "approved": approved,
        "status": status_value,
        "created_at": _now(),
        "execution_note": "Execução real pode ser feita via webhook_url/API do n8n no ambiente configurado.",
        "target_url": wf.get("webhook_url") or f"{cfg.get('n8n_base_url')}/webhook/{workflow_id}",
    }
    data = _load(EXECUTIONS_FILE, {"executions": []})
    data.setdefault("executions", []).insert(0, ex)
    _save(EXECUTIONS_FILE, data)
    _audit(AUDIT_FILE, {"event": "execute_workflow", "workflow_id": workflow_id, "status": status_value})
    return {"ok": True, "execution": ex, "summary": "Workflow aguardando aprovação." if status_value == "waiting_approval" else "Workflow pronto para execução."}


def callback(execution_id: str, status_value: str, result: dict[str, Any] | None = None) -> dict[str, Any]:
    data = _load(EXECUTIONS_FILE, {"executions": []})
    for ex in data.get("executions", []):
        if ex.get("id") == execution_id:
            ex["status"] = status_value
            ex["result"] = result or {}
            ex["updated_at"] = _now()
            _save(EXECUTIONS_FILE, data)
            _audit(AUDIT_FILE, {"event": "callback", "execution_id": execution_id, "status": status_value})
            return {"ok": True, "execution": ex, "summary": "Callback registrado."}
    return {"ok": False, "summary": "Execução não encontrada."}


def list_executions(limit: int = 100) -> dict[str, Any]:
    executions = _load(EXECUTIONS_FILE, {"executions": []}).get("executions", [])
    return {"ok": True, "executions": executions[:max(1, min(limit, 500))], "count": len(executions)}


def map_intent(message: str) -> dict[str, Any]:
    t = (message or "").lower()
    scores = []
    for key, tpl in TEMPLATES.items():
        score = sum(1 for term in [key, tpl["label"].lower(), tpl["trigger"]] + tpl["steps"] if term.lower() in t)
        if score:
            scores.append((score, key, tpl))
    scores.sort(reverse=True, key=lambda x: x[0])
    if not scores:
        return {"ok": True, "matched": False, "suggestion": "Registrar workflow n8n ou escolher template manualmente."}
    score, key, tpl = scores[0]
    return {"ok": True, "matched": True, "template_key": key, "template": tpl, "confidence": min(0.95, 0.55 + score * 0.1)}


def answer_for_n8n(message: str = "") -> str:
    mapped = map_intent(message)
    if mapped.get("matched"):
        return f"Vou usar o HAL n8n Workflow Center. Detectei o template {mapped['template']['label']} para acionar workflow determinístico no n8n, com aprovação humana quando for crítico."
    return "Vou usar o HAL n8n Workflow Center para mapear seu pedido a um workflow do n8n, executar por webhook/API e registrar histórico/callback."
