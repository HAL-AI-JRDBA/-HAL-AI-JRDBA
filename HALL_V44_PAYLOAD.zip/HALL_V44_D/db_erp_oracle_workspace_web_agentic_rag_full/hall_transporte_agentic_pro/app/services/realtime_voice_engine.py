from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "realtime_voice_engine"
CONFIG_FILE = DATA_DIR / "config.json"
SESSIONS_FILE = DATA_DIR / "sessions.json"
EVENTS_FILE = DATA_DIR / "events.jsonl"
AUDIO_DIR = DATA_DIR / "audio_samples"


DEFAULT_CONFIG: dict[str, Any] = {
    "enabled": True,
    "mode": "browser_realtime_plus_local_adapters",
    "locale": "pt-BR",
    "accent": "paulista/neutro brasileiro",
    "voice_style": "natural, calmo, claro, humilde, profissional",
    "wake_words": ["hall", "oi hall", "olá hall", "bom dia hall", "boa tarde hall", "boa noite hall"],
    "turn_taking": {
        "continuous_listening": True,
        "wait_for_user_silence_ms": 1250,
        "min_final_silence_ms": 900,
        "max_speech_segment_ms": 45000,
        "do_not_answer_while_user_is_speaking": True,
        "barge_in_enabled": True,
        "stop_tts_when_user_speaks": True,
        "ask_clarifying_question_when_low_confidence": True,
        "confidence_threshold": 0.62
    },
    "noise_handling": {
        "vad_enabled": True,
        "noise_suppression": True,
        "echo_cancellation": True,
        "auto_gain_control": True,
        "min_voice_energy": 0.015,
        "speech_start_frames": 4,
        "speech_end_silence_frames": 10
    },
    "stt": {
        "primary": "browser_speech_recognition",
        "local_preferred": "faster_whisper",
        "fallback": "whisper_cpp",
        "streaming": True,
        "partial_transcripts": True,
        "final_transcript_required": True
    },
    "tts": {
        "primary": "browser_speech_synthesis",
        "local_preferred": "piper",
        "custom_voice_preferred": "coqui_xtts_or_f5_tts",
        "fallback": "browser_speech_synthesis",
        "speed": 0.88,
        "pitch": 0.94,
        "volume": 1.0,
        "sentence_pause_ms": 420,
        "paragraph_pause_ms": 760
    },
    "custom_voice": {
        "enabled_when_authorized_sample_exists": True,
        "profile_id": "aprigiovoice_authorized",
        "minimum_sample_minutes": 3,
        "recommended_sample_minutes": 5,
        "store_local_only": True,
        "sample_dir": "data/realtime_voice_engine/audio_samples"
    },
    "visual_feedback": {
        "avatar_pulse": True,
        "states": ["idle", "listening", "thinking", "speaking", "interrupted", "error"],
        "show_partial_transcript": True,
        "show_tool_route": True
    },
    "routing": {
        "send_final_transcript_to_unified_turn": True,
        "auto_select_tool": True,
        "safe_actions_require_approval": True
    }
}


ENGINE_OPTIONS: dict[str, dict[str, Any]] = {
    "browser_speech_api": {
        "label": "Browser Speech API",
        "ready": True,
        "local": "depende_do_navegador/sistema",
        "best_for": "demonstração rápida, baixa instalação",
        "limitations": "qualidade e vozes dependem do Windows/Chrome/Edge"
    },
    "faster_whisper": {
        "label": "faster-whisper local",
        "ready": "adapter_ready",
        "local": True,
        "best_for": "STT local robusto em português com CPU/GPU",
        "install_hint": "pip install faster-whisper"
    },
    "whisper_cpp": {
        "label": "whisper.cpp local",
        "ready": "adapter_ready",
        "local": True,
        "best_for": "STT local leve para CPU",
        "install_hint": "instalar whisper.cpp e modelo ggml/gguf"
    },
    "piper": {
        "label": "Piper TTS local",
        "ready": "adapter_ready",
        "local": True,
        "best_for": "TTS leve em CPU",
        "install_hint": "instalar piper e modelo pt-BR"
    },
    "coqui_xtts": {
        "label": "Coqui XTTS local",
        "ready": "adapter_ready",
        "local": True,
        "best_for": "voz natural e voz autorizada do usuário",
        "install_hint": "requer modelo, dependências de áudio e idealmente GPU"
    },
    "f5_tts": {
        "label": "F5-TTS local",
        "ready": "adapter_ready",
        "local": True,
        "best_for": "voz natural/clonagem autorizada moderna",
        "install_hint": "requer instalação específica e amostra de voz"
    },
    "openvoice": {
        "label": "OpenVoice local",
        "ready": "adapter_ready",
        "local": True,
        "best_for": "conversão/timbre de voz autorizada",
        "install_hint": "requer amostra de voz autorizada"
    }
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text(json.dumps(DEFAULT_CONFIG, ensure_ascii=False, indent=2), encoding="utf-8")
    if not SESSIONS_FILE.exists():
        SESSIONS_FILE.write_text(json.dumps({"sessions": []}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _event(event: dict[str, Any]) -> None:
    _ensure()
    with EVENTS_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def status() -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    sessions = _load(SESSIONS_FILE, {"sessions": []}).get("sessions", [])
    samples = list(AUDIO_DIR.glob("*"))
    return {
        "ok": True,
        "name": "HAL Real-Time Voice Engine",
        "description": "Camada de voz em tempo real para conversa natural: escuta contínua, VAD, pausa, barge-in, STT/TTS local preparado e roteamento automático.",
        "enabled": cfg.get("enabled", True),
        "locale": cfg.get("locale"),
        "accent": cfg.get("accent"),
        "active_sessions": len([s for s in sessions if s.get("status") == "active"]),
        "sessions_count": len(sessions),
        "authorized_voice_samples_count": len(samples),
        "capabilities": [
            "Escuta contínua com wake word opcional",
            "VAD lógico e política de silêncio final",
            "Não responder enquanto o usuário fala",
            "Barge-in real no navegador: para TTS quando usuário volta a falar",
            "Transcrição parcial e final",
            "TTS pausado, mais lento e mais audível",
            "Preparado para faster-whisper, whisper.cpp, Piper, Coqui XTTS, F5-TTS e OpenVoice",
            "Preparado para voz própria autorizada",
            "Avatar com estados: idle, listening, thinking, speaking, interrupted e error",
            "Roteamento automático do texto final para o HAL escolher a ferramenta correta",
        ],
        "browser_ready": True,
        "local_adapters_ready": True,
        "production_note": "Para qualidade próxima de GPT-Live/Alexa, instalar STT/TTS local neural e, para voz própria, fornecer amostra autorizada.",
    }


def get_config() -> dict[str, Any]:
    return {"ok": True, "config": _load(CONFIG_FILE, DEFAULT_CONFIG), "engine_options": ENGINE_OPTIONS}


def update_config(config: dict[str, Any]) -> dict[str, Any]:
    current = _load(CONFIG_FILE, DEFAULT_CONFIG)
    merged = _deep_merge(current, config or {})
    _save(CONFIG_FILE, merged)
    _event({"event": "update_config"})
    return {"ok": True, "config": merged, "summary": "Configuração do Real-Time Voice Engine atualizada."}


def _deep_merge(base: dict[str, Any], changes: dict[str, Any]) -> dict[str, Any]:
    out = dict(base)
    for k, v in changes.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def start_session(user_name: str = "", mode: str = "assistant", channel: str = "web") -> dict[str, Any]:
    data = _load(SESSIONS_FILE, {"sessions": []})
    sid = f"rtv_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    session = {
        "id": sid,
        "user_name": user_name,
        "mode": mode,
        "channel": channel,
        "status": "active",
        "state": "idle",
        "partial_transcript": "",
        "final_transcript": "",
        "last_route": "",
        "created_at": _now(),
        "updated_at": _now(),
        "events": [],
    }
    data.setdefault("sessions", []).insert(0, session)
    _save(SESSIONS_FILE, data)
    _event({"event": "start_session", "session_id": sid, "mode": mode, "channel": channel})
    return {"ok": True, "session": session, "summary": "Sessão de voz em tempo real iniciada."}


def list_sessions(limit: int = 50) -> dict[str, Any]:
    data = _load(SESSIONS_FILE, {"sessions": []})
    sessions = data.get("sessions", [])
    return {"ok": True, "sessions": sessions[:max(1, min(limit, 200))], "count": len(sessions)}


def update_session_state(session_id: str, state: str, partial_transcript: str = "", final_transcript: str = "", route: str = "") -> dict[str, Any]:
    data = _load(SESSIONS_FILE, {"sessions": []})
    sessions = data.get("sessions", [])
    for s in sessions:
        if s.get("id") == session_id:
            s["state"] = state
            s["updated_at"] = _now()
            if partial_transcript:
                s["partial_transcript"] = partial_transcript
            if final_transcript:
                s["final_transcript"] = final_transcript
            if route:
                s["last_route"] = route
            s.setdefault("events", []).append({"ts": _now(), "state": state, "partial": partial_transcript, "final": final_transcript, "route": route})
            _save(SESSIONS_FILE, data)
            _event({"event": "update_session_state", "session_id": session_id, "state": state})
            return {"ok": True, "session": s}
    return {"ok": False, "summary": "Sessão não encontrada."}


def stop_session(session_id: str) -> dict[str, Any]:
    data = _load(SESSIONS_FILE, {"sessions": []})
    sessions = data.get("sessions", [])
    for s in sessions:
        if s.get("id") == session_id:
            s["status"] = "stopped"
            s["state"] = "idle"
            s["updated_at"] = _now()
            _save(SESSIONS_FILE, data)
            _event({"event": "stop_session", "session_id": session_id})
            return {"ok": True, "session": s, "summary": "Sessão de voz encerrada."}
    return {"ok": False, "summary": "Sessão não encontrada."}


def turn_policy() -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    return {
        "ok": True,
        "policy": cfg["turn_taking"],
        "noise_handling": cfg["noise_handling"],
        "recommended_client_behavior": [
            "Começar escuta contínua após clique do usuário.",
            "Enquanto houver fala detectada, não enviar pergunta ao backend.",
            "Enviar ao backend apenas a transcrição final após silêncio final.",
            "Se usuário falar enquanto o TTS toca, cancelar speechSynthesis imediatamente.",
            "Mostrar estado visual do avatar: ouvindo, pensando, falando ou interrompido.",
            "Quando confiança for baixa, pedir esclarecimento antes de rotear ferramenta.",
        ],
    }


def client_script_spec() -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    return {
        "ok": True,
        "frontend_events": [
            "rtv:start",
            "rtv:listening",
            "rtv:partial_transcript",
            "rtv:final_transcript",
            "rtv:thinking",
            "rtv:speaking",
            "rtv:barge_in",
            "rtv:error",
            "rtv:stop",
        ],
        "browser_requirements": [
            "Chrome ou Edge recomendados",
            "Permissão de microfone",
            "SpeechRecognition/webkitSpeechRecognition para protótipo",
            "speechSynthesis para TTS browser",
            "HTTPS ou localhost para microfone",
        ],
        "config": cfg,
        "notes": "O modo browser permite uma demo funcional rápida. O modo produção deve usar faster-whisper/Piper/Coqui/F5 local no backend.",
    }


def local_install_plan(cpu_only: bool = True, has_gpu: bool = False, vram_gb: int = 0) -> dict[str, Any]:
    tier = "CPU"
    if has_gpu:
        tier = "GPU 24GB+" if vram_gb >= 24 else "GPU 8-16GB"
    if cpu_only or not has_gpu:
        stt = ["whisper.cpp", "faster-whisper small/base"]
        tts = ["Piper pt-BR"]
        custom = ["Coqui XTTS/F5-TTS pode funcionar, mas será lento sem GPU"]
    elif vram_gb >= 24:
        stt = ["faster-whisper large-v3"]
        tts = ["F5-TTS", "Coqui XTTS", "OpenVoice"]
        custom = ["Voz própria autorizada com melhor qualidade"]
    else:
        stt = ["faster-whisper medium/small"]
        tts = ["Piper", "Coqui XTTS menor", "F5-TTS otimizado"]
        custom = ["Voz própria autorizada com ajustes de latência"]
    return {
        "ok": True,
        "hardware_tier": tier,
        "recommended_stt": stt,
        "recommended_tts": tts,
        "custom_voice": custom,
        "steps": [
            "Instalar dependências de áudio no sistema operacional.",
            "Instalar STT local escolhido.",
            "Instalar TTS local escolhido.",
            "Baixar modelo pt-BR compatível.",
            "Configurar caminhos no arquivo data/realtime_voice_engine/config.json.",
            "Testar microfone no navegador.",
            "Validar barge-in e silêncio final.",
            "Se usar voz própria, adicionar amostra autorizada em audio_samples.",
        ],
    }


def voice_sample_requirements() -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    return {
        "ok": True,
        "profile": cfg["custom_voice"],
        "legal_and_ethics": [
            "Usar somente voz própria ou voz com autorização explícita.",
            "Manter amostra local por padrão.",
            "Avisar usuários quando uma voz sintética/customizada estiver sendo usada.",
        ],
        "recording": [
            "3 minutos mínimo; 5 a 10 minutos recomendado.",
            "WAV, MP3 ou M4A.",
            "Ambiente silencioso.",
            "Fala natural em português do Brasil.",
            "Frases curtas e longas, saudações, explicações técnicas e pausas.",
            "Sem música de fundo.",
        ],
        "suggested_script": (
            "Olá, eu sou o Aprigio. Esta é uma amostra autorizada para configurar a voz do HAL. "
            "O objetivo é uma fala clara, natural, com sotaque paulista, pausada e agradável. "
            "O HAL deve responder com educação, objetividade e humildade, sem interromper o usuário."
        ),
    }


def natural_response_preset(text: str) -> dict[str, Any]:
    cleaned = (text or "").strip()
    # Pequeno pós-processamento para fala mais natural em TTS.
    speakable = cleaned.replace("JR-AI", "Jota Erre AI").replace("SQL", "éssi quê éle").replace("BI", "B I").replace("RAG", "R A G")
    speakable = speakable.replace("HAL", "Hall")
    return {
        "ok": True,
        "original": cleaned,
        "speakable": speakable,
        "tts": _load(CONFIG_FILE, DEFAULT_CONFIG)["tts"],
        "guidance": "Falar mais lento, com pausas curtas entre frases e tom cordial/profissional.",
    }


def answer_for_realtime_voice(message: str = "") -> str:
    return (
        "Vou usar o HAL Real-Time Voice Engine. "
        "Essa camada adiciona escuta contínua, detecção de pausa, barge-in, transcrição parcial/final, TTS mais lento e audível, "
        "avatar com estados de voz e roteamento automático para a ferramenta correta. "
        "Para atingir voz realmente natural no nível comercial, use Piper/Coqui/F5/OpenVoice local e, se desejar sua voz, envie uma amostra autorizada."
    )
