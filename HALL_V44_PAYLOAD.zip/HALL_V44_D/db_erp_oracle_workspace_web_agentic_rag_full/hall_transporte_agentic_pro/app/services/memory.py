from __future__ import annotations

import json
import math
import re
import time
import uuid
from collections import Counter
from pathlib import Path
from typing import Any

from app.core.config import root_dir

MEMORY_FILE = root_dir() / "data" / "memory" / "memories.json"


def _ensure() -> None:
    MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not MEMORY_FILE.exists():
        MEMORY_FILE.write_text(json.dumps({"items": []}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load() -> dict[str, Any]:
    _ensure()
    try:
        return json.loads(MEMORY_FILE.read_text(encoding="utf-8-sig"))
    except Exception:
        return {"items": []}


def _save(data: dict[str, Any]) -> None:
    _ensure()
    MEMORY_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def tokenize(text: str) -> list[str]:
    text = (text or "").lower()
    text = re.sub(r"[^a-záéíóúãõâêôç0-9 ]+", " ", text)
    return [t for t in text.split() if len(t) >= 3]


def vectorize(text: str) -> dict[str, float]:
    counts = Counter(tokenize(text))
    norm = math.sqrt(sum(v * v for v in counts.values())) or 1.0
    return {k: v / norm for k, v in counts.items()}


def cosine(a: dict[str, float], b: dict[str, float]) -> float:
    return sum(a.get(k, 0.0) * b.get(k, 0.0) for k in set(a) & set(b))


def add_memory(text: str, tags: list[str] | None = None, source: str = "manual", importance: int = 3) -> dict[str, Any]:
    text = (text or "").strip()
    if not text:
        return {"ok": False, "summary": "Memória vazia."}
    item = {
        "id": f"mem_{uuid.uuid4().hex[:10]}",
        "text": text,
        "tags": tags or [],
        "source": source,
        "importance": max(1, min(5, int(importance))),
        "embedding": vectorize(text + " " + " ".join(tags or [])),
        "created_at": _now(),
        "updated_at": _now(),
    }
    data = _load()
    data.setdefault("items", []).insert(0, item)
    _save(data)
    return {"ok": True, "memory": item, "summary": "Memória salva localmente."}


def search(query: str, limit: int = 8) -> dict[str, Any]:
    qv = vectorize(query)
    data = _load()
    scored = []
    for item in data.get("items", []):
        emb = item.get("embedding") or vectorize(item.get("text", ""))
        score = cosine(qv, emb) + item.get("importance", 3) * 0.02
        if score > 0.02:
            it = {k: v for k, v in item.items() if k != "embedding"}
            it["score"] = round(score, 4)
            scored.append((score, it))
    scored.sort(key=lambda x: x[0], reverse=True)
    return {"ok": True, "query": query, "rows": [x[1] for x in scored[:limit]], "count": len(scored)}


def list_memories(limit: int = 100) -> dict[str, Any]:
    data = _load()
    rows = [{k: v for k, v in m.items() if k != "embedding"} for m in data.get("items", [])[:limit]]
    return {"ok": True, "rows": rows, "count": len(data.get("items", []))}


def extract_memory_request(message: str) -> str:
    raw = (message or "").strip()
    low = raw.lower()
    patterns = [
        "lembre que ", "memorize que ", "guarde que ",
        "salve na memória que ", "salve na memoria que ", "anote que "
    ]
    for p in patterns:
        idx = low.find(p)
        if idx >= 0:
            return raw[idx + len(p):].strip(" .")
    return ""


def maybe_remember(message: str) -> dict[str, Any]:
    text = extract_memory_request(message)
    if not text:
        return {"ok": False, "remembered": False}
    return add_memory(text, tags=["hall", "voz", "preferencia"], source="conversation", importance=4)
