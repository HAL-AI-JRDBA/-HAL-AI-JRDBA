from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _slug(text: str) -> str:
    import re
    text = (text or "item").lower()
    text = re.sub(r"[^a-z0-9áéíóúãõâêôç]+", "-", text)
    text = (text.replace("á","a").replace("é","e").replace("í","i").replace("ó","o").replace("ú","u")
            .replace("ã","a").replace("õ","o").replace("â","a").replace("ê","e").replace("ô","o").replace("ç","c"))
    return re.sub(r"-+", "-", text).strip("-") or "item"


def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists():
        path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(path: Path, event: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")

DATA_DIR = root_dir() / "data" / "cron_enterprise"
JOBS_FILE = DATA_DIR / "scheduled_jobs.json"
RUNS_FILE = DATA_DIR / "runs.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"

FREQUENCIES = ["once", "hourly", "daily", "weekly", "monthly", "cron_expression"]


def status() -> dict[str, Any]:
    jobs = _load(JOBS_FILE, {"jobs": []}).get("jobs", [])
    runs = _load(RUNS_FILE, {"runs": []}).get("runs", [])
    return {
        "ok": True,
        "name": "HAL Cron Enterprise",
        "description": "Agendador enterprise para jobs recorrentes/robustos, retry, logs, entrega por canal e execução como serviço.",
        "jobs_count": len(jobs),
        "enabled_jobs": len([j for j in jobs if j.get("enabled")]),
        "runs_count": len(runs),
        "capabilities": [
            "Agendamento diário/semanal/mensal/cron",
            "Retry automático",
            "Histórico de execuções",
            "Entrega por canal",
            "Integração com Agent Runtime, n8n, Channel Gateway e monitoramento",
            "Plano de instalação como serviço Windows/systemd",
        ],
    }


def create_job(name: str, prompt: str, frequency: str = "daily", cron: str = "", channel: str = "", enabled: bool = True, max_retries: int = 3) -> dict[str, Any]:
    if frequency not in FREQUENCIES:
        return {"ok": False, "summary": "Frequência não suportada.", "available": FREQUENCIES}
    data = _load(JOBS_FILE, {"jobs": []})
    jid = f"cron_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    job = {
        "id": jid,
        "name": name,
        "prompt": prompt,
        "frequency": frequency,
        "cron": cron,
        "channel": channel,
        "enabled": enabled,
        "max_retries": max_retries,
        "status": "scheduled" if enabled else "disabled",
        "created_at": _now(),
        "updated_at": _now(),
        "next_run_hint": next_run_hint(frequency, cron),
    }
    data.setdefault("jobs", []).insert(0, job)
    _save(JOBS_FILE, data)
    _audit(AUDIT_FILE, {"event": "create_job", "job_id": jid})
    return {"ok": True, "job": job, "summary": "Job agendado."}


def next_run_hint(frequency: str, cron: str = "") -> str:
    if frequency == "hourly":
        return "próxima hora"
    if frequency == "daily":
        return "próximo dia no horário configurado"
    if frequency == "weekly":
        return "próxima semana"
    if frequency == "monthly":
        return "próximo mês"
    if frequency == "cron_expression":
        return f"cron: {cron}"
    return "execução única"


def list_jobs(limit: int = 100) -> dict[str, Any]:
    jobs = _load(JOBS_FILE, {"jobs": []}).get("jobs", [])
    return {"ok": True, "jobs": jobs[:max(1, min(limit, 500))], "count": len(jobs)}


def set_enabled(job_id: str, enabled: bool) -> dict[str, Any]:
    data = _load(JOBS_FILE, {"jobs": []})
    for job in data.get("jobs", []):
        if job.get("id") == job_id:
            job["enabled"] = enabled
            job["status"] = "scheduled" if enabled else "disabled"
            job["updated_at"] = _now()
            _save(JOBS_FILE, data)
            _audit(AUDIT_FILE, {"event": "set_enabled", "job_id": job_id, "enabled": enabled})
            return {"ok": True, "job": job, "summary": "Job atualizado."}
    return {"ok": False, "summary": "Job não encontrado."}


def run_job(job_id: str, approved: bool = False) -> dict[str, Any]:
    jobs = _load(JOBS_FILE, {"jobs": []}).get("jobs", [])
    job = next((j for j in jobs if j.get("id") == job_id), None)
    if not job:
        return {"ok": False, "summary": "Job não encontrado."}
    run = {
        "id": f"run_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "job_id": job_id,
        "job_name": job.get("name"),
        "prompt": job.get("prompt"),
        "approved": approved,
        "status": "ready_to_execute" if approved else "waiting_approval",
        "attempt": 1,
        "created_at": _now(),
        "delivery_channel": job.get("channel"),
    }
    data = _load(RUNS_FILE, {"runs": []})
    data.setdefault("runs", []).insert(0, run)
    _save(RUNS_FILE, data)
    _audit(AUDIT_FILE, {"event": "run_job", "job_id": job_id, "status": run["status"]})
    return {"ok": True, "run": run, "summary": "Execução aguardando aprovação." if not approved else "Execução pronta."}


def list_runs(limit: int = 100) -> dict[str, Any]:
    runs = _load(RUNS_FILE, {"runs": []}).get("runs", [])
    return {"ok": True, "runs": runs[:max(1, min(limit, 500))], "count": len(runs)}


def service_install_plan() -> dict[str, Any]:
    return {
        "ok": True,
        "windows_service": [
            "Usar NSSM ou Task Scheduler",
            "Comando: python -m app.services.cron_worker",
            "Executar com usuário de serviço sem privilégios administrativos",
        ],
        "linux_systemd": [
            "Criar /etc/systemd/system/jr-ai-hall-cron.service",
            "ExecStart=/usr/bin/python -m app.services.cron_worker",
            "Restart=always",
        ],
        "production_recommendations": [
            "Persistir runs",
            "Retry com backoff",
            "Alertar falhas pelo Channel Gateway",
            "Separar jobs críticos com aprovação",
        ],
    }


def answer_for_cron(message: str = "") -> str:
    return "Vou usar o HAL Cron Enterprise para agendar tarefas recorrentes com retry, logs, aprovação humana, entrega por canal e execução como serviço Windows/systemd."
