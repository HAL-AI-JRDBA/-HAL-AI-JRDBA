from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir

DATA_DIR = root_dir() / "data" / "open_ai_access_center"
INSTALLED_AGENTS_FILE = DATA_DIR / "installed_agents.json"
PROFILES_FILE = DATA_DIR / "deployment_profiles.json"
ROI_FILE = DATA_DIR / "roi_cases.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"
BACKUP_DIR = DATA_DIR / "backups"

HARDWARE_PROFILES: dict[str, dict[str, Any]] = {
    "cpu_light": {
        "label": "CPU leve / notebook comum",
        "description": "Ambiente sem GPU, ideal para demo, pequenas empresas e tarefas de baixa latência com modelos pequenos/quantizados.",
        "ram_min_gb": 8,
        "gpu_required": False,
        "recommended_runtime": "Ollama ou llama.cpp com modelos 2B a 7B quantizados",
        "recommended_models": ["qwen2.5:3b", "gemma3:4b", "phi3:mini", "nomic-embed-text"],
    },
    "cpu_standard": {
        "label": "CPU forte / servidor pequeno",
        "description": "Servidor sem GPU, com boa RAM, adequado para RAG, atendimento, SQL assistido e agentes leves.",
        "ram_min_gb": 16,
        "gpu_required": False,
        "recommended_runtime": "Ollama/llama.cpp com modelos 7B a 14B quantizados",
        "recommended_models": ["qwen2.5:7b", "llama3.1:8b", "qwen2.5-coder:7b", "mxbai-embed-large"],
    },
    "gpu_8gb": {
        "label": "GPU 8GB",
        "description": "Cliente com GPU de entrada. Boa para voz, visão leve, agentes e modelos 7B/8B mais rápidos.",
        "ram_min_gb": 16,
        "gpu_required": True,
        "vram_min_gb": 8,
        "recommended_runtime": "Ollama com CUDA/ROCm ou llama.cpp GPU offload",
        "recommended_models": ["qwen2.5:7b", "llama3.1:8b", "qwen2.5-coder:7b", "llava:7b", "nomic-embed-text"],
    },
    "gpu_16gb": {
        "label": "GPU 16GB",
        "description": "Perfil corporativo intermediário para agentes, Dev Studio, SaaS Builder, voz/visão e BI com mais qualidade.",
        "ram_min_gb": 32,
        "gpu_required": True,
        "vram_min_gb": 16,
        "recommended_runtime": "Ollama com modelos 14B/32B quantizados conforme memória",
        "recommended_models": ["qwen2.5:14b", "qwen2.5-coder:14b", "deepseek-coder-v2", "llava:13b", "mxbai-embed-large"],
    },
    "gpu_24gb_plus": {
        "label": "GPU 24GB+ / Enterprise",
        "description": "Perfil avançado para clientes com GPU robusta, múltiplos agentes, código, visão, voz neural e tarefas longas.",
        "ram_min_gb": 64,
        "gpu_required": True,
        "vram_min_gb": 24,
        "recommended_runtime": "Ollama/vLLM/TGI conforme política local do cliente",
        "recommended_models": ["qwen2.5:32b", "qwen2.5-coder:32b", "deepseek-coder-v2", "llama3.1:70b", "bge-m3"],
    },
}

MODEL_CATALOG: dict[str, dict[str, Any]] = {
    "conversation_router": {
        "label": "Conversa, intenção e roteamento HAL",
        "purpose": "Entender usuário, manter contexto, escolher ferramenta correta e responder com clareza.",
        "models": [
            {"key": "qwen2.5", "label": "Qwen 2.5", "sizes": ["3b", "7b", "14b", "32b"], "local": True, "open": "open-weight"},
            {"key": "llama3.1", "label": "Llama 3.1", "sizes": ["8b", "70b"], "local": True, "open": "open-weight"},
            {"key": "gemma3", "label": "Gemma", "sizes": ["4b", "12b", "27b"], "local": True, "open": "open-weight"},
        ],
    },
    "code_dev_saas": {
        "label": "Código, Dev Studio, Codex Local e SaaS Builder",
        "purpose": "Gerar código, testes, patches, revisão, debug, apps/sites e fluxos de desenvolvimento.",
        "models": [
            {"key": "qwen2.5-coder", "label": "Qwen Coder", "sizes": ["7b", "14b", "32b"], "local": True, "open": "open-weight"},
            {"key": "deepseek-coder-v2", "label": "DeepSeek Coder V2", "sizes": ["lite", "full"], "local": True, "open": "open-source/open-weight"},
            {"key": "starcoder2", "label": "StarCoder2", "sizes": ["3b", "7b", "15b"], "local": True, "open": "open"},
        ],
    },
    "rag_embeddings": {
        "label": "RAG, documentos e busca semântica",
        "purpose": "Indexar documentos, manuais, normas, contratos, políticas e conhecimento interno.",
        "models": [
            {"key": "nomic-embed-text", "label": "Nomic Embed Text", "type": "embedding", "local": True},
            {"key": "mxbai-embed-large", "label": "MxBai Embed Large", "type": "embedding", "local": True},
            {"key": "bge-m3", "label": "BGE-M3", "type": "embedding/reranker", "local": True},
        ],
    },
    "voice": {
        "label": "Voz em tempo real",
        "purpose": "STT, TTS, barge-in, fala natural e voz própria autorizada.",
        "models": [
            {"key": "faster-whisper", "label": "faster-whisper", "type": "stt", "local": True},
            {"key": "whisper.cpp", "label": "whisper.cpp", "type": "stt", "local": True},
            {"key": "piper", "label": "Piper TTS", "type": "tts", "local": True},
            {"key": "coqui-xtts", "label": "Coqui XTTS", "type": "tts_clone", "local": True},
            {"key": "f5-tts", "label": "F5-TTS", "type": "tts_clone", "local": True},
            {"key": "openvoice", "label": "OpenVoice", "type": "voice_conversion", "local": True},
        ],
    },
    "vision": {
        "label": "Visão de tela, câmera e dashboards",
        "purpose": "Analisar tela, gráficos, imagens, dashboards, câmera e documentos visuais.",
        "models": [
            {"key": "llava", "label": "LLaVA", "sizes": ["7b", "13b"], "local": True},
            {"key": "qwen-vl", "label": "Qwen-VL", "sizes": ["varia por distribuição"], "local": True},
            {"key": "gemma-multimodal", "label": "Gemma multimodal", "sizes": ["quando disponível no ambiente"], "local": True},
        ],
    },
    "sql_dba_bi": {
        "label": "SQL, DBA, BI e bancos relacionais/NoSQL",
        "purpose": "Consultas, diagnóstico, explicação de SQL, índices, dashboards e dados empresariais.",
        "models": [
            {"key": "qwen2.5-coder", "label": "Qwen Coder", "local": True},
            {"key": "deepseek-coder-v2", "label": "DeepSeek Coder", "local": True},
            {"key": "qwen2.5", "label": "Qwen geral", "local": True},
        ],
    },
}

BUSINESS_MODES: dict[str, dict[str, Any]] = {
    "small_business": {
        "label": "Empresa pequena / entrada rápida",
        "description": "Instalação leve, baixo custo, foco em atendimento, documentos, dados simples e produtividade imediata.",
        "features": ["Console Unificado", "Human Voice", "RAG", "Atendimento", "1 a 3 agentes", "ROI simples"],
        "recommended_profile": "cpu_light",
    },
    "professional": {
        "label": "Empresa média / operação completa",
        "description": "Inclui dados, BI, bancos, agentes, monitoramento e automações com aprovação.",
        "features": ["Business Teams", "SQL Copilot", "Power BI", "Zabbix/Grafana", "Agent Runtime", "5 a 10 agentes"],
        "recommended_profile": "cpu_standard",
    },
    "enterprise_local": {
        "label": "Enterprise Local / cliente com infraestrutura",
        "description": "Instalação local/on-premise com GPU, RBAC, auditoria, múltiplos usuários, tarefas longas e voz/visão avançadas.",
        "features": ["GPU", "RBAC", "logs", "agentes paralelos", "sandbox", "voz neural", "PWA/HTTPS/VPN"],
        "recommended_profile": "gpu_16gb",
    },
}

AGENT_MARKETPLACE: dict[str, dict[str, Any]] = {
    "hall_financeiro": {"label": "Funcionário Digital Financeiro", "area": "Financeiro/Contábil", "tools": ["SQL Copilot", "Power BI", "RAG", "Agent Runtime"], "approval": True},
    "hall_ti_dba": {"label": "Funcionário Digital TI/DBA", "area": "TI/DBA", "tools": ["DBA", "Zabbix", "Grafana", "SQL", "Agent Runtime"], "approval": True},
    "hall_atendimento": {"label": "Funcionário Digital Atendimento", "area": "Atendimento", "tools": ["RAG", "WhatsApp adapter", "Human Voice", "Governança"], "approval": True},
    "hall_vendas_sdr": {"label": "Funcionário Digital Vendas/SDR", "area": "Vendas", "tools": ["CRM", "RAG", "Business Teams", "E-mail/WhatsApp"], "approval": True},
    "hall_dados_bi": {"label": "Funcionário Digital Dados/BI", "area": "Dados/BI", "tools": ["SQL", "NoSQL", "Power BI", "ChartDB", "RAG"], "approval": False},
    "hall_operacoes": {"label": "Funcionário Digital Operações", "area": "Operações", "tools": ["BI", "Zabbix/Grafana", "RAG", "Agent Runtime"], "approval": True},
    "hall_dev_saas": {"label": "Funcionário Digital Dev/SaaS Builder", "area": "Desenvolvimento", "tools": ["Dev Studio", "SaaS Builder", "Sandbox", "TDD", "Git"], "approval": True},
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    if not INSTALLED_AGENTS_FILE.exists():
        INSTALLED_AGENTS_FILE.write_text(json.dumps({"installed_agents": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not PROFILES_FILE.exists():
        PROFILES_FILE.write_text(json.dumps({"active_profile": "cpu_light", "business_mode": "small_business", "history": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not ROI_FILE.exists():
        ROI_FILE.write_text(json.dumps({"cases": []}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def status() -> dict[str, Any]:
    profiles = _load(PROFILES_FILE, {"active_profile": "cpu_light", "business_mode": "small_business", "history": []})
    installed = _load(INSTALLED_AGENTS_FILE, {"installed_agents": []}).get("installed_agents", [])
    return {
        "ok": True,
        "name": "HAL Open AI Access Center",
        "description": "Centro para democratizar IA local/open-source: instalação simplificada, escolha CPU/GPU, catálogo de modelos, marketplace de agentes, acesso seguro, ROI e atualização.",
        "active_profile": profiles.get("active_profile"),
        "business_mode": profiles.get("business_mode"),
        "installed_agents_count": len(installed),
        "hardware_profiles_count": len(HARDWARE_PROFILES),
        "model_categories_count": len(MODEL_CATALOG),
        "marketplace_agents_count": len(AGENT_MARKETPLACE),
        "capabilities": [
            "Escolha guiada entre CPU e GPU",
            "Catálogo de modelos open-source/open-weight por função",
            "Plano de download via Ollama/llama.cpp",
            "Modo empresa pequena, profissional e enterprise local",
            "Marketplace de funcionários digitais e agentes",
            "Acesso externo seguro para celular, tablet e navegador",
            "PWA/mobile-ready, VPN/HTTPS/reverse proxy planejado",
            "Calculadora de ROI e valor econômico",
            "Backup, atualização e rollback seguros",
            "Tudo local-first, sem dependência obrigatória de APIs fechadas",
        ],
    }


def hardware_profiles() -> dict[str, Any]:
    return {"ok": True, "profiles": [{"key": k, **v} for k, v in HARDWARE_PROFILES.items()]}


def model_catalog() -> dict[str, Any]:
    return {"ok": True, "catalog": [{"key": k, **v} for k, v in MODEL_CATALOG.items()]}


def business_modes() -> dict[str, Any]:
    return {"ok": True, "modes": [{"key": k, **v} for k, v in BUSINESS_MODES.items()]}


def marketplace() -> dict[str, Any]:
    return {"ok": True, "agents": [{"key": k, **v} for k, v in AGENT_MARKETPLACE.items()], **_load(INSTALLED_AGENTS_FILE, {"installed_agents": []})}


def set_profile(profile: str, business_mode: str = "") -> dict[str, Any]:
    if profile not in HARDWARE_PROFILES:
        return {"ok": False, "summary": "Perfil de hardware não encontrado.", "available": list(HARDWARE_PROFILES)}
    if business_mode and business_mode not in BUSINESS_MODES:
        return {"ok": False, "summary": "Modo de negócio não encontrado.", "available_modes": list(BUSINESS_MODES)}
    data = _load(PROFILES_FILE, {"active_profile": "cpu_light", "business_mode": "small_business", "history": []})
    data["active_profile"] = profile
    if business_mode:
        data["business_mode"] = business_mode
    data.setdefault("history", []).insert(0, {"ts": _now(), "profile": profile, "business_mode": data.get("business_mode")})
    _save(PROFILES_FILE, data)
    _audit({"event": "set_profile", "profile": profile, "business_mode": data.get("business_mode")})
    return {"ok": True, "profile": HARDWARE_PROFILES[profile], "business_mode": data.get("business_mode"), "summary": "Perfil de acesso à IA atualizado."}


def recommend_stack(profile: str = "", use_case: str = "geral", business_mode: str = "") -> dict[str, Any]:
    if not profile:
        profile = _load(PROFILES_FILE, {"active_profile": "cpu_light"}).get("active_profile", "cpu_light")
    if profile not in HARDWARE_PROFILES:
        profile = "cpu_light"
    hw = HARDWARE_PROFILES[profile]
    use_case_l = (use_case or "").lower()
    categories = ["conversation_router", "rag_embeddings"]
    if any(x in use_case_l for x in ["código", "codigo", "dev", "saas", "app", "site", "debug", "teste"]):
        categories.append("code_dev_saas")
    if any(x in use_case_l for x in ["voz", "audio", "áudio", "fala", "microfone"]):
        categories.append("voice")
    if any(x in use_case_l for x in ["visão", "visao", "tela", "camera", "imagem", "dashboard"]):
        categories.append("vision")
    if any(x in use_case_l for x in ["sql", "banco", "oracle", "mongo", "mongodb", "bi", "power bi", "dba"]):
        categories.append("sql_dba_bi")
    categories = list(dict.fromkeys(categories))
    commands = ollama_pull_plan(profile, categories)
    return {
        "ok": True,
        "profile_key": profile,
        "hardware": hw,
        "business_mode": business_mode or _load(PROFILES_FILE, {"business_mode": "small_business"}).get("business_mode"),
        "use_case": use_case,
        "categories": [{"key": c, **MODEL_CATALOG[c]} for c in categories],
        "recommended_models": hw.get("recommended_models", []),
        "ollama_commands": commands,
        "notes": [
            "Validar nomes/tags dos modelos no ambiente Ollama do cliente antes de baixar.",
            "Sem GPU, priorizar modelos pequenos/quantizados e RAG com embeddings leves.",
            "Com GPU, liberar modelos maiores, voz neural, visão e agentes paralelos.",
        ],
    }


def ollama_pull_plan(profile: str, categories: list[str] | None = None) -> list[str]:
    cats = categories or ["conversation_router", "rag_embeddings"]
    model_candidates = []
    hw = HARDWARE_PROFILES.get(profile, HARDWARE_PROFILES["cpu_light"])
    model_candidates.extend(hw.get("recommended_models", []))
    if "code_dev_saas" in cats:
        model_candidates.append("qwen2.5-coder:7b" if profile.startswith("cpu") else "qwen2.5-coder:14b")
    if "vision" in cats:
        model_candidates.append("llava:7b")
    if "rag_embeddings" in cats:
        model_candidates.append("nomic-embed-text")
    # Preserve order and uniqueness
    unique = []
    for m in model_candidates:
        if m and m not in unique:
            unique.append(m)
    return [f"ollama pull {m}" for m in unique]


def installer_plan(profile: str = "cpu_light", business_mode: str = "small_business") -> dict[str, Any]:
    if profile not in HARDWARE_PROFILES:
        profile = "cpu_light"
    if business_mode not in BUSINESS_MODES:
        business_mode = "small_business"
    stack = recommend_stack(profile, business_mode=business_mode, use_case="geral voz rag sql agentes")
    return {
        "ok": True,
        "title": "Instalador guiado JR-AI/HAL",
        "profile": HARDWARE_PROFILES[profile],
        "business_mode": BUSINESS_MODES[business_mode],
        "steps": [
            "Verificar Python, Node e Git.",
            "Instalar dependências do projeto.",
            "Instalar Ollama ou runtime local equivalente.",
            "Selecionar perfil CPU/GPU.",
            "Baixar modelos recomendados.",
            "Criar usuário admin local.",
            "Configurar porta local, HTTPS/VPN se necessário.",
            "Ativar marketplace de agentes conforme segmento.",
            "Executar health check.",
            "Gerar backup inicial e ponto de rollback.",
        ],
        "commands": [
            "INSTALAR_TUDO_JR_AI_HALL_COMPLETO.bat",
            *stack["ollama_commands"],
            "INICIAR_JR_AI_CONSOLE_UNIFICADO.bat",
        ],
        "output_url": "http://127.0.0.1:8000",
    }


def enable_agent(agent_key: str) -> dict[str, Any]:
    if agent_key not in AGENT_MARKETPLACE:
        return {"ok": False, "summary": "Agente não encontrado no marketplace.", "available": list(AGENT_MARKETPLACE)}
    data = _load(INSTALLED_AGENTS_FILE, {"installed_agents": []})
    installed = data.setdefault("installed_agents", [])
    if not any(a.get("key") == agent_key for a in installed):
        installed.insert(0, {"key": agent_key, **AGENT_MARKETPLACE[agent_key], "installed_at": _now(), "status": "enabled"})
    _save(INSTALLED_AGENTS_FILE, data)
    _audit({"event": "enable_agent", "agent_key": agent_key})
    return {"ok": True, "agent": AGENT_MARKETPLACE[agent_key], "summary": "Funcionário digital/agente habilitado."}


def secure_access_plan(exposure: str = "vpn", domain: str = "") -> dict[str, Any]:
    exposure = exposure or "vpn"
    options = {
        "local_only": ["Acesso somente http://127.0.0.1:8000", "Sem exposição externa", "Ideal para laboratório e dados muito sensíveis"],
        "lan": ["Acesso pela rede interna", "Firewall liberando apenas rede corporativa", "Usuários autenticados"],
        "vpn": ["Acesso remoto por VPN", "Sem publicar porta aberta na internet", "Recomendado para clientes enterprise"],
        "reverse_proxy_https": ["Nginx/Caddy com HTTPS", "Domínio próprio", "RBAC/JWT", "Logs e rate limit"],
        "zero_trust": ["Proxy Zero Trust", "Autenticação por identidade", "Políticas por usuário/dispositivo", "Indicado para celular/tablet remoto"],
    }
    return {
        "ok": True,
        "exposure": exposure,
        "domain": domain,
        "recommended_steps": options.get(exposure, options["vpn"]),
        "mobile_pwa": {
            "enabled_plan": True,
            "targets": ["iPad", "Android Tablet", "iPhone", "Android", "Desktop"],
            "requirements": ["HTTPS ou localhost", "layout responsivo", "login", "permissão de microfone/câmera"],
        },
        "security_controls": ["JWT/RBAC", "aprovação humana", "logs", "cofre de segredos", "read-only por padrão", "LGPD", "backup/rollback"],
    }


def roi_calculator(employees: int = 5, hours_per_week: float = 6, hourly_cost: float = 60, reduction_percent: float = 40, monthly_fee: float = 3500) -> dict[str, Any]:
    monthly_hours = employees * hours_per_week * 4.33
    monthly_waste = monthly_hours * hourly_cost
    savings = monthly_waste * (reduction_percent / 100.0)
    net = savings - monthly_fee
    roi = (net / monthly_fee * 100.0) if monthly_fee else 0
    case = {
        "id": f"roi_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "employees": employees,
        "hours_per_week": hours_per_week,
        "hourly_cost": hourly_cost,
        "reduction_percent": reduction_percent,
        "monthly_fee": monthly_fee,
        "monthly_hours_affected": round(monthly_hours, 2),
        "monthly_waste_cost": round(monthly_waste, 2),
        "estimated_monthly_savings": round(savings, 2),
        "estimated_net_gain": round(net, 2),
        "estimated_roi_percent": round(roi, 2),
        "created_at": _now(),
    }
    data = _load(ROI_FILE, {"cases": []})
    data.setdefault("cases", []).insert(0, case)
    _save(ROI_FILE, data)
    _audit({"event": "roi_calculator", "case_id": case["id"]})
    return {"ok": True, "case": case, "summary": "ROI estimado calculado."}


def update_and_backup_plan() -> dict[str, Any]:
    return {
        "ok": True,
        "backup_dir": str(BACKUP_DIR.relative_to(root_dir())),
        "backup_steps": [
            "Parar serviços do HAL.",
            "Copiar pasta data/, config.json e arquivos .env.",
            "Exportar lista de modelos instalados.",
            "Gerar ZIP com timestamp.",
            "Registrar hash/manifesto do backup.",
        ],
        "update_steps": [
            "Criar backup antes da atualização.",
            "Validar ZIP novo em ambiente de homologação.",
            "Executar testes de backend/frontend.",
            "Aplicar atualização preservando data/ e .env.",
            "Executar health check.",
            "Se falhar, executar rollback para backup anterior.",
        ],
        "rollback_policy": "Toda atualização deve ter backup anterior e validação de versão antes de liberar para usuários.",
    }


def health_check() -> dict[str, Any]:
    checks = {
        "data_dir": DATA_DIR.exists(),
        "profiles_file": PROFILES_FILE.exists(),
        "installed_agents_file": INSTALLED_AGENTS_FILE.exists(),
        "roi_file": ROI_FILE.exists(),
        "backup_dir": BACKUP_DIR.exists(),
    }
    return {"ok": all(checks.values()), "checks": checks, "timestamp": _now()}


def answer_for_open_access(message: str = "") -> str:
    return (
        "Vou usar o HAL Open AI Access Center. "
        "Essa camada coloca IA local e aberta na mão de qualquer empresa: escolhe CPU ou GPU, recomenda modelos open-source/open-weight, "
        "gera comandos de download via Ollama, habilita marketplace de funcionários digitais, calcula ROI, orienta acesso remoto seguro e cria plano de backup/atualização. "
        "A filosofia é local-first, sem dependência obrigatória de APIs fechadas."
    )
