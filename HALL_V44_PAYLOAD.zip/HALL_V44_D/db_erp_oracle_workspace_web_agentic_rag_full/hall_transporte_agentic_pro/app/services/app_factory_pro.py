from __future__ import annotations

import csv
import io
import json
import re
import shutil
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir

DATA_DIR = root_dir() / "data" / "app_factory_pro"
APPS_DIR = DATA_DIR / "generated_apps"
AUDIT_FILE = DATA_DIR / "audit.jsonl"
CONFIG_FILE = DATA_DIR / "config.json"
REQUESTS_FILE = DATA_DIR / "requests.json"

DEFAULT_CONFIG = {
    "enabled": True,
    "local_first": True,
    "white_label": {"brand_name": "AJDS / HAL", "primary_color": "#db2777", "logo_path": ""},
    "github": {"enabled": False, "remote_url": "", "token_env": "GITHUB_TOKEN", "default_branch": "main"},
    "deploy": {"enabled": False, "mode": "local_docker", "provider": "local", "public_url": ""},
    "ai_cost_guard": {"enabled": True, "monthly_limit_brl": 300.0, "alert_threshold_pct": 80},
    "billing": {"enabled": True, "provider": "manual_or_stripe", "failed_payment_alert": True},
}

TEMPLATES = [
    {"id": "personal_finance", "name": "Finanças Pessoais", "description": "Receitas, despesas, saldo, metas, filtros, relatórios, cobrança e teto de IA."},
    {"id": "crm", "name": "CRM Comercial", "description": "Leads, oportunidades, funil, follow-up, relatórios e atividades."},
    {"id": "clinic", "name": "Clínica / Saúde", "description": "Pacientes, agenda, atendimentos, financeiro e relatórios."},
    {"id": "store", "name": "Loja / Varejo", "description": "Produtos, vendas, estoque, clientes, caixa e relatórios."},
    {"id": "school", "name": "Escola / Cursos", "description": "Alunos, turmas, aulas, pagamentos, portal e relatórios."},
    {"id": "transport", "name": "Transporte / Logística", "description": "Frota, viagens, bilhetagem, indicadores e alertas."},
    {"id": "inventory", "name": "Estoque / Almoxarifado", "description": "Itens, entradas, saídas, níveis mínimos e inventário."},
    {"id": "helpdesk", "name": "Helpdesk", "description": "Chamados, SLA, responsáveis, status e prioridade."},
    {"id": "members_area", "name": "Área de Membros", "description": "Login, cursos, conteúdos, progresso, planos e pagamentos."},
    {"id": "booking", "name": "Agendamento", "description": "Serviços, horários, reservas, clientes e confirmação."},
]

APP_MAIN_PY = r'''from __future__ import annotations

import base64
import csv
import hashlib
import hmac
import io
import json
import os
import secrets
import sqlite3
import time
from pathlib import Path

from fastapi import FastAPI, Form, Request, Response, HTTPException, Header
from fastapi.responses import HTMLResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
DB = ROOT / "app.db"
SETTINGS_FILE = ROOT / "settings.json"
USERS_FILE = ROOT / "users.json"
AUDIT_FILE = ROOT / "audit.jsonl"
LOCAL_SECRET_FILE = ROOT / ".hall_local_session_secret"
SESSION_COOKIE = "hall_app_session"
SESSION_TTL = int(os.getenv("HALL_APP_SESSION_TTL", "28800"))
SECURE_COOKIE = os.getenv("HALL_APP_SECURE_COOKIE", "false").lower() in {"1","true","yes","s"}
LOGIN_WINDOW = 300
LOGIN_LIMIT = 5
LOGIN_ATTEMPTS = {}

app = FastAPI(title="HAL Secure Generated App")
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")

DEFAULT_SETTINGS = {
    "brand_name": "HAL App Pro",
    "billing_status": "ok",
    "billing_failed": False,
    "billing_failed_message": "Cobrança falhou: atualize o método de pagamento para evitar bloqueio.",
    "monthly_ai_cost_limit": 300.0,
    "current_ai_cost": 0.0,
    "currency": "BRL",
    "data_retention_days": 365,
    "privacy_contact": "",
}

def audit(event: str, **data):
    row = {"ts": time.strftime("%Y-%m-%d %H:%M:%S"), "event": event, **data}
    with AUDIT_FILE.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")

def _session_secret() -> bytes:
    env = os.getenv("HALL_APP_SESSION_SECRET", "").strip()
    if env:
        return env.encode("utf-8")
    if not LOCAL_SECRET_FILE.exists():
        LOCAL_SECRET_FILE.write_text(secrets.token_urlsafe(48), encoding="utf-8")
        try: os.chmod(LOCAL_SECRET_FILE, 0o600)
        except Exception: pass
    return LOCAL_SECRET_FILE.read_text(encoding="utf-8").strip().encode("utf-8")

def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")

def _unb64(text: str) -> bytes:
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))

def _sign_session(email: str, role: str) -> tuple[str, str]:
    payload = {"email": email, "role": role, "exp": int(time.time()) + SESSION_TTL, "csrf": secrets.token_urlsafe(24)}
    raw = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    body = _b64(raw); sig = _b64(hmac.new(_session_secret(), body.encode("ascii"), hashlib.sha256).digest())
    return body + "." + sig, payload["csrf"]

def _parse_session(token: str) -> dict:
    try:
        body, sig = token.split(".", 1)
        expected = _b64(hmac.new(_session_secret(), body.encode("ascii"), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, expected): return {}
        data = json.loads(_unb64(body).decode("utf-8"))
        if int(data.get("exp", 0)) < int(time.time()): return {}
        return data
    except Exception:
        return {}

def _hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return "scrypt$" + _b64(salt) + "$" + _b64(digest)

def _verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, salt_s, digest_s = encoded.split("$", 2)
        if scheme != "scrypt": return False
        salt = _unb64(salt_s); expected = _unb64(digest_s)
        actual = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32)
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False

def users() -> dict:
    if not USERS_FILE.exists(): USERS_FILE.write_text(json.dumps({"users": {}}, indent=2), encoding="utf-8")
    try: return json.loads(USERS_FILE.read_text(encoding="utf-8-sig"))
    except Exception: return {"users": {}}

def _bootstrap_admin_from_env():
    data = users(); email = os.getenv("HALL_APP_ADMIN_EMAIL", "").strip().lower(); password = os.getenv("HALL_APP_ADMIN_PASSWORD", "")
    if data.get("users") or not email or len(password) < 12: return
    data["users"][email] = {"password_hash": _hash_password(password), "role": "admin", "active": True, "created_at": time.time()}
    USERS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    audit("admin_bootstrap", email=email)

_bootstrap_admin_from_env()

def conn():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

def settings():
    if not SETTINGS_FILE.exists(): SETTINGS_FILE.write_text(json.dumps(DEFAULT_SETTINGS, ensure_ascii=False, indent=2), encoding="utf-8")
    return json.loads(SETTINGS_FILE.read_text(encoding="utf-8-sig"))

def save_settings(data): SETTINGS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

def init_db():
    with conn() as c:
        c.execute("CREATE TABLE IF NOT EXISTS records (id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT NOT NULL,type TEXT NOT NULL,category TEXT NOT NULL,description TEXT NOT NULL,amount REAL NOT NULL)")
        c.execute("CREATE TABLE IF NOT EXISTS privacy_requests (id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT NOT NULL,request_type TEXT NOT NULL,status TEXT NOT NULL,created_at TEXT NOT NULL)")
        c.commit()
init_db()

@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Content-Security-Policy"] = "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'"
    if SECURE_COOKIE: response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response

def identity(request: Request) -> dict:
    return _parse_session(request.cookies.get(SESSION_COOKIE, ""))

def require_login(request: Request) -> dict:
    me = identity(request)
    if not me: raise HTTPException(status_code=401, detail="login_required")
    return me

def require_role(request: Request, *roles: str) -> dict:
    me = require_login(request)
    if roles and me.get("role") not in roles: raise HTTPException(status_code=403, detail="forbidden")
    return me

def require_csrf(request: Request, x_csrf_token: str = "") -> dict:
    me = require_login(request)
    if not x_csrf_token or not hmac.compare_digest(str(me.get("csrf", "")), str(x_csrf_token)):
        raise HTTPException(status_code=403, detail="csrf_failed")
    return me

def _login_allowed(ip: str) -> bool:
    now=time.time(); rows=[t for t in LOGIN_ATTEMPTS.get(ip,[]) if now-t < LOGIN_WINDOW]; LOGIN_ATTEMPTS[ip]=rows
    return len(rows) < LOGIN_LIMIT

def _login_fail(ip: str): LOGIN_ATTEMPTS.setdefault(ip, []).append(time.time())

@app.get("/", response_class=HTMLResponse)
def home(): return (BASE / "templates" / "index.html").read_text(encoding="utf-8-sig")

@app.get("/api/health")
def health(): return {"ok": True, "app": "generated_by_hall_v26_2", "ts": time.time()}

@app.get("/api/bootstrap-required")
def bootstrap_required(): return {"ok": True, "required": not bool(users().get("users"))}

@app.post("/api/login")
def login(request: Request, response: Response, email: str = Form(...), password: str = Form(...)):
    ip = request.client.host if request.client else "unknown"
    if not _login_allowed(ip): raise HTTPException(status_code=429, detail="too_many_login_attempts")
    email = email.strip().lower()[:254]; row = users().get("users", {}).get(email)
    if not row or not row.get("active") or not _verify_password(password, row.get("password_hash", "")):
        _login_fail(ip); audit("login_failed", email=email, ip=ip); raise HTTPException(status_code=401, detail="invalid_credentials")
    LOGIN_ATTEMPTS.pop(ip, None); token, csrf = _sign_session(email, row.get("role", "user"))
    response.set_cookie(SESSION_COOKIE, token, httponly=True, secure=SECURE_COOKIE, samesite="strict", max_age=SESSION_TTL, path="/")
    audit("login_success", email=email, ip=ip)
    return {"ok": True, "csrf_token": csrf, "role": row.get("role")}

@app.post("/api/logout")
def logout(request: Request, response: Response, x_csrf_token: str = Header("")):
    me=require_csrf(request,x_csrf_token); response.delete_cookie(SESSION_COOKIE, path="/"); audit("logout", email=me.get("email")); return {"ok":True}

@app.get("/api/me")
def me(request: Request):
    who=identity(request); return {"ok":True,"logged":bool(who),"user":who.get("email") if who else None,"role":who.get("role") if who else None,"csrf_token":who.get("csrf") if who else None,"settings":settings() if who else {}}

def filtered_records(date_from="", date_to="", category="", type="", search=""):
    where=[]; args=[]
    if date_from: where.append("date >= ?"); args.append(date_from[:10])
    if date_to: where.append("date <= ?"); args.append(date_to[:10])
    if category: where.append("category = ?"); args.append(category[:120])
    if type: where.append("type = ?"); args.append(type[:30])
    if search: where.append("(description LIKE ? OR category LIKE ?)"); args.extend([f"%{search[:120]}%",f"%{search[:120]}%"])
    sql="SELECT * FROM records"+(" WHERE "+" AND ".join(where) if where else "")+" ORDER BY date DESC,id DESC LIMIT 1000"
    with conn() as c: return [dict(r) for r in c.execute(sql,args).fetchall()]

@app.get("/api/records")
def records(request: Request, date_from="", date_to="", category="", type="", search=""):
    require_login(request); rows=filtered_records(date_from,date_to,category,type,search); return {"ok":True,"items":rows,"empty":not rows}

@app.post("/api/records")
def create_record(request: Request, x_csrf_token: str = Header(""), date: str=Form(...), type: str=Form(...), category: str=Form(...), description: str=Form(...), amount: float=Form(...)):
    me=require_csrf(request,x_csrf_token)
    if type not in {"receita","despesa"}: raise HTTPException(400,"invalid_type")
    category=category.strip()[:120]; description=description.strip()[:500]
    if not category or not description: raise HTTPException(400,"required_fields")
    with conn() as c: c.execute("INSERT INTO records(date,type,category,description,amount) VALUES(?,?,?,?,?)",(date[:10],type,category,description,float(amount))); c.commit()
    audit("record_created", user=me.get("email")); return {"ok":True}

@app.delete("/api/records/{record_id}")
def delete_record(request: Request, record_id: int, x_csrf_token: str = Header("")):
    me=require_csrf(request,x_csrf_token); require_role(request,"admin")
    with conn() as c: c.execute("DELETE FROM records WHERE id=?",(int(record_id),)); c.commit()
    audit("record_deleted", user=me.get("email"), record_id=record_id); return {"ok":True}

@app.get("/api/dashboard")
def dashboard(request: Request, date_from="", date_to="", category="", type="", search=""):
    require_login(request); rows=filtered_records(date_from,date_to,category,type,search)
    receitas=sum(r["amount"] for r in rows if r["type"]=="receita"); despesas=sum(r["amount"] for r in rows if r["type"]=="despesa"); por_categoria={}
    for r in rows: por_categoria[r["category"]]=por_categoria.get(r["category"],0.0)+(r["amount"] if r["type"]=="receita" else -r["amount"])
    return {"ok":True,"receitas":receitas,"despesas":despesas,"saldo":receitas-despesas,"count":len(rows),"empty":not rows,"por_categoria":por_categoria}

@app.get("/api/categories")
def categories(request: Request):
    require_login(request)
    with conn() as c: cats=[r["category"] for r in c.execute("SELECT DISTINCT category FROM records ORDER BY category").fetchall()]
    return {"ok":True,"items":cats}

@app.get("/api/settings")
def get_settings(request: Request): require_role(request,"admin"); return {"ok":True,"settings":settings()}

@app.post("/api/settings")
def update_settings(request: Request, x_csrf_token: str=Header(""), brand_name: str=Form(""), monthly_ai_cost_limit: float=Form(300.0), billing_status: str=Form("ok")):
    me=require_csrf(request,x_csrf_token); require_role(request,"admin"); s=settings()
    if brand_name: s["brand_name"]=brand_name[:120]
    s["monthly_ai_cost_limit"]=max(0.0,float(monthly_ai_cost_limit)); s["billing_status"]=billing_status if billing_status in {"ok","failed"} else "ok"; s["billing_failed"]=s["billing_status"]=="failed"; save_settings(s); audit("settings_updated",user=me.get("email")); return {"ok":True,"settings":s}

@app.get("/api/billing")
def billing(request: Request): require_login(request); s=settings(); return {"ok":True,"billing_status":s.get("billing_status"),"billing_failed":s.get("billing_failed"),"message":s.get("billing_failed_message") if s.get("billing_failed") else "Cobrança em dia"}

@app.get("/api/ai-cost/check")
def ai_cost_check(request: Request, estimated_cost: float=0.0): require_login(request); s=settings(); current=float(s.get("current_ai_cost",0)); limit=float(s.get("monthly_ai_cost_limit",0)); projected=current+max(0,float(estimated_cost)); return {"ok":True,"allowed":projected<=limit,"current":current,"estimated":estimated_cost,"projected":projected,"limit":limit}

def _csv_safe(v):
    s=str(v if v is not None else ""); return "'"+s if s[:1] in {"=","+","-","@"} else s

@app.get("/api/export.csv", response_class=PlainTextResponse)
def export_csv(request: Request, date_from="", date_to="", category="", type="", search=""):
    me=require_login(request); rows=filtered_records(date_from,date_to,category,type,search); buf=io.StringIO(); w=csv.writer(buf); w.writerow(["date","type","category","description","amount"])
    for r in rows: w.writerow([_csv_safe(r[k]) for k in ["date","type","category","description","amount"]])
    audit("csv_export",user=me.get("email"),count=len(rows)); return Response(buf.getvalue(),media_type="text/csv",headers={"Content-Disposition":"attachment; filename=export.csv"})

@app.post("/api/privacy/request")
def privacy_request(request: Request, x_csrf_token: str=Header(""), request_type: str=Form(...)):
    me=require_csrf(request,x_csrf_token); allowed={"access","export","correction","deletion"}
    if request_type not in allowed: raise HTTPException(400,"invalid_privacy_request")
    with conn() as c: c.execute("INSERT INTO privacy_requests(email,request_type,status,created_at) VALUES(?,?,?,?)",(me.get("email"),request_type,"open",time.strftime("%Y-%m-%d %H:%M:%S"))); c.commit()
    audit("privacy_request",user=me.get("email"),request_type=request_type); return {"ok":True,"status":"open","notice":"Solicitação registrada para tratamento conforme política e base legal aplicáveis."}
'''

INDEX_HTML = r'''<!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>HAL Secure App</title><link rel="stylesheet" href="/static/style.css"></head><body><main><section id="loginPanel" class="login-card"><h1>HAL App Pro</h1><p>Aplicação gerada com Production Security Baseline V26.2.</p><form id="loginForm"><label>E-mail<input name="email" autocomplete="username" placeholder="E-mail" required></label><label>Senha<input name="password" type="password" autocomplete="current-password" placeholder="Senha" required></label><button>Entrar</button></form><small>Não existe senha padrão. Configure HALL_APP_ADMIN_EMAIL e HALL_APP_ADMIN_PASSWORD no ambiente.</small></section><section id="appPanel" class="hidden"><header><div><h1 id="brandName">HAL App Pro</h1><p>Secure by default • RBAC • CSRF • Audit • Backup/Restore • Privacy Readiness.</p></div><button id="logoutBtn">Sair</button></header><div id="billingAlert" class="alert hidden"></div><nav><button data-page="dashboard">Dashboard</button><button data-page="records">Registros</button><button data-page="reports">Relatórios</button><button data-page="settings">Configurações</button><button data-page="privacy">Privacidade</button></nav><section id="dashboard" class="page"><div class="filters"><label>Busca<input id="search" placeholder="Buscar descrição/categoria"></label><label>De<input id="date_from" type="date"></label><label>Até<input id="date_to" type="date"></label><label>Tipo<select id="type"><option value="">Todos</option><option value="receita">Receitas</option><option value="despesa">Despesas</option></select></label><label>Categoria<select id="category"><option value="">Todas categorias</option></select></label></div><div class="cards"><div><span>Receitas</span><strong id="receitas">R$ 0,00</strong></div><div><span>Despesas</span><strong id="despesas">R$ 0,00</strong></div><div><span>Saldo</span><strong id="saldo">R$ 0,00</strong></div><div><span>Registros</span><strong id="count">0</strong></div></div><pre id="chart"></pre></section><section id="records" class="page hidden"><h2>Novo registro</h2><form id="recordForm" class="grid-form"><label>Data<input name="date" type="date" required></label><label>Tipo<select name="type"><option value="receita">Receita</option><option value="despesa">Despesa</option></select></label><label>Categoria<input name="category" maxlength="120" required></label><label>Descrição<input name="description" maxlength="500" required></label><label>Valor<input name="amount" type="number" step="0.01" required></label><button>Salvar</button></form><div id="emptyState" class="empty hidden">Nenhum registro encontrado para esse filtro.</div><table><thead><tr><th>Data</th><th>Tipo</th><th>Categoria</th><th>Descrição</th><th>Valor</th><th></th></tr></thead><tbody id="items"></tbody></table></section><section id="reports" class="page hidden"><h2>Relatórios</h2><p>Os relatórios respeitam os filtros ativos.</p><a id="csvLink" href="/api/export.csv" target="_blank" rel="noopener">Exportar CSV filtrado</a></section><section id="settings" class="page hidden"><h2>Configurações</h2><form id="settingsForm" class="grid-form"><label>Marca<input name="brand_name" id="settingBrand"></label><label>Teto IA<input name="monthly_ai_cost_limit" id="settingCost" type="number" step="0.01"></label><label>Cobrança<select name="billing_status" id="settingBilling"><option value="ok">Cobrança OK</option><option value="failed">Cobrança falhou</option></select></label><button>Salvar configurações</button></form><button id="aiCostBtn">Testar teto de custo de IA</button><pre id="costResult"></pre></section><section id="privacy" class="page hidden"><h2>Privacidade / LGPD Readiness</h2><p>Solicitações são registradas para tratamento conforme política, base legal e processo da organização.</p><form id="privacyForm"><label>Solicitação<select name="request_type"><option value="access">Acesso</option><option value="export">Exportação</option><option value="correction">Correção</option><option value="deletion">Exclusão</option></select></label><button>Registrar solicitação</button></form><pre id="privacyResult"></pre></section></section></main><script src="/static/app.js"></script></body></html>'''

STYLE_CSS = r'''body{margin:0;background:#08111f;color:#e5eefc;font-family:Arial,sans-serif}main{max-width:1180px;margin:0 auto;padding:26px}.hidden{display:none!important}.login-card,header,.page,.cards div{background:#101b33;border:1px solid #263b65;border-radius:18px;padding:18px}.login-card{max-width:420px;margin:12vh auto}header{display:flex;justify-content:space-between;gap:20px;align-items:center;margin-bottom:14px;background:linear-gradient(135deg,#16213e,#7f1d5a)}nav{display:flex;gap:10px;flex-wrap:wrap;margin:14px 0}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:14px 0}.cards span{display:block;color:#9fb3d9}.cards strong{font-size:26px}.filters,.grid-form{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin:12px 0}input,select,button{padding:12px;border-radius:12px;border:1px solid #38527f;background:#0b1325;color:#fff}button{background:#db2777;font-weight:bold;cursor:pointer}.alert{background:#7f1d1d;border:1px solid #ef4444;border-radius:14px;padding:14px;margin:12px 0}.empty{border:1px dashed #64748b;border-radius:14px;padding:20px;color:#cbd5e1;text-align:center;margin:12px 0}table{width:100%;border-collapse:collapse;margin-top:12px}td,th{border-bottom:1px solid #263b65;padding:10px;text-align:left}a{color:#93c5fd}@media(max-width:900px){.cards,.filters,.grid-form{grid-template-columns:1fr}header{display:block}}'''

APP_JS = r'''const EMPTY_MSG='Nenhum registro encontrado';const $=id=>document.getElementById(id);let csrf='';let role='';const fmt=v=>Number(v||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});function params(){const p=new URLSearchParams();['search','date_from','date_to','type','category'].forEach(id=>{const v=$(id)?.value;if(v)p.set(id,v)});return p.toString();}async function api(url,opt={}){const method=(opt.method||'GET').toUpperCase();opt.headers=new Headers(opt.headers||{});if(!['GET','HEAD','OPTIONS'].includes(method)&&csrf)opt.headers.set('X-CSRF-Token',csrf);const r=await fetch(url,opt);if(r.status===401){$('loginPanel').classList.remove('hidden');$('appPanel').classList.add('hidden');throw new Error('login_required')}let data={};try{data=await r.json()}catch(e){data={ok:false,error:'invalid_response'}}if(!r.ok)throw new Error(data.detail||data.error||('HTTP '+r.status));return data;}function showPage(id){document.querySelectorAll('.page').forEach(p=>p.classList.add('hidden'));$(id)?.classList.remove('hidden');}document.querySelectorAll('nav [data-page]').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));loginForm.onsubmit=async e=>{e.preventDefault();try{const r=await fetch('/api/login',{method:'POST',body:new FormData(loginForm)});const d=await r.json();if(!r.ok)throw new Error(d.detail||'login_failed');csrf=d.csrf_token||'';role=d.role||'';await init();}catch(err){alert('Login falhou: '+err.message)}};async function logout(){await api('/api/logout',{method:'POST'});location.reload();}$('logoutBtn')?.addEventListener('click',logout);async function init(){const me=await fetch('/api/me').then(r=>r.json());if(!me.logged)return;csrf=me.csrf_token||csrf;role=me.role||'';$('loginPanel').classList.add('hidden');$('appPanel').classList.remove('hidden');$('brandName').textContent=me.settings.brand_name||'HAL App Pro';$('settingBrand').value=me.settings.brand_name||'';$('settingCost').value=me.settings.monthly_ai_cost_limit||300;$('settingBilling').value=me.settings.billing_status||'ok';if(role!=='admin'){$('settings')?.remove();document.querySelector('[data-page="settings"]')?.remove();}await loadCategories();await loadAll();await loadBilling();}async function loadCategories(){const r=await api('/api/categories');const sel=$('category');sel.replaceChildren(new Option('Todas categorias',''));r.items.forEach(c=>sel.add(new Option(c,c)));}async function loadAll(){await loadDashboard();await loadRecords();$('csvLink').href='/api/export.csv?'+params();}['search','date_from','date_to','type','category'].forEach(id=>$(id)?.addEventListener(id==='search'?'input':'change',loadAll));async function loadDashboard(){const r=await api('/api/dashboard?'+params());$('receitas').textContent=fmt(r.receitas);$('despesas').textContent=fmt(r.despesas);$('saldo').textContent=fmt(r.saldo);$('count').textContent=r.count;$('chart').textContent=Object.entries(r.por_categoria).map(([k,v])=>`${k}: ${fmt(v)}`).join('\n')||'Sem dados para gráfico.';}function td(text){const x=document.createElement('td');x.textContent=String(text??'');return x;}async function loadRecords(){const r=await api('/api/records?'+params());$('emptyState').classList.toggle('hidden',!r.empty);const body=$('items');body.replaceChildren();r.items.forEach(i=>{const tr=document.createElement('tr');['date','type','category','description'].forEach(k=>tr.appendChild(td(i[k])));tr.appendChild(td(fmt(i.amount)));const action=document.createElement('td');if(role==='admin'){const b=document.createElement('button');b.textContent='Excluir';b.addEventListener('click',()=>delRecord(i.id));action.appendChild(b)}tr.appendChild(action);body.appendChild(tr)});}recordForm.onsubmit=async e=>{e.preventDefault();await api('/api/records',{method:'POST',body:new FormData(recordForm)});recordForm.reset();await loadCategories();await loadAll();};async function delRecord(id){if(!confirm('Excluir este registro?'))return;await api('/api/records/'+encodeURIComponent(id),{method:'DELETE'});await loadAll();}async function loadBilling(){const r=await api('/api/billing');$('billingAlert').classList.toggle('hidden',!r.billing_failed);$('billingAlert').textContent=r.billing_failed?'Cobrança falhou: '+r.message:'';}settingsForm.onsubmit=async e=>{e.preventDefault();await api('/api/settings',{method:'POST',body:new FormData(settingsForm)});await init();};async function checkAiCost(){const r=await api('/api/ai-cost/check?estimated_cost=250');$('costResult').textContent=JSON.stringify(r,null,2);}$('aiCostBtn')?.addEventListener('click',checkAiCost);privacyForm.onsubmit=async e=>{e.preventDefault();const r=await api('/api/privacy/request',{method:'POST',body:new FormData(privacyForm)});$('privacyResult').textContent=JSON.stringify(r,null,2);};init();'''

STYLE_CSS = STYLE_CSS + r'''
:focus-visible{outline:3px solid #38bdf8;outline-offset:2px}@media(max-width:760px){main{padding:12px}.cards,.grid-form,.filters{grid-template-columns:1fr!important}table{display:block;overflow-x:auto}header{align-items:flex-start;gap:12px;flex-direction:column}nav{display:flex;overflow-x:auto;gap:8px}}
'''

README_APP = '''# {{APP_TITLE}}

Sistema gerado pelo HAL Autonomous Software Studio / App Factory Pro V26.2.

## Production Security Baseline
- Não existe usuário/senha padrão.
- Configure HALL_APP_ADMIN_EMAIL e HALL_APP_ADMIN_PASSWORD no ambiente no primeiro boot.
- A senha é persistida somente como hash scrypt.
- Sessão assinada por HMAC, CSRF, rate limit, RBAC, security headers e audit log.
- Em produção, defina HALL_APP_SESSION_SECRET e HALL_APP_SECURE_COOKIE=true.

## Quality Gates
Antes de publicar, execute os gates de Security, Backup/Restore, LGPD/Privacy Readiness, Responsividade/Acessibilidade e Deploy Readiness. O deploy é deny-by-default até todos os gates críticos passarem e existir aprovação humana.

## LGPD
LGPD Readiness é uma verificação técnica e não substitui avaliação do DPO/jurídico, definição de base legal, contratos e processos organizacionais.

## Execução local
python -m uvicorn app.main:app --host 127.0.0.1 --port 8090

## Backup / Restore
python scripts/backup.py
python scripts/restore_test.py
'''

QUALITY_GATE_PY = r'''from pathlib import Path
import json
BASE=Path(__file__).parent
checks=[]
def add(name,ok,detail=''): checks.append({'name':name,'ok':bool(ok),'detail':detail})
required=['app/main.py','app/templates/index.html','app/static/app.js','app/static/style.css','requirements.txt','README.md','Dockerfile','docker-compose.yml','.env.example','PRIVACY_READINESS.md','privacy/data_inventory.json','scripts/backup.py','scripts/restore_test.py','production_gate.py']
for rel in required:add('file:'+rel,(BASE/rel).exists())
main=(BASE/'app/main.py').read_text(encoding='utf-8-sig');html=(BASE/'app/templates/index.html').read_text(encoding='utf-8-sig');js=(BASE/'app/static/app.js').read_text(encoding='utf-8-sig');css=(BASE/'app/static/style.css').read_text(encoding='utf-8-sig')
add('no_default_credentials','admin123' not in (main+html+js).lower())
add('password_hash','scrypt' in main.lower() or 'argon2' in main.lower() or 'bcrypt' in main.lower())
add('signed_session','hmac' in main.lower())
add('csrf','csrf' in main.lower() and 'x-csrf-token' in js.lower())
add('rate_limit','login_attempt' in main.lower())
add('rbac','require_role' in main)
add('security_headers','content-security-policy' in main.lower())
add('audit','audit(' in main)
add('responsive','@media' in css.lower() and 'viewport' in html.lower())
add('privacy_request','/api/privacy/request' in main)
try:compile(main,str(BASE/'app/main.py'),'exec');add('python_syntax',True)
except Exception as e:add('python_syntax',False,str(e))
res={'ok':all(c['ok'] for c in checks),'checks':checks,'score':round(sum(1 for c in checks if c['ok'])/len(checks)*100,2)}
(BASE/'quality_gate_report.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(res,ensure_ascii=False,indent=2))
'''
TEST_QUALITY_GATE_PY = "def test_quality_gate_exists():\n    from pathlib import Path\n    assert Path('quality_gate.py').exists()\n"
DOCKERFILE = 'FROM python:3.11-slim\nWORKDIR /app\nCOPY requirements.txt .\nRUN pip install --no-cache-dir -r requirements.txt\nCOPY . .\nCMD ["python", "-m", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8090"]\n'
DOCKER_COMPOSE = 'services:\n  app:\n    build: .\n    ports:\n      - "8090:8090"\n    env_file:\n      - .env\n    volumes:\n      - app_data:/app/data\n    healthcheck:\n      test: ["CMD", "python", "-c", "import urllib.request; urllib.request.urlopen(\"http://127.0.0.1:8090/api/health\")"]\n      interval: 30s\n      timeout: 5s\n      retries: 3\nvolumes:\n  app_data:\n'
DEPLOY_GUIDE = '# Deploy\n\nLocal: python -m uvicorn app.main:app --host 127.0.0.1 --port 8090\n\nDocker: docker compose up --build\n'
GITHUB_GUIDE = '# GitHub\n\nConfigure GITHUB_REMOTE_URL e execute github/INIT_GIT_PUSH.bat.\n'

BACKUP_PY = r'''from pathlib import Path
import json, shutil, sqlite3, time
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'backups'/time.strftime('%Y%m%d_%H%M%S'); OUT.mkdir(parents=True,exist_ok=True)
files=['app.db','settings.json','users.json']
manifest={'created_at':time.strftime('%Y-%m-%d %H:%M:%S'),'files':[]}
for name in files:
 p=ROOT/name
 if p.exists(): shutil.copy2(p,OUT/name); manifest['files'].append(name)
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8');print(OUT)
'''
RESTORE_TEST_PY = r'''from pathlib import Path
import json, shutil, sqlite3, tempfile
ROOT=Path(__file__).resolve().parents[1]; backups=sorted([p for p in (ROOT/'backups').glob('*') if p.is_dir()],reverse=True)
if not backups: raise SystemExit('Nenhum backup disponível para restore drill.')
source=backups[0]/'app.db'
if not source.exists(): raise SystemExit('Backup sem app.db.')
with tempfile.TemporaryDirectory(prefix='hall_restore_') as td:
 dst=Path(td)/'app.db'; shutil.copy2(source,dst); c=sqlite3.connect(dst); row=c.execute('PRAGMA integrity_check').fetchone(); c.close(); ok=bool(row and str(row[0]).lower()=='ok'); print(json.dumps({'ok':ok,'backup':str(backups[0]),'integrity_check':row[0] if row else None},indent=2)); raise SystemExit(0 if ok else 2)
'''
PRODUCTION_GATE_PY = r'''from pathlib import Path
import json, os, sys
ROOT=Path(__file__).resolve().parent
report=ROOT/'production_readiness_report.json'
if not report.exists():
 print('BLOCKED: execute o Production Quality Gate pela HAL antes do deploy.'); raise SystemExit(3)
data=json.loads(report.read_text(encoding='utf-8-sig'))
if not data.get('deploy_allowed'):
 print('BLOCKED: gates de produção ainda não aprovados.'); print(json.dumps(data,ensure_ascii=False,indent=2)); raise SystemExit(4)
print('Gates técnicos aprovados. Ainda é necessária aprovação humana de release.')
'''
PRIVACY_READINESS_MD = '# LGPD / Privacy Readiness\n\nEste arquivo é um checklist técnico e **não substitui avaliação jurídica/DPO**.\n\n- Definir finalidade e base legal por tratamento.\n- Aplicar minimização de dados.\n- Definir retention (retenção) e descarte.\n- Mapear operadores/suboperadores e transferências.\n- Tratar direitos do titular: acesso, correção, exportação e solicitação de exclusão.\n- Registrar consentimento somente quando consentimento for a base legal aplicável.\n- Manter auditoria e controle de acesso.\n- Avaliar incident response e comunicação de incidente.\n'
DATA_INVENTORY = {'version': '1.0', 'classification': 'internal', 'retention': {'days': 365, 'owner': 'configure'}, 'datasets': [{'name': 'users', 'personal_data': True, 'sensitive': False, 'purpose': 'authentication', 'legal_basis': 'define_with_DPO'}, {'name': 'records', 'personal_data': 'depends_on_domain', 'sensitive': 'depends_on_domain', 'purpose': 'core_business', 'legal_basis': 'define_with_DPO'}], 'data_subject_rights': ['access', 'correction', 'export', 'deletion_request'], 'minimization': True}
ENV_EXAMPLE = '# Production secrets - NEVER commit real values\nHALL_APP_ADMIN_EMAIL=admin@example.com\nHALL_APP_ADMIN_PASSWORD=CHANGE_ME_MIN_12_CHARS\nHALL_APP_SESSION_SECRET=GENERATE_A_LONG_RANDOM_SECRET\nHALL_APP_SECURE_COOKIE=true\nHALL_APP_SESSION_TTL=28800\n'

def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    APPS_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text(json.dumps(DEFAULT_CONFIG, ensure_ascii=False, indent=2), encoding="utf-8")
    if not REQUESTS_FILE.exists():
        REQUESTS_FILE.write_text(json.dumps({"requests": []}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def _slug(text: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9_\-]+", "_", (text or "app").strip().lower()).strip("_")
    return s[:80] or "app"


def _read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return default


def status() -> dict[str, Any]:
    _ensure()
    cfg = _read_json(CONFIG_FILE, DEFAULT_CONFIG)
    generated = [p.name for p in APPS_DIR.iterdir() if p.is_dir()]
    return {
        "ok": True,
        "name": "HAL App Factory Pro",
        "description": "Fábrica local/white-label com BSPA, Production Security Baseline, backup/restore, LGPD Readiness e deploy gates.",
        "config": cfg,
        "templates_count": len(TEMPLATES),
        "generated_apps_count": len(generated),
        "generated_apps": generated[:50],
        "capabilities": [
            "Gerar sistemas completos por linguagem natural",
            "Login local com sessão",
            "Páginas, componentes e navegação",
            "CRUD funcional",
            "Filtros que filtram de verdade",
            "Cálculos de dashboard",
            "Estado vazio quando filtro não acha nada",
            "Configurações com alerta de cobrança falhou",
            "Teto de custo de IA",
            "Preview local",
            "GitHub manifest",
            "Deploy local/Docker manifest",
            "Quality Gate funcional",
            "White-label com marca do cliente",
            "Production Security Baseline V26.2",
            "Backup + restore drill",
            "LGPD/Privacy Readiness Gate",
            "Deploy deny-by-default até gates críticos",
        ],
    }


def catalog() -> dict[str, Any]:
    _ensure()
    return {"ok": True, "templates": TEMPLATES, "default_stack": ["Python", "FastAPI", "SQLite", "HTML/CSS/JS"]}


def configure(changes: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    cfg = _read_json(CONFIG_FILE, DEFAULT_CONFIG)
    for k, v in (changes or {}).items():
        if isinstance(v, dict) and isinstance(cfg.get(k), dict):
            cfg[k].update(v)
        else:
            cfg[k] = v
    CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    _audit({"event": "configure", "changes": changes})
    return {"ok": True, "config": cfg}


def is_app_factory_request(message: str) -> bool:
    low = (message or "").lower()
    app_terms = ["software", "sistema", "app", "aplicativo", "plataforma", "lovable", "zheus", "gerar código", "codigo fonte", "código fonte", "interface web"]
    full_terms = ["login", "todas as páginas", "todas as paginas", "filtros", "cálculos", "calculos", "github", "deploy", "assinatura", "cobrança", "cobranca", "teto de custo", "preview", "white label", "marca", "saas", "sistema inteiro"]
    actions = ["quero", "preciso", "crie", "criar", "gerar", "gere", "desenvolver", "fazer", "contemple", "adicionar"]
    return any(a in low for a in actions) and (any(t in low for t in app_terms) or any(t in low for t in full_terms))


def detect_template(message: str) -> str:
    low = (message or "").lower()
    if any(x in low for x in ["finanças pessoais", "financas pessoais", "gastos", "despesas", "receitas", "controle financeiro pessoal"]):
        return "personal_finance"
    if any(x in low for x in ["crm", "lead", "vendedor", "comercial"]):
        return "crm"
    if any(x in low for x in ["clínica", "clinica", "paciente", "consulta médica", "saúde", "saude"]):
        return "clinic"
    if any(x in low for x in ["loja", "varejo", "produto", "estoque", "venda"]):
        return "store"
    if any(x in low for x in ["escola", "curso", "aluno", "turma", "faculdade"]):
        return "school"
    if any(x in low for x in ["transporte", "logística", "logistica", "frota", "bilhetagem"]):
        return "transport"
    if any(x in low for x in ["helpdesk", "chamado", "sla", "suporte"]):
        return "helpdesk"
    if any(x in low for x in ["membros", "curso online", "área de membros", "area de membros"]):
        return "members_area"
    if any(x in low for x in ["agendamento", "agenda", "reserva", "horário", "horario"]):
        return "booking"
    return "personal_finance"


def blueprint_from_prompt(message: str, app_name: str = "") -> dict[str, Any]:
    _ensure()
    template = detect_template(message)
    title = app_name or ("HAL Finanças Pessoais Pro" if template == "personal_finance" else "HAL App Pro")
    slug = _slug(title)
    cfg = _read_json(CONFIG_FILE, DEFAULT_CONFIG)
    blueprint = {
        "id": f"app_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "title": title,
        "slug": slug,
        "template": template,
        "source_prompt": message,
        "brand": cfg.get("white_label", {}),
        "stack": {"backend": "FastAPI", "frontend": "HTML/CSS/JavaScript", "database": "SQLite local", "runtime": "Local-first / Docker opcional"},
        "pages": [
            {"id": "login", "name": "Login", "purpose": "Autenticação local e proteção do app"},
            {"id": "dashboard", "name": "Dashboard", "purpose": "Indicadores principais com cálculos reais"},
            {"id": "records", "name": "Lançamentos/Registros", "purpose": "CRUD funcional com filtros"},
            {"id": "reports", "name": "Relatórios", "purpose": "Resumo filtrável e exportação"},
            {"id": "settings", "name": "Configurações", "purpose": "Marca, billing, custo de IA e alertas"},
            {"id": "billing", "name": "Cobrança", "purpose": "Status de cobrança, falha de pagamento e plano"},
        ],
        "features": ["login", "logout", "dashboard", "crud", "filters", "calculations", "empty_state", "settings", "billing_failed_alert", "ai_cost_limit", "csv_export", "quality_gate", "github_manifest", "docker_deploy", "white_label", "rbac", "csrf", "rate_limit", "signed_session", "security_headers", "audit", "backup_restore", "privacy_center", "lgpd_readiness", "production_gate"],
        "quality_checks": ["arquivos obrigatórios", "rotas principais", "filtros", "cálculos", "estado vazio", "configurações", "billing", "custo de IA", "sintaxe Python", "no default credentials", "password hash", "signed session", "CSRF", "RBAC", "rate limit", "security headers", "audit", "backup/restore", "LGPD readiness", "responsive/accessibility", "deploy readiness"],
        "created_at": _now(),
    }
    save_request({"type": "blueprint", "blueprint": blueprint})
    return {"ok": True, "blueprint": blueprint, "answer": answer_from_blueprint(blueprint)}


def answer_from_blueprint(bp: dict[str, Any]) -> str:
    return (
        "Sim — isso agora entra no HAL App Factory Pro. Eu trato como criação de sistema completo, não como conversa genérica.\n\n"
        f"Projeto sugerido: **{bp['title']}**.\n"
        "Stack: Python + FastAPI + SQLite + HTML/CSS/JavaScript, local-first e com Docker opcional.\n\n"
        "O app gerado contempla: login, dashboard, páginas funcionais, CRUD, filtros reais, cálculos de indicadores, tela vazia quando não há resultado, configurações, alerta de cobrança falhou, teto de custo de IA, exportação CSV, manifesto GitHub, manifesto de deploy, white-label e quality gate.\n\n"
        "Posso gerar o scaffold completo agora e validar os arquivos automaticamente."
    )


def generate_app(message: str, app_name: str = "", template_id: str = "", include_sample_data: bool = True) -> dict[str, Any]:
    bp = blueprint_from_prompt(message, app_name).get("blueprint", {})
    if template_id:
        bp["template"] = template_id
    slug = bp.get("slug") or _slug(app_name or "hall_app")
    dest = APPS_DIR / slug
    if dest.exists():
        shutil.rmtree(dest)
    _write_app_files(dest, bp, include_sample_data=include_sample_data)
    qg = run_quality_gate(dest)
    preview = preview_manifest(dest, bp)
    gh = github_manifest(dest, bp)
    deploy = deploy_manifest(dest, bp)
    try:
        from services.production_quality_gates_v262 import ProductionQualityGate
        production_gate = ProductionQualityGate(root_dir()).run_all(dest, {})
    except Exception as exc:
        production_gate = {"ok": False, "deploy_allowed": False, "error": str(exc)}
    result = {"ok": True, "app": bp, "path": str(dest), "url": "http://127.0.0.1:8090", "run": "python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8090", "quality_gate": qg, "production_gate": production_gate, "preview": preview, "github": gh, "deploy": deploy}
    save_request({"type": "generate_app", "result": result})
    _audit({"event": "generate_app", "slug": slug, "quality_ok": qg.get("ok")})
    return result


def _write_app_files(dest: Path, bp: dict[str, Any], include_sample_data: bool = True) -> None:
    (dest / "app").mkdir(parents=True, exist_ok=True)
    (dest / "app" / "templates").mkdir(parents=True, exist_ok=True)
    (dest / "app" / "static").mkdir(parents=True, exist_ok=True)
    (dest / "tests").mkdir(parents=True, exist_ok=True)
    (dest / "deploy").mkdir(parents=True, exist_ok=True)
    (dest / "github").mkdir(parents=True, exist_ok=True)
    (dest / "scripts").mkdir(parents=True, exist_ok=True)
    (dest / "privacy").mkdir(parents=True, exist_ok=True)
    (dest / "backups").mkdir(parents=True, exist_ok=True)
    (dest / "app" / "main.py").write_text(APP_MAIN_PY, encoding="utf-8")
    (dest / "app" / "templates" / "index.html").write_text(INDEX_HTML, encoding="utf-8")
    (dest / "app" / "static" / "style.css").write_text(STYLE_CSS, encoding="utf-8")
    (dest / "app" / "static" / "app.js").write_text(APP_JS, encoding="utf-8")
    (dest / "requirements.txt").write_text("fastapi\nuvicorn\njinja2\npython-multipart\nitsdangerous\n", encoding="utf-8")
    (dest / "README.md").write_text(README_APP.replace("{{APP_TITLE}}", bp.get("title", "HAL App Pro")), encoding="utf-8")
    (dest / "app_factory_blueprint.json").write_text(json.dumps(bp, ensure_ascii=False, indent=2), encoding="utf-8")
    (dest / "quality_gate.py").write_text(QUALITY_GATE_PY, encoding="utf-8")
    (dest / "tests" / "test_quality_gate.py").write_text(TEST_QUALITY_GATE_PY, encoding="utf-8")
    (dest / "Dockerfile").write_text(DOCKERFILE, encoding="utf-8")
    (dest / "docker-compose.yml").write_text(DOCKER_COMPOSE, encoding="utf-8")
    (dest / "deploy" / "DEPLOY_GUIDE.md").write_text(DEPLOY_GUIDE, encoding="utf-8")
    (dest / "github" / "GITHUB_GUIDE.md").write_text(GITHUB_GUIDE, encoding="utf-8")
    (dest / ".env.example").write_text(ENV_EXAMPLE, encoding="utf-8")
    (dest / "PRIVACY_READINESS.md").write_text(PRIVACY_READINESS_MD, encoding="utf-8")
    (dest / "privacy" / "data_inventory.json").write_text(json.dumps(DATA_INVENTORY, ensure_ascii=False, indent=2), encoding="utf-8")
    (dest / "scripts" / "backup.py").write_text(BACKUP_PY, encoding="utf-8")
    (dest / "scripts" / "restore_test.py").write_text(RESTORE_TEST_PY, encoding="utf-8")
    (dest / "production_gate.py").write_text(PRODUCTION_GATE_PY, encoding="utf-8")
    (dest / "INICIAR_APP.bat").write_text('@echo off\nchcp 65001 >nul\npython -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8090\npause\n'.replace("\n", "\r\n"), encoding="utf-8")
    (dest / "github" / "INIT_GIT_PUSH.bat").write_text('@echo off\nchcp 65001 >nul\nif "%GITHUB_REMOTE_URL%"=="" (echo Configure GITHUB_REMOTE_URL primeiro.& pause & exit /b 1)\ngit init\ngit add .\ngit commit -m "initial app generated by HAL App Factory Pro"\ngit branch -M main\ngit remote add origin %GITHUB_REMOTE_URL%\ngit push -u origin main\npause\n'.replace("\n", "\r\n"), encoding="utf-8")
    if include_sample_data:
        sample = [{"date":"2026-08-01","type":"receita","category":"Salário","description":"Salário mensal","amount":8500.0},{"date":"2026-08-02","type":"despesa","category":"Moradia","description":"Aluguel","amount":2600.0}]
        (dest / "sample_data.json").write_text(json.dumps(sample, ensure_ascii=False, indent=2), encoding="utf-8")


def preview_manifest(path: str | Path, bp: dict[str, Any]) -> dict[str, Any]:
    p = Path(path)
    manifest = {"ok": True, "type": "local_preview", "url": "http://127.0.0.1:8090", "command": "python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8090", "pages": [x.get("name") for x in bp.get("pages", [])], "path": str(p)}
    (p / "preview_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest


def github_manifest(path: str | Path, bp: dict[str, Any]) -> dict[str, Any]:
    p = Path(path)
    manifest = {"ok": True, "configured": bool(_read_json(CONFIG_FILE, DEFAULT_CONFIG).get("github", {}).get("remote_url")), "steps": ["git init", "git add .", "git commit", "git remote add origin", "git push"], "script": "github/INIT_GIT_PUSH.bat", "token_env": "GITHUB_TOKEN", "path": str(p)}
    (p / "github" / "github_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest


def deploy_manifest(path: str | Path, bp: dict[str, Any]) -> dict[str, Any]:
    p = Path(path)
    manifest = {"ok": True, "modes": ["local", "docker", "vps"], "local_command": "python -m uvicorn app.main:app --host 127.0.0.1 --port 8090", "docker_command": "docker compose up --build", "health_url": "http://127.0.0.1:8090/api/health", "predeploy_gate": "python production_gate.py", "policy": "deny_by_default", "required_env": ["HALL_APP_ADMIN_EMAIL","HALL_APP_ADMIN_PASSWORD","HALL_APP_SESSION_SECRET","HALL_APP_SECURE_COOKIE=true"], "path": str(p)}
    (p / "deploy" / "deploy_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest


def run_quality_gate(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    checks: list[dict[str, Any]] = []
    def add(name: str, ok: bool, detail: str = "") -> None:
        checks.append({"name": name, "ok": bool(ok), "detail": detail})
    required = ["app/main.py", "app/templates/index.html", "app/static/app.js", "app/static/style.css", "requirements.txt", "README.md", "Dockerfile", "docker-compose.yml", "quality_gate.py"]
    for rel in required:
        add(f"file:{rel}", (p / rel).exists(), str(p / rel))
    main = (p / "app/main.py").read_text(encoding="utf-8", errors="ignore") if (p / "app/main.py").exists() else ""
    html = (p / "app/templates/index.html").read_text(encoding="utf-8", errors="ignore") if (p / "app/templates/index.html").exists() else ""
    js = (p / "app/static/app.js").read_text(encoding="utf-8", errors="ignore") if (p / "app/static/app.js").exists() else ""
    add("login_route", "def login" in main and "/api/login" in main)
    add("logout_route", "/api/logout" in main)
    add("records_api", "/api/records" in main)
    add("filters_api", "date_from" in main and "date_to" in main and "category" in main and "search" in main)
    add("calculations_api", "/api/dashboard" in main and "saldo" in main and "por_categoria" in main)
    add("empty_state", "emptyState" in html and "Nenhum registro encontrado" in js)
    add("settings", "/api/settings" in main and "monthly_ai_cost_limit" in main)
    add("billing_failed_alert", "billing_failed" in main and "Cobrança falhou" in js)
    add("ai_cost_guard", "/api/ai-cost/check" in main and "monthly_ai_cost_limit" in main)
    add("csv_export", "/api/export.csv" in main)
    try:
        compile(main, str(p / "app/main.py"), "exec")
        add("python_syntax", True)
    except Exception as exc:
        add("python_syntax", False, str(exc))
    ok = all(c["ok"] for c in checks)
    result = {"ok": ok, "checks": checks, "score": round(sum(1 for c in checks if c["ok"]) / max(1, len(checks)) * 100, 2)}
    (p / "quality_gate_report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result


def save_request(item: dict[str, Any]) -> None:
    _ensure()
    data = _read_json(REQUESTS_FILE, {"requests": []})
    data.setdefault("requests", []).insert(0, {"ts": _now(), **item})
    data["requests"] = data["requests"][:500]
    REQUESTS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def list_requests(limit: int = 50) -> dict[str, Any]:
    _ensure()
    data = _read_json(REQUESTS_FILE, {"requests": []})
    return {"ok": True, "requests": data.get("requests", [])[:limit]}
