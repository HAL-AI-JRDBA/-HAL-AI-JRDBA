from __future__ import annotations

import json
import os
import re
import time
import uuid
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "omnichannel_voice_text_delivery"
CONFIG_FILE = DATA_DIR / "config.json"
CONTACTS_FILE = DATA_DIR / "contacts.json"
DELIVERIES_FILE = DATA_DIR / "deliveries.json"
AUDIO_DIR = DATA_DIR / "audio"
AUDIT_FILE = DATA_DIR / "audit.jsonl"


CHANNELS: dict[str, dict[str, Any]] = {
    "whatsapp": {
        "label": "WhatsApp Business Cloud API",
        "keywords": ["whatsapp", "whats", "zap"],
        "supports_text": True,
        "supports_voice": True,
        "required_env": ["WHATSAPP_TOKEN", "WHATSAPP_PHONE_NUMBER_ID"],
        "recipient_field": "phone_number",
        "notes": "Para envio real, configurar WhatsApp Business Cloud API, número remetente e permissão do destinatário.",
    },
    "telegram": {
        "label": "Telegram Bot API",
        "keywords": ["telegram"],
        "supports_text": True,
        "supports_voice": True,
        "required_env": ["TELEGRAM_BOT_TOKEN"],
        "recipient_field": "chat_id",
        "notes": "Para envio real, configurar bot token e chat_id/grupo/canal autorizado.",
    },
    "teams": {
        "label": "Microsoft Teams",
        "keywords": ["teams", "microsoft teams"],
        "supports_text": True,
        "supports_voice": False,
        "required_env": ["TEAMS_WEBHOOK_URL"],
        "recipient_field": "webhook_or_channel",
        "notes": "Entrega textual via webhook/conector. Voz em reunião usa Meeting Intelligence Gateway.",
    },
    "email": {
        "label": "E-mail",
        "keywords": ["email", "e-mail"],
        "supports_text": True,
        "supports_voice": True,
        "required_env": ["SMTP_HOST", "SMTP_USER", "SMTP_PASSWORD"],
        "recipient_field": "email",
        "notes": "Preparado para envio futuro por SMTP; nesta camada fica registrado/preparado.",
    },
}

DEFAULT_CONFIG = {
    "enabled": True,
    "default_channels": ["whatsapp", "telegram"],
    "send_email_to_requester": True,
    "requester_email_required_when_asked": True,
    "email_subject_prefix": "Resposta do HAL",
    "send_text": True,
    "send_voice": True,
    "auto_deliver_when_channel_requested": True,
    "auto_deliver_all_answers": False,
    "require_approval_for_external_send": True,
    "voice_provider": "local_optional",
    "voice_format": "wav",
    "voice_speed": "calm",
    "voice_tone": "natural_paulista_cordial",
    "max_text_chars": 3500,
    "max_voice_chars": 1200,
    "language": "pt-BR",
    "delivery_mode": "prepare_if_credentials_missing",
    "audit_enabled": True,
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    for path, default in [
        (CONFIG_FILE, DEFAULT_CONFIG),
        (CONTACTS_FILE, {"contacts": []}),
        (DELIVERIES_FILE, {"deliveries": []}),
    ]:
        if not path.exists():
            path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    if not _load(CONFIG_FILE, DEFAULT_CONFIG).get("audit_enabled", True):
        return
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def status() -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    contacts = _load(CONTACTS_FILE, {"contacts": []}).get("contacts", [])
    deliveries = _load(DELIVERIES_FILE, {"deliveries": []}).get("deliveries", [])
    return {
        "ok": True,
        "name": "HAL Omnichannel Voice/Text Delivery",
        "description": "Entrega respostas do HAL em WhatsApp, Telegram e outros canais, em texto e voz, quando autorizado/configurado.",
        "enabled": cfg.get("enabled", True),
        "contacts_count": len(contacts),
        "deliveries_count": len(deliveries),
        "channels_supported": len(CHANNELS),
        "config": cfg,
        "capabilities": [
            "Enviar resposta por texto no WhatsApp",
            "Enviar resposta por voz no WhatsApp",
            "Enviar resposta por texto no Telegram",
            "Enviar resposta por voz no Telegram",
            "Enviar e-mail para o solicitante",
            "Preparar payload quando credenciais estiverem ausentes",
            "Gerar roteiro de voz natural",
            "Gerar arquivo de voz local quando pyttsx3 estiver disponível",
            "Escolher canal pelo pedido do usuário",
            "Manter contatos por usuário/setor/time",
            "Anexar áudio local ao e-mail quando disponível",
            "Exigir aprovação humana para envio externo",
            "Registrar auditoria das entregas",
            "Integrar com Conversa Natural, Meeting Intelligence e Enterprise Teams",
        ],
    }


def catalog() -> dict[str, Any]:
    return {
        "ok": True,
        "channels": [{"key": k, **v} for k, v in CHANNELS.items()],
        "config": _load(CONFIG_FILE, DEFAULT_CONFIG),
    }


def update_config(changes: dict[str, Any]) -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    deep_update(cfg, changes or {})
    _save(CONFIG_FILE, cfg)
    _audit({"event": "update_config"})
    return {"ok": True, "config": cfg, "summary": "Configuração de entrega omnichannel atualizada."}


def deep_update(base: dict[str, Any], changes: dict[str, Any]) -> None:
    for k, v in changes.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            deep_update(base[k], v)
        else:
            base[k] = v


def register_contact(
    name: str,
    channel: str,
    recipient: str,
    user_id: str = "",
    team_id: str = "",
    department: str = "",
    send_text: bool = True,
    send_voice: bool = True,
    active: bool = True,
) -> dict[str, Any]:
    channel_key = normalize_channel(channel)
    if channel_key not in CHANNELS:
        return {"ok": False, "summary": "Canal não suportado.", "available": list(CHANNELS)}
    data = _load(CONTACTS_FILE, {"contacts": []})
    contact = {
        "id": f"contact_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "name": name or "Contato HAL",
        "channel": channel_key,
        "channel_label": CHANNELS[channel_key]["label"],
        "recipient": recipient,
        "recipient_field": CHANNELS[channel_key]["recipient_field"],
        "user_id": user_id,
        "team_id": team_id,
        "department": department,
        "send_text": send_text,
        "send_voice": send_voice,
        "active": active,
        "created_at": _now(),
    }
    data.setdefault("contacts", []).insert(0, contact)
    _save(CONTACTS_FILE, data)
    _audit({"event": "register_contact", "contact_id": contact["id"], "channel": channel_key})
    return {"ok": True, "contact": contact, "summary": "Contato/canal registrado para entrega."}


def list_contacts(channel: str = "", department: str = "", limit: int = 100) -> dict[str, Any]:
    items = _load(CONTACTS_FILE, {"contacts": []}).get("contacts", [])
    if channel:
        items = [c for c in items if c.get("channel") == normalize_channel(channel)]
    if department:
        items = [c for c in items if c.get("department") == department]
    return {"ok": True, "contacts": items[:max(1, min(limit, 500))], "count": len(items)}


def normalize_channel(channel: str) -> str:
    low = (channel or "").lower().strip()
    if low in {"whats", "zap", "whatsapp"}:
        return "whatsapp"
    if "telegram" in low:
        return "telegram"
    if "teams" in low:
        return "teams"
    if "mail" in low or "e-mail" in low or "email" in low or "solicitante" in low or "requerente" in low:
        return "email"
    return low


def infer_channels(message: str) -> list[str]:
    low = (message or "").lower()
    found: list[str] = []
    for key, spec in CHANNELS.items():
        if any(k in low for k in spec["keywords"]):
            found.append(key)

    if any(x in low for x in ["solicitante", "requerente", "quem solicitou", "quem pediu", "para mim por email", "para mim por e-mail"]):
        if "email" not in found:
            found.append("email")

    if "voz" in low or "áudio" in low or "audio" in low:
        cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
        for c in cfg.get("default_channels", []):
            if c not in found:
                found.append(c)
    return found


def should_deliver_for_message(message: str) -> bool:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    if cfg.get("auto_deliver_all_answers", False):
        return True
    if cfg.get("auto_deliver_when_channel_requested", True) and infer_channels(message):
        return True
    return False


def extract_recipient_hint(message: str) -> str:
    text = message or ""
    # telefone simples BR/internacional
    m = re.search(r"(\+?\d[\d\s().-]{8,}\d)", text)
    if m:
        return re.sub(r"[^\d+]", "", m.group(1))
    # Telegram @usuario ou chat id
    m = re.search(r"(@[A-Za-z0-9_]{4,})", text)
    if m:
        return m.group(1)
    m = re.search(r"(chat[_\s-]?id|telegram)\s*[:=]?\s*(-?\d{5,})", text, flags=re.I)
    if m:
        return m.group(2)
    # email
    m = re.search(r"[\w.\-+]+@[\w.\-]+\.\w+", text)
    if m:
        return m.group(0)
    return ""


def select_contacts(message: str, explicit_channel: str = "", explicit_recipient: str = "") -> list[dict[str, Any]]:
    channels = [normalize_channel(explicit_channel)] if explicit_channel else infer_channels(message)
    hint = explicit_recipient or extract_recipient_hint(message)
    if hint and "@" in hint and "email" not in channels:
        channels = ["email"]
    if not channels:
        channels = _load(CONFIG_FILE, DEFAULT_CONFIG).get("default_channels", ["whatsapp", "telegram"])
    contacts = _load(CONTACTS_FILE, {"contacts": []}).get("contacts", [])
    selected: list[dict[str, Any]] = []

    if hint:
        for ch in channels:
            selected.append({
                "id": "",
                "name": "Destinatário informado",
                "channel": ch,
                "channel_label": CHANNELS.get(ch, {}).get("label", ch),
                "recipient": hint,
                "send_text": True,
                "send_voice": True,
                "active": True,
            })
        return selected

    for c in contacts:
        if not c.get("active", True):
            continue
        if c.get("channel") in channels:
            selected.append(c)

    return selected


def make_text_answer(answer: str, question: str = "") -> str:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    max_chars = int(cfg.get("max_text_chars", 3500))
    text = (answer or "").strip()
    if not text:
        text = "Eu entendi a pergunta, mas ainda não tenho uma resposta pronta."
    if question:
        text = f"HAL respondeu:\n\n{text}"
    if len(text) > max_chars:
        text = text[:max_chars].rsplit(" ", 1)[0] + "\n\n[resposta resumida para envio]"
    return text


def make_voice_script(answer: str, question: str = "") -> str:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    max_chars = int(cfg.get("max_voice_chars", 1200))
    text = " ".join((answer or "").split())
    if not text:
        text = "Eu entendi a pergunta, mas ainda não tenho uma resposta pronta."
    # Deixar voz mais natural e curta.
    text = text.replace("HAL respondeu:", "")
    if len(text) > max_chars:
        text = text[:max_chars].rsplit(" ", 1)[0] + ". Posso detalhar mais por texto se quiser."
    return text


def synthesize_voice_file(text: str, delivery_id: str) -> dict[str, Any]:
    """Gera áudio local quando houver pyttsx3. Caso contrário cria manifesto de voz.

    A entrega real de voz por WhatsApp/Telegram depende de TTS instalado e credenciais.
    """
    _ensure()
    wav_path = AUDIO_DIR / f"{delivery_id}.wav"
    manifest_path = AUDIO_DIR / f"{delivery_id}.voice.json"

    try:
        import pyttsx3  # type: ignore
        engine = pyttsx3.init()
        # Ajuste leve; se a voz PT-BR estiver instalada no Windows/Linux, o motor usa a voz disponível.
        rate = engine.getProperty("rate")
        if isinstance(rate, int):
            engine.setProperty("rate", max(135, min(rate, 165)))
        engine.save_to_file(text, str(wav_path))
        engine.runAndWait()
        if wav_path.exists() and wav_path.stat().st_size > 0:
            return {"ok": True, "audio_path": str(wav_path), "provider": "pyttsx3", "format": "wav"}
    except Exception as exc:
        manifest_path.write_text(
            json.dumps(
                {
                    "ok": False,
                    "provider": "manifest_only",
                    "reason": str(exc),
                    "voice_script": text,
                    "how_to_enable": "Instale/configure pyttsx3 ou outro TTS local e rode novamente.",
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        return {"ok": False, "audio_path": "", "manifest_path": str(manifest_path), "provider": "manifest_only", "error": str(exc)}

    manifest_path.write_text(json.dumps({"voice_script": text}, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": False, "audio_path": "", "manifest_path": str(manifest_path), "provider": "manifest_only"}


def env_missing(channel: str) -> list[str]:
    missing = []
    for e in CHANNELS.get(channel, {}).get("required_env", []):
        if not os.getenv(e) and not os.getenv(f"HALL_{e}"):
            missing.append(e)
    return missing


def _env(name: str) -> str:
    return os.getenv(name) or os.getenv(f"HALL_{name}") or ""


def send_telegram_text(chat_id: str, text: str) -> dict[str, Any]:
    token = _env("TELEGRAM_BOT_TOKEN")
    if not token:
        return {"ok": False, "status": "prepared", "reason": "TELEGRAM_BOT_TOKEN ausente"}
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = json.dumps({"chat_id": chat_id, "text": text}).encode("utf-8")
    return _http_json(url, payload)


def send_telegram_voice(chat_id: str, audio_path: str, caption: str = "") -> dict[str, Any]:
    # Sem multipart robusto aqui; mantém como preparado se não houver sender externo.
    token = _env("TELEGRAM_BOT_TOKEN")
    if not token:
        return {"ok": False, "status": "prepared", "reason": "TELEGRAM_BOT_TOKEN ausente"}
    if not audio_path or not Path(audio_path).exists():
        return {"ok": False, "status": "prepared", "reason": "arquivo de áudio ausente"}
    return {
        "ok": False,
        "status": "prepared",
        "reason": "Envio multipart de voz deve ser feito pelo sender externo/desktop companion.",
        "audio_path": audio_path,
        "chat_id": chat_id,
    }


def send_whatsapp_text(phone_number: str, text: str) -> dict[str, Any]:
    token = _env("WHATSAPP_TOKEN")
    phone_number_id = _env("WHATSAPP_PHONE_NUMBER_ID")
    if not token or not phone_number_id:
        return {"ok": False, "status": "prepared", "reason": "WHATSAPP_TOKEN ou WHATSAPP_PHONE_NUMBER_ID ausente"}
    url = f"https://graph.facebook.com/v20.0/{phone_number_id}/messages"
    payload = json.dumps(
        {
            "messaging_product": "whatsapp",
            "to": phone_number,
            "type": "text",
            "text": {"preview_url": False, "body": text},
        }
    ).encode("utf-8")
    return _http_json(url, payload, bearer=token)


def send_whatsapp_voice(phone_number: str, audio_path: str, caption: str = "") -> dict[str, Any]:
    token = _env("WHATSAPP_TOKEN")
    phone_number_id = _env("WHATSAPP_PHONE_NUMBER_ID")
    if not token or not phone_number_id:
        return {"ok": False, "status": "prepared", "reason": "WHATSAPP_TOKEN ou WHATSAPP_PHONE_NUMBER_ID ausente"}
    return {
        "ok": False,
        "status": "prepared",
        "reason": "WhatsApp voz exige upload de mídia ou URL pública de áudio. Use sender externo/desktop companion.",
        "audio_path": audio_path,
        "phone_number": phone_number,
    }


def _http_json(url: str, payload: bytes, bearer: str = "") -> dict[str, Any]:
    headers = {"Content-Type": "application/json"}
    if bearer:
        headers["Authorization"] = f"Bearer {bearer}"
    req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            try:
                body = json.loads(raw)
            except Exception:
                body = {"raw": raw}
            return {"ok": 200 <= resp.status < 300, "status_code": resp.status, "body": body}
    except Exception as exc:
        return {"ok": False, "status": "error", "error": str(exc)}



def send_email_text_voice(to_email: str, subject: str, text: str, audio_path: str = "") -> dict[str, Any]:
    import smtplib
    from email.message import EmailMessage

    host = _env("SMTP_HOST")
    port = int(_env("SMTP_PORT") or "587")
    user = _env("SMTP_USER")
    password = _env("SMTP_PASSWORD")
    from_addr = _env("SMTP_FROM") or user

    if not host or not user or not password or not from_addr:
        return {"ok": False, "status": "prepared", "reason": "SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD ou SMTP_FROM ausente"}

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = from_addr
    msg["To"] = to_email
    msg.set_content(text)

    if audio_path and Path(audio_path).exists():
        data = Path(audio_path).read_bytes()
        msg.add_attachment(data, maintype="audio", subtype="wav", filename=Path(audio_path).name)

    try:
        with smtplib.SMTP(host, port, timeout=25) as smtp:
            smtp.starttls()
            smtp.login(user, password)
            smtp.send_message(msg)
        return {"ok": True, "status": "sent", "to": to_email, "subject": subject, "audio_attached": bool(audio_path and Path(audio_path).exists())}
    except Exception as exc:
        return {"ok": False, "status": "error", "error": str(exc), "to": to_email}


def build_email_subject(question: str = "") -> str:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    prefix = cfg.get("email_subject_prefix", "Resposta do HAL")
    cleaned = " ".join((question or "").split())
    cleaned = re.sub(r"(?i)(hall[,:\s]+|envie|mande|por whatsapp|por telegram|por e-mail|por email|para o solicitante)", "", cleaned).strip()
    if cleaned:
        cleaned = cleaned[:80].rsplit(" ", 1)[0] if len(cleaned) > 80 else cleaned
        return f"{prefix} — {cleaned}"
    return prefix


def create_delivery(
    question: str,
    answer: str,
    channel: str = "",
    recipient: str = "",
    contacts: list[dict[str, Any]] | None = None,
    send_text: bool | None = None,
    send_voice: bool | None = None,
    approved: bool = False,
    source: str = "hall",
) -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    if not cfg.get("enabled", True):
        return {"ok": False, "summary": "Entrega omnichannel desativada."}

    final_send_text = cfg.get("send_text", True) if send_text is None else bool(send_text)
    final_send_voice = cfg.get("send_voice", True) if send_voice is None else bool(send_voice)

    if cfg.get("require_approval_for_external_send", True) and not approved:
        mode = "prepared_waiting_approval"
    else:
        mode = "send_or_prepare"

    selected_contacts = contacts or select_contacts(question, channel, recipient)
    delivery_id = f"deliv_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    text_answer = make_text_answer(answer, question)
    voice_script = make_voice_script(answer, question)
    voice_artifact = synthesize_voice_file(voice_script, delivery_id) if final_send_voice else {}

    if not selected_contacts:
        delivery = {
            "id": delivery_id,
            "source": source,
            "question": question,
            "answer": answer,
            "text_answer": text_answer,
            "voice_script": voice_script,
            "voice_artifact": voice_artifact,
            "status": "needs_recipient",
            "approved": approved,
            "channels": infer_channels(question) or cfg.get("default_channels", []),
            "results": [],
            "created_at": _now(),
            "summary": "Preciso saber o destinatário: número do WhatsApp ou chat_id/@usuário do Telegram.",
        }
        save_delivery(delivery)
        return {"ok": True, "delivery": delivery, "summary": delivery["summary"]}

    results = []
    for c in selected_contacts:
        ch = normalize_channel(c.get("channel", channel))
        rec = c.get("recipient", recipient)
        item = {
            "contact": c,
            "channel": ch,
            "recipient": rec,
            "text": {"enabled": final_send_text and c.get("send_text", True), "status": "skipped"},
            "voice": {"enabled": final_send_voice and c.get("send_voice", True), "status": "skipped"},
        }

        missing = env_missing(ch)
        if mode == "prepared_waiting_approval":
            item["status"] = "waiting_approval"
            item["reason"] = "Envio externo exige aprovação humana."
        elif missing:
            item["status"] = "prepared_missing_credentials"
            item["missing_env"] = missing
        else:
            item["status"] = "attempted"

        if item["text"]["enabled"]:
            if mode == "send_or_prepare" and not missing:
                if ch == "telegram":
                    item["text"] = {**item["text"], **send_telegram_text(rec, text_answer)}
                elif ch == "whatsapp":
                    item["text"] = {**item["text"], **send_whatsapp_text(rec, text_answer)}
                elif ch == "email":
                    item["text"] = {**item["text"], **send_email_text_voice(rec, build_email_subject(question), text_answer, "")}
                else:
                    item["text"] = {**item["text"], "status": "prepared", "reason": "Sender do canal ainda não implementado."}
            else:
                item["text"] = {**item["text"], "status": "prepared", "payload": text_answer}

        if item["voice"]["enabled"]:
            audio_path = voice_artifact.get("audio_path", "")
            if mode == "send_or_prepare" and not missing:
                if ch == "telegram":
                    item["voice"] = {**item["voice"], **send_telegram_voice(rec, audio_path, "Resposta do HAL")}
                elif ch == "whatsapp":
                    item["voice"] = {**item["voice"], **send_whatsapp_voice(rec, audio_path, "Resposta do HAL")}
                elif ch == "email":
                    item["voice"] = {**item["voice"], **send_email_text_voice(rec, build_email_subject(question), text_answer, audio_path)}
                else:
                    item["voice"] = {**item["voice"], "status": "prepared", "reason": "Voz do canal ainda não implementada."}
            else:
                item["voice"] = {
                    **item["voice"],
                    "status": "prepared",
                    "voice_script": voice_script,
                    "audio_path": audio_path,
                    "manifest_path": voice_artifact.get("manifest_path", ""),
                }
        results.append(item)

    delivery = {
        "id": delivery_id,
        "source": source,
        "question": question,
        "answer": answer,
        "text_answer": text_answer,
        "voice_script": voice_script,
        "voice_artifact": voice_artifact,
        "status": summarize_delivery_status(results),
        "approved": approved,
        "results": results,
        "created_at": _now(),
        "summary": delivery_summary(results, approved),
    }
    save_delivery(delivery)
    _audit({"event": "create_delivery", "delivery_id": delivery_id, "status": delivery["status"], "contacts": len(selected_contacts)})
    return {"ok": True, "delivery": delivery, "summary": delivery["summary"]}


def summarize_delivery_status(results: list[dict[str, Any]]) -> str:
    if not results:
        return "needs_recipient"
    statuses = {r.get("status") for r in results}
    if "waiting_approval" in statuses:
        return "waiting_approval"
    if "prepared_missing_credentials" in statuses:
        return "prepared_missing_credentials"
    if "attempted" in statuses:
        return "attempted"
    return "prepared"


def delivery_summary(results: list[dict[str, Any]], approved: bool) -> str:
    if not results:
        return "Preciso de destinatário para enviar."
    if not approved:
        return "Resposta preparada para WhatsApp/Telegram em texto e voz. Envio externo aguardando aprovação."
    if any(r.get("status") == "prepared_missing_credentials" for r in results):
        return "Resposta preparada em texto e voz, mas faltam credenciais do canal para envio real."
    return "Entrega processada/preparada para os canais configurados."


def save_delivery(delivery: dict[str, Any]) -> None:
    data = _load(DELIVERIES_FILE, {"deliveries": []})
    data.setdefault("deliveries", []).insert(0, delivery)
    data["deliveries"] = data["deliveries"][:500]
    _save(DELIVERIES_FILE, data)


def list_deliveries(status_filter: str = "", channel: str = "", limit: int = 100) -> dict[str, Any]:
    items = _load(DELIVERIES_FILE, {"deliveries": []}).get("deliveries", [])
    if status_filter:
        items = [d for d in items if d.get("status") == status_filter]
    if channel:
        ch = normalize_channel(channel)
        items = [d for d in items if any(r.get("channel") == ch for r in d.get("results", []))]
    return {"ok": True, "deliveries": items[:max(1, min(limit, 500))], "count": len(items)}


def approve_and_send(delivery_id: str) -> dict[str, Any]:
    data = _load(DELIVERIES_FILE, {"deliveries": []})
    for d in data.get("deliveries", []):
        if d.get("id") == delivery_id:
            # recria usando dados originais e approved=True
            contacts = [r.get("contact", {}) for r in d.get("results", [])]
            result = create_delivery(
                d.get("question", ""),
                d.get("answer", ""),
                contacts=contacts,
                approved=True,
                source=d.get("source", "hall_approval"),
            )
            d["status"] = "approved_recreated"
            d["approved_at"] = _now()
            _save(DELIVERIES_FILE, data)
            return {"ok": True, "delivery": d, "send_result": result, "summary": "Entrega aprovada e reenviada/processada."}
    return {"ok": False, "summary": "Entrega não encontrada."}


def deliver_if_requested(question: str, answer: str, approved: bool = False, source: str = "hall_auto") -> dict[str, Any]:
    if not should_deliver_for_message(question):
        return {"ok": True, "skipped": True, "summary": "Nenhum canal solicitado e autoenvio geral desativado."}
    return create_delivery(question, answer, approved=approved, source=source)


def seed_demo() -> dict[str, Any]:
    c1 = register_contact("Demo WhatsApp", "whatsapp", "+5511999999999", department="financeiro")
    c2 = register_contact("Demo Telegram", "telegram", "123456789", department="ti_dba")
    delivery = create_delivery(
        "HAL, envie essa resposta no WhatsApp e Telegram em voz e texto.",
        "Claro. Esta é uma resposta de demonstração do HAL em texto e também preparada em voz.",
        approved=False,
        source="demo",
    )
    return {"ok": True, "contacts": [c1.get("contact"), c2.get("contact")], "delivery": delivery.get("delivery"), "summary": "Demo de entrega WhatsApp/Telegram criada."}


def answer_for_omnichannel(message: str = "") -> str:
    channels = infer_channels(message) or ["whatsapp", "telegram"]
    labels = ", ".join(CHANNELS[c]["label"] for c in channels if c in CHANNELS)
    return (
        f"Vou usar o HAL Omnichannel Voice/Text Delivery para entregar respostas em {labels}. "
        "Ele prepara texto, voz e e-mail ao solicitante quando pedido, escolhe o canal pelo contexto, registra auditoria e só envia externamente quando houver destinatário, credenciais e aprovação/política configurada."
    )
