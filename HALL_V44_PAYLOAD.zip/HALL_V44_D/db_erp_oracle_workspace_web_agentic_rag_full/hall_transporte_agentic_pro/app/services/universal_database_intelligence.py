from __future__ import annotations

import importlib.util
import json
import os
import re
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "universal_database_intelligence_v25"
AUDIT_FILE = DATA_DIR / "audit.jsonl"


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def _vtuple(version: str | int | float | None) -> tuple[int, ...]:
    if version is None:
        return ()
    nums = [int(x) for x in re.findall(r"\d+", str(version))[:5]]
    return tuple(nums)


def _at_least(version: str, minimum: str) -> bool:
    v = _vtuple(version)
    m = _vtuple(minimum)
    if not v:
        return False
    n = max(len(v), len(m))
    return v + (0,) * (n-len(v)) >= m + (0,) * (n-len(m))


def _module_available(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except Exception:
        # Test doubles / partially imported optional drivers may have no __spec__.
        return name in __import__('sys').modules


ENGINE_CATALOG: dict[str, dict[str, Any]] = {
    "oracle": {
        "label": "Oracle Database", "family": "sql", "default_port": 1521,
        "drivers": ["oracledb", "cx_Oracle"], "dialect": "Oracle SQL / PL/SQL",
        "version_query": "SELECT banner FROM v$version WHERE ROWNUM = 1",
        "version_patterns": [r"Oracle Database.*?Release\s+([0-9.]+)", r"Oracle.*?([0-9]+\.[0-9.]+(?:\.[0-9.]+)*)"],
        "skills": ["sessions", "locks", "top_sql", "waits", "storage", "indexes", "statistics", "backup", "replication", "ha", "explain", "tuning"],
    },
    "sqlserver": {
        "label": "Microsoft SQL Server", "family": "sql", "default_port": 1433,
        "drivers": ["pyodbc", "pymssql"], "dialect": "T-SQL",
        "version_query": "SELECT CAST(SERVERPROPERTY('ProductVersion') AS varchar(64)) AS version, CAST(SERVERPROPERTY('Edition') AS varchar(128)) AS edition",
        "version_patterns": [r"Microsoft SQL Server.*?([0-9]+\.[0-9.]+(?:\.[0-9.]+)*)", r"SQL Server\s+([0-9]{4})"],
        "skills": ["sessions", "locks", "top_sql", "waits", "storage", "indexes", "statistics", "backup", "replication", "ha", "explain", "tuning"],
    },
    "postgresql": {
        "label": "PostgreSQL", "family": "sql", "default_port": 5432,
        "drivers": ["psycopg", "psycopg2"], "dialect": "PostgreSQL SQL / PL/pgSQL",
        "version_query": "SHOW server_version",
        "version_patterns": [r"PostgreSQL\s+([0-9]+(?:\.[0-9]+){0,3})"],
        "skills": ["sessions", "locks", "top_sql", "waits", "storage", "indexes", "statistics", "backup", "replication", "ha", "explain", "tuning"],
    },
    "mysql": {
        "label": "MySQL", "family": "sql", "default_port": 3306,
        "drivers": ["pymysql", "mysql.connector"], "dialect": "MySQL SQL",
        "version_query": "SELECT VERSION()",
        "version_patterns": [r"MySQL.*?([0-9]+\.[0-9]+(?:\.[0-9]+)?)", r"^([0-9]+\.[0-9]+(?:\.[0-9]+)?)"],
        "skills": ["sessions", "locks", "top_sql", "waits", "storage", "indexes", "statistics", "backup", "replication", "ha", "explain", "tuning"],
    },
    "mariadb": {
        "label": "MariaDB", "family": "sql", "default_port": 3306,
        "drivers": ["mariadb", "pymysql"], "dialect": "MariaDB SQL",
        "version_query": "SELECT VERSION()",
        "version_patterns": [r"([0-9]+\.[0-9]+(?:\.[0-9]+)?)-MariaDB", r"MariaDB.*?([0-9]+\.[0-9]+(?:\.[0-9]+)?)"],
        "skills": ["sessions", "locks", "top_sql", "waits", "storage", "indexes", "statistics", "backup", "replication", "ha", "explain", "tuning"],
    },
    "sqlite": {
        "label": "SQLite", "family": "sql_embedded", "default_port": None,
        "drivers": ["sqlite3"], "dialect": "SQLite SQL",
        "version_query": "SELECT sqlite_version()",
        "version_patterns": [r"SQLite.*?([0-9]+\.[0-9]+(?:\.[0-9]+)?)", r"^([0-9]+\.[0-9]+(?:\.[0-9]+)?)"],
        "skills": ["storage", "indexes", "statistics", "backup", "explain", "tuning"],
    },
    "firebird": {
        "label": "Firebird", "family": "sql", "default_port": 3050,
        "drivers": ["firebird.driver"], "dialect": "Firebird SQL / PSQL",
        "version_query": "SELECT RDB$GET_CONTEXT('SYSTEM','ENGINE_VERSION') FROM RDB$DATABASE",
        "version_patterns": [r"Firebird.*?([0-9]+\.[0-9]+(?:\.[0-9]+)?)"],
        "skills": ["sessions", "locks", "top_sql", "storage", "indexes", "statistics", "backup", "replication", "ha", "explain", "tuning"],
    },
    "db2": {
        "label": "IBM Db2", "family": "sql", "default_port": 50000,
        "drivers": ["ibm_db", "ibm_db_dbi"], "dialect": "Db2 SQL / SQL PL",
        "version_query": "SELECT service_level FROM TABLE(sysproc.env_get_inst_info()) AS t FETCH FIRST 1 ROW ONLY",
        "version_patterns": [r"DB2.*?v?([0-9]+\.[0-9]+(?:\.[0-9]+)?)", r"Db2.*?([0-9]+\.[0-9]+(?:\.[0-9]+)?)"],
        "skills": ["sessions", "locks", "top_sql", "waits", "storage", "indexes", "statistics", "backup", "replication", "ha", "explain", "tuning"],
    },
    "mongodb": {
        "label": "MongoDB", "family": "nosql_document", "default_port": 27017,
        "drivers": ["pymongo"], "dialect": "MongoDB Query / Aggregation Pipeline",
        "version_query": "db.runCommand({buildInfo:1})",
        "version_patterns": [r"MongoDB.*?v?([0-9]+\.[0-9]+(?:\.[0-9]+)?)", r"version[\"']?\s*[:=]\s*[\"']([0-9.]+)"],
        "skills": ["sessions", "locks", "top_sql", "storage", "indexes", "statistics", "backup", "replication", "ha", "explain", "tuning"],
    },
    "redis": {
        "label": "Redis", "family": "nosql_key_value", "default_port": 6379,
        "drivers": ["redis"], "dialect": "Redis Commands",
        "version_query": "INFO server",
        "version_patterns": [r"redis_version:([0-9.]+)", r"Redis.*?([0-9]+\.[0-9]+(?:\.[0-9]+)?)"],
        "skills": ["sessions", "top_sql", "storage", "backup", "replication", "ha", "tuning"],
    },
    "elasticsearch": {
        "label": "Elasticsearch", "family": "search_document", "default_port": 9200,
        "drivers": ["elasticsearch"], "dialect": "Elasticsearch Query DSL / ES|QL",
        "version_query": "GET /",
        "version_patterns": [r"Elasticsearch.*?([0-9]+\.[0-9]+(?:\.[0-9]+)?)", r'\"number\"\s*:\s*\"([0-9.]+)\"'],
        "skills": ["sessions", "top_sql", "storage", "indexes", "backup", "replication", "ha", "explain", "tuning"],
    },
    "opensearch": {
        "label": "OpenSearch", "family": "search_document", "default_port": 9200,
        "drivers": ["opensearchpy"], "dialect": "OpenSearch Query DSL / PPL",
        "version_query": "GET /",
        "version_patterns": [r"OpenSearch.*?([0-9]+\.[0-9]+(?:\.[0-9]+)?)", r'\"number\"\s*:\s*\"([0-9.]+)\"'],
        "skills": ["sessions", "top_sql", "storage", "indexes", "backup", "replication", "ha", "explain", "tuning"],
    },
    "cassandra": {
        "label": "Apache Cassandra", "family": "nosql_wide_column", "default_port": 9042,
        "drivers": ["cassandra"], "dialect": "CQL",
        "version_query": "SELECT release_version FROM system.local",
        "version_patterns": [r"Cassandra.*?([0-9]+\.[0-9]+(?:\.[0-9]+)?)"],
        "skills": ["sessions", "top_sql", "storage", "indexes", "backup", "replication", "ha", "explain", "tuning"],
    },
    "couchdb": {
        "label": "Apache CouchDB", "family": "nosql_document", "default_port": 5984,
        "drivers": ["couchdb"], "dialect": "Mango Query / CouchDB HTTP API",
        "version_query": "GET /",
        "version_patterns": [r"CouchDB.*?([0-9]+\.[0-9]+(?:\.[0-9]+)?)", r'\"version\"\s*:\s*\"([0-9.]+)\"'],
        "skills": ["sessions", "storage", "indexes", "backup", "replication", "ha", "explain", "tuning"],
    },
    "neo4j": {
        "label": "Neo4j", "family": "graph", "default_port": 7687,
        "drivers": ["neo4j"], "dialect": "Cypher",
        "version_query": "CALL dbms.components() YIELD versions RETURN versions[0] AS version",
        "version_patterns": [r"Neo4j.*?([0-9]+\.[0-9]+(?:\.[0-9]+)?)"],
        "skills": ["sessions", "locks", "top_sql", "storage", "indexes", "backup", "replication", "ha", "explain", "tuning"],
    },
    "generic_sql": {
        "label": "Generic SQL (ODBC/JDBC/SQLAlchemy)", "family": "sql_generic", "default_port": None,
        "drivers": ["sqlalchemy", "pyodbc"], "dialect": "ANSI SQL + capability probing",
        "version_query": "driver/database metadata",
        "version_patterns": [],
        "skills": ["storage", "indexes", "statistics", "explain", "tuning"],
    },
    "generic_rest": {
        "label": "Generic Database REST/API", "family": "api_generic", "default_port": None,
        "drivers": [], "dialect": "HTTP/REST metadata + provider-specific payload",
        "version_query": "GET metadata/version endpoint when available",
        "version_patterns": [],
        "skills": ["storage", "backup", "replication", "ha", "tuning"],
    },
}


VERSION_FEATURES: dict[str, list[dict[str, Any]]] = {
    "oracle": [
        {"feature": "cdb_pdb", "min": "12.1", "label": "CDB/PDB multitenant"},
        {"feature": "fetch_first", "min": "12.1", "label": "FETCH FIRST / OFFSET"},
        {"feature": "identity_columns", "min": "12.1", "label": "Identity columns"},
        {"feature": "json_sql", "min": "12.1", "label": "SQL/JSON"},
        {"feature": "automatic_indexing", "min": "19", "label": "Automatic Indexing (edition/service dependent)"},
        {"feature": "vector_type", "min": "23", "label": "VECTOR datatype / AI Vector Search"},
    ],
    "postgresql": [
        {"feature": "logical_replication", "min": "10", "label": "Built-in logical replication"},
        {"feature": "partition_pruning", "min": "11", "label": "Modern partition pruning"},
        {"feature": "generated_columns", "min": "12", "label": "Generated columns"},
        {"feature": "merge", "min": "15", "label": "MERGE"},
    ],
    "sqlserver": [
        {"feature": "query_store", "min": "13", "label": "Query Store (SQL Server 2016+)"},
        {"feature": "string_agg", "min": "14", "label": "STRING_AGG (SQL Server 2017+)"},
        {"feature": "accelerated_db_recovery", "min": "15", "label": "Accelerated Database Recovery (2019+)"},
        {"feature": "parameter_sensitive_plan", "min": "16", "label": "Parameter Sensitive Plan optimization (2022+)"},
    ],
    "mysql": [
        {"feature": "window_functions", "min": "8.0", "label": "Window functions"},
        {"feature": "cte", "min": "8.0", "label": "WITH / CTE"},
        {"feature": "explain_analyze", "min": "8.0.18", "label": "EXPLAIN ANALYZE"},
        {"feature": "show_replica_status", "min": "8.0.22", "label": "SHOW REPLICA STATUS terminology"},
    ],
    "mariadb": [
        {"feature": "window_functions", "min": "10.2", "label": "Window functions"},
        {"feature": "cte", "min": "10.2", "label": "WITH / CTE"},
        {"feature": "system_versioned_tables", "min": "10.3", "label": "System-versioned tables"},
    ],
    "sqlite": [
        {"feature": "window_functions", "min": "3.25", "label": "Window functions"},
        {"feature": "generated_columns", "min": "3.31", "label": "Generated columns"},
        {"feature": "returning", "min": "3.35", "label": "RETURNING"},
        {"feature": "strict_tables", "min": "3.37", "label": "STRICT tables"},
    ],
    "mongodb": [
        {"feature": "transactions", "min": "4.0", "label": "Multi-document transactions (replica set)"},
        {"feature": "sharded_transactions", "min": "4.2", "label": "Transactions on sharded clusters"},
        {"feature": "time_series", "min": "5.0", "label": "Time-series collections"},
        {"feature": "queryable_encryption", "min": "6.0", "label": "Queryable Encryption (availability depends on release)"},
    ],
    "redis": [
        {"feature": "acl", "min": "6.0", "label": "ACL"},
        {"feature": "io_threads", "min": "6.0", "label": "I/O threads"},
        {"feature": "functions", "min": "7.0", "label": "Redis Functions"},
    ],
    "elasticsearch": [
        {"feature": "data_streams", "min": "7.9", "label": "Data streams"},
        {"feature": "esql", "min": "8.11", "label": "ES|QL (version availability evolves)"},
    ],
    "opensearch": [
        {"feature": "knn", "min": "1.0", "label": "k-NN plugin/distribution support"},
        {"feature": "neural_search", "min": "2.9", "label": "Neural search features (plugin/config dependent)"},
    ],
    "cassandra": [
        {"feature": "sai", "min": "5.0", "label": "Storage Attached Indexes in upstream Cassandra 5"},
    ],
    "couchdb": [
        {"feature": "clustered", "min": "2.0", "label": "Native clustered architecture"},
        {"feature": "partitioned_db", "min": "3.0", "label": "Partitioned databases"},
    ],
    "neo4j": [
        {"feature": "show_transactions", "min": "5.0", "label": "SHOW TRANSACTIONS command"},
        {"feature": "vector_index", "min": "5.11", "label": "Vector indexes (exact availability varies by minor release)"},
    ],
}


COMPATIBILITY_RULES: dict[str, list[dict[str, Any]]] = {
    "oracle": [
        {"pattern": r"\bFETCH\s+FIRST\b|\bOFFSET\s+\d+\s+ROWS\b", "min": "12.1", "feature": "FETCH FIRST/OFFSET", "alternative": "Use ROWNUM / ROW_NUMBER() compatible with the target release."},
        {"pattern": r"\bCREATE\s+PLUGGABLE\b|\bV\$PDBS\b|\bCDB_", "min": "12.1", "feature": "CDB/PDB", "alternative": "This database release is non-CDB; use database/schema concepts available in that release."},
        {"pattern": r"\bVECTOR\b|VECTOR_DISTANCE|VECTOR_SEARCH", "min": "23", "feature": "AI Vector Search", "alternative": "Use an external vector store or upgrade to a release supporting vectors."},
    ],
    "postgresql": [
        {"pattern": r"\bMERGE\b", "min": "15", "feature": "MERGE", "alternative": "Use INSERT ... ON CONFLICT plus UPDATE logic on older PostgreSQL."},
        {"pattern": r"\bGENERATED\s+ALWAYS\s+AS\b", "min": "12", "feature": "Generated columns", "alternative": "Use trigger/view/application logic on older releases."},
    ],
    "sqlserver": [
        {"pattern": r"\bSTRING_AGG\s*\(", "min": "14", "feature": "STRING_AGG", "alternative": "Use FOR XML PATH/STUFF on older SQL Server."},
        {"pattern": r"\bAPPROX_COUNT_DISTINCT\s*\(", "min": "15", "feature": "APPROX_COUNT_DISTINCT", "alternative": "Use COUNT(DISTINCT ...) where acceptable."},
    ],
    "mysql": [
        {"pattern": r"\bWITH\b", "min": "8.0", "feature": "CTE", "alternative": "Use derived tables/subqueries on MySQL 5.7 and older."},
        {"pattern": r"\bOVER\s*\(", "min": "8.0", "feature": "Window functions", "alternative": "Use variables/self-joins/derived tables on older releases."},
        {"pattern": r"\bEXPLAIN\s+ANALYZE\b", "min": "8.0.18", "feature": "EXPLAIN ANALYZE", "alternative": "Use EXPLAIN FORMAT=JSON and runtime metrics from Performance Schema."},
    ],
    "mariadb": [
        {"pattern": r"\bOVER\s*\(", "min": "10.2", "feature": "Window functions", "alternative": "Use derived tables/self-joins on older MariaDB."},
        {"pattern": r"\bWITH\b", "min": "10.2", "feature": "CTE", "alternative": "Use derived tables/subqueries on older MariaDB."},
    ],
    "sqlite": [
        {"pattern": r"\bRETURNING\b", "min": "3.35", "feature": "RETURNING", "alternative": "Execute the DML and read last_insert_rowid()/a follow-up SELECT."},
        {"pattern": r"\bOVER\s*\(", "min": "3.25", "feature": "Window functions", "alternative": "Use correlated subqueries/self-joins on older SQLite."},
    ],
    "neo4j": [
        {"pattern": r"\bSHOW\s+TRANSACTIONS\b", "min": "5.0", "feature": "SHOW TRANSACTIONS", "alternative": "Use the transaction procedures available in the installed Neo4j 4.x release."},
    ],
}


DIAGNOSTIC_LIBRARY: dict[str, list[dict[str, Any]]] = {
    "oracle": [
        {"skill": "identity", "query": "SELECT banner FROM v$version WHERE ROWNUM = 1", "min": "8.1"},
        {"skill": "sessions", "query": "SELECT status, COUNT(*) qtd FROM v$session WHERE type='USER' GROUP BY status", "min": "8.1"},
        {"skill": "locks", "query": "SELECT sid, serial#, username, status, blocking_session, event, seconds_in_wait FROM v$session WHERE blocking_session IS NOT NULL", "min": "10.1"},
        {"skill": "top_sql", "query": "SELECT * FROM (SELECT sql_id, executions, elapsed_time, cpu_time, buffer_gets, disk_reads, SUBSTR(sql_text,1,200) sql_text FROM v$sql WHERE executions > 0 ORDER BY elapsed_time DESC) WHERE ROWNUM <= 20", "min": "10.1"},
        {"skill": "storage", "query": "SELECT tablespace_name, ROUND(SUM(bytes)/1024/1024) mb FROM dba_data_files GROUP BY tablespace_name ORDER BY tablespace_name", "min": "8.1"},
        {"skill": "backup", "query": "SELECT status, input_type, start_time, end_time FROM v$rman_backup_job_details ORDER BY start_time DESC FETCH FIRST 20 ROWS ONLY", "min": "12.1", "fallback": "SELECT * FROM (SELECT status, input_type, start_time, end_time FROM v$rman_backup_job_details ORDER BY start_time DESC) WHERE ROWNUM <= 20"},
        {"skill": "replication", "query": "SELECT dest_id, status, target, destination, error, recovery_mode FROM v$archive_dest_status WHERE status <> 'INACTIVE'", "min": "10.1"},
        {"skill": "ha", "query": "SELECT database_role, open_mode, protection_mode, switchover_status FROM v$database", "min": "10.1"},
    ],
    "postgresql": [
        {"skill": "identity", "query": "SELECT version(), current_setting('server_version_num') server_version_num"},
        {"skill": "sessions", "query": "SELECT state, COUNT(*) FROM pg_stat_activity GROUP BY state ORDER BY 2 DESC"},
        {"skill": "locks", "query": "SELECT a.pid, a.usename, a.state, a.wait_event_type, a.wait_event, pg_blocking_pids(a.pid) blockers, a.query FROM pg_stat_activity a WHERE cardinality(pg_blocking_pids(a.pid)) > 0", "min": "9.6"},
        {"skill": "top_sql", "query": "SELECT queryid, calls, total_exec_time, mean_exec_time, rows, LEFT(query,200) query FROM pg_stat_statements ORDER BY total_exec_time DESC LIMIT 20", "extension": "pg_stat_statements"},
        {"skill": "storage", "query": "SELECT datname, pg_size_pretty(pg_database_size(datname)) size FROM pg_database ORDER BY pg_database_size(datname) DESC"},
        {"skill": "replication", "query": "SELECT application_name, client_addr, state, sync_state, write_lag, flush_lag, replay_lag FROM pg_stat_replication", "min": "9.2"},
    ],
    "sqlserver": [
        {"skill": "identity", "query": "SELECT SERVERPROPERTY('ProductVersion') version, SERVERPROPERTY('Edition') edition, SERVERPROPERTY('ProductLevel') product_level"},
        {"skill": "sessions", "query": "SELECT status, COUNT(*) sessions FROM sys.dm_exec_sessions WHERE is_user_process=1 GROUP BY status"},
        {"skill": "locks", "query": "SELECT request_session_id, resource_type, request_mode, request_status FROM sys.dm_tran_locks ORDER BY request_session_id"},
        {"skill": "top_sql", "query": "SELECT TOP 20 qs.execution_count, qs.total_elapsed_time, qs.total_worker_time, qs.total_logical_reads, SUBSTRING(st.text,1,4000) sql_text FROM sys.dm_exec_query_stats qs CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) st ORDER BY qs.total_elapsed_time DESC"},
        {"skill": "backup", "query": "SELECT TOP 20 database_name, type, backup_start_date, backup_finish_date FROM msdb.dbo.backupset ORDER BY backup_finish_date DESC"},
        {"skill": "ha", "query": "SELECT ag.name, ar.replica_server_name, ars.role_desc, ars.connected_state_desc, ars.synchronization_health_desc FROM sys.availability_groups ag JOIN sys.availability_replicas ar ON ag.group_id=ar.group_id JOIN sys.dm_hadr_availability_replica_states ars ON ar.replica_id=ars.replica_id", "min": "11"},
    ],
    "mysql": [
        {"skill": "identity", "query": "SELECT VERSION() version"},
        {"skill": "sessions", "query": "SELECT COMMAND, COUNT(*) FROM information_schema.PROCESSLIST GROUP BY COMMAND"},
        {"skill": "top_sql", "query": "SELECT DIGEST, COUNT_STAR, SUM_TIMER_WAIT, AVG_TIMER_WAIT, LEFT(DIGEST_TEXT,200) sql_text FROM performance_schema.events_statements_summary_by_digest ORDER BY SUM_TIMER_WAIT DESC LIMIT 20", "min": "5.6"},
        {"skill": "storage", "query": "SELECT table_schema, ROUND(SUM(data_length+index_length)/1024/1024,2) mb FROM information_schema.tables GROUP BY table_schema ORDER BY mb DESC"},
        {"skill": "replication", "query": "SHOW REPLICA STATUS", "min": "8.0.22", "fallback": "SHOW SLAVE STATUS"},
    ],
    "mariadb": [
        {"skill": "identity", "query": "SELECT VERSION() version"},
        {"skill": "sessions", "query": "SELECT COMMAND, COUNT(*) FROM information_schema.PROCESSLIST GROUP BY COMMAND"},
        {"skill": "top_sql", "query": "SELECT DIGEST, COUNT_STAR, SUM_TIMER_WAIT, AVG_TIMER_WAIT, LEFT(DIGEST_TEXT,200) sql_text FROM performance_schema.events_statements_summary_by_digest ORDER BY SUM_TIMER_WAIT DESC LIMIT 20", "min": "10.0"},
        {"skill": "storage", "query": "SELECT table_schema, ROUND(SUM(data_length+index_length)/1024/1024,2) mb FROM information_schema.tables GROUP BY table_schema ORDER BY mb DESC"},
        {"skill": "replication", "query": "SHOW SLAVE STATUS"},
    ],
    "sqlite": [
        {"skill": "identity", "query": "SELECT sqlite_version() version"},
        {"skill": "storage", "query": "PRAGMA database_list"},
        {"skill": "indexes", "query": "SELECT name, tbl_name, sql FROM sqlite_master WHERE type='index' ORDER BY tbl_name, name"},
        {"skill": "statistics", "query": "SELECT * FROM sqlite_stat1"},
        {"skill": "backup", "query": "PRAGMA wal_checkpoint(PASSIVE)"},
    ],
    "firebird": [
        {"skill": "identity", "query": "SELECT RDB$GET_CONTEXT('SYSTEM','ENGINE_VERSION') version FROM RDB$DATABASE"},
        {"skill": "sessions", "query": "SELECT MON$ATTACHMENT_ID, MON$USER, MON$REMOTE_ADDRESS, MON$STATE FROM MON$ATTACHMENTS"},
        {"skill": "top_sql", "query": "SELECT MON$STATEMENT_ID, MON$ATTACHMENT_ID, MON$STATE, MON$SQL_TEXT FROM MON$STATEMENTS"},
        {"skill": "storage", "query": "SELECT MON$DATABASE_NAME, MON$PAGE_SIZE, MON$PAGES FROM MON$DATABASE"},
    ],
    "db2": [
        {"skill": "identity", "query": "SELECT service_level, fixpack_num FROM TABLE(sysproc.env_get_inst_info()) AS t"},
        {"skill": "sessions", "query": "SELECT application_handle, session_auth_id, application_name, application_status FROM TABLE(MON_GET_CONNECTION(NULL,-2))"},
        {"skill": "locks", "query": "SELECT application_handle, lock_object_type, lock_mode, lock_status FROM TABLE(MON_GET_LOCKS(NULL,-2))"},
        {"skill": "top_sql", "query": "SELECT stmt_text, num_executions, total_act_time, total_cpu_time FROM TABLE(MON_GET_PKG_CACHE_STMT(NULL,NULL,NULL,-2)) ORDER BY total_act_time DESC FETCH FIRST 20 ROWS ONLY"},
    ],
    "mongodb": [
        {"skill": "identity", "command": {"buildInfo": 1}},
        {"skill": "sessions", "command": {"currentOp": 1, "$all": True}},
        {"skill": "storage", "command": {"dbStats": 1}},
        {"skill": "replication", "command": {"replSetGetStatus": 1}},
        {"skill": "ha", "command": {"hello": 1}},
    ],
    "redis": [
        {"skill": "identity", "command": "INFO server"},
        {"skill": "sessions", "command": "CLIENT LIST"},
        {"skill": "top_sql", "command": "SLOWLOG GET 20"},
        {"skill": "storage", "command": "INFO memory"},
        {"skill": "replication", "command": "INFO replication"},
        {"skill": "backup", "command": "INFO persistence"},
    ],
    "elasticsearch": [
        {"skill": "identity", "endpoint": "GET /"},
        {"skill": "ha", "endpoint": "GET /_cluster/health"},
        {"skill": "storage", "endpoint": "GET /_cat/indices?format=json&bytes=mb"},
        {"skill": "top_sql", "endpoint": "GET /_tasks?detailed=true&actions=*search"},
        {"skill": "backup", "endpoint": "GET /_snapshot"},
    ],
    "opensearch": [
        {"skill": "identity", "endpoint": "GET /"},
        {"skill": "ha", "endpoint": "GET /_cluster/health"},
        {"skill": "storage", "endpoint": "GET /_cat/indices?format=json&bytes=mb"},
        {"skill": "top_sql", "endpoint": "GET /_tasks?detailed=true&actions=*search"},
        {"skill": "backup", "endpoint": "GET /_snapshot"},
    ],
    "cassandra": [
        {"skill": "identity", "query": "SELECT release_version, cluster_name, data_center, rack FROM system.local"},
        {"skill": "ha", "query": "SELECT peer, data_center, rack, release_version FROM system.peers"},
        {"skill": "storage", "query": "SELECT keyspace_name, replication FROM system_schema.keyspaces"},
    ],
    "couchdb": [
        {"skill": "identity", "endpoint": "GET /"},
        {"skill": "ha", "endpoint": "GET /_membership"},
        {"skill": "sessions", "endpoint": "GET /_active_tasks"},
        {"skill": "storage", "endpoint": "GET /_all_dbs"},
    ],
    "neo4j": [
        {"skill": "identity", "query": "CALL dbms.components() YIELD name, versions, edition RETURN name, versions, edition"},
        {"skill": "sessions", "query": "SHOW TRANSACTIONS YIELD transactionId, username, currentQuery, status, elapsedTime", "min": "5.0", "fallback": "CALL dbms.listTransactions()"},
        {"skill": "indexes", "query": "SHOW INDEXES", "min": "4.0"},
        {"skill": "storage", "query": "SHOW DATABASES", "min": "4.0"},
    ],
}


ENGINE_ALIASES = {
    "mssql": "sqlserver", "sql server": "sqlserver", "postgres": "postgresql", "pg": "postgresql",
    "mongo": "mongodb", "elastic": "elasticsearch", "open search": "opensearch", "ibm db2": "db2",
    "couch db": "couchdb", "fire bird": "firebird",
}


def normalize_engine(value: str) -> str:
    key = re.sub(r"\s+", " ", (value or "").strip().lower())
    key = ENGINE_ALIASES.get(key, key.replace("-", ""))
    if key in ENGINE_CATALOG:
        return key
    # match labels
    for k, data in ENGINE_CATALOG.items():
        if key and key in data["label"].lower():
            return k
    return "generic_sql" if key else ""


def detect_engine(banner: str = "", hint: str = "") -> dict[str, Any]:
    text = f"{hint}\n{banner}".strip()
    low = text.lower()
    explicit = normalize_engine(hint)
    if hint and explicit and explicit not in {"generic_sql", "generic_rest"}:
        engine = explicit
    else:
        signatures = [
            ("oracle", ["oracle database", "oracle9i", "oracle10g", "oracle11g", "oracle12c", "oracle19c", "oracle23"]),
            ("sqlserver", ["microsoft sql server", "sql server"]),
            ("postgresql", ["postgresql", "postgres "]),
            ("mariadb", ["mariadb"]),
            ("mysql", ["mysql"]),
            ("sqlite", ["sqlite"]),
            ("firebird", ["firebird"]),
            ("db2", ["db2", "ibm db2"]),
            ("mongodb", ["mongodb", "mongod"]),
            ("redis", ["redis_version", "redis server"]),
            ("opensearch", ["opensearch"]),
            ("elasticsearch", ["elasticsearch"]),
            ("cassandra", ["cassandra"]),
            ("couchdb", ["couchdb"]),
            ("neo4j", ["neo4j"]),
        ]
        engine = ""
        for candidate, needles in signatures:
            if any(n in low for n in needles):
                engine = candidate
                break
        if not engine:
            engine = explicit or "generic_sql"
    version = detect_version(engine, banner)
    return {"ok": True, "engine": engine, "version": version, "catalog": engine_info(engine)}


def detect_version(engine: str, banner: str) -> str:
    e = normalize_engine(engine) or engine
    text = str(banner or "")
    for pattern in ENGINE_CATALOG.get(e, {}).get("version_patterns", []):
        m = re.search(pattern, text, re.I | re.S)
        if m:
            return m.group(1)
    # conservative generic fallback: only parse dotted number when banner carries engine/hint
    m = re.search(r"\b([0-9]+\.[0-9]+(?:\.[0-9]+){0,3})\b", text)
    return m.group(1) if m else ""


def engine_info(engine: str) -> dict[str, Any]:
    key = normalize_engine(engine) or "generic_sql"
    data = ENGINE_CATALOG.get(key, ENGINE_CATALOG["generic_sql"])
    return {"key": key, **data, "driver_status": driver_status(key)}


def driver_status(engine: str = "") -> dict[str, Any]:
    keys = [normalize_engine(engine)] if engine else list(ENGINE_CATALOG)
    result = {}
    for key in keys:
        if not key:
            continue
        drivers = ENGINE_CATALOG[key].get("drivers", [])
        result[key] = {
            "drivers": [{"name": d, "installed": _module_available(d.split(".")[0])} for d in drivers],
            "any_installed": any(_module_available(d.split(".")[0]) for d in drivers) if drivers else True,
        }
    return result.get(normalize_engine(engine), {}) if engine else result


def capability_matrix(engine: str, version: str = "", edition: str = "") -> dict[str, Any]:
    key = normalize_engine(engine) or "generic_sql"
    base_skills = ENGINE_CATALOG.get(key, ENGINE_CATALOG["generic_sql"]).get("skills", [])
    features = []
    for item in VERSION_FEATURES.get(key, []):
        supported = _at_least(version, item["min"]) if version else None
        features.append({**item, "supported": supported})
    skills = {}
    for skill in ["sessions", "locks", "top_sql", "waits", "storage", "indexes", "statistics", "backup", "replication", "ha", "explain", "tuning"]:
        skills[skill] = {
            "supported": skill in base_skills,
            "score_target": 10 if skill in base_skills else 0,
            "mode": "native" if skill in base_skills else "not_applicable_or_generic_fallback",
        }
    return {
        "ok": True, "engine": key, "label": ENGINE_CATALOG[key]["label"], "version": version,
        "edition": edition, "dialect": ENGINE_CATALOG[key]["dialect"], "skills": skills,
        "version_features": features,
        "note": "Feature support may additionally depend on edition, extension/plugin, license, deployment mode and privileges.",
    }


def compatibility_review(engine: str, version: str, statement: str) -> dict[str, Any]:
    key = normalize_engine(engine) or "generic_sql"
    findings = []
    for rule in COMPATIBILITY_RULES.get(key, []):
        if re.search(rule["pattern"], statement or "", re.I | re.S) and version and not _at_least(version, rule["min"]):
            findings.append({
                "severity": "error", "feature": rule["feature"], "requires": f">= {rule['min']}",
                "target_version": version, "alternative": rule["alternative"],
            })
    # Cross-dialect anti-patterns: high-confidence only.
    cross = []
    stmt = statement or ""
    if key != "oracle" and re.search(r"\bROWNUM\b|\bNVL\s*\(|\bV\$SESSION\b", stmt, re.I):
        cross.append({"severity": "error", "feature": "Oracle-specific syntax", "alternative": f"Rewrite for {ENGINE_CATALOG[key]['dialect']}."})
    if key != "sqlserver" and re.search(r"\bTOP\s+\d+\b|\bGETDATE\s*\(", stmt, re.I):
        cross.append({"severity": "error", "feature": "SQL Server-specific syntax", "alternative": f"Rewrite for {ENGINE_CATALOG[key]['dialect']}."})
    if key not in {"mysql", "mariadb"} and re.search(r"\bLIMIT\s+\d+\s*,\s*\d+\b|\bIFNULL\s*\(", stmt, re.I):
        cross.append({"severity": "warning", "feature": "MySQL/MariaDB-specific syntax", "alternative": f"Review for {ENGINE_CATALOG[key]['dialect']}."})
    findings.extend(cross)
    return {
        "ok": not any(x["severity"] == "error" for x in findings), "engine": key, "version": version,
        "compatible": not findings, "findings": findings,
        "rule": "Do not execute a statement containing an unsupported feature for the detected engine/version.",
    }


def diagnostic_plan(engine: str, version: str = "", scopes: list[str] | None = None) -> dict[str, Any]:
    key = normalize_engine(engine) or "generic_sql"
    wanted = set(scopes or [])
    items = []
    for item in DIAGNOSTIC_LIBRARY.get(key, []):
        if wanted and item.get("skill") not in wanted:
            continue
        chosen = dict(item)
        min_v = item.get("min")
        if min_v and version and not _at_least(version, min_v):
            if item.get("fallback"):
                chosen["query"] = item["fallback"]
                chosen["compatibility"] = f"fallback_for_{version}"
            else:
                chosen["supported"] = False
                chosen["reason"] = f"requires >= {min_v}"
                items.append(chosen)
                continue
        chosen["supported"] = True
        items.append(chosen)
    # Complete every applicable skill with an explicit provider-aware advisory plan when
    # no single safe portable query exists. This is better than fabricating a command:
    # HAL knows the skill is applicable, but marks it as adapter/advisory until live metadata
    # confirms edition/plugins/privileges.
    existing = {x.get("skill") for x in items}
    for skill in ENGINE_CATALOG.get(key, ENGINE_CATALOG["generic_sql"]).get("skills", []):
        if wanted and skill not in wanted:
            continue
        if skill not in existing:
            items.append({
                "skill": skill,
                "supported": True,
                "mode": "provider_adapter_advisory",
                "action": f"Use {ENGINE_CATALOG[key]['label']} native metadata/diagnostic facilities for {skill}; probe capabilities before execution.",
            })
            existing.add(skill)
    if key.startswith("generic"):
        generic_core = [
            {"skill": "identity", "supported": True, "action": "Read driver/database metadata"},
            {"skill": "metadata", "supported": True, "action": "Discover schemas/catalogs/tables/columns through ODBC/JDBC/SQLAlchemy/REST metadata"},
            {"skill": "safe_probe", "supported": True, "action": "Run read-only capability probes before generating vendor-specific syntax"},
        ]
        present = {x.get("skill") for x in items}
        items = [x for x in generic_core if x["skill"] not in present] + items
    return {
        "ok": True, "engine": key, "version": version, "read_only": True,
        "items": items, "count": len(items),
        "safety": ["Read-only by default", "Version check before execution", "Timeout/row limits", "Human approval for write/change actions"],
    }


def _connection_by_id(connection_id: str) -> dict[str, Any] | None:
    try:
        from app.services import database_access_wizard
        data = database_access_wizard.list_connections(limit=500)
        for item in data.get("connections", []):
            if item.get("id") == connection_id:
                return item
    except Exception:
        return None
    return None


def _env_value(prefix: str, key: str, default: Any = "") -> Any:
    return os.getenv(f"{prefix}_{key}", default)


def connection_profile(connection_id: str, execute_probe: bool = False) -> dict[str, Any]:
    conn = _connection_by_id(connection_id)
    if not conn:
        return {"ok": False, "error": "Conexão não encontrada no Database Access Wizard.", "connection_id": connection_id}
    engine = normalize_engine(conn.get("database_type", "")) or "generic_sql"
    prefix = conn.get("env_prefix") or ""
    profile = {
        "ok": True, "connection": {k: v for k, v in conn.items() if k.lower() not in {"password", "token", "secret"}},
        "engine": engine_info(engine), "capabilities": capability_matrix(engine),
        "credential_source": f"environment/credential-vault prefix {prefix}", "credentials_exposed": False,
    }
    if execute_probe:
        profile["probe"] = probe_registered_connection(conn)
        if profile["probe"].get("version"):
            profile["capabilities"] = capability_matrix(engine, profile["probe"]["version"], profile["probe"].get("edition", ""))
            profile["diagnostic_plan"] = diagnostic_plan(engine, profile["probe"]["version"])
    else:
        profile["diagnostic_plan"] = diagnostic_plan(engine)
    return profile


def _first_row(cursor) -> Any:
    row = cursor.fetchone()
    if row is None:
        return None
    if isinstance(row, (list, tuple)):
        return row[0] if len(row) == 1 else list(row)
    return row


def probe_registered_connection(conn: dict[str, Any]) -> dict[str, Any]:
    engine = normalize_engine(conn.get("database_type", "")) or "generic_sql"
    prefix = conn.get("env_prefix") or ""
    started = time.time()
    try:
        if engine == "sqlite":
            path = _env_value(prefix, "FILE_PATH", conn.get("database_name") or conn.get("host"))
            if not path:
                return {"ok": False, "error": f"Defina {prefix}_FILE_PATH.", "engine": engine}
            db = sqlite3.connect(path, timeout=5)
            try:
                version = str(db.execute("SELECT sqlite_version()").fetchone()[0])
            finally:
                db.close()
            return _probe_ok(engine, version, started)
        if engine == "oracle":
            import oracledb
            user = _env_value(prefix, "USER")
            pwd = _env_value(prefix, "PASSWORD")
            host = _env_value(prefix, "HOST", conn.get("host", ""))
            port = int(_env_value(prefix, "PORT", conn.get("port") or 1521))
            service = _env_value(prefix, "SERVICE_NAME_OR_SID", conn.get("database_name", ""))
            dsn = oracledb.makedsn(host, port, service_name=service)
            db = oracledb.connect(user=user, password=pwd, dsn=dsn)
            try:
                cur = db.cursor(); cur.execute(ENGINE_CATALOG[engine]["version_query"]); banner = str(_first_row(cur) or "")
            finally: db.close()
            return _probe_ok(engine, detect_version(engine, banner), started, banner=banner)
        if engine == "postgresql":
            import psycopg
            db = psycopg.connect(host=_env_value(prefix,"HOST",conn.get("host","")), port=int(_env_value(prefix,"PORT",conn.get("port") or 5432)), dbname=_env_value(prefix,"DATABASE",conn.get("database_name","")), user=_env_value(prefix,"USER"), password=_env_value(prefix,"PASSWORD"), connect_timeout=5)
            try:
                with db.cursor() as cur: cur.execute("SHOW server_version"); version = str(cur.fetchone()[0])
            finally: db.close()
            return _probe_ok(engine, version, started)
        if engine == "sqlserver":
            import pyodbc
            host = _env_value(prefix,"HOST",conn.get("host","")); port = _env_value(prefix,"PORT",conn.get("port") or 1433)
            database = _env_value(prefix,"DATABASE",conn.get("database_name","")); user = _env_value(prefix,"USER"); pwd = _env_value(prefix,"PASSWORD")
            driver = _env_value(prefix,"ODBC_DRIVER","ODBC Driver 18 for SQL Server")
            cs = f"DRIVER={{{driver}}};SERVER={host},{port};DATABASE={database};UID={user};PWD={pwd};TrustServerCertificate=yes;Connection Timeout=5"
            db = pyodbc.connect(cs, timeout=5)
            try:
                cur=db.cursor(); cur.execute(ENGINE_CATALOG[engine]["version_query"]); row=cur.fetchone(); version=str(row[0]); edition=str(row[1]) if len(row)>1 else ""
            finally: db.close()
            return _probe_ok(engine, version, started, edition=edition)
        if engine in {"mysql", "mariadb"}:
            try:
                import pymysql
                db=pymysql.connect(host=_env_value(prefix,"HOST",conn.get("host","")), port=int(_env_value(prefix,"PORT",conn.get("port") or 3306)), user=_env_value(prefix,"USER"), password=_env_value(prefix,"PASSWORD"), database=_env_value(prefix,"DATABASE",conn.get("database_name","")), connect_timeout=5, read_timeout=5, write_timeout=5)
                try:
                    with db.cursor() as cur: cur.execute("SELECT VERSION()"); version=str(cur.fetchone()[0])
                finally: db.close()
            except ImportError:
                if engine == "mariadb":
                    import mariadb
                    db=mariadb.connect(host=_env_value(prefix,"HOST",conn.get("host","")), port=int(_env_value(prefix,"PORT",conn.get("port") or 3306)), user=_env_value(prefix,"USER"), password=_env_value(prefix,"PASSWORD"), database=_env_value(prefix,"DATABASE",conn.get("database_name","")), connect_timeout=5)
                    try:
                        cur=db.cursor(); cur.execute("SELECT VERSION()"); version=str(cur.fetchone()[0])
                    finally: db.close()
                else:
                    raise
            return _probe_ok(engine, version, started)
        if engine == "mongodb":
            from pymongo import MongoClient
            uri=_env_value(prefix,"URI") or f"mongodb://{_env_value(prefix,'HOST',conn.get('host','localhost'))}:{_env_value(prefix,'PORT',conn.get('port') or 27017)}"
            client=MongoClient(uri, serverSelectionTimeoutMS=5000)
            try: info=client.admin.command("buildInfo"); version=str(info.get("version", ""))
            finally: client.close()
            return _probe_ok(engine, version, started)
        if engine == "redis":
            import redis
            client=redis.Redis(host=_env_value(prefix,"HOST",conn.get("host","localhost")), port=int(_env_value(prefix,"PORT",conn.get("port") or 6379)), db=int(_env_value(prefix,"DB",0)), password=_env_value(prefix,"PASSWORD") or None, socket_connect_timeout=5, socket_timeout=5, decode_responses=True)
            info=client.info("server"); version=str(info.get("redis_version", "")); client.close()
            return _probe_ok(engine, version, started)
        if engine == "neo4j":
            from neo4j import GraphDatabase
            uri=_env_value(prefix,"URI") or f"bolt://{_env_value(prefix,'HOST',conn.get('host','localhost'))}:{_env_value(prefix,'PORT',conn.get('port') or 7687)}"
            drv=GraphDatabase.driver(uri, auth=(_env_value(prefix,"USER"), _env_value(prefix,"PASSWORD")))
            try:
                with drv.session(database=_env_value(prefix,"DATABASE",conn.get("database_name","")) or None) as s:
                    rec=s.run("CALL dbms.components() YIELD versions RETURN versions[0] AS version LIMIT 1").single(); version=str(rec["version"] if rec else "")
            finally: drv.close()
            return _probe_ok(engine, version, started)
        if engine == "firebird":
            from firebird.driver import connect
            host=_env_value(prefix,"HOST",conn.get("host","localhost")); port=int(_env_value(prefix,"PORT",conn.get("port") or 3050))
            database=_env_value(prefix,"DATABASE_PATH",conn.get("database_name","")); user=_env_value(prefix,"USER"); pwd=_env_value(prefix,"PASSWORD")
            dsn=f"{host}/{port}:{database}" if host else database
            db=connect(dsn, user=user, password=pwd, charset=_env_value(prefix,"CHARSET","UTF8"))
            try:
                cur=db.cursor(); cur.execute("SELECT RDB$GET_CONTEXT('SYSTEM','ENGINE_VERSION') FROM RDB$DATABASE"); version=str(cur.fetchone()[0])
            finally: db.close()
            return _probe_ok(engine, version, started)
        if engine == "db2":
            import ibm_db
            host=_env_value(prefix,"HOST",conn.get("host","")); port=_env_value(prefix,"PORT",conn.get("port") or 50000)
            database=_env_value(prefix,"DATABASE",conn.get("database_name","")); user=_env_value(prefix,"USER"); pwd=_env_value(prefix,"PASSWORD")
            cs=f"DATABASE={database};HOSTNAME={host};PORT={port};PROTOCOL=TCPIP;UID={user};PWD={pwd};CONNECTTIMEOUT=5;"
            db=ibm_db.connect(cs,"","")
            try:
                info=ibm_db.server_info(db); version=str(getattr(info,"DBMS_VER","") or "")
            finally: ibm_db.close(db)
            return _probe_ok(engine, version, started)
        if engine == "elasticsearch":
            from elasticsearch import Elasticsearch
            url=_env_value(prefix,"URL") or f"http://{_env_value(prefix,'HOST',conn.get('host','localhost'))}:{_env_value(prefix,'PORT',conn.get('port') or 9200)}"
            api_key=_env_value(prefix,"API_KEY") or None
            kwargs={"request_timeout":5}
            if api_key: kwargs["api_key"]=api_key
            client=Elasticsearch(url,**kwargs); info=client.info(); client.close()
            version=str((info.get("version") or {}).get("number", ""))
            return _probe_ok(engine, version, started, cluster_name=info.get("cluster_name", ""))
        if engine == "opensearch":
            from opensearchpy import OpenSearch
            url=_env_value(prefix,"URL")
            if url:
                from urllib.parse import urlparse
                u=urlparse(url); hosts=[{"host":u.hostname or "localhost","port":u.port or (443 if u.scheme=="https" else 9200),"scheme":u.scheme or "http"}]
            else:
                hosts=[{"host":_env_value(prefix,"HOST",conn.get("host","localhost")),"port":int(_env_value(prefix,"PORT",conn.get("port") or 9200)),"scheme":"http"}]
            user=_env_value(prefix,"USER"); pwd=_env_value(prefix,"PASSWORD")
            client=OpenSearch(hosts=hosts,http_auth=(user,pwd) if user else None,timeout=5); info=client.info(); client.close()
            version=str((info.get("version") or {}).get("number", ""))
            return _probe_ok(engine, version, started, cluster_name=info.get("cluster_name", ""))
        if engine == "cassandra":
            from cassandra.cluster import Cluster
            from cassandra.auth import PlainTextAuthProvider
            raw=_env_value(prefix,"CONTACT_POINTS",conn.get("host","") or "127.0.0.1")
            points=[x.strip() for x in str(raw).split(",") if x.strip()]
            user=_env_value(prefix,"USER"); pwd=_env_value(prefix,"PASSWORD")
            auth=PlainTextAuthProvider(username=user,password=pwd) if user else None
            cluster=Cluster(points,port=int(_env_value(prefix,"PORT",conn.get("port") or 9042)),auth_provider=auth,connect_timeout=5)
            session=cluster.connect()
            try:
                row=session.execute("SELECT release_version FROM system.local").one(); version=str(getattr(row,"release_version","") or "")
            finally: cluster.shutdown()
            return _probe_ok(engine, version, started)
        if engine in {"couchdb", "generic_rest"}:
            import base64 as _b64
            import urllib.request as _urlreq
            url=_env_value(prefix,"URL") or conn.get("host","")
            if not url:
                return {"ok":False,"engine":engine,"error":f"Defina {prefix}_URL."}
            req=_urlreq.Request(str(url).rstrip("/")+"/",method="GET")
            user=_env_value(prefix,"USER"); pwd=_env_value(prefix,"PASSWORD"); api_key=_env_value(prefix,"API_KEY")
            if user:
                token=_b64.b64encode(f"{user}:{pwd}".encode()).decode(); req.add_header("Authorization",f"Basic {token}")
            elif api_key:
                req.add_header("Authorization",f"Bearer {api_key}")
            with _urlreq.urlopen(req,timeout=5) as resp:
                body=json.loads(resp.read().decode("utf-8","replace"))
            version=str(body.get("version","") or (body.get("version") or {}).get("number","") if isinstance(body.get("version"),dict) else body.get("version", ""))
            return _probe_ok(engine, version, started, metadata={k:v for k,v in body.items() if k.lower() not in {"password","token","secret","api_key"}})
        if engine == "generic_sql":
            url=_env_value(prefix,"URL")
            if not url:
                return {"ok": False, "engine": engine, "error": f"Defina {prefix}_URL com uma URL SQLAlchemy para o fallback genérico."}
            from sqlalchemy import create_engine, text
            eng=create_engine(url, pool_pre_ping=True, connect_args={})
            with eng.connect() as c:
                dialect=eng.dialect.name; driver=eng.dialect.driver
            return {"ok": True, "engine": engine, "detected_dialect": dialect, "driver": driver, "latency_ms": round((time.time()-started)*1000, 1), "read_only_probe": True}
        return {"ok": False, "engine": engine, "error": "Probe real ainda requer o driver/adaptador específico. O plano/capability probing genérico permanece disponível.", "driver_status": driver_status(engine)}
    except Exception as exc:
        result={"ok": False, "engine": engine, "error": str(exc), "error_type": type(exc).__name__, "latency_ms": round((time.time()-started)*1000,1), "driver_status": driver_status(engine)}
        _audit({"event":"probe_failed","engine":engine,"connection_id":conn.get("id"),"error_type":type(exc).__name__})
        return result


def _probe_ok(engine: str, version: str, started: float, **extra: Any) -> dict[str, Any]:
    result={"ok":True,"engine":engine,"version":version,"latency_ms":round((time.time()-started)*1000,1),"read_only_probe":True,**extra}
    _audit({"event":"probe_ok","engine":engine,"version":version})
    return result


def status() -> dict[str, Any]:
    drivers=driver_status()
    native=sum(1 for k,v in drivers.items() if v.get("any_installed"))
    providers=len(ENGINE_CATALOG)
    return {
        "ok": True,
        "name": "HAL Universal Database Intelligence V25",
        "providers": providers,
        "native_driver_ready": native,
        "coverage": {
            "sql": [k for k,v in ENGINE_CATALOG.items() if v["family"].startswith("sql")],
            "nosql": [k for k,v in ENGINE_CATALOG.items() if not v["family"].startswith("sql") and not k.startswith("generic")],
            "fallbacks": ["generic_sql", "generic_rest"],
        },
        "skills": ["automatic_engine_detection", "version_awareness", "capability_matrix", "dialect_guard", "health", "sessions", "locks", "top_sql", "waits", "storage", "indexes", "statistics", "backup", "replication", "ha", "explain", "tuning", "generic_metadata_discovery"],
        "policy": {
            "read_only_default": True,
            "detect_before_generate": True,
            "version_guard_before_execute": True,
            "write_requires_human_approval": True,
            "credentials_never_returned": True,
        },
        "quality_target": "10/10 per applicable skill; unsupported/not-applicable features must be stated instead of fabricated.",
        "important": "No software can truthfully guarantee every proprietary database/version without the matching driver, privileges and vendor semantics. V25 uses native adapters plus capability probing/fallbacks and refuses unsupported syntax.",
    }


def catalog() -> dict[str, Any]:
    return {"ok":True,"engines":[engine_info(k) for k in ENGINE_CATALOG],"version_feature_rules":VERSION_FEATURES,"compatibility_rule_counts":{k:len(v) for k,v in COMPATIBILITY_RULES.items()}}


def skill_audit(engine: str, version: str = "") -> dict[str, Any]:
    cap=capability_matrix(engine,version)
    plan=diagnostic_plan(engine,version)
    planned={x.get("skill") for x in plan["items"] if x.get("supported")}
    rows=[]
    for skill,meta in cap["skills"].items():
        applicable=bool(meta["supported"])
        ready=(skill in planned) or skill in {"explain","tuning","indexes","statistics","waits"} and applicable
        rows.append({"skill":skill,"applicable":applicable,"plan_available":ready,"score":10 if applicable and ready else (0 if not applicable else 7),"note":"N/A for this engine" if not applicable else ("native/version-aware plan" if ready else "adapter extension recommended")})
    return {"ok":True,"engine":cap["engine"],"version":version,"skills":rows,"target":"10/10 for every applicable skill"}


SQLSERVER_YEAR_TO_MAJOR = {
    "2008": "10.0", "2008 r2": "10.5", "2012": "11.0", "2014": "12.0",
    "2016": "13.0", "2017": "14.0", "2019": "15.0", "2022": "16.0", "2025": "17.0",
}
ORACLE_MARKETING_TO_RELEASE = {
    "9i": "9.2", "10g": "10.2", "11g": "11.2", "12c": "12.1",
    "18c": "18", "19c": "19", "21c": "21", "23c": "23", "23ai": "23",
}


def canonical_version(engine: str, version_or_marketing: str) -> str:
    key = normalize_engine(engine) or engine
    raw = (version_or_marketing or "").strip().lower()
    if key == "sqlserver":
        for label, major in SQLSERVER_YEAR_TO_MAJOR.items():
            if label in raw:
                return major
    if key == "oracle":
        for label, release in ORACLE_MARKETING_TO_RELEASE.items():
            if label in raw:
                return release
    m = re.search(r"([0-9]+(?:\.[0-9]+){0,4})", raw)
    return m.group(1) if m else ""


def infer_engine_from_message(message: str) -> str:
    low = (message or "").lower()
    ordered = [
        ("sqlserver", ["sql server", "mssql", "t-sql", "tsql"]),
        ("postgresql", ["postgresql", "postgres", "pg_stat_"]),
        ("mariadb", ["mariadb", "maria db"]),
        ("mysql", ["mysql", "innodb"]),
        ("oracle", ["oracle", "pl/sql", "plsql", "awr", "ash", "v$session", "rman"]),
        ("sqlite", ["sqlite", "sqlite3"]),
        ("firebird", ["firebird"]),
        ("db2", ["db2", "ibm db2"]),
        ("mongodb", ["mongodb", "mongo ", "aggregation pipeline"]),
        ("redis", ["redis", "slowlog"]),
        ("opensearch", ["opensearch", "open search"]),
        ("elasticsearch", ["elasticsearch", "elastic search"]),
        ("cassandra", ["cassandra", "cql"]),
        ("couchdb", ["couchdb", "couch db"]),
        ("neo4j", ["neo4j", "cypher"]),
    ]
    for key, terms in ordered:
        if any(t in low for t in terms):
            return key
    return ""


def infer_version_from_message(engine: str, message: str) -> str:
    low = (message or "").lower()
    key = normalize_engine(engine) or engine
    if key == "sqlserver":
        for year in sorted(SQLSERVER_YEAR_TO_MAJOR, key=len, reverse=True):
            if year in low:
                return SQLSERVER_YEAR_TO_MAJOR[year]
    if key == "oracle":
        for label in sorted(ORACLE_MARKETING_TO_RELEASE, key=len, reverse=True):
            if label in low:
                return ORACLE_MARKETING_TO_RELEASE[label]
    m = re.search(r"\b(?:vers[aã]o|version|release)?\s*v?([0-9]+\.[0-9]+(?:\.[0-9]+){0,3})\b", low)
    return m.group(1) if m else ""


def infer_scopes(message: str) -> list[str]:
    low = (message or "").lower()
    mapping = {
        "sessions": ["sessão", "sessao", "session", "conexão", "conexao", "connection"],
        "locks": ["lock", "bloque", "deadlock", "blocking"],
        "top_sql": ["query", "queries", "sql pesada", "top sql", "lenta", "lento", "slow"],
        "waits": ["wait", "espera", "evento de espera"],
        "storage": ["tablespace", "storage", "disco", "espaço", "espaco", "size", "tamanho"],
        "indexes": ["índice", "indice", "index", "indexes", "indices"],
        "statistics": ["estatística", "estatistica", "statistics", "stats"],
        "backup": ["backup", "rman", "dump", "snapshot"],
        "replication": ["replica", "replicação", "replicacao", "standby", "wal", "binlog"],
        "ha": ["alta disponibilidade", "high availability", "always on", "dataguard", "data guard", "cluster", "rac"],
        "explain": ["plano", "explain", "execution plan", "plano de execução", "plano de execucao"],
        "tuning": ["tuning", "performance", "desempenho", "otimizar", "otimizacao", "otimização", "lento", "lenta"],
    }
    scopes=[]
    for skill, terms in mapping.items():
        if any(t in low for t in terms):
            scopes.append(skill)
    return scopes or ["sessions", "locks", "top_sql", "storage", "backup", "replication", "ha", "tuning"]


def guided_answer(message: str, connection_id: str = "", execute_probe: bool = False) -> dict[str, Any]:
    engine = infer_engine_from_message(message)
    if connection_id:
        profile = connection_profile(connection_id, execute_probe=execute_probe)
        if not profile.get("ok"):
            return profile
        engine = profile.get("engine", {}).get("key") or engine or "generic_sql"
        version = (profile.get("probe") or {}).get("version", "")
        plan = diagnostic_plan(engine, version, infer_scopes(message))
        return {
            "ok": True,
            "mode": "registered_connection",
            "engine": engine,
            "version": version,
            "answer": (
                f"Vou usar o HAL Universal Database Intelligence no {ENGINE_CATALOG[engine]['label']}"
                + (f" {version}" if version else "")
                + ". Primeiro valido versão/capacidades e só depois uso comandos compatíveis. "
                  "Diagnóstico é somente leitura por padrão; mudanças exigem aprovação humana."
            ),
            "profile": profile,
            "plan": plan,
        }
    if not engine:
        return {
            "ok": True,
            "mode": "needs_connection_or_engine",
            "answer": (
                "Consigo tratar bancos SQL e NoSQL, mas para não assumir dialeto errado preciso saber qual conexão/SGBD usar. "
                "Se a conexão estiver cadastrada, seleciono-a e detecto a versão automaticamente; se o banco não estiver no catálogo, uso o fallback genérico por metadata/capability probing."
            ),
            "supported": list(ENGINE_CATALOG),
        }
    version = infer_version_from_message(engine, message)
    scopes = infer_scopes(message)
    plan = diagnostic_plan(engine, version, scopes)
    cap = capability_matrix(engine, version)
    return {
        "ok": True,
        "mode": "engine_version_plan",
        "engine": engine,
        "version": version,
        "answer": (
            f"Detectei {ENGINE_CATALOG[engine]['label']}"
            + (f" {version}" if version else " (versão ainda não confirmada)")
            + ". Vou usar o adaptador e o dialeto corretos, aplicar o Version Guard antes de qualquer SQL/comando e montar diagnóstico equivalente para esse SGBD."
        ),
        "capabilities": cap,
        "plan": plan,
        "skill_audit": skill_audit(engine, version),
    }
