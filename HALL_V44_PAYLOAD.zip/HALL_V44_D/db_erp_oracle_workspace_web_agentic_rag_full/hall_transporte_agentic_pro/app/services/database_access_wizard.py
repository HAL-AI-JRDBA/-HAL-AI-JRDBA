from __future__ import annotations

import json
import os
import re
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "database_access_wizard"
CONNECTIONS_FILE = DATA_DIR / "connections.json"
REQUESTS_FILE = DATA_DIR / "data_requests.json"
PLANS_FILE = DATA_DIR / "query_plans.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"


DATABASE_CATALOG: dict[str, dict[str, Any]] = {
    "oracle": {
        "label": "Oracle",
        "family": "sql",
        "default_port": 1521,
        "driver": "oracledb",
        "env": ["HOST", "PORT", "SERVICE_NAME_OR_SID", "USER", "PASSWORD"],
        "question": "O banco é Oracle? Informe host, porta, service name/SID, usuário somente leitura e schema principal.",
    },
    "sqlserver": {
        "label": "SQL Server",
        "family": "sql",
        "default_port": 1433,
        "driver": "pyodbc/pymssql",
        "env": ["HOST", "PORT", "DATABASE", "USER", "PASSWORD", "ODBC_DRIVER"],
        "question": "O banco é SQL Server? Informe servidor, porta, database, usuário somente leitura e driver ODBC.",
    },
    "postgresql": {
        "label": "PostgreSQL",
        "family": "sql",
        "default_port": 5432,
        "driver": "psycopg",
        "env": ["HOST", "PORT", "DATABASE", "USER", "PASSWORD", "SSLMODE"],
        "question": "O banco é PostgreSQL? Informe host, porta, database, usuário somente leitura e schema.",
    },
    "mysql": {
        "label": "MySQL",
        "family": "sql",
        "default_port": 3306,
        "driver": "pymysql",
        "env": ["HOST", "PORT", "DATABASE", "USER", "PASSWORD"],
        "question": "O banco é MySQL? Informe host, porta, database e usuário somente leitura.",
    },
    "mariadb": {
        "label": "MariaDB",
        "family": "sql",
        "default_port": 3306,
        "driver": "mariadb/pymysql",
        "env": ["HOST", "PORT", "DATABASE", "USER", "PASSWORD"],
        "question": "O banco é MariaDB? Informe host, porta, database e usuário somente leitura.",
    },
    "sqlite": {
        "label": "SQLite",
        "family": "sql",
        "default_port": None,
        "driver": "sqlite3",
        "env": ["FILE_PATH"],
        "question": "O banco é SQLite? Informe o caminho do arquivo .db/.sqlite.",
    },
    "firebird": {
        "label": "Firebird",
        "family": "sql",
        "default_port": 3050,
        "driver": "firebird-driver",
        "env": ["HOST", "PORT", "DATABASE_PATH", "USER", "PASSWORD"],
        "question": "O banco é Firebird? Informe host, porta, caminho da base, usuário somente leitura e charset.",
    },
    "db2": {
        "label": "IBM DB2",
        "family": "sql",
        "default_port": 50000,
        "driver": "ibm_db",
        "env": ["HOST", "PORT", "DATABASE", "USER", "PASSWORD"],
        "question": "O banco é DB2? Informe host, porta, database e usuário somente leitura.",
    },
    "mongodb": {
        "label": "MongoDB",
        "family": "nosql_document",
        "default_port": 27017,
        "driver": "pymongo",
        "env": ["URI", "DATABASE", "USER", "PASSWORD"],
        "question": "O banco é MongoDB? Informe URI, database, coleção principal e usuário somente leitura.",
    },
    "redis": {
        "label": "Redis",
        "family": "nosql_key_value",
        "default_port": 6379,
        "driver": "redis",
        "env": ["HOST", "PORT", "DB", "PASSWORD"],
        "question": "O banco é Redis? Informe host, porta, DB e padrão de chaves que devo consultar.",
    },
    "elasticsearch": {
        "label": "Elasticsearch",
        "family": "nosql_search",
        "default_port": 9200,
        "driver": "elasticsearch",
        "env": ["URL", "INDEX", "API_KEY"],
        "question": "O banco é Elasticsearch? Informe URL, índice/padrão de índices e API key por variável de ambiente.",
    },
    "cassandra": {
        "label": "Cassandra",
        "family": "nosql_wide_column",
        "default_port": 9042,
        "driver": "cassandra-driver",
        "env": ["CONTACT_POINTS", "KEYSPACE", "USER", "PASSWORD"],
        "question": "O banco é Cassandra? Informe contact points, keyspace, tabela e usuário somente leitura.",
    },
    "couchdb": {
        "label": "CouchDB",
        "family": "nosql_document",
        "default_port": 5984,
        "driver": "requests",
        "env": ["URL", "DATABASE", "USER", "PASSWORD"],
        "question": "O banco é CouchDB? Informe URL, database e usuário somente leitura.",
    },
    "opensearch": {
        "label": "OpenSearch",
        "family": "nosql_search",
        "default_port": 9200,
        "driver": "opensearch-py",
        "env": ["URL", "INDEX", "USER", "PASSWORD"],
        "question": "O banco é OpenSearch? Informe URL, índice/padrão de índices e credencial por variável de ambiente.",
    },
    "neo4j": {
        "label": "Neo4j",
        "family": "graph",
        "default_port": 7687,
        "driver": "neo4j",
        "env": ["URI", "DATABASE", "USER", "PASSWORD"],
        "question": "O banco é Neo4j? Informe URI Bolt/Neo4j, database e usuário somente leitura.",
    },
    "generic_sql": {
        "label": "Generic SQL (ODBC/JDBC/SQLAlchemy)",
        "family": "sql_generic",
        "default_port": None,
        "driver": "sqlalchemy/pyodbc/JDBC",
        "env": ["URL"],
        "question": "Banco SQL fora do catálogo? Informe uma URL/DSN de conexão e a HAL fará metadata/capability probing antes de gerar SQL específico.",
    },
    "generic_rest": {
        "label": "Generic Database REST/API",
        "family": "api_generic",
        "default_port": None,
        "driver": "HTTP/REST",
        "env": ["URL", "API_KEY"],
        "question": "Banco/serviço exposto por REST? Informe a URL de metadata/consulta e credenciais em variável de ambiente.",
    },
}


INTENT_CATALOG = {
    "consultar": ["consultar", "mostrar", "listar", "ver", "buscar", "trazer", "extrair", "quanto", "quais", "quem", "quantas", "quantos"],
    "comparar": ["comparar", "evolução", "evolucao", "queda", "aumento", "diferença", "diferenca", "variação", "variacao"],
    "agrupar": ["por linha", "por empresa", "por filial", "por cliente", "por produto", "por veículo", "por veiculo", "por data", "por mês", "por mes"],
    "alertar": ["alertar", "risco", "pendente", "vencido", "atrasado", "crítico", "critico", "ruptura", "divergência", "divergencia"],
    "escrever": ["atualizar", "alterar", "excluir", "deletar", "insert", "update", "delete", "drop", "cancelar", "baixar", "reembolsar"],
}


SEGMENT_HINTS = {
    "transporte_passageiros": ["passagem", "passagens", "bilhetagem", "vale-transporte", "vale transporte", "linha", "viagem", "ônibus", "onibus", "arrecadação", "arrecadacao"],
    "logistica": ["entrega", "frete", "cte", "manifesto", "rota", "transportadora", "pedido entregue", "sla entrega"],
    "financeiro_contabil": ["contas a receber", "contas a pagar", "dre", "inadimplência", "inadimplencia", "cobrança", "cobranca", "baixa", "boleto"],
    "varejo_atacado": ["produto", "estoque", "ruptura", "loja", "sku", "venda por produto", "ticket médio", "ticket medio"],
    "saude": ["paciente", "consulta", "convênio", "convenio", "prontuário", "prontuario"],
    "industria": ["produção", "producao", "ordem de produção", "ordem de producao", "lote", "op", "manufatura"],
    "educacao": ["aluno", "matrícula", "matricula", "turma", "nota", "frequência", "frequencia"],
}


REQUIRED_REQUEST_FIELDS = [
    ("connection_id_or_database_type", "Qual banco/conexão devo acessar? Ex: Oracle ERP Produção, MongoDB BI, SQL Server Financeiro."),
    ("business_question", "Qual pergunta de negócio você quer responder?"),
    ("data_scope", "Qual período, filtro, empresa, filial, linha, cliente, produto ou unidade devo considerar?"),
    ("entities_or_tables", "Você sabe quais tabelas, views, coleções, índices ou entidades devo consultar? Se não souber, posso sugerir um mapeamento."),
    ("metrics_or_fields", "Quais campos/métricas precisa retornar? Ex: total, quantidade, status, valor, linha, data, cliente."),
    ("output_format", "Como quer receber o resultado? Resumo, tabela, ranking, gráfico, CSV/Excel, relatório ou mensagem para aprovação."),
]


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not CONNECTIONS_FILE.exists():
        CONNECTIONS_FILE.write_text(json.dumps({"connections": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not REQUESTS_FILE.exists():
        REQUESTS_FILE.write_text(json.dumps({"requests": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not PLANS_FILE.exists():
        PLANS_FILE.write_text(json.dumps({"plans": []}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def status() -> dict[str, Any]:
    connections = _load(CONNECTIONS_FILE, {"connections": []}).get("connections", [])
    requests = _load(REQUESTS_FILE, {"requests": []}).get("requests", [])
    plans = _load(PLANS_FILE, {"plans": []}).get("plans", [])
    return {
        "ok": True,
        "name": "HAL Database Access Wizard",
        "description": "Assistente universal SQL/NoSQL integrado ao HAL Universal Database Intelligence V25: registra a conexão, detecta SGBD/versão/capacidades e monta um plano seguro e compatível com a release.",
        "databases_supported": len(DATABASE_CATALOG),
        "connections_count": len(connections),
        "requests_count": len(requests),
        "plans_count": len(plans),
        "capabilities": [
            "Suportar SQL e NoSQL",
            "Perguntar qual banco/conexão usar quando não estiver claro",
            "Perguntar quais informações, filtros e campos o usuário precisa",
            "Criar plano de consulta seguro antes de executar",
            "Consulta somente leitura por padrão",
            "Bloquear escrita sem aprovação humana",
            "Gerar SQL ou pseudo-query NoSQL conforme o banco",
            "Orientar configuração por variáveis de ambiente/cofre",
            "Preparar integração com ERP, venda de passagens, vale-transporte e qualquer segmento",
            "Detectar SGBD, versão, edition/deployment e capacidades antes de gerar comandos",
            "Aplicar Version Guard para evitar sintaxe de releases mais novas no banco conectado",
            "Usar diagnóstico/tuning equivalente para Oracle, SQL Server, PostgreSQL, MySQL/MariaDB, SQLite, Firebird, Db2, MongoDB, Redis, Elasticsearch/OpenSearch, Cassandra, CouchDB e Neo4j",
            "Usar fallback genérico ODBC/JDBC/SQLAlchemy/REST para tecnologias fora do catálogo",
        ],
    }


def catalog() -> dict[str, Any]:
    result = {
        "ok": True,
        "databases": [{"key": key, **value} for key, value in DATABASE_CATALOG.items()],
        "required_request_fields": [{"key": k, "question": q} for k, q in REQUIRED_REQUEST_FIELDS],
        "intent_catalog": INTENT_CATALOG,
    }
    try:
        from app.services import universal_database_intelligence as udi
        result["universal_intelligence"] = udi.status()
    except Exception as exc:
        result["universal_intelligence"] = {"ok": False, "error": str(exc)}
    return result


def register_connection(
    name: str,
    database_type: str,
    env_prefix: str = "",
    host: str = "",
    port: str | int | None = None,
    database_name: str = "",
    schema_or_keyspace: str = "",
    readonly: bool = True,
    description: str = "",
) -> dict[str, Any]:
    db_key = (database_type or "").lower().strip()
    if db_key not in DATABASE_CATALOG:
        return {"ok": False, "summary": "Tipo de banco não suportado.", "available": list(DATABASE_CATALOG)}
    env_prefix = env_prefix or re.sub(r"[^A-Z0-9]+", "_", name.upper()).strip("_") or f"DB_{db_key.upper()}"
    data = _load(CONNECTIONS_FILE, {"connections": []})
    conn = {
        "id": f"dbconn_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "name": name,
        "database_type": db_key,
        "database_label": DATABASE_CATALOG[db_key]["label"],
        "family": DATABASE_CATALOG[db_key]["family"],
        "env_prefix": env_prefix,
        "host": host,
        "port": port if port not in {"", None} else DATABASE_CATALOG[db_key]["default_port"],
        "database_name": database_name,
        "schema_or_keyspace": schema_or_keyspace,
        "readonly": readonly,
        "description": description,
        "status": "registered",
        "created_at": _now(),
        "credential_policy": "Credenciais devem ficar em variáveis de ambiente/cofre. Não salvar senha no JSON.",
        "required_env": [f"{env_prefix}_{x}" for x in DATABASE_CATALOG[db_key]["env"]],
    }
    data.setdefault("connections", []).insert(0, conn)
    _save(CONNECTIONS_FILE, data)
    _audit({"event": "register_connection", "connection_id": conn["id"], "database_type": db_key})
    return {"ok": True, "connection": conn, "summary": "Conexão de banco registrada em modo seguro."}


def list_connections(database_type: str = "", limit: int = 100) -> dict[str, Any]:
    connections = _load(CONNECTIONS_FILE, {"connections": []}).get("connections", [])
    if database_type:
        connections = [c for c in connections if c.get("database_type") == database_type.lower()]
    return {"ok": True, "connections": connections[:max(1, min(limit, 500))], "count": len(connections)}


def infer_segment(message: str) -> str:
    text = (message or "").lower()
    for segment, terms in SEGMENT_HINTS.items():
        if any(term in text for term in terms):
            return segment
    return "generico_corporativo"


def infer_intents(message: str) -> list[str]:
    text = (message or "").lower()
    result = []
    for intent, terms in INTENT_CATALOG.items():
        if any(term in text for term in terms):
            result.append(intent)
    return result or ["consultar"]


def infer_database_type(message: str) -> str:
    text = (message or "").lower()
    for key, value in DATABASE_CATALOG.items():
        if key in text or value["label"].lower() in text:
            return key
    if "mongodb" in text or "mongo" in text:
        return "mongodb"
    if "elastic" in text:
        return "elasticsearch"
    if "sql server" in text:
        return "sqlserver"
    return ""


def extract_known_requirements(message: str) -> dict[str, Any]:
    text = message or ""
    low = text.lower()
    requirements: dict[str, Any] = {
        "database_type": infer_database_type(text),
        "segment": infer_segment(text),
        "intents": infer_intents(text),
        "business_question": text.strip(),
        "entities_or_tables": [],
        "metrics_or_fields": [],
        "data_scope": "",
        "output_format": "",
        "risky_write_intent": "escrever" in infer_intents(text),
    }

    entity_terms = {
        "venda_passagens": ["passagem", "passagens", "vendas de passagens", "linha", "viagem"],
        "vale_transporte": ["vale-transporte", "vale transporte", "recarga", "empresa", "cartão", "cartao"],
        "bilhetagem": ["bilhetagem", "arrecadação", "arrecadacao", "validador"],
        "financeiro": ["contas a receber", "contas a pagar", "boleto", "inadimplência", "cobrança"],
        "estoque": ["estoque", "produto", "sku", "ruptura"],
        "cliente": ["cliente", "clientes", "crm"],
    }
    for entity, terms in entity_terms.items():
        if any(term in low for term in terms):
            requirements["entities_or_tables"].append(entity)

    metric_terms = ["total", "quantidade", "valor", "receita", "status", "pendente", "ranking", "média", "media", "count", "sum"]
    requirements["metrics_or_fields"] = [m for m in metric_terms if m in low]

    if "hoje" in low:
        requirements["data_scope"] = "hoje"
    elif "ontem" in low:
        requirements["data_scope"] = "ontem"
    elif "mês" in low or "mes" in low:
        requirements["data_scope"] = "mês"
    elif "período" in low or "periodo" in low:
        requirements["data_scope"] = "período a definir"

    if "excel" in low:
        requirements["output_format"] = "Excel"
    elif "tabela" in low:
        requirements["output_format"] = "Tabela"
    elif "relatório" in low or "relatorio" in low:
        requirements["output_format"] = "Relatório"
    elif "resumo" in low:
        requirements["output_format"] = "Resumo"

    return requirements


def missing_questions(requirements: dict[str, Any], connection_id: str = "") -> list[dict[str, str]]:
    missing: list[dict[str, str]] = []
    if not connection_id and not requirements.get("database_type"):
        missing.append({"field": "connection_id_or_database_type", "question": REQUIRED_REQUEST_FIELDS[0][1]})
    if not requirements.get("business_question"):
        missing.append({"field": "business_question", "question": REQUIRED_REQUEST_FIELDS[1][1]})
    if not requirements.get("data_scope"):
        missing.append({"field": "data_scope", "question": REQUIRED_REQUEST_FIELDS[2][1]})
    if not requirements.get("entities_or_tables"):
        missing.append({"field": "entities_or_tables", "question": REQUIRED_REQUEST_FIELDS[3][1]})
    if not requirements.get("metrics_or_fields"):
        missing.append({"field": "metrics_or_fields", "question": REQUIRED_REQUEST_FIELDS[4][1]})
    if not requirements.get("output_format"):
        missing.append({"field": "output_format", "question": REQUIRED_REQUEST_FIELDS[5][1]})
    return missing


def create_data_request(
    user_question: str,
    connection_id: str = "",
    database_type: str = "",
    entities_or_tables: list[str] | None = None,
    filters: dict[str, Any] | None = None,
    metrics_or_fields: list[str] | None = None,
    output_format: str = "",
    approved: bool = False,
) -> dict[str, Any]:
    requirements = extract_known_requirements(user_question)
    if database_type:
        requirements["database_type"] = database_type
    if entities_or_tables:
        requirements["entities_or_tables"] = entities_or_tables
    if metrics_or_fields:
        requirements["metrics_or_fields"] = metrics_or_fields
    if output_format:
        requirements["output_format"] = output_format
    if filters:
        requirements["filters"] = filters
        if filters.get("period"):
            requirements["data_scope"] = str(filters["period"])

    questions = missing_questions(requirements, connection_id)
    status_value = "needs_clarification" if questions else "ready_to_plan"
    req = {
        "id": f"datareq_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "user_question": user_question,
        "connection_id": connection_id,
        "requirements": requirements,
        "missing_questions": questions,
        "approved": approved,
        "status": status_value,
        "created_at": _now(),
    }
    data = _load(REQUESTS_FILE, {"requests": []})
    data.setdefault("requests", []).insert(0, req)
    _save(REQUESTS_FILE, data)
    _audit({"event": "create_data_request", "request_id": req["id"], "status": status_value})
    return {"ok": True, "request": req, "summary": _request_summary(req)}


def _request_summary(req: dict[str, Any]) -> str:
    if req["status"] == "needs_clarification":
        first = req["missing_questions"][0]["question"] if req.get("missing_questions") else "Preciso de mais detalhes."
        return f"Para consultar o banco com precisão, preciso confirmar algumas informações. Primeiro: {first}"
    return "Tenho informações suficientes para montar o plano seguro de consulta."


def list_requests(limit: int = 100) -> dict[str, Any]:
    requests = _load(REQUESTS_FILE, {"requests": []}).get("requests", [])
    return {"ok": True, "requests": requests[:max(1, min(limit, 500))], "count": len(requests)}


def create_query_plan(request_id: str = "", user_question: str = "", connection_id: str = "", approved: bool = False) -> dict[str, Any]:
    if request_id:
        requests = _load(REQUESTS_FILE, {"requests": []}).get("requests", [])
        req = next((r for r in requests if r.get("id") == request_id), None)
        if not req:
            return {"ok": False, "summary": "Solicitação de dados não encontrada."}
    else:
        created = create_data_request(user_question, connection_id=connection_id, approved=approved)
        req = created["request"]

    if req.get("missing_questions"):
        return {
            "ok": False,
            "status": "needs_clarification",
            "request": req,
            "clarifying_questions": req.get("missing_questions", []),
            "summary": _request_summary(req),
        }

    requirements = req["requirements"]
    db_type = requirements.get("database_type") or _connection_db_type(req.get("connection_id", ""))
    family = DATABASE_CATALOG.get(db_type, {}).get("family", "sql")
    plan = {
        "id": f"dbplan_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "request_id": req["id"],
        "connection_id": req.get("connection_id", ""),
        "database_type": db_type,
        "database_family": family,
        "segment": requirements.get("segment"),
        "intents": requirements.get("intents", []),
        "readonly": not requirements.get("risky_write_intent", False),
        "approved": approved,
        "status": "waiting_approval" if requirements.get("risky_write_intent") and not approved else "ready",
        "created_at": _now(),
        "query_template": build_query_template(db_type, requirements),
        "execution_policy": safe_execution_policy(requirements),
        "required_before_execution": execution_prerequisites(db_type, req.get("connection_id", "")),
    }
    data = _load(PLANS_FILE, {"plans": []})
    data.setdefault("plans", []).insert(0, plan)
    _save(PLANS_FILE, data)
    _audit({"event": "create_query_plan", "plan_id": plan["id"], "status": plan["status"]})
    return {"ok": True, "plan": plan, "summary": "Plano de consulta criado. Ele só deve executar depois de validar conexão, permissões e escopo."}


def _connection_db_type(connection_id: str) -> str:
    if not connection_id:
        return ""
    conns = _load(CONNECTIONS_FILE, {"connections": []}).get("connections", [])
    conn = next((c for c in conns if c.get("id") == connection_id), None)
    return conn.get("database_type", "") if conn else ""


def build_query_template(db_type: str, requirements: dict[str, Any]) -> str:
    family = DATABASE_CATALOG.get(db_type, {}).get("family", "sql")
    entities = requirements.get("entities_or_tables") or ["ENTIDADE_A_MAPEAR"]
    metrics = requirements.get("metrics_or_fields") or ["*"]
    scope = requirements.get("data_scope") or "PERIODO_A_DEFINIR"

    entity = entities[0]
    if family == "sql":
        if "venda_passagens" in entities:
            return "SELECT linha, COUNT(*) AS qtd_passagens, SUM(valor) AS receita FROM vendas_passagens WHERE data_venda = :periodo GROUP BY linha ORDER BY receita DESC;"
        if "vale_transporte" in entities:
            return "SELECT empresa, COUNT(*) AS pedidos, SUM(valor) AS total FROM pedidos_vale_transporte WHERE status_pagamento = 'PENDENTE' AND data_pedido >= :inicio GROUP BY empresa ORDER BY total DESC;"
        if "bilhetagem" in entities:
            return "SELECT linha, veiculo, SUM(valor) AS arrecadacao FROM movimento_bilhetagem WHERE data_movimento = :periodo GROUP BY linha, veiculo;"
        return f"SELECT {', '.join(metrics)} FROM {entity} WHERE periodo = :periodo LIMIT/ROWNUM 100;"
    if db_type == "mongodb":
        return json.dumps(
            {
                "collection": entity,
                "pipeline": [
                    {"$match": {"periodo": scope}},
                    {"$group": {"_id": "$campo_agrupamento", "total": {"$sum": "$valor"}, "quantidade": {"$sum": 1}}},
                    {"$sort": {"total": -1}},
                    {"$limit": 100},
                ],
            },
            ensure_ascii=False,
            indent=2,
        )
    if db_type == "redis":
        return f"SCAN MATCH {entity}:* COUNT 1000  # depois filtrar/agregar no HAL conforme escopo {scope}"
    if db_type == "elasticsearch":
        return json.dumps(
            {
                "index": entity,
                "query": {"bool": {"filter": [{"range": {"data": {"gte": scope}}}]}},
                "aggs": {"por_campo": {"terms": {"field": "campo.keyword"}, "aggs": {"total": {"sum": {"field": "valor"}}}}},
                "size": 0,
            },
            ensure_ascii=False,
            indent=2,
        )
    if db_type == "cassandra":
        return f"SELECT {', '.join(metrics)} FROM {entity} WHERE periodo = ? LIMIT 100;"
    return f"Consulta NoSQL para {db_type}: mapear entidade {entity}, filtro {scope} e campos {metrics}."


def safe_execution_policy(requirements: dict[str, Any]) -> dict[str, Any]:
    return {
        "default_mode": "read_only",
        "write_blocked_without_approval": True,
        "risky_write_intent": bool(requirements.get("risky_write_intent")),
        "max_rows_default": 100,
        "mask_sensitive_fields": True,
        "blocked_operations": ["DROP", "DELETE", "UPDATE", "INSERT", "MERGE", "TRUNCATE", "$out", "$merge"],
        "requires_human_approval_for": [
            "qualquer escrita",
            "cancelamento",
            "baixa financeira",
            "reembolso",
            "envio externo",
            "exportação de dados pessoais",
            "consulta sem filtro em produção",
        ],
    }


def execution_prerequisites(db_type: str, connection_id: str) -> list[str]:
    prereq = [
        "Confirmar ambiente: produção, homologação ou cópia de leitura.",
        "Confirmar usuário somente leitura.",
        "Confirmar período/filtros para evitar varredura grande.",
        "Confirmar tabelas/coleções/índices ou permitir descoberta controlada.",
        "Confirmar formato de saída.",
    ]
    if not connection_id:
        prereq.insert(0, "Registrar ou escolher uma conexão de banco.")
    if db_type:
        prereq.append(f"Instalar/validar driver: {DATABASE_CATALOG.get(db_type, {}).get('driver', 'driver adequado')}.")
    return prereq


def list_plans(limit: int = 100) -> dict[str, Any]:
    plans = _load(PLANS_FILE, {"plans": []}).get("plans", [])
    return {"ok": True, "plans": plans[:max(1, min(limit, 500))], "count": len(plans)}


def guided_answer(message: str, approved: bool = False) -> dict[str, Any]:
    # V25: pedidos DBA/performance/versão usam a camada Universal Database Intelligence.
    db_intel_terms = [
        "performance", "desempenho", "tuning", "lock", "deadlock", "sessão", "sessao",
        "top sql", "query lenta", "query pesada", "backup", "replica", "replicação", "replicacao",
        "alta disponibilidade", "high availability", "tablespace", "índice", "indice", "index",
        "estatística", "estatistica", "statistics", "versão", "versao", "version", "release",
        "plano de execução", "plano de execucao", "explain", "saúde do banco", "saude do banco",
    ]
    if any(term in (message or "").lower() for term in db_intel_terms):
        try:
            from app.services import universal_database_intelligence as udi
            intel = udi.guided_answer(message)
            if intel.get("ok"):
                return intel
        except Exception:
            pass
    request = create_data_request(message, approved=approved)["request"]
    if request.get("missing_questions"):
        questions = request["missing_questions"]
        answer = (
            "Para eu acessar a base certa e trazer um resultado preciso, preciso dessas informações:\n"
            + "\n".join([f"{i+1}. {q['question']}" for i, q in enumerate(questions)])
            + "\n\nSem isso, eu não devo inventar consulta nem escolher banco sozinho."
        )
        return {
            "ok": True,
            "mode": "clarification_required",
            "answer": answer,
            "request": request,
            "clarifying_questions": questions,
        }

    plan = create_query_plan(request_id=request["id"], approved=approved)
    answer = (
        "Tenho dados suficientes para montar o plano seguro de consulta. "
        "Vou consultar em modo somente leitura, respeitando filtros e limite de linhas. "
        "Qualquer escrita, cancelamento, baixa, reembolso ou envio externo exigirá aprovação humana."
    )
    return {"ok": True, "mode": "query_plan_ready", "answer": answer, "request": request, "plan": plan.get("plan")}


def seed_examples() -> dict[str, Any]:
    conn1 = register_connection("ERP Transporte Oracle", "oracle", env_prefix="ERP_TRANSPORTE", database_name="ERP", schema_or_keyspace="TRANSPORTE", description="Venda de passagens, bilhetagem e vale-transporte.")["connection"]
    conn2 = register_connection("BI Clientes MongoDB", "mongodb", env_prefix="BI_MONGO", database_name="bi_clientes", description="Base NoSQL de eventos e atendimento.")["connection"]
    examples = [
        create_data_request("Quantas passagens foram vendidas hoje por linha?", connection_id=conn1["id"], entities_or_tables=["venda_passagens"], filters={"period": "hoje"}, metrics_or_fields=["linha", "quantidade", "receita"], output_format="Tabela")["request"],
        create_data_request("Quais empresas estão com vale-transporte pendente?", connection_id=conn1["id"], entities_or_tables=["vale_transporte"], filters={"period": "mês"}, metrics_or_fields=["empresa", "total", "status"], output_format="Resumo")["request"],
        create_data_request("Quais clientes tiveram mais interações no app?", connection_id=conn2["id"], entities_or_tables=["eventos_clientes"], filters={"period": "últimos 7 dias"}, metrics_or_fields=["cliente", "quantidade"], output_format="Ranking")["request"],
    ]
    return {"ok": True, "connections": [conn1, conn2], "requests": examples, "summary": "Exemplos de acesso SQL/NoSQL criados."}


def answer_for_database_access(message: str = "") -> str:
    return guided_answer(message).get("answer", "Vou usar o HAL Database Access Wizard para perguntar qual banco acessar e quais dados buscar.")
