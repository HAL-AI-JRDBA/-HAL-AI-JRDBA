from __future__ import annotations

import json
import re
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir
from app.tools.business_domains import detect_domain
from app.tools.database_platforms import detect_database


DATA_DIR = root_dir() / "data" / "saas_builder"
PROJECTS_FILE = DATA_DIR / "projects.json"
CLIENTS_FILE = DATA_DIR / "clients.json"
BILLING_FILE = DATA_DIR / "billing_plans.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"
GENERATED_DIR = DATA_DIR / "generated_projects"


APP_TEMPLATES: dict[str, dict[str, Any]] = {
    "site_institucional": {
        "label": "Site Institucional",
        "description": "Landing page ou site comercial com identidade visual, seções, formulário e CTA.",
        "stack": ["HTML", "CSS", "FastAPI opcional"],
        "features": ["Home", "Sobre", "Serviços", "Contato", "Formulário", "SEO básico"],
    },
    "web_app_crud": {
        "label": "Sistema Web CRUD",
        "description": "Sistema com login, cadastros, listagem, edição, exclusão, dashboard e API.",
        "stack": ["FastAPI", "HTML/CSS/JS", "SQLite por padrão", "Docker opcional"],
        "features": ["Login", "CRUD", "Dashboard", "API REST", "Auditoria básica"],
    },
    "dashboard_bi": {
        "label": "Dashboard / BI",
        "description": "Aplicativo de indicadores com cards, filtros, gráficos e conexão a dados.",
        "stack": ["FastAPI", "Chart.js", "SQL/NoSQL connector"],
        "features": ["KPIs", "Filtros", "Gráficos", "Exportação", "Conexões de dados"],
    },
    "portal_cliente": {
        "label": "Portal do Cliente",
        "description": "Portal white-label para clientes consultarem dados, documentos, chamados e indicadores.",
        "stack": ["FastAPI", "JWT", "SQLite/PostgreSQL", "Web UI"],
        "features": ["Login", "Área do cliente", "Documentos", "Chamados", "Indicadores"],
    },
    "crm_leads": {
        "label": "CRM / Leads",
        "description": "Funil comercial, leads, oportunidades, follow-up e automação de vendas.",
        "stack": ["FastAPI", "SQLite/PostgreSQL", "Web UI"],
        "features": ["Leads", "Funil", "Tarefas", "Histórico", "Follow-up"],
    },
    "erp_modulo": {
        "label": "Módulo ERP",
        "description": "Módulo específico para operação, financeiro, estoque, logística ou outro segmento.",
        "stack": ["FastAPI", "Banco relacional/NoSQL", "Web UI"],
        "features": ["Cadastros", "Movimentos", "Relatórios", "Aprovação", "Integração"],
    },
    "marketplace": {
        "label": "Marketplace",
        "description": "Base para catálogo, fornecedores, clientes, pedidos e pagamentos.",
        "stack": ["FastAPI", "SQLite/PostgreSQL", "Web UI", "Billing adapter"],
        "features": ["Catálogo", "Pedidos", "Clientes", "Fornecedores", "Pagamento"],
    },
    "api_backend": {
        "label": "API Backend",
        "description": "API para integração entre sistemas, aplicativos, BI e automações.",
        "stack": ["FastAPI", "OpenAPI", "JWT", "Docker"],
        "features": ["REST API", "Autenticação", "Logs", "Health Check", "Swagger"],
    },
}

DEPLOY_TARGETS: dict[str, dict[str, Any]] = {
    "local": {"label": "Local", "description": "Executar na máquina local ou servidor interno.", "status": "ready"},
    "docker": {"label": "Docker", "description": "Gerar Dockerfile e docker-compose.", "status": "ready"},
    "vps": {"label": "VPS / Servidor Próprio", "description": "Deploy em Linux/Windows Server com domínio próprio.", "status": "plan_ready"},
    "vercel": {"label": "Vercel", "description": "Deploy frontend/static ou fullstack adaptado.", "status": "adapter_plan"},
    "render": {"label": "Render", "description": "Deploy web service/API.", "status": "adapter_plan"},
    "railway": {"label": "Railway", "description": "Deploy app + banco gerenciado.", "status": "adapter_plan"},
    "on_premise": {"label": "On-premise Cliente", "description": "Instalação dentro da infraestrutura do cliente.", "status": "ready"},
}

BILLING_PROVIDERS: dict[str, dict[str, Any]] = {
    "stripe": {"label": "Stripe", "status": "adapter_ready", "notes": "Requer chaves Stripe e webhooks."},
    "mercado_pago": {"label": "Mercado Pago", "status": "adapter_ready", "notes": "Requer access token e webhooks."},
    "pagseguro": {"label": "PagSeguro", "status": "adapter_plan", "notes": "Requer credenciais e integração."},
    "manual": {"label": "Cobrança Manual", "status": "ready", "notes": "Controle de planos/clientes sem gateway."},
}

SKILLS: dict[str, dict[str, Any]] = {
    "code_review": {"label": "Code Review", "description": "Revisar código gerado e sugerir correções."},
    "tdd": {"label": "TDD / Testes", "description": "Criar testes, cenários e validações."},
    "debugging": {"label": "Debugging", "description": "Analisar erros, logs e corrigir falhas."},
    "git_worktrees": {"label": "Git Worktrees", "description": "Organizar versões e branches de trabalho."},
    "rollback": {"label": "Rollback", "description": "Voltar para versão anterior do projeto."},
    "deploy": {"label": "Deploy Assistido", "description": "Gerar plano de publicação local, Docker, VPS ou cloud."},
    "integration": {"label": "Integrações", "description": "Criar conectores para APIs, bancos, BI e canais."},
    "security": {"label": "Segurança JWT/WebSocket", "description": "Adicionar autenticação, autorização e auditoria."},
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    GENERATED_DIR.mkdir(parents=True, exist_ok=True)
    if not PROJECTS_FILE.exists():
        PROJECTS_FILE.write_text(json.dumps({"projects": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not CLIENTS_FILE.exists():
        CLIENTS_FILE.write_text(json.dumps({"clients": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    if not BILLING_FILE.exists():
        BILLING_FILE.write_text(json.dumps({"plans": default_billing_plans()}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _slug(text: str) -> str:
    text = (text or "app").lower()
    text = re.sub(r"[^a-z0-9áéíóúãõâêôç]+", "-", text)
    text = (text.replace("á","a").replace("é","e").replace("í","i").replace("ó","o").replace("ú","u")
            .replace("ã","a").replace("õ","o").replace("â","a").replace("ê","e").replace("ô","o").replace("ç","c"))
    return re.sub(r"-+", "-", text).strip("-") or "app"


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def default_billing_plans() -> list[dict[str, Any]]:
    return [
        {"key": "starter", "label": "Starter", "price_monthly": 97.00, "limits": {"projects": 3, "users": 3, "ai_runs_month": 500}},
        {"key": "business", "label": "Business", "price_monthly": 297.00, "limits": {"projects": 15, "users": 20, "ai_runs_month": 5000}},
        {"key": "enterprise", "label": "Enterprise", "price_monthly": 0.00, "limits": {"projects": "custom", "users": "custom", "ai_runs_month": "custom"}},
    ]


def status() -> dict[str, Any]:
    projects = _load(PROJECTS_FILE, {"projects": []}).get("projects", [])
    clients = _load(CLIENTS_FILE, {"clients": []}).get("clients", [])
    return {
        "ok": True,
        "name": "HAL SaaS Builder / White Label Studio",
        "description": "Criação de apps/sites com IA, white-label, projetos por cliente, preview local, versões, rollback e plano de deploy.",
        "projects_count": len(projects),
        "clients_count": len(clients),
        "templates_count": len(APP_TEMPLATES),
        "deploy_targets_count": len(DEPLOY_TARGETS),
        "billing_providers": list(BILLING_PROVIDERS),
        "skills": list(SKILLS),
        "capabilities": [
            "Criar apps e sites com IA a partir de descrição",
            "Gerar código-fonte inicial completo",
            "White-label com nome, logo, cores e domínio",
            "Projetos por cliente",
            "Preview local do projeto gerado",
            "Versionamento e rollback",
            "Plano de deploy local, Docker, VPS ou cloud",
            "Planos e cobrança recorrente conceitual",
            "Skills: Code Review, TDD, Debugging, Deploy, Rollback e Segurança",
        ],
    }


def templates() -> dict[str, Any]:
    return {"ok": True, "templates": [{"key": k, **v} for k, v in APP_TEMPLATES.items()]}


def deploy_targets() -> dict[str, Any]:
    return {"ok": True, "deploy_targets": [{"key": k, **v} for k, v in DEPLOY_TARGETS.items()]}


def billing_providers() -> dict[str, Any]:
    return {"ok": True, "providers": [{"key": k, **v} for k, v in BILLING_PROVIDERS.items()], **_load(BILLING_FILE, {"plans": default_billing_plans()})}


def skills() -> dict[str, Any]:
    return {"ok": True, "skills": [{"key": k, **v} for k, v in SKILLS.items()]}


def infer_template(idea: str, explicit: str = "") -> str:
    if explicit and explicit in APP_TEMPLATES:
        return explicit
    t = (idea or "").lower()
    rules = [
        ("site_institucional", ["site", "landing", "página", "pagina", "institucional"]),
        ("dashboard_bi", ["dashboard", "indicador", "bi", "gráfico", "grafico", "kpi"]),
        ("portal_cliente", ["portal", "cliente", "área do cliente", "area do cliente"]),
        ("crm_leads", ["crm", "lead", "leads", "funil", "vendas", "sdr"]),
        ("marketplace", ["marketplace", "catálogo", "catalogo", "fornecedor", "pedido"]),
        ("api_backend", ["api", "backend", "integração", "integracao", "webhook"]),
        ("erp_modulo", ["erp", "módulo", "modulo", "financeiro", "estoque", "logística", "logistica"]),
        ("web_app_crud", ["sistema", "app", "cadastro", "crud", "aplicativo"]),
    ]
    scores = [(sum(1 for term in terms if term in t), key) for key, terms in rules]
    scores = [x for x in scores if x[0] > 0]
    if not scores:
        return "web_app_crud"
    scores.sort(reverse=True)
    return scores[0][1]


def create_client(name: str, email: str = "", company: str = "", plan: str = "starter") -> dict[str, Any]:
    clients = _load(CLIENTS_FILE, {"clients": []})
    client_id = f"client_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    item = {"id": client_id, "name": name or company or "Cliente", "email": email, "company": company or name, "plan": plan, "created_at": _now(), "updated_at": _now()}
    clients.setdefault("clients", []).insert(0, item)
    _save(CLIENTS_FILE, clients)
    _audit({"event": "create_client", "client_id": client_id})
    return {"ok": True, "client": item}


def create_project(
    idea: str,
    client_name: str = "",
    company_name: str = "",
    template: str = "",
    segment: str = "",
    database: str = "",
    app_name: str = "",
    domain: str = "",
    primary_color: str = "#ff0060",
    accent_color: str = "#3b82f6",
    logo_text: str = "AJDS",
    billing_provider: str = "manual",
    deploy_target: str = "local",
) -> dict[str, Any]:
    _ensure()
    template_key = infer_template(idea, template)
    tpl = APP_TEMPLATES[template_key]
    domain_info = detect_domain((segment or "") + " " + idea)
    db_info = detect_database((database or "") + " " + idea)
    project_id = f"saas_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    name = app_name or suggest_app_name(idea, company_name, tpl["label"])
    slug = _slug(name)
    project = {
        "id": project_id,
        "name": name,
        "slug": slug,
        "idea": idea,
        "client_name": client_name or company_name or "Cliente não informado",
        "company_name": company_name or client_name or "Empresa Cliente",
        "template_key": template_key,
        "template": tpl,
        "segment": domain_info,
        "database": db_info,
        "white_label": {
            "product_name": name,
            "company_name": company_name or client_name or "Empresa Cliente",
            "logo_text": logo_text,
            "primary_color": primary_color,
            "accent_color": accent_color,
            "domain": domain,
        },
        "billing": {"provider": billing_provider, "plans": default_billing_plans()},
        "deploy": {"target": deploy_target, "target_info": DEPLOY_TARGETS.get(deploy_target, DEPLOY_TARGETS["local"])},
        "versions": [],
        "status": "planned",
        "created_at": _now(),
        "updated_at": _now(),
    }
    data = _load(PROJECTS_FILE, {"projects": []})
    data.setdefault("projects", []).insert(0, project)
    _save(PROJECTS_FILE, data)
    _audit({"event": "create_project", "project_id": project_id, "template": template_key})
    return {"ok": True, "project": project, "summary": f"Projeto SaaS criado: {name}."}


def suggest_app_name(idea: str, company: str, template_label: str) -> str:
    t = (idea or "").lower()
    if "varejo" in t:
        return "Retail AI Portal"
    if "logística" in t or "logistica" in t:
        return "Logistics AI Control"
    if "financeiro" in t or "contábil" in t or "contabil" in t:
        return "Finance AI Manager"
    if "transporte" in t:
        return "Transport AI Hub"
    if company:
        return f"{company} AI App"
    return template_label


def list_projects(limit: int = 100) -> dict[str, Any]:
    data = _load(PROJECTS_FILE, {"projects": []})
    rows = data.get("projects", [])[:max(1, min(limit, 500))]
    return {"ok": True, "projects": rows, "count": len(data.get("projects", []))}


def get_project(project_id: str) -> dict[str, Any]:
    for p in _load(PROJECTS_FILE, {"projects": []}).get("projects", []):
        if p.get("id") == project_id:
            return {"ok": True, "project": p}
    return {"ok": False, "summary": "Projeto não encontrado."}


def _update_project(project: dict[str, Any]) -> None:
    data = _load(PROJECTS_FILE, {"projects": []})
    rows = data.get("projects", [])
    for i, p in enumerate(rows):
        if p.get("id") == project.get("id"):
            rows[i] = project
            data["projects"] = rows
            _save(PROJECTS_FILE, data)
            return


def generate_code(project_id: str) -> dict[str, Any]:
    found = get_project(project_id)
    if not found.get("ok"):
        return found
    project = found["project"]
    out = GENERATED_DIR / project["slug"]
    out.mkdir(parents=True, exist_ok=True)
    (out / "app").mkdir(exist_ok=True)
    (out / "static").mkdir(exist_ok=True)
    (out / "data").mkdir(exist_ok=True)

    write_backend(out, project)
    write_frontend(out, project)
    write_config_files(out, project)

    version = {
        "id": f"ver_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "path": str(out.relative_to(root_dir())),
        "summary": "Código-fonte inicial gerado.",
        "created_at": _now(),
    }
    project.setdefault("versions", []).insert(0, version)
    project["status"] = "code_generated"
    project["updated_at"] = _now()
    _update_project(project)
    _audit({"event": "generate_code", "project_id": project_id, "version": version["id"]})
    return {"ok": True, "project": project, "version": version, "path": str(out), "summary": "Código-fonte inicial gerado com sucesso."}


def write_backend(out: Path, project: dict[str, Any]) -> None:
    backend = f'''from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path

APP_NAME = {project["name"]!r}
COMPANY_NAME = {project["company_name"]!r}
SEGMENT = {project["segment"].get("label")!r}
DATABASE = {project["database"].get("label")!r}

ROOT = Path(__file__).resolve().parents[1]
app = FastAPI(title=APP_NAME, version="0.1.0")
app.mount("/static", StaticFiles(directory=str(ROOT / "static")), name="static")

@app.get("/", response_class=HTMLResponse)
def home():
    return (ROOT / "static" / "index.html").read_text(encoding="utf-8-sig")

@app.get("/api/health")
def health():
    return {{"ok": True, "app": APP_NAME, "company": COMPANY_NAME, "segment": SEGMENT, "database": DATABASE}}

@app.get("/api/kpis")
def kpis():
    return {{
        "ok": True,
        "cards": [
            {{"label": "Receita", "value": "R$ 128.450", "trend": "+12%"}},
            {{"label": "Clientes", "value": "342", "trend": "+8%"}},
            {{"label": "Processos", "value": "1.284", "trend": "+21%"}},
            {{"label": "Alertas", "value": "7", "trend": "-5%"}}
        ]
    }}
'''
    (out / "app" / "main.py").write_text(backend, encoding="utf-8")
    (out / "app" / "__init__.py").write_text("", encoding="utf-8")


def write_frontend(out: Path, project: dict[str, Any]) -> None:
    wl = project["white_label"]
    html = f'''<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>{project["name"]}</title>
  <link rel="stylesheet" href="/static/styles.css" />
</head>
<body>
  <main class="shell">
    <header>
      <div class="logo">{wl.get("logo_text","AI")}</div>
      <div>
        <h1>{project["name"]}</h1>
        <p>{project["company_name"]} - {project["segment"].get("label")} - {project["database"].get("label")}</p>
      </div>
    </header>

    <section class="hero">
      <h2>Aplicação white-label gerada pelo HAL SaaS Builder</h2>
      <p>{project["idea"]}</p>
      <button onclick="loadKpis()">Carregar indicadores</button>
    </section>

    <section id="cards" class="cards"></section>

    <section class="panel">
      <h3>Próximos passos</h3>
      <ul>
        <li>Conectar banco real: {project["database"].get("label")}</li>
        <li>Configurar domínio: {wl.get("domain") or "domínio próprio do cliente"}</li>
        <li>Ativar login/JWT e auditoria</li>
        <li>Definir plano de assinatura e gateway de pagamento</li>
      </ul>
    </section>
  </main>
  <script src="/static/app.js"></script>
</body>
</html>'''
    css = f''':root {{
  --primary: {wl.get("primary_color") or "#ff0060"};
  --accent: {wl.get("accent_color") or "#3b82f6"};
}}
* {{ box-sizing: border-box; }}
body {{
  margin: 0; min-height: 100vh; color: #f4f7ff; font-family: Segoe UI, Arial, sans-serif;
  background: radial-gradient(circle at 20% 10%, rgba(255,0,96,.25), transparent 28%),
              radial-gradient(circle at 85% 20%, rgba(59,130,246,.25), transparent 30%),
              linear-gradient(150deg, #050711, #111936 60%, #070914);
}}
.shell {{ max-width: 1180px; margin: 0 auto; padding: 28px; }}
header {{ display:flex; align-items:center; gap:18px; border:1px solid rgba(255,255,255,.12); background:rgba(10,16,38,.76); border-radius:22px; padding:18px; }}
.logo {{ width:78px; height:78px; border-radius:20px; display:grid; place-items:center; background:linear-gradient(135deg,var(--primary),var(--accent)); font-weight:900; font-size:30px; }}
h1 {{ margin:0; }} p {{ color:#b8c5e3; }}
.hero, .panel {{ margin-top:20px; border:1px solid rgba(255,255,255,.12); background:rgba(9,15,38,.78); border-radius:24px; padding:24px; }}
button {{ border:0; border-radius:14px; padding:12px 18px; color:white; font-weight:800; background:linear-gradient(135deg,var(--primary),var(--accent)); cursor:pointer; }}
.cards {{ display:grid; grid-template-columns: repeat(auto-fit, minmax(220px,1fr)); gap:16px; margin-top:20px; }}
.card {{ border:1px solid rgba(255,255,255,.12); border-radius:20px; padding:18px; background:rgba(255,255,255,.06); }}
.card strong {{ display:block; font-size:32px; margin-top:10px; }}
.trend {{ color:#9df1ff; }}
'''
    js = '''async function loadKpis(){
  const r = await fetch('/api/kpis');
  const data = await r.json();
  const el = document.getElementById('cards');
  el.innerHTML = data.cards.map(c => `<div class="card"><span>${c.label}</span><strong>${c.value}</strong><p class="trend">${c.trend}</p></div>`).join('');
}
loadKpis();
'''
    (out / "static" / "index.html").write_text(html, encoding="utf-8")
    (out / "static" / "styles.css").write_text(css, encoding="utf-8")
    (out / "static" / "app.js").write_text(js, encoding="utf-8")


def write_config_files(out: Path, project: dict[str, Any]) -> None:
    (out / "requirements.txt").write_text("fastapi>=0.110\nuvicorn[standard]>=0.27\n", encoding="utf-8")
    (out / ".env.example").write_text(f'''APP_NAME={project["name"]}
DATABASE_TYPE={project["database"].get("key")}
DATABASE_URL=configure_aqui
JWT_SECRET=troque_esta_chave
BILLING_PROVIDER={project["billing"].get("provider")}
DOMAIN={project["white_label"].get("domain")}
''', encoding="utf-8")
    (out / "Dockerfile").write_text('''FROM python:3.11-slim
WORKDIR /app
COPY . .
RUN pip install --no-cache-dir -r requirements.txt
EXPOSE 8080
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8080"]
''', encoding="utf-8")
    (out / "docker-compose.yml").write_text('''services:
  app:
    build: .
    ports:
      - "8080:8080"
    env_file:
      - .env.example
''', encoding="utf-8")
    (out / "README.md").write_text(f'''# {project["name"]}

Aplicação white-label gerada pelo HAL SaaS Builder.

## Executar local

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 127.0.0.1 --port 8080
```

Acesse:

```text
http://127.0.0.1:8080
```

## Deploy Docker

```bash
docker compose up --build
```

## Configurações

- Empresa: {project["company_name"]}
- Segmento: {project["segment"].get("label")}
- Banco: {project["database"].get("label")}
- Domínio: {project["white_label"].get("domain") or "não informado"}
- Billing: {project["billing"].get("provider")}

## Próximas etapas

1. Conectar banco real.
2. Configurar autenticação/JWT.
3. Configurar domínio.
4. Configurar cobrança recorrente.
5. Executar testes e code review.
''', encoding="utf-8")
    (out / "deploy_plan.json").write_text(json.dumps(deploy_plan_for(project), ensure_ascii=False, indent=2), encoding="utf-8")


def versions(project_id: str) -> dict[str, Any]:
    found = get_project(project_id)
    if not found.get("ok"):
        return found
    return {"ok": True, "versions": found["project"].get("versions", []), "project": found["project"]}


def rollback(project_id: str, version_id: str = "") -> dict[str, Any]:
    found = get_project(project_id)
    if not found.get("ok"):
        return found
    project = found["project"]
    versions = project.get("versions", [])
    if not versions:
        return {"ok": False, "summary": "Não há versões para rollback."}
    target = next((v for v in versions if v.get("id") == version_id), versions[0])
    project["active_version"] = target
    project["status"] = "rollback_selected"
    project["updated_at"] = _now()
    _update_project(project)
    _audit({"event": "rollback", "project_id": project_id, "version": target.get("id")})
    return {"ok": True, "project": project, "version": target, "summary": "Versão selecionada para rollback."}


def deploy_plan(project_id: str, target: str = "") -> dict[str, Any]:
    found = get_project(project_id)
    if not found.get("ok"):
        return found
    plan = deploy_plan_for(found["project"], target or found["project"].get("deploy", {}).get("target", "local"))
    return {"ok": True, "project": found["project"], "deploy_plan": plan}


def deploy_plan_for(project: dict[str, Any], target: str = "local") -> dict[str, Any]:
    target_info = DEPLOY_TARGETS.get(target, DEPLOY_TARGETS["local"])
    return {
        "target": target,
        "target_label": target_info["label"],
        "steps": [
            "Validar código gerado.",
            "Executar testes e code review.",
            "Configurar variáveis de ambiente.",
            f"Configurar banco: {project['database'].get('label')}.",
            "Configurar autenticação JWT e política de acesso.",
            "Configurar domínio e SSL.",
            "Configurar billing se houver assinatura.",
            "Executar deploy.",
            "Validar health check e logs.",
            "Registrar versão ativa para rollback.",
        ],
        "commands": {
            "local": ["pip install -r requirements.txt", "uvicorn app.main:app --host 127.0.0.1 --port 8080"],
            "docker": ["docker compose up --build"],
            "vps": ["scp/rsync do projeto para VPS", "docker compose up -d --build", "configurar Nginx/SSL"],
        },
        "notes": target_info["description"],
    }


def preview_info(project_id: str) -> dict[str, Any]:
    found = get_project(project_id)
    if not found.get("ok"):
        return found
    project = found["project"]
    path = GENERATED_DIR / project["slug"] / "static" / "index.html"
    return {
        "ok": path.exists(),
        "project": project,
        "preview_type": "static_local",
        "path": str(path),
        "relative_path": str(path.relative_to(root_dir())) if path.exists() else "",
        "how_to_run": [
            "Entre na pasta generated_projects/<slug>.",
            "Execute: pip install -r requirements.txt",
            "Execute: uvicorn app.main:app --host 127.0.0.1 --port 8080",
            "Abra: http://127.0.0.1:8080",
        ],
    }


def no_code_spec() -> dict[str, Any]:
    return {
        "ok": True,
        "fields": [
            {"name": "idea", "label": "Descreva o app/site", "type": "textarea", "required": True},
            {"name": "client_name", "label": "Cliente", "type": "text"},
            {"name": "company_name", "label": "Empresa/marca", "type": "text"},
            {"name": "template", "label": "Tipo de app", "type": "select", "options": [t["label"] for t in templates()["templates"]]},
            {"name": "segment", "label": "Segmento", "type": "text"},
            {"name": "database", "label": "Banco", "type": "text"},
            {"name": "domain", "label": "Domínio próprio", "type": "text"},
            {"name": "colors", "label": "Cores da marca", "type": "color"},
            {"name": "billing", "label": "Cobrança", "type": "select", "options": [p["label"] for p in billing_providers()["providers"]]},
            {"name": "deploy", "label": "Deploy", "type": "select", "options": [d["label"] for d in deploy_targets()["deploy_targets"]]},
        ],
        "flow": [
            "Descrever ideia",
            "Escolher template",
            "Aplicar white-label",
            "Gerar código",
            "Preview local",
            "Code review/TDD",
            "Plano de deploy",
            "Publicação controlada",
            "Billing/assinatura",
            "Versionamento e rollback",
        ],
    }


def answer_for_saas_builder(idea: str, template: str = "", database: str = "", segment: str = "") -> str:
    tpl_key = infer_template(idea, template)
    tpl = APP_TEMPLATES[tpl_key]
    seg = detect_domain((segment or "") + " " + idea)
    db = detect_database((database or "") + " " + idea)
    return (
        f"Vou usar o HAL SaaS Builder / White Label Studio. "
        f"Detectei o tipo de projeto: {tpl['label']}; segmento: {seg['label']}; banco sugerido: {db['label']}. "
        "Posso criar o projeto white-label, gerar código-fonte inicial, preparar preview local, versionamento, rollback, plano de deploy e configuração de assinatura. "
        "Para publicar em produção, vou exigir revisão técnica e aprovação humana."
    )
