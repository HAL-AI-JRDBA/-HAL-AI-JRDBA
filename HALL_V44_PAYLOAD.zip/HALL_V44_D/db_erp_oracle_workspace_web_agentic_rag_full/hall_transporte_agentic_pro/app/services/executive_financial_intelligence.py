from __future__ import annotations

import json
import math
import re
import time
import uuid
from pathlib import Path
from typing import Any

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "executive_financial_intelligence"
CONFIG_FILE = DATA_DIR / "config.json"
RULES_FILE = DATA_DIR / "kpi_rules.json"
SOURCES_FILE = DATA_DIR / "data_sources.json"
REQUESTS_FILE = DATA_DIR / "executive_requests.json"
SNAPSHOTS_FILE = DATA_DIR / "financial_snapshots.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"


INDICATORS: dict[str, dict[str, Any]] = {
    "revenue_gross": {
        "label": "Receita Bruta",
        "group": "receita",
        "formula": "total_vendas_brutas",
        "description": "Total vendido antes de deduções, impostos, cancelamentos e devoluções.",
        "required_fields": ["gross_revenue"],
    },
    "revenue_net": {
        "label": "Receita Líquida",
        "group": "receita",
        "formula": "receita_bruta - deducoes - impostos_sobre_vendas - devolucoes",
        "description": "Receita efetivamente reconhecida após deduções comerciais e tributárias.",
        "required_fields": ["net_revenue"],
    },
    "cogs": {
        "label": "Custos",
        "group": "resultado",
        "formula": "custos_diretos + custos_operacionais",
        "description": "Custos associados à operação, mercadoria, serviço ou produção.",
        "required_fields": ["cogs"],
    },
    "gross_profit": {
        "label": "Lucro Bruto",
        "group": "resultado",
        "formula": "receita_liquida - custos",
        "description": "Resultado após subtrair os custos diretamente ligados à operação.",
        "required_fields": ["net_revenue", "cogs"],
    },
    "operating_profit": {
        "label": "Lucro Operacional",
        "group": "resultado",
        "formula": "lucro_bruto - despesas_operacionais",
        "description": "Resultado da operação antes de efeitos financeiros e impostos finais.",
        "required_fields": ["gross_profit", "operating_expenses"],
    },
    "net_income": {
        "label": "Lucro Líquido",
        "group": "resultado",
        "formula": "resultado_final_após_todas_as_receitas_despesas_impostos",
        "description": "Resultado final da empresa no período.",
        "required_fields": ["net_income"],
    },
    "ebitda": {
        "label": "EBITDA",
        "group": "fundamentalista",
        "formula": "lucro_operacional + depreciação + amortização",
        "description": "Resultado operacional antes de juros, impostos, depreciação e amortização. Pode ter ajustes gerenciais por empresa.",
        "required_fields": ["operating_profit", "depreciation", "amortization"],
    },
    "ebitda_margin": {
        "label": "Margem EBITDA",
        "group": "margens",
        "formula": "EBITDA / receita_liquida",
        "description": "Mostra quanto da receita líquida vira geração operacional antes de juros, impostos, depreciação e amortização.",
        "required_fields": ["ebitda", "net_revenue"],
    },
    "gross_margin": {
        "label": "Margem Bruta",
        "group": "margens",
        "formula": "lucro_bruto / receita_liquida",
        "description": "Indica eficiência da operação antes das despesas administrativas/comerciais.",
        "required_fields": ["gross_profit", "net_revenue"],
    },
    "operating_margin": {
        "label": "Margem Operacional",
        "group": "margens",
        "formula": "lucro_operacional / receita_liquida",
        "description": "Indica a rentabilidade da operação principal.",
        "required_fields": ["operating_profit", "net_revenue"],
    },
    "net_margin": {
        "label": "Margem Líquida",
        "group": "margens",
        "formula": "lucro_liquido / receita_liquida",
        "description": "Indica quanto sobra de lucro final para cada real de receita líquida.",
        "required_fields": ["net_income", "net_revenue"],
    },
    "cash_balance": {
        "label": "Saldo de Caixa",
        "group": "caixa",
        "formula": "caixa + bancos + aplicações_resgatáveis",
        "description": "Disponibilidade imediata ou de curtíssimo prazo.",
        "required_fields": ["cash_balance"],
    },
    "cash_flow_operating": {
        "label": "Fluxo de Caixa Operacional",
        "group": "caixa",
        "formula": "entradas_operacionais - saídas_operacionais",
        "description": "Geração ou consumo de caixa da operação.",
        "required_fields": ["cash_in", "cash_out"],
    },
    "accounts_receivable": {
        "label": "Contas a Receber",
        "group": "capital_giro",
        "formula": "total_títulos_a_receber_abertos",
        "description": "Valores pendentes de recebimento.",
        "required_fields": ["accounts_receivable"],
    },
    "accounts_payable": {
        "label": "Contas a Pagar",
        "group": "capital_giro",
        "formula": "total_títulos_a_pagar_abertos",
        "description": "Compromissos financeiros em aberto.",
        "required_fields": ["accounts_payable"],
    },
    "delinquency_rate": {
        "label": "Inadimplência",
        "group": "capital_giro",
        "formula": "recebíveis_vencidos / contas_a_receber",
        "description": "Percentual do contas a receber vencido.",
        "required_fields": ["overdue_receivables", "accounts_receivable"],
    },
    "working_capital": {
        "label": "Capital de Giro",
        "group": "capital_giro",
        "formula": "ativo_circulante - passivo_circulante",
        "description": "Folga financeira de curto prazo.",
        "required_fields": ["current_assets", "current_liabilities"],
    },
    "current_ratio": {
        "label": "Liquidez Corrente",
        "group": "liquidez",
        "formula": "ativo_circulante / passivo_circulante",
        "description": "Capacidade de pagar obrigações de curto prazo com ativos de curto prazo.",
        "required_fields": ["current_assets", "current_liabilities"],
    },
    "quick_ratio": {
        "label": "Liquidez Seca",
        "group": "liquidez",
        "formula": "(ativo_circulante - estoques) / passivo_circulante",
        "description": "Liquidez de curto prazo desconsiderando estoques.",
        "required_fields": ["current_assets", "inventory", "current_liabilities"],
    },
    "net_debt": {
        "label": "Dívida Líquida",
        "group": "endividamento",
        "formula": "dívida_bruta - caixa",
        "description": "Dívida descontando disponibilidades de caixa.",
        "required_fields": ["gross_debt", "cash_balance"],
    },
    "net_debt_ebitda": {
        "label": "Dívida Líquida / EBITDA",
        "group": "endividamento",
        "formula": "dívida_líquida / EBITDA",
        "description": "Mede alavancagem em relação à geração operacional.",
        "required_fields": ["net_debt", "ebitda"],
    },
    "roe": {
        "label": "ROE",
        "group": "rentabilidade",
        "formula": "lucro_líquido / patrimônio_líquido",
        "description": "Retorno sobre o patrimônio líquido.",
        "required_fields": ["net_income", "equity"],
    },
    "roa": {
        "label": "ROA",
        "group": "rentabilidade",
        "formula": "lucro_líquido / ativos_totais",
        "description": "Retorno sobre os ativos.",
        "required_fields": ["net_income", "total_assets"],
    },
    "roi": {
        "label": "ROI",
        "group": "rentabilidade",
        "formula": "ganho_do_investimento / investimento",
        "description": "Retorno sobre investimento.",
        "required_fields": ["investment_gain", "investment_cost"],
    },
    "roic": {
        "label": "ROIC",
        "group": "rentabilidade",
        "formula": "NOPAT / capital_investido",
        "description": "Retorno sobre capital investido.",
        "required_fields": ["nopat", "invested_capital"],
    },
    "break_even": {
        "label": "Ponto de Equilíbrio",
        "group": "eficiencia",
        "formula": "custos_fixos / margem_de_contribuição",
        "description": "Volume necessário para cobrir custos e despesas.",
        "required_fields": ["fixed_costs", "contribution_margin"],
    },
    "average_ticket": {
        "label": "Ticket Médio",
        "group": "operacional",
        "formula": "receita / quantidade_de_transações",
        "description": "Valor médio por venda/transação/passagem/pedido.",
        "required_fields": ["net_revenue", "transactions"],
    },
    "unit_cost": {
        "label": "Custo por Unidade",
        "group": "operacional",
        "formula": "custo_total / unidades",
        "description": "Custo médio por unidade, viagem, produto, pedido ou serviço.",
        "required_fields": ["total_cost", "units"],
    },
    "growth_mom": {
        "label": "Crescimento Mensal",
        "group": "crescimento",
        "formula": "(valor_atual - valor_mês_anterior) / valor_mês_anterior",
        "description": "Evolução contra o mês anterior.",
        "required_fields": ["current_value", "previous_value"],
    },
    "growth_yoy": {
        "label": "Crescimento Anual",
        "group": "crescimento",
        "formula": "(valor_atual - valor_ano_anterior) / valor_ano_anterior",
        "description": "Evolução contra o mesmo período do ano anterior.",
        "required_fields": ["current_value", "year_ago_value"],
    },
    "free_cash_flow": {
        "label": "Free Cash Flow",
        "group": "valor",
        "formula": "fluxo_operacional - capex",
        "description": "Caixa livre gerado após investimentos necessários.",
        "required_fields": ["cash_flow_operating", "capex"],
    },
    "ev_ebitda": {
        "label": "EV / EBITDA",
        "group": "valuation",
        "formula": "enterprise_value / EBITDA",
        "description": "Múltiplo de valor da empresa sobre geração operacional.",
        "required_fields": ["enterprise_value", "ebitda"],
    },
}

DEFAULT_RULES = {
    "company_rule_version": "gerencial_padrao",
    "currency": "BRL",
    "period_type": "mensal",
    "ebitda_rule": {
        "method": "operating_profit_plus_depreciation_amortization",
        "formula": "EBITDA = Lucro Operacional + Depreciação + Amortização",
        "allow_management_adjustments": True,
        "requires_account_mapping": True,
    },
    "health_score_weights": {
        "ebitda_margin": 0.22,
        "net_margin": 0.18,
        "cash_flow_operating": 0.18,
        "current_ratio": 0.14,
        "net_debt_ebitda": 0.14,
        "delinquency_rate": 0.14,
    },
    "alert_thresholds": {
        "ebitda_margin_min": 0.12,
        "net_margin_min": 0.05,
        "current_ratio_min": 1.20,
        "net_debt_ebitda_max": 3.0,
        "delinquency_rate_max": 0.08,
        "cash_runway_days_min": 30,
    },
}

DEFAULT_CONFIG = {
    "enabled": True,
    "local_first": True,
    "cloud_optional": True,
    "require_real_source": True,
    "never_invent_numbers": True,
    "default_period": "mês atual",
    "default_granularity": "empresa",
    "supported_granularity": ["empresa", "filial", "unidade", "centro_custo", "linha_negocio", "produto", "cliente", "segmento"],
    "allowed_sources": ["erp", "database", "powerbi", "dre", "contabilidade", "planilha", "crm", "bilhetagem", "vendas"],
    "executive_profiles": ["diretoria", "gestor", "controladoria", "financeiro", "contabilidade", "sócio", "socio"],
    "remote_access_policy": "local_first_secure_remote_optional",
    "approval_required_for_external_delivery": True,
    "audit_enabled": True,
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    for path, default in [
        (CONFIG_FILE, DEFAULT_CONFIG),
        (RULES_FILE, DEFAULT_RULES),
        (SOURCES_FILE, {"sources": []}),
        (REQUESTS_FILE, {"requests": []}),
        (SNAPSHOTS_FILE, {"snapshots": []}),
    ]:
        if not path.exists():
            path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    if not _load(CONFIG_FILE, DEFAULT_CONFIG).get("audit_enabled", True):
        return
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def status() -> dict[str, Any]:
    sources = _load(SOURCES_FILE, {"sources": []}).get("sources", [])
    requests = _load(REQUESTS_FILE, {"requests": []}).get("requests", [])
    snapshots = _load(SNAPSHOTS_FILE, {"snapshots": []}).get("snapshots", [])
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    return {
        "ok": True,
        "name": "HAL Executive Financial Intelligence",
        "description": "Indicadores fundamentalistas, saúde financeira, EBITDA, DRE, caixa, margens, liquidez, endividamento, rentabilidade e análise executiva por fonte real.",
        "enabled": cfg.get("enabled", True),
        "local_first": cfg.get("local_first", True),
        "cloud_optional": cfg.get("cloud_optional", True),
        "indicators_count": len(INDICATORS),
        "sources_count": len(sources),
        "requests_count": len(requests),
        "snapshots_count": len(snapshots),
        "capabilities": [
            "Painel executivo financeiro",
            "Indicadores fundamentalistas da empresa",
            "EBITDA e margem EBITDA",
            "DRE gerencial e contábil",
            "Fluxo de caixa",
            "Margens bruta, operacional e líquida",
            "Liquidez corrente e seca",
            "Endividamento e dívida líquida / EBITDA",
            "ROE, ROA, ROI e ROIC",
            "Contas a pagar e receber",
            "Inadimplência",
            "Capital de giro",
            "Ponto de equilíbrio",
            "Ticket médio e custo por unidade",
            "Análise por filial, unidade, centro de custo e linha de negócio",
            "Comparativo mensal/anual",
            "Alertas executivos",
            "Explicação simples dos números para gestores",
            "Perguntas de aprofundamento coerentes",
            "Sem inventar dados: exige fonte real ou modo demo",
        ],
    }


def catalog() -> dict[str, Any]:
    groups: dict[str, list[dict[str, Any]]] = {}
    for key, spec in INDICATORS.items():
        groups.setdefault(spec["group"], []).append({"key": key, **spec})
    return {
        "ok": True,
        "indicators": [{"key": k, **v} for k, v in INDICATORS.items()],
        "groups": groups,
        "rules": _load(RULES_FILE, DEFAULT_RULES),
        "config": _load(CONFIG_FILE, DEFAULT_CONFIG),
    }


def update_config(changes: dict[str, Any]) -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    deep_update(cfg, changes or {})
    _save(CONFIG_FILE, cfg)
    _audit({"event": "update_config"})
    return {"ok": True, "config": cfg, "summary": "Configuração executiva atualizada."}


def update_rules(changes: dict[str, Any]) -> dict[str, Any]:
    rules = _load(RULES_FILE, DEFAULT_RULES)
    deep_update(rules, changes or {})
    _save(RULES_FILE, rules)
    _audit({"event": "update_rules"})
    return {"ok": True, "rules": rules, "summary": "Regras de indicadores atualizadas."}


def deep_update(base: dict[str, Any], changes: dict[str, Any]) -> None:
    for k, v in changes.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            deep_update(base[k], v)
        else:
            base[k] = v


def register_source(
    name: str,
    source_type: str = "database",
    connection_ref: str = "",
    system: str = "",
    company: str = "",
    description: str = "",
    enabled: bool = True,
) -> dict[str, Any]:
    src = {
        "id": f"src_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "name": name or "Fonte Executiva",
        "source_type": source_type,
        "connection_ref": connection_ref,
        "system": system,
        "company": company,
        "description": description,
        "enabled": enabled,
        "created_at": _now(),
    }
    data = _load(SOURCES_FILE, {"sources": []})
    data.setdefault("sources", []).insert(0, src)
    _save(SOURCES_FILE, data)
    _audit({"event": "register_source", "source_id": src["id"], "type": source_type})
    return {"ok": True, "source": src, "summary": "Fonte executiva registrada."}


def list_sources(source_type: str = "", limit: int = 100) -> dict[str, Any]:
    items = _load(SOURCES_FILE, {"sources": []}).get("sources", [])
    if source_type:
        items = [s for s in items if s.get("source_type") == source_type]
    return {"ok": True, "sources": items[:max(1, min(limit, 500))], "count": len(items)}


def save_snapshot(
    period: str,
    company: str = "",
    branch: str = "",
    cost_center: str = "",
    values: dict[str, float] | None = None,
    source: str = "manual_demo",
) -> dict[str, Any]:
    snap = {
        "id": f"snap_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "period": period or "mês atual",
        "company": company,
        "branch": branch,
        "cost_center": cost_center,
        "source": source,
        "values": values or {},
        "created_at": _now(),
    }
    data = _load(SNAPSHOTS_FILE, {"snapshots": []})
    data.setdefault("snapshots", []).insert(0, snap)
    _save(SNAPSHOTS_FILE, data)
    _audit({"event": "save_snapshot", "snapshot_id": snap["id"]})
    return {"ok": True, "snapshot": snap, "summary": "Snapshot financeiro salvo."}


def list_snapshots(period: str = "", company: str = "", limit: int = 100) -> dict[str, Any]:
    items = _load(SNAPSHOTS_FILE, {"snapshots": []}).get("snapshots", [])
    if period:
        items = [s for s in items if s.get("period") == period]
    if company:
        items = [s for s in items if s.get("company") == company]
    return {"ok": True, "snapshots": items[:max(1, min(limit, 500))], "count": len(items)}


def _num(values: dict[str, Any], key: str, default: float = 0.0) -> float:
    try:
        val = values.get(key, default)
        if val in ("", None):
            return default
        return float(val)
    except Exception:
        return default


def _safe_div(a: float, b: float) -> float | None:
    if abs(b) < 1e-12:
        return None
    return a / b


def calculate_indicators(values: dict[str, Any]) -> dict[str, Any]:
    gross_revenue = _num(values, "gross_revenue", _num(values, "revenue_gross"))
    net_revenue = _num(values, "net_revenue", _num(values, "revenue_net", gross_revenue))
    cogs = _num(values, "cogs")
    operating_expenses = _num(values, "operating_expenses")
    depreciation = _num(values, "depreciation")
    amortization = _num(values, "amortization")
    net_income = _num(values, "net_income")
    cash_balance = _num(values, "cash_balance")
    cash_in = _num(values, "cash_in")
    cash_out = _num(values, "cash_out")
    accounts_receivable = _num(values, "accounts_receivable")
    accounts_payable = _num(values, "accounts_payable")
    overdue_receivables = _num(values, "overdue_receivables")
    current_assets = _num(values, "current_assets")
    current_liabilities = _num(values, "current_liabilities")
    inventory = _num(values, "inventory")
    gross_debt = _num(values, "gross_debt")
    equity = _num(values, "equity")
    total_assets = _num(values, "total_assets")
    fixed_costs = _num(values, "fixed_costs")
    contribution_margin_value = _num(values, "contribution_margin_value")
    transactions = _num(values, "transactions")
    units = _num(values, "units")
    total_cost = _num(values, "total_cost", cogs + operating_expenses)
    capex = _num(values, "capex")
    enterprise_value = _num(values, "enterprise_value")
    nopat = _num(values, "nopat")
    invested_capital = _num(values, "invested_capital")

    gross_profit = values.get("gross_profit")
    gross_profit = float(gross_profit) if gross_profit not in ("", None) else net_revenue - cogs

    operating_profit = values.get("operating_profit")
    operating_profit = float(operating_profit) if operating_profit not in ("", None) else gross_profit - operating_expenses

    ebitda = values.get("ebitda")
    ebitda = float(ebitda) if ebitda not in ("", None) else operating_profit + depreciation + amortization

    cash_flow_operating = values.get("cash_flow_operating")
    cash_flow_operating = float(cash_flow_operating) if cash_flow_operating not in ("", None) else cash_in - cash_out

    net_debt = gross_debt - cash_balance
    working_capital = current_assets - current_liabilities

    computed = {
        "gross_revenue": gross_revenue,
        "net_revenue": net_revenue,
        "cogs": cogs,
        "gross_profit": gross_profit,
        "operating_profit": operating_profit,
        "net_income": net_income,
        "ebitda": ebitda,
        "ebitda_margin": _safe_div(ebitda, net_revenue),
        "gross_margin": _safe_div(gross_profit, net_revenue),
        "operating_margin": _safe_div(operating_profit, net_revenue),
        "net_margin": _safe_div(net_income, net_revenue),
        "cash_balance": cash_balance,
        "cash_flow_operating": cash_flow_operating,
        "accounts_receivable": accounts_receivable,
        "accounts_payable": accounts_payable,
        "delinquency_rate": _safe_div(overdue_receivables, accounts_receivable),
        "working_capital": working_capital,
        "current_ratio": _safe_div(current_assets, current_liabilities),
        "quick_ratio": _safe_div(current_assets - inventory, current_liabilities),
        "net_debt": net_debt,
        "net_debt_ebitda": _safe_div(net_debt, ebitda),
        "roe": _safe_div(net_income, equity),
        "roa": _safe_div(net_income, total_assets),
        "roi": _safe_div(_num(values, "investment_gain"), _num(values, "investment_cost")),
        "roic": _safe_div(nopat, invested_capital),
        "break_even": _safe_div(fixed_costs, contribution_margin_value),
        "average_ticket": _safe_div(net_revenue, transactions),
        "unit_cost": _safe_div(total_cost, units),
        "free_cash_flow": cash_flow_operating - capex,
        "ev_ebitda": _safe_div(enterprise_value, ebitda),
    }

    # Clean NaN/Inf
    for k, v in list(computed.items()):
        if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
            computed[k] = None
    return computed


def format_money(v: Any) -> str:
    if v is None:
        return "não disponível"
    try:
        return f"R$ {float(v):,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    except Exception:
        return str(v)


def format_pct(v: Any) -> str:
    if v is None:
        return "não disponível"
    try:
        return f"{float(v) * 100:.2f}%".replace(".", ",")
    except Exception:
        return str(v)


def health_score(indicators: dict[str, Any]) -> dict[str, Any]:
    rules = _load(RULES_FILE, DEFAULT_RULES)
    th = rules.get("alert_thresholds", DEFAULT_RULES["alert_thresholds"])

    score = 100.0
    alerts: list[dict[str, Any]] = []

    def penalize(condition: bool, points: float, code: str, message: str, severity: str = "atenção") -> None:
        nonlocal score
        if condition:
            score -= points
            alerts.append({"code": code, "severity": severity, "message": message})

    ebitda_margin = indicators.get("ebitda_margin")
    net_margin = indicators.get("net_margin")
    current_ratio = indicators.get("current_ratio")
    net_debt_ebitda = indicators.get("net_debt_ebitda")
    delinquency_rate = indicators.get("delinquency_rate")
    cash_flow = indicators.get("cash_flow_operating")

    penalize(ebitda_margin is not None and ebitda_margin < th.get("ebitda_margin_min", 0.12), 16, "low_ebitda_margin", "Margem EBITDA abaixo do parâmetro definido.")
    penalize(net_margin is not None and net_margin < th.get("net_margin_min", 0.05), 14, "low_net_margin", "Margem líquida abaixo do parâmetro definido.")
    penalize(current_ratio is not None and current_ratio < th.get("current_ratio_min", 1.2), 12, "low_current_ratio", "Liquidez corrente abaixo do mínimo desejado.")
    penalize(net_debt_ebitda is not None and net_debt_ebitda > th.get("net_debt_ebitda_max", 3.0), 16, "high_leverage", "Dívida líquida / EBITDA acima do limite definido.", "crítico")
    penalize(delinquency_rate is not None and delinquency_rate > th.get("delinquency_rate_max", 0.08), 12, "high_delinquency", "Inadimplência acima do limite definido.")
    penalize(cash_flow is not None and cash_flow < 0, 14, "negative_operating_cash_flow", "Fluxo de caixa operacional negativo.", "crítico")

    score = max(0.0, min(100.0, score))
    if score >= 80:
        label = "saudável"
    elif score >= 60:
        label = "atenção"
    elif score >= 40:
        label = "risco"
    else:
        label = "crítico"

    return {"score": round(score, 1), "label": label, "alerts": alerts}


def executive_summary_from_values(values: dict[str, Any], period: str = "mês atual", scope: str = "empresa") -> dict[str, Any]:
    indicators = calculate_indicators(values)
    health = health_score(indicators)

    summary_lines = [
        f"Visão executiva do período {period} para {scope}: situação geral **{health['label']}** com score {health['score']}/100.",
        f"Receita líquida: {format_money(indicators.get('net_revenue'))}.",
        f"EBITDA: {format_money(indicators.get('ebitda'))}, margem EBITDA: {format_pct(indicators.get('ebitda_margin'))}.",
        f"Lucro líquido: {format_money(indicators.get('net_income'))}, margem líquida: {format_pct(indicators.get('net_margin'))}.",
        f"Fluxo de caixa operacional: {format_money(indicators.get('cash_flow_operating'))}.",
        f"Liquidez corrente: {indicators.get('current_ratio') if indicators.get('current_ratio') is not None else 'não disponível'}.",
        f"Dívida líquida / EBITDA: {indicators.get('net_debt_ebitda') if indicators.get('net_debt_ebitda') is not None else 'não disponível'}.",
    ]

    if health["alerts"]:
        summary_lines.append("Pontos de atenção: " + "; ".join(a["message"] for a in health["alerts"][:4]))
    else:
        summary_lines.append("Nenhum alerta crítico foi identificado com os parâmetros atuais.")

    summary_lines.append("Quer que eu detalhe por filial, centro de custo, linha de negócio ou período comparativo?")

    return {
        "ok": True,
        "period": period,
        "scope": scope,
        "indicators": indicators,
        "health": health,
        "answer": "\n".join(summary_lines),
    }


def latest_snapshot_values() -> dict[str, Any] | None:
    snaps = _load(SNAPSHOTS_FILE, {"snapshots": []}).get("snapshots", [])
    if not snaps:
        return None
    return snaps[0].get("values", {})


def extract_period(message: str) -> str:
    low = (message or "").lower()
    if "hoje" in low:
        return "hoje"
    if "mês atual" in low or "mes atual" in low or "este mês" in low or "esse mês" in low:
        return "mês atual"
    if "mês anterior" in low or "mes anterior" in low:
        return "mês anterior"
    if "ano" in low:
        return "ano atual"
    m = re.search(r"(20\d{2}[-/]\d{1,2}|[01]?\d/20\d{2})", message or "")
    return m.group(1) if m else "mês atual"


def extract_scope(message: str) -> str:
    low = (message or "").lower()
    if "filial" in low:
        return "filial"
    if "centro de custo" in low:
        return "centro de custo"
    if "linha de negócio" in low or "linha de negocio" in low:
        return "linha de negócio"
    if "unidade" in low:
        return "unidade"
    return "empresa"


def classify_financial_question(message: str) -> dict[str, Any]:
    low = (message or "").lower()
    matched = []
    terms = {
        "ebitda": ["ebitda", "margem ebitda"],
        "dre": ["dre", "resultado", "demonstrativo"],
        "cash": ["fluxo de caixa", "caixa", "capital de giro"],
        "margin": ["margem", "margens", "lucro"],
        "debt": ["dívida", "divida", "endividamento", "alavancagem"],
        "liquidity": ["liquidez", "corrente", "seca"],
        "profitability": ["roe", "roa", "roi", "roic", "rentabilidade"],
        "valuation": ["valuation", "ev/ebitda", "ev ebitda", "valor da empresa"],
        "executive_health": ["saúde financeira", "saude financeira", "indicadores fundamentalistas", "fundamentalistas", "gestores", "diretoria"],
        "comparison": ["compare", "comparar", "comparativo", "mês anterior", "mes anterior", "ano anterior"],
        "branch": ["filial", "unidade", "centro de custo", "linha de negócio", "linha de negocio"],
    }
    for key, vals in terms.items():
        if any(v in low for v in vals):
            matched.append(key)
    if not matched:
        matched.append("executive_health")
    return {"ok": True, "topics": matched, "period": extract_period(message), "scope": extract_scope(message)}


def build_clarifying_questions(message: str) -> list[str]:
    return [
        "Qual fonte devo usar: ERP, banco de dados, Power BI, DRE contábil, planilha ou sistema financeiro?",
        "Qual período devo considerar: hoje, mês atual, mês anterior, trimestre ou ano?",
        "A análise é consolidada da empresa ou por filial, unidade, centro de custo ou linha de negócio?",
        "O EBITDA deve seguir regra contábil ou regra gerencial com ajustes internos?",
    ]


def guided_answer(message: str, approved: bool = False, values: dict[str, Any] | None = None) -> dict[str, Any]:
    classification = classify_financial_question(message)
    period = classification["period"]
    scope = classification["scope"]

    srcs = _load(SOURCES_FILE, {"sources": []}).get("sources", [])
    latest_values = values or latest_snapshot_values()

    request = {
        "id": f"exec_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "message": message,
        "classification": classification,
        "approved": approved,
        "created_at": _now(),
    }

    if latest_values:
        result = executive_summary_from_values(latest_values, period=period, scope=scope)
        request["status"] = "answered_from_snapshot_or_values"
        request["result"] = result
        save_request(request)
        _audit({"event": "guided_answer", "request_id": request["id"], "mode": "snapshot"})
        return {
            "ok": True,
            "request": request,
            "answer": result["answer"],
            "indicators": result["indicators"],
            "health": result["health"],
            "needs_real_source": False,
            "next_questions": ["Quer detalhar por filial, centro de custo, linha de negócio ou comparar com outro período?"],
        }

    if not srcs:
        answer = (
            "Consigo fazer essa análise executiva, mas não vou inventar números. "
            "Para responder EBITDA, DRE, margem, caixa, liquidez e endividamento, preciso de uma fonte real de dados.\n\n"
            "Me informe uma destas fontes: ERP, banco SQL/NoSQL, Power BI, DRE contábil, planilha autorizada ou sistema financeiro.\n\n"
            "Para configurar corretamente, preciso de:\n"
            "1. fonte dos dados;\n"
            f"2. período desejado, que entendi como {period};\n"
            f"3. escopo, que entendi como {scope};\n"
            "4. regra de EBITDA: contábil ou gerencial.\n\n"
            "Depois disso eu consigo responder como painel executivo e explicar os números em linguagem simples."
        )
        request["status"] = "needs_source"
        request["missing"] = build_clarifying_questions(message)
        save_request(request)
        _audit({"event": "guided_answer", "request_id": request["id"], "mode": "needs_source"})
        return {
            "ok": True,
            "request": request,
            "answer": answer,
            "needs_real_source": True,
            "next_questions": build_clarifying_questions(message),
        }

    # Fonte existe, mas a execução real depende dos conectores de banco/ERP/Power BI.
    source_list = ", ".join([s.get("name", "Fonte") for s in srcs[:5]])
    answer = (
        f"Encontrei fonte(s) executiva(s) cadastrada(s): {source_list}. "
        "O próximo passo é executar a consulta real no conector correspondente, sem expor o banco direto e respeitando permissões.\n\n"
        f"Entendi o período como **{period}** e o escopo como **{scope}**. "
        "Vou preparar a análise de EBITDA, DRE, caixa, margens, liquidez, endividamento e rentabilidade.\n\n"
        "Se quiser, eu posso começar pela visão consolidada e depois abrir por filial, centro de custo ou linha de negócio."
    )
    request["status"] = "source_registered_query_plan"
    request["sources"] = srcs[:5]
    save_request(request)
    _audit({"event": "guided_answer", "request_id": request["id"], "mode": "query_plan"})
    return {
        "ok": True,
        "request": request,
        "answer": answer,
        "needs_real_source": False,
        "query_plan": build_query_plan(message, srcs[:3], classification),
        "next_questions": ["Deseja consolidado, por filial, centro de custo ou linha de negócio?"],
    }


def build_query_plan(message: str, sources: list[dict[str, Any]], classification: dict[str, Any]) -> list[dict[str, Any]]:
    steps = [
        {"id": "validate_permissions", "label": "Validar perfil executivo e permissões por empresa/filial/indicador", "status": "pending"},
        {"id": "load_rules", "label": "Carregar regra de EBITDA, DRE e plano de contas configurado", "status": "pending"},
        {"id": "extract_financial_data", "label": "Consultar fonte real: ERP/banco/Power BI/DRE/contabilidade", "status": "pending"},
        {"id": "calculate_indicators", "label": "Calcular indicadores fundamentalistas e executivos", "status": "pending"},
        {"id": "detect_alerts", "label": "Comparar com metas, histórico e limites de risco", "status": "pending"},
        {"id": "explain_executive", "label": "Explicar em linguagem simples para gestores", "status": "pending"},
    ]
    if sources:
        steps.insert(2, {"id": "select_source", "label": f"Usar fonte principal: {sources[0].get('name')}", "status": "selected"})
    if "comparison" in classification.get("topics", []):
        steps.append({"id": "compare_periods", "label": "Comparar período atual com mês/ano anterior", "status": "pending"})
    if "branch" in classification.get("topics", []):
        steps.append({"id": "breakdown_scope", "label": "Quebrar por filial/unidade/centro de custo", "status": "pending"})
    return steps


def save_request(request: dict[str, Any]) -> None:
    data = _load(REQUESTS_FILE, {"requests": []})
    data.setdefault("requests", []).insert(0, request)
    data["requests"] = data["requests"][:500]
    _save(REQUESTS_FILE, data)


def list_requests(status_filter: str = "", limit: int = 100) -> dict[str, Any]:
    items = _load(REQUESTS_FILE, {"requests": []}).get("requests", [])
    if status_filter:
        items = [i for i in items if i.get("status") == status_filter]
    return {"ok": True, "requests": items[:max(1, min(limit, 500))], "count": len(items)}


def seed_demo() -> dict[str, Any]:
    # Exemplo gerencial sem representar dado real da empresa.
    values = {
        "gross_revenue": 1850000,
        "net_revenue": 1680000,
        "cogs": 930000,
        "operating_expenses": 455000,
        "depreciation": 38000,
        "amortization": 12000,
        "net_income": 148000,
        "cash_balance": 620000,
        "cash_in": 1450000,
        "cash_out": 1320000,
        "accounts_receivable": 720000,
        "accounts_payable": 510000,
        "overdue_receivables": 76000,
        "current_assets": 1580000,
        "current_liabilities": 1120000,
        "inventory": 250000,
        "gross_debt": 1200000,
        "equity": 2400000,
        "total_assets": 4900000,
        "fixed_costs": 390000,
        "contribution_margin_value": 0.38,
        "transactions": 42000,
        "units": 42000,
        "capex": 85000,
        "enterprise_value": 7800000,
        "nopat": 210000,
        "invested_capital": 3100000,
    }
    src = register_source("Demonstração Executiva Local", "demo", "demo://executive-finance", "HAL Demo", "AJDS Demo", "Fonte demonstrativa para validar painel executivo.", True)
    snap = save_snapshot("mês atual", "Empresa Demo", "Consolidado", "", values, "demo")
    result = executive_summary_from_values(values, "mês atual", "empresa")
    return {"ok": True, "source": src.get("source"), "snapshot": snap.get("snapshot"), "summary": result, "message": "Demo executiva criada."}


def answer_for_executive_finance(message: str = "") -> str:
    res = guided_answer(message or "indicadores fundamentalistas da empresa")
    return res.get("answer", "")
