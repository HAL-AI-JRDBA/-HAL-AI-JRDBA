from __future__ import annotations

import json
import os
import time
import urllib.request
import sys
from pathlib import Path
from dataclasses import dataclass
from typing import Any

from app.core.config import root_dir
_hall_project = str(Path(__file__).resolve().parents[3])
if _hall_project not in sys.path:
    sys.path.insert(0, _hall_project)
from services.gemma4_v42 import Gemma4, conversation_model, prepare_payload, final_answer, guard_local_model
from services import ssot_context_v43 as official


DATA_DIR = root_dir() / "data" / "multi_model_router"
CONFIG_FILE = DATA_DIR / "config.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"

DEFAULT_MODELS = {
    "chat": "qwen2.5:7b",
    "dialog": "qwen2.5:7b",
    "code": "qwen2.5-coder:14b",
    "fast_code": "qwen2.5-coder:7b",
    "deep_code": "deepseek-coder-v2:16b",
    "sql": "sqlcoder:7b-q4_0",
    "embed": "embeddinggemma:latest",
    "vision": "llava:latest",
    "fast": "phi3:mini",
}

ENV_MAP = {
    "chat": ["HALL_MODEL_CHAT", "HALL_DIALOG_MODEL", "OLLAMA_MODEL"],
    "dialog": ["HALL_MODEL_DIALOG", "HALL_DIALOG_MODEL", "HALL_MODEL_CHAT", "OLLAMA_MODEL"],
    "code": ["HALL_MODEL_CODE"],
    "fast_code": ["HALL_MODEL_FAST_CODE"],
    "deep_code": ["HALL_MODEL_DEEP_CODE"],
    "sql": ["HALL_MODEL_SQL"],
    "embed": ["HALL_MODEL_EMBED", "HALL_EMBEDDING_MODEL"],
    "vision": ["HALL_MODEL_VISION"],
    "fast": ["HALL_MODEL_FAST"],
}

CODE_INTENTS = {"software_builder", "app_factory", "enterprise_productization"}
SQL_INTENTS = {"database", "erp"}
VISION_INTENTS = {"vision", "image", "screen_analysis"}
CYBER_INTENTS = {"cyber_defense"}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        initial_models = dict(DEFAULT_MODELS)
        if os.getenv('HALL_SSOT_V43') == '1':
            # Match the weights prepared by the V43 installer on a fresh machine.
            initial_models.update(code='qwen2.5-coder:7b', fast_code='qwen2.5-coder:7b',
                                  deep_code='qwen2.5-coder:7b', sql='qwen2.5-coder:7b', fast='qwen2.5:7b')
        CONFIG_FILE.write_text(json.dumps({
            "ollama_url": os.getenv("OLLAMA_URL", "http://127.0.0.1:11435"),
            "models": initial_models,
            "timeouts": {"generate": 120, "chat": 120, "sql": 120, "fast_code": 120, "code": 180, "deep_code": 240, "vision": 180, "test": 45, "embed": 30, "tags": 5},
            "routing": {
                "chat": ["conversa", "explicação", "suporte pessoal", "educação", "geral"],
                "code": ["software", "app", "sistema", "python", "frontend", "backend", "api"],
                "sql": ["sql", "banco de dados", "select", "join", "relatório de banco"],
                "embed": ["rag", "busca semântica", "documentos", "knowledge center"],
                "vision": ["imagem", "print", "tela", "screenshot", "documento visual"],
                "cyber": ["segurança defensiva", "ransomware", "phishing", "postura"],
            },
            "boot_check_enabled": True,
            "auto_pull_missing": False
        }, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def ollama_url() -> str:
    _ensure()
    try:
        cfg = json.loads(CONFIG_FILE.read_text(encoding="utf-8-sig"))
    except Exception:
        cfg = {}
    return os.getenv("OLLAMA_URL") or cfg.get("ollama_url") or "http://127.0.0.1:11435"


def role_url(role: str) -> str:
    if role in {'chat', 'dialog'} and conversation_model(root_dir().parent):
        return Gemma4(root_dir().parent).url()
    return ollama_url()


def model_for(role: str) -> str:
    role = role or "chat"
    if role in {'chat', 'dialog'}:
        selected = conversation_model(root_dir().parent)
        if selected:
            return selected
    for env in ENV_MAP.get(role, []):
        val = os.getenv(env)
        if val:
            return val
    _ensure()
    try:
        cfg = json.loads(CONFIG_FILE.read_text(encoding="utf-8-sig"))
        configured = cfg.get("models", {}).get(role)
        if configured:
            return configured
    except Exception:
        pass
    return DEFAULT_MODELS.get(role, DEFAULT_MODELS["chat"])


def all_configured_models() -> dict[str, str]:
    return {role: model_for(role) for role in DEFAULT_MODELS}


def list_installed_models(url: str | None = None) -> dict[str, Any]:
    url = url or ollama_url()
    try:
        req = urllib.request.Request(f"{url.rstrip('/')}/api/tags", method="GET")
        with urllib.request.urlopen(req, timeout=4) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
        data = json.loads(raw)
        names = sorted([m.get("name", "") for m in data.get("models", []) if m.get("name")])
        return {"ok": True, "url": url, "models": names, "count": len(names)}
    except Exception as exc:
        return {"ok": False, "url": url, "models": [], "count": 0, "error": str(exc)}


def _model_available(model: str, installed: list[str]) -> bool:
    return any(n == model or n.startswith(model + ":") or model.startswith(n + ":") for n in installed)


def route_model(message: str = "", intent: str = "", task_type: str = "", has_image: bool = False) -> dict[str, Any]:
    low = (message or "").lower()
    intent = (intent or "").lower()
    task_type = (task_type or "").lower()

    role = "chat"
    reason = "conversa geral"

    sql_actions = [
        "sql", "select", "join", "query", "consulta no banco", "consultar banco",
        "gere uma consulta", "gerar consulta", "crie uma consulta", "listar dados",
        "buscar dados", "relatório de banco", "relatorio de banco", "max(", "sum(",
        "group by", "where", "insert", "update", "delete from"
    ]
    db_terms = ["oracle", "postgres", "postgresql", "mysql", "mariadb", "sql server", "mongodb", "banco de dados", "base de dados"]
    asks_sql = any(x in low for x in sql_actions) or (any(x in low for x in db_terms) and any(x in low for x in ["tabela", "coluna", "campo", "dados", "registro", "consulta", "relatório", "relatorio"]))

    if has_image or intent in VISION_INTENTS or any(x in low for x in ["imagem", "print", "screenshot", "tela", "foto", "ocr visual"]):
        role, reason = "vision", "imagem/visão"
    elif asks_sql and (intent in SQL_INTENTS or any(x in low for x in db_terms + sql_actions)):
        role, reason = "sql", "geração/consulta SQL ou acesso a dados"
    elif intent in SQL_INTENTS:
        role, reason = "chat", "explicação/diagnóstico de banco; SQLCoder só é usado quando há tarefa SQL explícita"
    elif "embedding" in task_type or intent in {"rag", "knowledge", "knowledge_center"} or any(x in low for x in ["embedding", "vetor", "busca semântica", "busca semantica", "rag", "indexar documento", "knowledge center"]):
        role, reason = "embed", "embedding/RAG"
    elif any(x in low for x in ["arquitetura complexa", "refatorar", "refatoração", "refatoracao", "deepseek", "complexo", "muito grande"]) and any(y in low for y in ["código", "codigo", "software", "sistema", "arquitetura", "backend", "frontend", "api", "projeto"]):
        role, reason = "deep_code", "programação complexa"
    elif any(x in low for x in ["rápido", "rapido", "corrigir pequeno", "ajuste simples"]) and any(y in low for y in ["código", "codigo", "software", "script", "função", "funcao"]):
        role, reason = "fast_code", "programação rápida"
    elif intent in CODE_INTENTS or any(x in low for x in ["software", "aplicativo", "crie um app", "código", "codigo", "python", "fastapi", "flask", "django", "streamlit", "frontend", "backend"]):
        if any(x in low for x in ["arquitetura complexa", "refatorar", "refatoração", "refatoracao", "deepseek", "complexo", "muito grande"]):
            role, reason = "deep_code", "programação complexa"
        elif any(x in low for x in ["rápido", "rapido", "corrigir pequeno", "ajuste simples"]):
            role, reason = "fast_code", "programação rápida"
        else:
            role, reason = "code", "geração de software/código"
    elif intent in CYBER_INTENTS or any(x in low for x in ["ransomware", "phishing", "malware", "invasão", "invasao", "cibersegurança", "segurança"]):
        role, reason = "chat", "segurança defensiva com modelo conversacional"
    elif any(x in low for x in ["rápido", "resuma em uma frase", "curto e simples"]):
        role, reason = "fast", "resposta rápida"

    return {"ok": True, "role": role, "model": model_for(role), "reason": reason, "intent": intent, "task_type": task_type}


def _role_timeout(role: str) -> float:
    env_map = {
        "chat": "HALL_DIALOG_TIMEOUT", "dialog": "HALL_DIALOG_TIMEOUT", "fast": "HALL_FAST_TIMEOUT",
        "sql": "HALL_SQL_TIMEOUT", "fast_code": "HALL_FAST_CODE_TIMEOUT", "code": "HALL_CODE_TIMEOUT",
        "deep_code": "HALL_DEEP_CODE_TIMEOUT", "vision": "HALL_VISION_TIMEOUT"
    }
    defaults = {"chat":120, "dialog":120, "fast":60, "sql":120, "fast_code":120, "code":180, "deep_code":240, "vision":180}
    try:
        return float(os.getenv(env_map.get(role, "HALL_MODEL_TIMEOUT"), str(defaults.get(role, 120))))
    except Exception:
        return float(defaults.get(role, 120))


def generate(prompt: str, message: str = "", intent: str = "", role: str | None = None, system: str = "", timeout: float | None = None) -> dict[str, Any]:
    chosen = {"role": role, "model": model_for(role)} if role else route_model(message or prompt, intent=intent)
    selected_role = chosen.get("role") or "chat"
    model = chosen["model"]
    url = role_url(selected_role)
    final_prompt = f"{system}\n\n{prompt}".strip() if system else prompt
    base_messages=([{'role':'system','content':system}] if system else [])+[{'role':'user','content':prompt}]
    prepared,ssot_pack=official.augment_current(_hall_project,base_messages,byte_budget=2400)
    if ssot_pack.get('sources'):
        official.ensure_local_inference(url,model)
        final_prompt='\n\n'.join(x['role'].upper()+':\n'+x['content'] for x in prepared)
    keep_alive = os.getenv("HALL_CHAT_KEEP_ALIVE", "15m") if selected_role in {"chat", "dialog"} else os.getenv("HALL_SPECIALIST_KEEP_ALIVE", "2m")
    payload = json.dumps(prepare_payload({
        "model": model,
        "prompt": final_prompt,
        "stream": False,
        "keep_alive": keep_alive,
        "options": {
            "temperature": 0.25 if selected_role in {"code", "fast_code", "deep_code", "sql"} else 0.45,
            "top_p": 0.9,
            "num_ctx": 4096,
            "num_predict": 900,
        },
    }, root_dir().parent)).encode("utf-8")
    started = time.time()
    effective_timeout = timeout or _role_timeout(selected_role)
    try:
        guard_local_model(model, url)
        req = urllib.request.Request(
            f"{url.rstrip('/')}/api/generate",
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        if ssot_pack.get('sources'):
            from services.ssot_v43 import BaseOficial
            data=BaseOficial._local_json(url.rstrip('/')+'/api/generate',json.loads(payload),effective_timeout)
            raw=json.dumps(data)
        else:
            with urllib.request.urlopen(req, timeout=effective_timeout) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
        data = json.loads(raw)
        answer = final_answer(model, data.get("response"))
        ssot=official.validate_current(_hall_project,ssot_pack,answer)
        elapsed = round(time.time() - started, 3)
        _audit({"event": "generate", "role": selected_role, "model": model, "ok": bool(answer), "elapsed_s": elapsed, "timeout_s": effective_timeout, "keep_alive": keep_alive})
        return {"ok": bool(answer), "answer": answer, "model": model, "role": selected_role, "elapsed_s": elapsed, "raw": data, "ssot": ssot, "sources": ssot.get('sources',[])}
    except Exception as exc:
        elapsed = round(time.time() - started, 3)
        _audit({"event": "generate_error", "role": selected_role, "model": model, "error": f"{type(exc).__name__}: {exc}", "elapsed_s": elapsed, "timeout_s": effective_timeout})
        return {"ok": False, "answer": "", "model": model, "role": selected_role, "elapsed_s": elapsed, "error": f"{type(exc).__name__}: {exc}"}


def embed(text: str, model: str | None = None) -> dict[str, Any]:
    url = ollama_url()
    model = model or model_for("embed")
    payload = json.dumps({"model": model, "input": text}).encode("utf-8")
    last_error = ""
    for endpoint in ["/api/embed", "/api/embeddings"]:
        try:
            body = payload if endpoint == "/api/embed" else json.dumps({"model": model, "prompt": text}).encode("utf-8")
            req = urllib.request.Request(
                f"{url.rstrip('/')}{endpoint}",
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=float(os.getenv("HALL_EMBED_TIMEOUT", "10"))) as resp:
                raw = resp.read().decode("utf-8", errors="replace")
            data = json.loads(raw)
            vector = data.get("embeddings") or data.get("embedding") or []
            if isinstance(vector, list) and vector and isinstance(vector[0], list):
                dims = len(vector[0])
            elif isinstance(vector, list):
                dims = len(vector)
            else:
                dims = 0
            return {"ok": dims > 0, "model": model, "endpoint": endpoint, "dimensions": dims, "raw_keys": list(data.keys())}
        except Exception as exc:
            last_error = str(exc)
    return {"ok": False, "model": model, "dimensions": 0, "error": last_error}


def test_generate_model(role: str, prompt: str = "") -> dict[str, Any]:
    prompts = {
        "chat": "Responda apenas: CHAT OK",
        "dialog": "Responda apenas: DIALOG OK",
        "code": "Responda apenas: CODE OK",
        "fast_code": "Responda apenas: FAST CODE OK",
        "deep_code": "Responda apenas: DEEP CODE OK",
        "sql": "Crie um SELECT simples para listar clientes ativos. Responda curto.",
        "vision": "Responda apenas: VISION OK",
        "fast": "Responda apenas: FAST OK",
    }
    role = role or "chat"
    if role == "embed":
        return embed("teste de embedding")
    return generate(prompt or prompts.get(role, "Responda apenas: OK"), role=role, timeout=float(os.getenv("HALL_MODEL_TEST_TIMEOUT", "45")))


def status(test: bool = False) -> dict[str, Any]:
    installed = list_installed_models()
    names = installed.get("models", [])
    chat_url = role_url('chat')
    chat_installed = installed if chat_url == installed.get('url') else list_installed_models(chat_url)
    configured = all_configured_models()
    roles = []
    for role, model in configured.items():
        item = {
            "role": role,
            "model": model,
            "installed": _model_available(model, chat_installed.get('models', []) if role in {'chat', 'dialog'} else names),
            "ollama_url": role_url(role),
            "env": ENV_MAP.get(role, []),
        }
        if test and item["installed"]:
            tr = test_generate_model(role)
            item["test_ok"] = bool(tr.get("ok"))
            item["test_error"] = tr.get("error", "")
            item["dimensions"] = tr.get("dimensions")
        roles.append(item)

    return {
        "ok": installed.get("ok", False) and chat_installed.get('ok', False),
        "name": "HAL Multi-Model Router V15",
        "ollama_url": installed.get("url", ollama_url()),
        "installed_models": names,
        "conversation_installed_models": chat_installed.get('models', []),
        "configured_models": configured,
        "roles": roles,
        "missing": [r for r in roles if not r["installed"]],
        "ready": installed.get("ok", False) and chat_installed.get('ok', False) and all(r["installed"] for r in roles if r["role"] in {"chat", "code", "sql", "embed", "vision"}),
        "test_mode": test,
    }


def boot_report(test: bool = False) -> str:
    st = status(test=test)
    lines = [
        "============================================================",
        "HAL Multi-Model Router V15",
        "============================================================",
        f"Ollama URL: {st.get('ollama_url')}",
        "",
    ]
    for r in st.get("roles", []):
        label = r["role"].upper().replace("_", " ")
        mark = "OK" if r.get("installed") else "FALTANDO"
        test_txt = ""
        if test and r.get("installed"):
            test_txt = " | TESTE OK" if r.get("test_ok") else f" | TESTE FALHOU {r.get('test_error','')[:80]}"
        lines.append(f"[{mark}] {label}: {r['model']}{test_txt}")
    if st.get("missing"):
        lines.append("")
        lines.append("Modelos faltando:")
        for r in st["missing"]:
            lines.append(f"  ollama pull {r['model']}")
    return "\n".join(lines)


def configure(changes: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    cfg = json.loads(CONFIG_FILE.read_text(encoding="utf-8-sig"))
    for k, v in (changes or {}).items():
        if k == "models" and isinstance(v, dict):
            cfg.setdefault("models", {}).update(v)
        else:
            cfg[k] = v
    CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    _audit({"event": "configure", "changes": changes})
    return {"ok": True, "config": cfg}
