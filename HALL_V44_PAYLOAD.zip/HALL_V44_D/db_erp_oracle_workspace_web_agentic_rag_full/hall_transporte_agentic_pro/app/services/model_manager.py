from __future__ import annotations

import json
import subprocess
import urllib.request
from dataclasses import dataclass
from typing import Any

from app.core.config import load_config


@dataclass
class ModelChoice:
    name: str
    reason: str
    mode: str


class OllamaClient:
    def __init__(self, base_url: str | None = None, timeout: int | None = None):
        cfg = load_config().get("ollama", {})
        self.base_url = (base_url or cfg.get("base_url") or "http://127.0.0.1:11435").rstrip("/")
        self.timeout = timeout or int(cfg.get("timeout_seconds") or 180)

    def available(self) -> bool:
        try:
            with urllib.request.urlopen(self.base_url + "/api/tags", timeout=5) as resp:
                return resp.status == 200
        except Exception:
            return False

    def list_models(self) -> dict[str, Any]:
        try:
            with urllib.request.urlopen(self.base_url + "/api/tags", timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8", errors="ignore"))
            return {"ok": True, "models": data.get("models", []), "raw": data}
        except Exception as exc:
            return {"ok": False, "summary": "Ollama offline ou inacessível.", "error": str(exc)}

    def has_model(self, name: str) -> bool:
        models = self.list_models()
        if not models.get("ok"):
            return False
        names = {m.get("name") for m in models.get("models", [])}
        return name in names or any(str(n).startswith(name + ":") for n in names if n)

    def chat(self, messages: list[dict[str, str]], model: str, temperature: float = 0.2) -> dict[str, Any]:
        payload = {
            "model": model,
            "messages": messages,
            "stream": False,
            "options": {"temperature": temperature}
        }
        req = urllib.request.Request(
            self.base_url + "/api/chat",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode("utf-8", errors="ignore"))
            return {"ok": True, "content": data.get("message", {}).get("content", ""), "raw": data}
        except Exception as exc:
            return {"ok": False, "summary": "Falha ao chamar modelo local.", "error": str(exc), "model": model}

    def generate_vision(self, prompt: str, image_b64: str, model: str) -> dict[str, Any]:
        payload = {"model": model, "prompt": prompt, "images": [image_b64], "stream": False}
        req = urllib.request.Request(
            self.base_url + "/api/generate",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode("utf-8", errors="ignore"))
            return {"ok": True, "content": data.get("response", ""), "raw": data}
        except Exception as exc:
            return {"ok": False, "summary": "Falha na visão multimodal.", "error": str(exc), "model": model}

    def pull_model(self, model: str) -> dict[str, Any]:
        try:
            proc = subprocess.run(["ollama", "pull", model], capture_output=True, text=True, timeout=1800)
            return {
                "ok": proc.returncode == 0,
                "model": model,
                "stdout": proc.stdout[-4000:],
                "stderr": proc.stderr[-4000:],
            }
        except Exception as exc:
            return {"ok": False, "model": model, "error": str(exc)}


def choose_model(intent: str = "chat", has_image: bool = False) -> ModelChoice:
    cfg = load_config()
    ollama = cfg.get("ollama", {})
    hardware = cfg.get("runtime", {}).get("hardware_profile", "cpu")

    if has_image:
        return ModelChoice(
            name=ollama.get("vision_model") or "gemma4:12b",
            reason="Pergunta com imagem/tela: usando modelo multimodal.",
            mode="vision",
        )

    if intent in {"coding", "dev"}:
        return ModelChoice(
            name=ollama.get("coding_model") or ollama.get("primary_chat_model") or "qwen2.5-coder:7b",
            reason="Pedido de programação/código: usando modelo de código.",
            mode="coding",
        )

    if hardware == "cpu":
        return ModelChoice(
            name=ollama.get("primary_chat_model") or ollama.get("fast_cpu_model") or "gemma4:12b",
            reason="Modo local CPU: usando modelo principal configurado, com fallback determinístico se estiver lento/offline.",
            mode="chat",
        )

    return ModelChoice(
        name=ollama.get("primary_chat_model") or "gemma4:12b",
        reason="Modo GPU/local: usando modelo principal.",
        mode="chat",
    )


def status() -> dict[str, Any]:
    client = OllamaClient()
    cfg = load_config().get("ollama", {})
    models = client.list_models()
    configured = {
        "primary_chat_model": cfg.get("primary_chat_model"),
        "fallback_chat_model": cfg.get("fallback_chat_model"),
        "fast_cpu_model": cfg.get("fast_cpu_model"),
        "vision_model": cfg.get("vision_model"),
        "coding_model": cfg.get("coding_model"),
    }
    availability = {}
    for key, model in configured.items():
        if model:
            availability[key] = {"model": model, "installed": client.has_model(model)}
    return {
        "ok": True,
        "ollama_online": client.available(),
        "configured": configured,
        "availability": availability,
        "installed_models": models,
        "recommendations": [
            "CPU sem GPU: use modelo menor/quantizado como gemma4:e2b ou qwen2.5:7b.",
            "GPU 8GB-12GB: tente gemma4:12b quantizado.",
            "GPU forte: use gemma4:31b/maior quando disponível no cliente.",
            "Visão: use gemma4 multimodal ou llava:latest.",
        ],
    }
