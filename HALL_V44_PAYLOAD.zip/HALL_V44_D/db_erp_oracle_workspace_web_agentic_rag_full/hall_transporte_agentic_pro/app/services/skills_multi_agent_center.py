from __future__ import annotations

import json
import os
import re
import shutil
import time
import uuid
import urllib.request
from pathlib import Path
from typing import Any

from app.core.config import root_dir


DATA_DIR = root_dir() / "data" / "skills_multi_agent_center"
SKILLS_DIR = DATA_DIR / "skills"
HUB_DIR = DATA_DIR / "local_skill_hub"
AGENTS_FILE = DATA_DIR / "agents.json"
SESSIONS_FILE = DATA_DIR / "agent_sessions.json"
TASKS_FILE = DATA_DIR / "agent_tasks.json"
RUNS_FILE = DATA_DIR / "skill_runs.json"
CONFIG_FILE = DATA_DIR / "config.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"
IMAGE_DIR = DATA_DIR / "image_generation"
FILES_WORKSPACE = DATA_DIR / "files_workspace"

DEFAULT_CONFIG = {
    "enabled": True,
    "local_first": True,
    "cloud_optional": True,
    "skills_extension": ".md",
    "skills_auto_install_enabled": True,
    "local_hub_enabled": True,
    "agents_enabled": True,
    "sessions_spawn_enabled": True,
    "agent_collaboration_enabled": True,
    "image_generation_enabled": True,
    "image_generation_mode": "prompt_or_local_endpoint",
    "image_endpoint": "",
    "code_execution_policy": "sandbox_required_for_real_execution",
    "allow_tool_calls": True,
    "approval_required_for_sensitive_skills": True,
    "audit_enabled": True,
    "default_model": "qwen2.5:7b",
}

DEFAULT_AGENTS = [
    {"id": "agent_financeiro", "name": "Agente Financeiro", "role": "Analisa DRE, EBITDA, caixa, inadimplência e indicadores executivos.", "skills": ["executive_finance_review"], "enabled": True},
    {"id": "agent_dados", "name": "Agente Dados/BI", "role": "Consulta SQL/NoSQL, Power BI, planilhas, arquivos e prepara análises.", "skills": ["database_query_planner"], "enabled": True},
    {"id": "agent_operacoes", "name": "Agente Operações", "role": "Analisa operação, transporte, logística, fábrica, varejo e indicadores de produtividade.", "skills": ["operations_diagnostics"], "enabled": True},
    {"id": "agent_atendimento", "name": "Agente Atendimento", "role": "Atende solicitações, explica em linguagem simples e prepara respostas para canais.", "skills": ["natural_customer_reply"], "enabled": True},
    {"id": "agent_educacao", "name": "Agente Educação", "role": "Explica qualquer assunto para leigos, crianças, escolas e universidades.", "skills": ["simple_teacher"], "enabled": True},
    {"id": "agent_pesquisa", "name": "Agente Pesquisa Web", "role": "Pesquisa web, resume fontes e separa fato de opinião.", "skills": ["web_research_brief"], "enabled": True},
    {"id": "agent_automacao", "name": "Agente Automação", "role": "Cria fluxos n8n, automação de navegador, agendamentos e rotinas.", "skills": ["workflow_builder"], "enabled": True},
    {"id": "agent_design", "name": "Agente Design/Imagem", "role": "Cria prompts, briefings visuais e pedidos de geração de imagens.", "skills": ["image_generation_brief"], "enabled": True},
]

SENSITIVE_KEYWORDS = [
    "enviar", "mandar", "deletar", "excluir", "cancelar", "alterar banco", "update", "delete", "drop", "insert",
    "pagamento", "cobrança", "cobranca", "whatsapp", "telegram", "e-mail", "email", "senha", "token", "credencial",
]

DEFAULT_SKILLS: dict[str, str] = {
    "executive_finance_review.md": """---\nid: executive_finance_review\nname: Revisão Executiva Financeira\ncategory: financeiro\nversion: 1.0\nrisk: medium\nagent: agent_financeiro\n---\n# Objetivo\nAnalisar saúde financeira, EBITDA, DRE, fluxo de caixa, margens, liquidez, endividamento, rentabilidade e pontos de atenção executivos.\n\n# Entrada esperada\n- Pergunta do gestor\n- Período\n- Fonte de dados real ou snapshot autorizado\n- Escopo: empresa, filial, unidade, centro de custo ou linha de negócio\n\n# Procedimento\n1. Não inventar números.\n2. Confirmar fonte dos dados.\n3. Calcular indicadores.\n4. Explicar em linguagem executiva simples.\n5. Fazer pergunta de aprofundamento.\n\n# Saída\nResumo executivo, indicadores, alertas e próximo passo.\n""",
    "database_query_planner.md": """---\nid: database_query_planner\nname: Planejador de Consulta SQL/NoSQL\ncategory: dados\nversion: 1.0\nrisk: high\nagent: agent_dados\n---\n# Objetivo\nPlanejar consultas em bancos SQL/NoSQL sem expor credenciais e sem executar ações destrutivas sem aprovação.\n\n# Procedimento\n1. Identificar banco: SQL Server, Oracle, PostgreSQL, MySQL, MongoDB, Redis, Elasticsearch ou outro.\n2. Perguntar conexão/fonte, tabelas/collections, filtros, período e formato de saída.\n3. Criar query somente leitura por padrão.\n4. Pedir aprovação para operações sensíveis.\n""",
    "simple_teacher.md": """---\nid: simple_teacher\nname: Professor Simples para Leigos e Crianças\ncategory: educacao\nversion: 1.0\nrisk: low\nagent: agent_educacao\n---\n# Objetivo\nExplicar qualquer assunto de forma humana, simples e adaptada à idade/nível do aluno.\n\n# Regras\n- Explicar primeiro com exemplo cotidiano.\n- Dividir em passos pequenos.\n- Não humilhar erro.\n- Perguntar se quer mais um exemplo.\n- Para crianças, usar linguagem leve e direta.\n""",
    "image_generation_brief.md": """---\nid: image_generation_brief\nname: Geração de Imagens e Briefing Visual\ncategory: imagem\nversion: 1.0\nrisk: low\nagent: agent_design\n---\n# Objetivo\nCriar prompt visual, briefing, estilo, formato e parâmetros para geração de imagens por ferramenta local ou endpoint configurado.\n\n# Saída\nPrompt, negative prompt opcional, proporção, estilo, uso comercial e observações de segurança.\n""",
    "workflow_builder.md": """---\nid: workflow_builder\nname: Criador de Workflows e Automações\ncategory: automacao\nversion: 1.0\nrisk: medium\nagent: agent_automacao\n---\n# Objetivo\nTransformar pedidos em fluxo n8n, automação de navegador, cron, integração por API/webhook ou tarefa recorrente.\n\n# Procedimento\n1. Identificar gatilho.\n2. Identificar sistemas envolvidos.\n3. Definir credenciais necessárias.\n4. Definir aprovação humana.\n5. Criar plano de execução.\n""",
    "web_research_brief.md": """---\nid: web_research_brief\nname: Pesquisa Web Confiável\ncategory: pesquisa\nversion: 1.0\nrisk: low\nagent: agent_pesquisa\n---\n# Objetivo\nPesquisar informação atual, resumir fontes, separar fatos de inferências e citar links quando o conector web estiver disponível.\n""",
    "natural_customer_reply.md": """---\nid: natural_customer_reply\nname: Resposta Natural ao Usuário/Cliente\ncategory: atendimento\nversion: 1.0\nrisk: low\nagent: agent_atendimento\n---\n# Objetivo\nResponder de forma humana, cordial, simples e objetiva, sem parecer formulário ou papagaio.\n""",
    "operations_diagnostics.md": """---\nid: operations_diagnostics\nname: Diagnóstico Operacional Multissetor\ncategory: operacoes\nversion: 1.0\nrisk: medium\nagent: agent_operacoes\n---\n# Objetivo\nAnalisar operação em transporte, logística, indústria, agronegócio, varejo, atacado, bancos e fintechs, pedindo fonte real quando precisar de dado.\n""",
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    HUB_DIR.mkdir(parents=True, exist_ok=True)
    IMAGE_DIR.mkdir(parents=True, exist_ok=True)
    FILES_WORKSPACE.mkdir(parents=True, exist_ok=True)
    for path, default in [
        (CONFIG_FILE, DEFAULT_CONFIG),
        (AGENTS_FILE, {"agents": DEFAULT_AGENTS}),
        (SESSIONS_FILE, {"sessions": []}),
        (TASKS_FILE, {"tasks": []}),
        (RUNS_FILE, {"runs": []}),
    ]:
        if not path.exists():
            path.write_text(json.dumps(default, ensure_ascii=False, indent=2), encoding="utf-8")
    for name, body in DEFAULT_SKILLS.items():
        path = SKILLS_DIR / name
        if not path.exists():
            path.write_text(body, encoding="utf-8")
        hub_path = HUB_DIR / name
        if not hub_path.exists():
            hub_path.write_text(body, encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    if not _load(CONFIG_FILE, DEFAULT_CONFIG).get("audit_enabled", True):
        return
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def parse_skill_markdown(text: str, file_name: str = "") -> dict[str, Any]:
    meta: dict[str, Any] = {}
    body = text or ""
    if body.startswith("---"):
        parts = body.split("---", 2)
        if len(parts) >= 3:
            raw = parts[1]
            body = parts[2].strip()
            for line in raw.splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    meta[k.strip()] = v.strip().strip('"').strip("'")
    skill_id = meta.get("id") or re.sub(r"[^a-z0-9_]+", "_", Path(file_name).stem.lower()).strip("_") or f"skill_{uuid.uuid4().hex[:8]}"
    return {
        "id": skill_id,
        "name": meta.get("name") or skill_id.replace("_", " ").title(),
        "category": meta.get("category", "geral"),
        "version": meta.get("version", "1.0"),
        "risk": meta.get("risk", "low"),
        "agent": meta.get("agent", ""),
        "file_name": file_name,
        "description": first_paragraph(body),
        "body": body,
        "meta": meta,
    }


def first_paragraph(body: str) -> str:
    cleaned = re.sub(r"#+\s*", "", body or "").strip()
    parts = [p.strip() for p in re.split(r"\n\s*\n", cleaned) if p.strip()]
    return (parts[0] if parts else "Skill sem descrição.")[:500]


def status() -> dict[str, Any]:
    _ensure()
    return {
        "ok": True,
        "name": "HAL Skills & Multi-Agent Center",
        "description": "Centro local-first de Skills em Markdown, hub local, agentes especializados, colaboração multiagente, sessions_spawn, geração de imagens e execução governada.",
        "config": _load(CONFIG_FILE, DEFAULT_CONFIG),
        "skills_count": len(list(SKILLS_DIR.glob("*.md"))),
        "hub_skills_count": len(list(HUB_DIR.glob("*.md"))),
        "agents_count": len(_load(AGENTS_FILE, {"agents": []}).get("agents", [])),
        "sessions_count": len(_load(SESSIONS_FILE, {"sessions": []}).get("sessions", [])),
        "tasks_count": len(_load(TASKS_FILE, {"tasks": []}).get("tasks", [])),
        "capabilities": [
            "Criar Skills locais em .md",
            "Instalar Skills de um hub local estilo ClawHub",
            "Executar Skills com entrada e contexto",
            "Criar agentes especializados por área",
            "Delegar tarefas para agentes",
            "Criar sessões paralelas estilo sessions_spawn",
            "Fazer agentes colaborarem entre si",
            "Gerar plano visual e prompt para imagens",
            "Preparar chamada para endpoint local de imagem quando configurado",
            "Gerenciar arquivos locais em workspace",
            "Criar plano de automação/código com sandbox obrigatório para execução real",
            "Auditar skills, agentes, sessões e tarefas",
            "Integrar com Conversa Natural V3 e Orchestrator",
        ],
    }


def list_skills(category: str = "", query: str = "") -> dict[str, Any]:
    _ensure()
    skills = []
    for path in sorted(SKILLS_DIR.glob("*.md")):
        skill = parse_skill_markdown(path.read_text(encoding="utf-8", errors="ignore"), path.name)
        if category and skill.get("category") != category:
            continue
        if query and query.lower() not in json.dumps(skill, ensure_ascii=False).lower():
            continue
        skill.pop("body", None)
        skills.append(skill)
    return {"ok": True, "skills": skills, "count": len(skills)}


def get_skill(skill_id: str) -> dict[str, Any]:
    _ensure()
    for path in SKILLS_DIR.glob("*.md"):
        skill = parse_skill_markdown(path.read_text(encoding="utf-8", errors="ignore"), path.name)
        if skill.get("id") == skill_id or path.stem == skill_id or path.name == skill_id:
            return {"ok": True, "skill": skill}
    return {"ok": False, "summary": "Skill não encontrada.", "skill_id": skill_id}


def create_skill(skill_id: str, name: str, category: str, body: str, risk: str = "low", agent: str = "") -> dict[str, Any]:
    _ensure()
    skill_id = re.sub(r"[^a-zA-Z0-9_\-]+", "_", skill_id or name or f"skill_{uuid.uuid4().hex[:8]}").strip("_").lower()
    if not skill_id:
        skill_id = f"skill_{uuid.uuid4().hex[:8]}"
    path = SKILLS_DIR / f"{skill_id}.md"
    skill_body = body or '# Objetivo\nDescreva a skill.'
    content = f"---\nid: {skill_id}\nname: {name or skill_id}\ncategory: {category or 'geral'}\nversion: 1.0\nrisk: {risk or 'low'}\nagent: {agent}\n---\n{skill_body}\n"
    path.write_text(content, encoding="utf-8")
    skill = parse_skill_markdown(content, path.name)
    _audit({"event": "create_skill", "skill_id": skill_id})
    return {"ok": True, "skill": {k: v for k, v in skill.items() if k != "body"}, "summary": "Skill criada/atualizada."}


def install_skill_from_text(file_name: str, content: str, install_to_hub: bool = False) -> dict[str, Any]:
    _ensure()
    safe = re.sub(r"[^a-zA-Z0-9_\-.]+", "_", file_name or f"skill_{uuid.uuid4().hex[:8]}.md")
    if not safe.endswith(".md"):
        safe += ".md"
    target = (HUB_DIR if install_to_hub else SKILLS_DIR) / safe
    target.write_text(content or "# Skill vazia", encoding="utf-8")
    skill = parse_skill_markdown(target.read_text(encoding="utf-8", errors="ignore"), target.name)
    _audit({"event": "install_skill_from_text", "skill_id": skill["id"], "to_hub": install_to_hub})
    return {"ok": True, "skill": {k: v for k, v in skill.items() if k != "body"}, "path": str(target), "summary": "Skill instalada."}


def list_hub(query: str = "") -> dict[str, Any]:
    _ensure()
    skills = []
    for path in sorted(HUB_DIR.glob("*.md")):
        skill = parse_skill_markdown(path.read_text(encoding="utf-8", errors="ignore"), path.name)
        if query and query.lower() not in json.dumps(skill, ensure_ascii=False).lower():
            continue
        skill.pop("body", None)
        skills.append(skill)
    return {"ok": True, "hub": skills, "count": len(skills)}


def install_from_hub(skill_id: str) -> dict[str, Any]:
    _ensure()
    for path in HUB_DIR.glob("*.md"):
        skill = parse_skill_markdown(path.read_text(encoding="utf-8", errors="ignore"), path.name)
        if skill.get("id") == skill_id or path.stem == skill_id or path.name == skill_id:
            dest = SKILLS_DIR / path.name
            shutil.copyfile(path, dest)
            _audit({"event": "install_from_hub", "skill_id": skill["id"]})
            skill.pop("body", None)
            return {"ok": True, "skill": skill, "summary": "Skill instalada do hub local."}
    return {"ok": False, "summary": "Skill não encontrada no hub local."}


def is_sensitive(text: str) -> bool:
    low = (text or "").lower()
    return any(k in low for k in SENSITIVE_KEYWORDS)


def run_skill(skill_id: str, input_text: str, context: dict[str, Any] | None = None, approved: bool = False) -> dict[str, Any]:
    found = get_skill(skill_id)
    if not found.get("ok"):
        return found
    skill = found["skill"]
    risk = skill.get("risk", "low")
    sensitive = risk in {"high", "critical"} or is_sensitive(input_text)
    if sensitive and not approved:
        result = {
            "ok": True,
            "status": "waiting_approval",
            "summary": "A skill parece envolver ação sensível. Preparei o plano, mas preciso de aprovação antes de executar.",
            "plan": build_skill_plan(skill, input_text, context or {}),
            "requires_approval": True,
        }
    else:
        result = {
            "ok": True,
            "status": "prepared",
            "summary": generate_skill_answer(skill, input_text, context or {}),
            "plan": build_skill_plan(skill, input_text, context or {}),
            "requires_approval": False,
        }
    run = {"id": f"run_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}", "skill_id": skill["id"], "input": input_text, "context": context or {}, "approved": approved, "result": result, "created_at": _now()}
    data = _load(RUNS_FILE, {"runs": []})
    data.setdefault("runs", []).insert(0, run)
    data["runs"] = data["runs"][:500]
    _save(RUNS_FILE, data)
    _audit({"event": "run_skill", "skill_id": skill["id"], "run_id": run["id"], "status": result["status"]})
    return {"ok": True, "run": run, **result}


def build_skill_plan(skill: dict[str, Any], input_text: str, context: dict[str, Any]) -> list[dict[str, Any]]:
    category = skill.get("category", "geral")
    steps = [
        {"id": "read_skill", "label": f"Ler instruções da skill {skill.get('name')}", "status": "done"},
        {"id": "understand_request", "label": "Entender pedido e contexto do usuário", "status": "pending"},
    ]
    if category in {"dados", "financeiro", "operacoes"}:
        steps.append({"id": "check_real_source", "label": "Verificar fonte real de dados antes de afirmar números", "status": "pending"})
    if category == "imagem":
        steps.append({"id": "create_visual_prompt", "label": "Criar briefing e prompt visual", "status": "pending"})
    if category == "automacao":
        steps.append({"id": "define_trigger_actions", "label": "Definir gatilho, ações, credenciais e aprovações", "status": "pending"})
    steps.append({"id": "produce_answer", "label": "Responder de forma natural e acionável", "status": "pending"})
    return steps


def generate_skill_answer(skill: dict[str, Any], input_text: str, context: dict[str, Any]) -> str:
    category = skill.get("category", "geral")
    if category == "educacao":
        return "Vou explicar de forma simples, por etapas e adaptada ao nível da pessoa. Se ela não entender, eu mudo o exemplo em vez de repetir a mesma coisa."
    if category == "financeiro":
        return "Vou analisar os indicadores executivos usando fonte real ou snapshot autorizado. Se faltar ERP, banco, Power BI ou DRE, eu pergunto a fonte antes de calcular."
    if category == "dados":
        return "Vou planejar a consulta em SQL/NoSQL com segurança, perguntando conexão, tabelas/collections, filtros, período e formato de saída."
    if category == "imagem":
        return create_image_brief(input_text, context).get("answer", "Briefing visual preparado.")
    if category == "automacao":
        return "Vou transformar o pedido em workflow: gatilho, sistemas envolvidos, credenciais necessárias, etapas e aprovações."
    return f"Skill '{skill.get('name')}' preparada para executar o pedido com segurança e resposta natural."


def list_agents() -> dict[str, Any]:
    agents = _load(AGENTS_FILE, {"agents": DEFAULT_AGENTS}).get("agents", [])
    return {"ok": True, "agents": agents, "count": len(agents)}


def register_agent(name: str, role: str, skills: list[str] | None = None, enabled: bool = True) -> dict[str, Any]:
    agent = {"id": f"agent_{re.sub(r'[^a-z0-9]+','_', (name or uuid.uuid4().hex[:6]).lower()).strip('_')}", "name": name, "role": role, "skills": skills or [], "enabled": enabled, "created_at": _now()}
    data = _load(AGENTS_FILE, {"agents": []})
    data.setdefault("agents", []).insert(0, agent)
    _save(AGENTS_FILE, data)
    _audit({"event": "register_agent", "agent_id": agent["id"]})
    return {"ok": True, "agent": agent, "summary": "Agente registrado."}


def match_agents(message: str) -> list[dict[str, Any]]:
    low = (message or "").lower()
    agents = _load(AGENTS_FILE, {"agents": DEFAULT_AGENTS}).get("agents", [])
    matched = []
    for agent in agents:
        blob = json.dumps(agent, ensure_ascii=False).lower()
        score = 0
        for word in set(re.findall(r"[a-zA-ZÀ-ÿ0-9]{4,}", low)):
            if word in blob:
                score += 1
        if score:
            a = dict(agent)
            a["score"] = score
            matched.append(a)
    if not matched:
        matched = [a for a in agents if a.get("id") in {"agent_atendimento", "agent_dados"}]
    return sorted(matched, key=lambda x: x.get("score", 0), reverse=True)[:5]


def spawn_session(objective: str, agents: list[str] | None = None, parent_session_id: str = "", context: dict[str, Any] | None = None) -> dict[str, Any]:
    selected_agents = agents or [a["id"] for a in match_agents(objective)[:3]]
    session = {
        "id": f"sess_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "parent_session_id": parent_session_id,
        "objective": objective,
        "agents": selected_agents,
        "context": context or {},
        "status": "spawned",
        "created_at": _now(),
        "events": [{"ts": _now(), "type": "spawn", "message": "Sessão multiagente criada."}],
    }
    data = _load(SESSIONS_FILE, {"sessions": []})
    data.setdefault("sessions", []).insert(0, session)
    _save(SESSIONS_FILE, data)
    _audit({"event": "spawn_session", "session_id": session["id"], "agents": selected_agents})
    return {"ok": True, "session": session, "summary": "Sessão paralela multiagente criada."}


def list_sessions(limit: int = 100) -> dict[str, Any]:
    sessions = _load(SESSIONS_FILE, {"sessions": []}).get("sessions", [])
    return {"ok": True, "sessions": sessions[:max(1, min(limit, 500))], "count": len(sessions)}


def delegate_task(objective: str, agent_id: str = "", skill_id: str = "", session_id: str = "", approved: bool = False) -> dict[str, Any]:
    if not agent_id:
        matches = match_agents(objective)
        agent_id = matches[0]["id"] if matches else "agent_atendimento"
    task = {
        "id": f"task_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}",
        "objective": objective,
        "agent_id": agent_id,
        "skill_id": skill_id,
        "session_id": session_id,
        "approved": approved,
        "status": "planned",
        "created_at": _now(),
        "plan": [
            {"id": "agent_review", "label": f"Agente {agent_id} analisa o pedido", "status": "pending"},
            {"id": "skill_select", "label": "Selecionar skill necessária", "status": "pending"},
            {"id": "execute_or_prepare", "label": "Executar ou preparar com aprovação", "status": "pending"},
            {"id": "natural_response", "label": "Responder ao usuário de forma natural", "status": "pending"},
        ],
    }
    if skill_id:
        task["skill_result"] = run_skill(skill_id, objective, {"agent_id": agent_id, "session_id": session_id}, approved=approved)
    data = _load(TASKS_FILE, {"tasks": []})
    data.setdefault("tasks", []).insert(0, task)
    data["tasks"] = data["tasks"][:1000]
    _save(TASKS_FILE, data)
    _audit({"event": "delegate_task", "task_id": task["id"], "agent_id": agent_id})
    return {"ok": True, "task": task, "summary": f"Tarefa delegada para {agent_id}."}


def list_tasks(status_filter: str = "", limit: int = 100) -> dict[str, Any]:
    tasks = _load(TASKS_FILE, {"tasks": []}).get("tasks", [])
    if status_filter:
        tasks = [t for t in tasks if t.get("status") == status_filter]
    return {"ok": True, "tasks": tasks[:max(1, min(limit, 500))], "count": len(tasks)}


def collaborate(objective: str, agents: list[str] | None = None, approved: bool = False) -> dict[str, Any]:
    sess = spawn_session(objective, agents=agents)
    selected = sess["session"]["agents"]
    tasks = [delegate_task(objective, agent_id=a, session_id=sess["session"]["id"], approved=approved).get("task") for a in selected]
    synthesis = synthesize_collaboration(objective, selected, tasks)
    _audit({"event": "collaborate", "session_id": sess["session"]["id"], "agents": selected})
    return {"ok": True, "session": sess["session"], "tasks": tasks, "answer": synthesis, "summary": "Colaboração multiagente preparada."}


def synthesize_collaboration(objective: str, agents: list[str], tasks: list[dict[str, Any]]) -> str:
    agent_names = []
    all_agents = {a["id"]: a for a in _load(AGENTS_FILE, {"agents": DEFAULT_AGENTS}).get("agents", [])}
    for a in agents:
        agent_names.append(all_agents.get(a, {}).get("name", a))
    return (
        f"Criei uma colaboração multiagente para: {objective}\n\n"
        f"Agentes envolvidos: {', '.join(agent_names)}.\n\n"
        "Cada agente recebeu uma parte do problema. O próximo passo é consolidar as respostas, validar dados reais quando houver números e devolver uma recomendação única, clara e executável."
    )


def create_image_brief(prompt: str, context: dict[str, Any] | None = None, style: str = "futurista profissional", size: str = "1024x1024") -> dict[str, Any]:
    _ensure()
    brief_id = f"img_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    brief = {
        "id": brief_id,
        "prompt_original": prompt,
        "prompt_final": f"{prompt}. Estilo: {style}. Alta qualidade, composição limpa, visual profissional, adequado para uso corporativo AJDS/HAL.",
        "negative_prompt": "texto distorcido, baixa resolução, ruído visual, marca protegida, logotipo não autorizado, rosto real sem permissão",
        "size": size,
        "mode": _load(CONFIG_FILE, DEFAULT_CONFIG).get("image_generation_mode", "prompt_or_local_endpoint"),
        "created_at": _now(),
    }
    endpoint = _load(CONFIG_FILE, DEFAULT_CONFIG).get("image_endpoint", "")
    if endpoint:
        brief["endpoint_status"] = "configured"
        brief["note"] = "Endpoint local configurado; integração real depende do gerador instalado no ambiente do cliente."
    else:
        brief["endpoint_status"] = "not_configured"
        brief["note"] = "Prompt pronto. Configure um endpoint local de imagem para gerar automaticamente."
    (IMAGE_DIR / f"{brief_id}.json").write_text(json.dumps(brief, ensure_ascii=False, indent=2), encoding="utf-8")
    answer = "Briefing visual criado. " + brief["note"] + "\n\nPrompt:\n" + brief["prompt_final"]
    return {"ok": True, "brief": brief, "answer": answer}


def list_image_briefs(limit: int = 100) -> dict[str, Any]:
    _ensure()
    items = []
    for p in sorted(IMAGE_DIR.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True)[:max(1, min(limit, 500))]:
        try:
            items.append(json.loads(p.read_text(encoding="utf-8-sig")))
        except Exception:
            pass
    return {"ok": True, "briefs": items, "count": len(items)}


def update_config(changes: dict[str, Any]) -> dict[str, Any]:
    cfg = _load(CONFIG_FILE, DEFAULT_CONFIG)
    for k, v in (changes or {}).items():
        cfg[k] = v
    _save(CONFIG_FILE, cfg)
    _audit({"event": "update_config"})
    return {"ok": True, "config": cfg, "summary": "Configuração de Skills & Multi-Agent atualizada."}


def guided_answer(message: str, approved: bool = False) -> dict[str, Any]:
    low = (message or "").lower()
    if any(x in low for x in ["gerar imagem", "criar imagem", "imagem", "desenhe", "visual", "figura"]):
        return create_image_brief(message)
    if any(x in low for x in ["multiagente", "multi agente", "agentes", "colabor", "sessions_spawn", "spawn"]):
        return collaborate(message, approved=approved)
    if any(x in low for x in ["skill", "clawhub", "hub"]):
        return {"ok": True, "answer": answer_for_skills(message), "skills": list_skills().get("skills", []), "hub": list_hub().get("hub", [])}
    return {"ok": True, "answer": answer_for_skills(message), "matched_agents": match_agents(message)}


def seed_demo() -> dict[str, Any]:
    _ensure()
    sess = spawn_session("Criar diagnóstico completo da empresa com agentes financeiro, dados, operações e automação.", agents=["agent_financeiro", "agent_dados", "agent_operacoes", "agent_automacao"])
    collab = collaborate("Analisar saúde financeira, dados de ERP, operação e preparar plano de ação para diretoria.", agents=["agent_financeiro", "agent_dados", "agent_operacoes"], approved=False)
    img = create_image_brief("Painel futurista do HAL com agentes colaborando e indicadores executivos")
    return {"ok": True, "session": sess.get("session"), "collaboration": collab, "image_brief": img.get("brief"), "summary": "Demo de Skills, agentes, sessions_spawn e imagem criada."}


def answer_for_skills(message: str = "") -> str:
    return (
        "Vou usar o HAL Skills & Multi-Agent Center. Ele permite criar e instalar Skills em Markdown, manter um hub local estilo ClawHub, "
        "delegar tarefas para agentes especializados, abrir sessões paralelas estilo sessions_spawn, fazer agentes colaborarem e preparar geração de imagens. "
        "Tudo segue local-first, com auditoria e aprovação para ações sensíveis."
    )
