from __future__ import annotations

import base64
import json
import mimetypes
import time
import uuid
from pathlib import Path
from typing import Any

from PIL import Image

from app.core.config import root_dir, load_config
from app.services.model_manager import OllamaClient, choose_model

CAPTURES = root_dir() / "data" / "captures"


def _ensure() -> None:
    CAPTURES.mkdir(parents=True, exist_ok=True)


def save_image(data: bytes, filename: str = "capture.png", source: str = "browser") -> dict[str, Any]:
    _ensure()
    suffix = Path(filename or "capture.png").suffix or ".png"
    image_id = f"img_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    path = CAPTURES / f"{image_id}{suffix}"
    path.write_bytes(data)
    meta = {
        "ok": True,
        "image_id": image_id,
        "path": str(path),
        "relative_path": str(path.relative_to(root_dir())),
        "source": source,
        "mime": mimetypes.guess_type(str(path))[0] or "application/octet-stream",
        "bytes": len(data),
        "info": image_info(path),
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    (CAPTURES / f"{image_id}.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return meta


def image_info(path: Path) -> dict[str, Any]:
    try:
        with Image.open(path) as img:
            return {"width": img.width, "height": img.height, "format": img.format}
    except Exception as exc:
        return {"error": str(exc)}


def analyze(image_path: str, question: str = "") -> dict[str, Any]:
    cfg = load_config()
    ollama_enabled = bool(cfg.get("ollama", {}).get("enabled"))
    path = Path(image_path)
    fallback = f"Imagem recebida e salva localmente ({path.name}). Para análise visual detalhada, mantenha Ollama ativo com modelo multimodal."
    if not ollama_enabled:
        return {"ok": True, "mode": "fallback", "analysis": fallback}
    try:
        image_b64 = base64.b64encode(path.read_bytes()).decode("ascii")
        choice = choose_model(intent="vision", has_image=True)
        prompt = question or "Descreva a tela/imagem em português e destaque o que devo fazer."
        client = OllamaClient()
        res = client.generate_vision(prompt, image_b64, choice.name)
        if res.get("ok") and res.get("content"):
            return {"ok": True, "mode": "ollama", "model": choice.name, "analysis": res["content"]}
        # fallback model
        fallback_model = cfg.get("ollama", {}).get("vision_fallback_model", "llava:latest")
        res2 = client.generate_vision(prompt, image_b64, fallback_model)
        if res2.get("ok") and res2.get("content"):
            return {"ok": True, "mode": "ollama_fallback", "model": fallback_model, "analysis": res2["content"]}
        return {"ok": True, "mode": "fallback_after_error", "analysis": fallback, "error": res}
    except Exception as exc:
        return {"ok": True, "mode": "fallback_after_exception", "analysis": fallback, "error": str(exc)}
