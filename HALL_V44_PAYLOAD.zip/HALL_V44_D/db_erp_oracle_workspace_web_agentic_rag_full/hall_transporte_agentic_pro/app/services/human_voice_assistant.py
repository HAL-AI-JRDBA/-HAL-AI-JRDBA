from __future__ import annotations

import json
import time
import uuid
import re
from pathlib import Path
from typing import Any

from app.core.config import root_dir
from app.tools.business_domains import detect_domain
from app.tools.database_platforms import detect_database


DATA_DIR = root_dir() / "data" / "human_voice_assistant"
VOICE_PROFILES_FILE = DATA_DIR / "voice_profiles.json"
PERSONAS_FILE = DATA_DIR / "personas.json"
SESSIONS_FILE = DATA_DIR / "sessions.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"
VOICE_SAMPLES_DIR = DATA_DIR / "voice_samples"


VOICE_ENGINES: dict[str, dict[str, Any]] = {
    "browser_speech": {
        "label": "Browser Speech API",
        "status": "ready",
        "type": "tts_browser",
        "quality": "média",
        "local": True,
        "notes": "Funciona no navegador, mas depende das vozes instaladas no Windows/Chrome/Edge.",
    },
    "piper": {
        "label": "Piper TTS Local",
        "status": "adapter_ready",
        "type": "tts_local",
        "quality": "boa",
        "local": True,
        "notes": "Leve, rápido, indicado para CPU. Requer modelo pt-BR instalado.",
    },
    "coqui_xtts": {
        "label": "Coqui XTTS Local",
        "status": "adapter_ready",
        "type": "tts_clone_local",
        "quality": "muito boa",
        "local": True,
        "notes": "Permite voz customizada com amostra autorizada. Requer mais recursos.",
    },
    "f5_tts": {
        "label": "F5-TTS Local",
        "status": "adapter_ready",
        "type": "tts_clone_local",
        "quality": "muito boa",
        "local": True,
        "notes": "Opção moderna para voz natural/clonagem autorizada. Melhor com GPU.",
    },
    "openvoice": {
        "label": "OpenVoice Local",
        "status": "adapter_ready",
        "type": "voice_conversion_local",
        "quality": "muito boa",
        "local": True,
        "notes": "Conversão/clonagem de timbre com amostras autorizadas.",
    },
    "edge_neural_optional": {
        "label": "Microsoft Edge Neural Voice opcional",
        "status": "optional_cloud_or_system",
        "type": "tts_optional",
        "quality": "alta",
        "local": False,
        "notes": "Pode soar mais natural, mas não segue a filosofia 100% local se usar serviço externo.",
    },
}

STT_ENGINES: dict[str, dict[str, Any]] = {
    "browser_speech_recognition": {
        "label": "Browser Speech Recognition",
        "status": "ready_when_browser_supports",
        "quality": "média",
        "local": False,
        "notes": "Rápido para protótipo; depende do navegador.",
    },
    "faster_whisper": {
        "label": "faster-whisper Local",
        "status": "adapter_ready",
        "quality": "alta",
        "local": True,
        "notes": "Recomendado para entender português, pausas, ruído e fala natural. CPU/GPU.",
    },
    "whisper_cpp": {
        "label": "whisper.cpp Local",
        "status": "adapter_ready",
        "quality": "boa",
        "local": True,
        "notes": "Leve e adequado para CPU.",
    },
}

AVATAR_THEMES: dict[str, dict[str, Any]] = {
    "hall_orb_magenta": {
        "label": "HAL Orb Magenta",
        "description": "Avatar futurístico central com esfera, pulsação e equalizador.",
        "style": "futuristic_orb",
        "color": "#ff0060",
    },
    "hall_orb_blue": {
        "label": "HAL Orb Azul",
        "description": "Avatar futurístico com orb azul/ciano para modo corporativo.",
        "style": "futuristic_orb",
        "color": "#3b82f6",
    },
    "executive_holo": {
        "label": "Holograma Executivo",
        "description": "Visual mais sério para reuniões, diretoria e clientes.",
        "style": "hologram",
        "color": "#17ffad",
    },
}

PERSONA_TEMPLATES: dict[str, dict[str, Any]] = {
    "personal_assistant": {
        "label": "Assistente Pessoal 24x7",
        "mission": "Ajudar o usuário no dia a dia, lembrar contexto, organizar prioridades, explicar com clareza e agir com educação.",
        "tone": "humilde, direto, claro, acolhedor, paulista/neutro brasileiro",
        "greeting": "Bom dia. Eu sou o HAL. Estou à disposição. O que você gostaria de fazer agora?",
        "examples": [
            "Organize minhas prioridades de hoje.",
            "Explique esse relatório de forma simples.",
            "Crie um lembrete operacional para acompanhamento manual.",
        ],
    },
    "enterprise_employee": {
        "label": "Funcionário Especialista 24x7",
        "mission": "Atuar como colaborador virtual especializado por área: financeiro, TI, dados, atendimento, operações, vendas ou gestão.",
        "tone": "profissional, calmo, objetivo, com perguntas de confirmação antes de agir",
        "greeting": "Olá. Estou pronto para atuar na área configurada. Me diga o objetivo e eu sigo o procedimento correto.",
        "examples": [
            "Analise contas a receber vencidas.",
            "Verifique alertas do Zabbix.",
            "Gere relatório de vendas e encaminhe para aprovação.",
        ],
    },
    "support_agent": {
        "label": "Atendente Humanizado",
        "mission": "Atender clientes com cordialidade, classificar intenção e escalar casos sensíveis.",
        "tone": "educado, paciente, acolhedor e claro",
        "greeting": "Olá, tudo bem? Sou o HAL. Pode me explicar o que aconteceu que eu vou te ajudar da melhor forma possível.",
        "examples": [
            "Atender reclamação de cliente.",
            "Explicar status de pedido.",
            "Abrir solicitação para equipe humana.",
        ],
    },
    "executive_agent": {
        "label": "Assessor Executivo",
        "mission": "Apoiar diretoria com indicadores, sínteses, priorização, riscos e recomendações.",
        "tone": "executivo, objetivo, seguro e elegante",
        "greeting": "Bom dia. Já posso preparar seu briefing executivo. O que deseja priorizar?",
        "examples": [
            "Prepare briefing diário.",
            "Liste riscos críticos da operação.",
            "Compare indicadores de ontem com hoje.",
        ],
    },
}

DEPARTMENT_ROLES: dict[str, dict[str, Any]] = {
    "financeiro": {
        "label": "Funcionário Financeiro/Contábil",
        "skills": ["CRC/CPG", "fluxo de caixa", "DRE", "inadimplência", "conciliação", "SQL/BI"],
        "requires_approval_for": ["cobrança", "envio externo", "alteração de dados", "baixa/lançamento"],
    },
    "ti_dba": {
        "label": "Funcionário TI/DBA",
        "skills": ["diagnóstico", "SQL", "DBA", "monitoramento", "logs", "performance", "incidentes"],
        "requires_approval_for": ["alterar produção", "executar script", "reiniciar serviço", "deploy"],
    },
    "vendas": {
        "label": "Funcionário Vendas/SDR",
        "skills": ["qualificação", "proposta", "follow-up", "CRM", "atendimento B2B"],
        "requires_approval_for": ["desconto", "proposta final", "mensagem externa em massa"],
    },
    "atendimento": {
        "label": "Funcionário Atendimento",
        "skills": ["triagem", "resposta ao cliente", "base de conhecimento", "escalação"],
        "requires_approval_for": ["casos sensíveis", "reembolso", "promessa comercial"],
    },
    "operacoes": {
        "label": "Funcionário Operações",
        "skills": ["logística", "transporte", "estoque", "monitoramento", "priorização"],
        "requires_approval_for": ["intervenção operacional", "mudança em escala/rota", "comunicação crítica"],
    },
    "dados_bi": {
        "label": "Funcionário Dados/BI",
        "skills": ["SQL", "NoSQL", "Power BI", "dashboards", "indicadores", "qualidade de dados"],
        "requires_approval_for": ["exportação de dados", "dados pessoais", "consulta pesada em produção"],
    },
}


def _ensure() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    VOICE_SAMPLES_DIR.mkdir(parents=True, exist_ok=True)
    if not VOICE_PROFILES_FILE.exists():
        VOICE_PROFILES_FILE.write_text(json.dumps(default_voice_profiles(), ensure_ascii=False, indent=2), encoding="utf-8")
    if not PERSONAS_FILE.exists():
        PERSONAS_FILE.write_text(json.dumps(default_personas(), ensure_ascii=False, indent=2), encoding="utf-8")
    if not SESSIONS_FILE.exists():
        SESSIONS_FILE.write_text(json.dumps({"sessions": []}, ensure_ascii=False, indent=2), encoding="utf-8")


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _load(path: Path, default: dict[str, Any]) -> dict[str, Any]:
    _ensure()
    try:
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else default
    except Exception:
        return default


def _save(path: Path, data: dict[str, Any]) -> None:
    _ensure()
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _audit(event: dict[str, Any]) -> None:
    _ensure()
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": _now(), **event}, ensure_ascii=False) + "\n")


def default_voice_profiles() -> dict[str, Any]:
    return {
        "profiles": [
            {
                "id": "ptbr_paulista_natural",
                "label": "Português BR Paulista Natural",
                "engine": "piper",
                "locale": "pt-BR",
                "accent": "paulista/neutro",
                "speed": 0.88,
                "pitch": -1,
                "pause_ms": 650,
                "interruption_enabled": True,
                "barge_in_enabled": True,
                "noise_tolerance": "medium",
                "human_style": {
                    "short_greeting": True,
                    "ask_clarifying_questions": True,
                    "wait_for_silence_before_answer": True,
                    "do_not_interrupt_user": True,
                    "humble_tone": True,
                    "clear_objective_explanations": True,
                },
                "sample_required": False,
                "status": "configured",
            },
            {
                "id": "aprigiovoice_authorized",
                "label": "Voz do Aprigio / Usuário Autorizado",
                "engine": "coqui_xtts_or_f5_tts",
                "locale": "pt-BR",
                "accent": "paulista",
                "speed": 0.86,
                "pitch": 0,
                "pause_ms": 700,
                "interruption_enabled": True,
                "barge_in_enabled": True,
                "noise_tolerance": "high",
                "human_style": {
                    "short_greeting": True,
                    "ask_clarifying_questions": True,
                    "wait_for_silence_before_answer": True,
                    "do_not_interrupt_user": True,
                    "humble_tone": True,
                    "clear_objective_explanations": True,
                },
                "sample_required": True,
                "minimum_sample_minutes": 3,
                "recommended_sample_minutes": 5,
                "status": "waiting_user_audio_sample",
            },
        ],
        "active_profile": "ptbr_paulista_natural",
    }


def default_personas() -> dict[str, Any]:
    return {
        "personas": [
            {"id": key, **value} for key, value in PERSONA_TEMPLATES.items()
        ],
        "department_roles": [
            {"id": key, **value} for key, value in DEPARTMENT_ROLES.items()
        ],
        "active_persona": "personal_assistant",
        "active_department_role": "",
    }


def status() -> dict[str, Any]:
    vp = _load(VOICE_PROFILES_FILE, default_voice_profiles())
    ps = _load(PERSONAS_FILE, default_personas())
    sessions = _load(SESSIONS_FILE, {"sessions": []}).get("sessions", [])
    return {
        "ok": True,
        "name": "HAL Human Voice Assistant 24x7",
        "description": "Camada de assistente humano-natural com avatar futurístico, voz pt-BR, modo assistente pessoal e funcionário especialista 24x7.",
        "active_voice_profile": vp.get("active_profile"),
        "active_persona": ps.get("active_persona"),
        "active_department_role": ps.get("active_department_role"),
        "sessions_count": len(sessions),
        "voice_engines": len(VOICE_ENGINES),
        "stt_engines": len(STT_ENGINES),
        "avatar_themes": len(AVATAR_THEMES),
        "capabilities": [
            "Avatar futurístico fixo no estilo assistente cinematográfico",
            "Conversa natural com saudação por horário",
            "Espera o usuário terminar a fala antes de responder",
            "Barge-in: usuário pode interromper a resposta",
            "Modo assistente pessoal 24x7",
            "Modo funcionário especialista por área 24x7",
            "Perfis de voz: pt-BR paulista/neutro e voz própria autorizada",
            "Preparado para Piper, Coqui XTTS, F5-TTS, OpenVoice, faster-whisper e whisper.cpp",
            "Roteamento para ferramentas corretas pelo HAL",
            "Perguntas de esclarecimento antes de ações críticas",
            "Aprovação humana para ações sensíveis",
        ],
    }


def voice_profiles() -> dict[str, Any]:
    return {"ok": True, **_load(VOICE_PROFILES_FILE, default_voice_profiles()), "engines": [{"key": k, **v} for k, v in VOICE_ENGINES.items()], "stt": [{"key": k, **v} for k, v in STT_ENGINES.items()]}


def personas() -> dict[str, Any]:
    return {"ok": True, **_load(PERSONAS_FILE, default_personas()), "templates": [{"key": k, **v} for k, v in PERSONA_TEMPLATES.items()], "roles": [{"key": k, **v} for k, v in DEPARTMENT_ROLES.items()]}


def avatar_themes() -> dict[str, Any]:
    return {"ok": True, "themes": [{"key": k, **v} for k, v in AVATAR_THEMES.items()]}


def set_voice_profile(profile_id: str) -> dict[str, Any]:
    data = _load(VOICE_PROFILES_FILE, default_voice_profiles())
    ids = [p["id"] for p in data.get("profiles", [])]
    if profile_id not in ids:
        return {"ok": False, "summary": "Perfil de voz não encontrado.", "available": ids}
    data["active_profile"] = profile_id
    _save(VOICE_PROFILES_FILE, data)
    _audit({"event": "set_voice_profile", "profile_id": profile_id})
    return {"ok": True, "active_profile": profile_id, "summary": "Perfil de voz atualizado."}


def set_persona(persona_id: str = "", department_role: str = "") -> dict[str, Any]:
    data = _load(PERSONAS_FILE, default_personas())
    persona_ids = [p["id"] for p in data.get("personas", [])]
    role_ids = [r["id"] for r in data.get("department_roles", [])]
    if persona_id and persona_id not in persona_ids:
        return {"ok": False, "summary": "Persona não encontrada.", "available_personas": persona_ids}
    if department_role and department_role not in role_ids:
        return {"ok": False, "summary": "Área/função não encontrada.", "available_roles": role_ids}
    if persona_id:
        data["active_persona"] = persona_id
    if department_role:
        data["active_department_role"] = department_role
    _save(PERSONAS_FILE, data)
    _audit({"event": "set_persona", "persona_id": persona_id, "department_role": department_role})
    return {"ok": True, "active_persona": data.get("active_persona"), "active_department_role": data.get("active_department_role"), "summary": "Persona atualizada."}


def greeting(now_hour: int | None = None, name: str = "") -> dict[str, Any]:
    if now_hour is None:
        now_hour = int(time.strftime("%H"))
    if 5 <= now_hour < 12:
        base = "Bom dia"
    elif 12 <= now_hour < 18:
        base = "Boa tarde"
    else:
        base = "Boa noite"
    who = f", {name}" if name else ""
    text = f"{base}{who}. Eu sou o HAL. Estou à disposição. O que você gostaria de fazer agora?"
    return {"ok": True, "greeting": text, "hour": now_hour}


def conversation_policy() -> dict[str, Any]:
    return {
        "ok": True,
        "turn_taking": {
            "wait_for_user_silence_ms": 1200,
            "min_final_silence_ms": 900,
            "max_initial_silence_ms": 5000,
            "do_not_answer_while_user_is_speaking": True,
            "allow_barge_in": True,
            "interrupt_assistant_when_user_speaks": True,
        },
        "speech_quality": {
            "target_locale": "pt-BR",
            "accent": "paulista/neutro",
            "speed": "lento e audível",
            "style": "natural, humano, humilde, claro e profissional",
            "avoid": ["voz metálica", "sotaque estrangeiro", "fala acelerada", "resposta antes do usuário terminar"],
        },
        "clarification": {
            "ask_when_missing_context": True,
            "ask_before_risky_action": True,
            "confirm_tool_choice_when_confidence_low": True,
        },
        "safety": {
            "human_approval_for_external_messages": True,
            "human_approval_for_database_write": True,
            "human_approval_for_desktop_actions": True,
            "audit_all_actions": True,
        },
    }


def create_session(user_name: str = "", mode: str = "personal_assistant", department_role: str = "", channel: str = "web") -> dict[str, Any]:
    data = _load(SESSIONS_FILE, {"sessions": []})
    sid = f"voice_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    session = {
        "id": sid,
        "user_name": user_name,
        "mode": mode,
        "department_role": department_role,
        "channel": channel,
        "status": "active",
        "created_at": _now(),
        "updated_at": _now(),
        "messages": [],
        "last_intent": "",
    }
    data.setdefault("sessions", []).insert(0, session)
    _save(SESSIONS_FILE, data)
    _audit({"event": "create_session", "session_id": sid, "mode": mode, "department_role": department_role})
    return {"ok": True, "session": session, "greeting": greeting(name=user_name).get("greeting")}


def list_sessions(limit: int = 50) -> dict[str, Any]:
    data = _load(SESSIONS_FILE, {"sessions": []})
    return {"ok": True, "sessions": data.get("sessions", [])[:max(1, min(limit, 200))], "count": len(data.get("sessions", []))}


def detect_human_intent(message: str) -> dict[str, Any]:
    text = (message or "").lower()
    intent = "general"
    if any(x in text for x in ["bom dia", "boa tarde", "boa noite", "oi", "olá", "ola", "tudo bem"]):
        intent = "greeting"
    elif any(x in text for x in ["organize", "agenda", "prioridade", "minhas tarefas", "assistente pessoal"]):
        intent = "personal_assistant"
    elif any(x in text for x in ["trabalhe como", "funcionário", "funcionario", "especialista", "24x7", "plantão", "plantao"]):
        intent = "employee_mode"
    elif any(x in text for x in ["financeiro", "contábil", "contabil", "contas a receber", "cobrança"]):
        intent = "financeiro"
    elif any(x in text for x in ["zabbix", "grafana", "banco lento", "oracle", "sql server", "dba", "incidente"]):
        intent = "ti_dba"
    elif any(x in text for x in ["cliente", "atendimento", "reclamação", "reclamacao", "whatsapp"]):
        intent = "atendimento"
    elif any(x in text for x in ["vendas", "lead", "sdr", "proposta"]):
        intent = "vendas"
    elif any(x in text for x in ["dashboard", "power bi", "indicador", "mongo", "mongodb", "dados"]):
        intent = "dados_bi"
    return {"ok": True, "intent": intent, "confidence": 0.86 if intent != "general" else 0.55}


def human_answer(message: str, user_name: str = "", department_role: str = "") -> dict[str, Any]:
    intent = detect_human_intent(message)["intent"]
    seg = detect_domain(message)
    db = detect_database(message)
    if intent == "greeting":
        return greeting(name=user_name)
    if intent == "employee_mode":
        text = (
            "Perfeito. Eu posso atuar como um funcionário especialista 24x7. "
            "Me diga a área desejada — financeiro, TI/DBA, dados/BI, atendimento, vendas ou operações — "
            "e eu sigo o procedimento dessa área, sempre pedindo aprovação antes de qualquer ação sensível."
        )
    elif intent in DEPARTMENT_ROLES:
        role = DEPARTMENT_ROLES[intent]
        text = (
            f"Entendi. Vou atuar como {role['label']}. "
            f"Tenho habilidades em {', '.join(role['skills'])}. "
            f"Antes de executar ações sensíveis como {', '.join(role['requires_approval_for'])}, vou pedir aprovação humana. "
            "Agora me diga o objetivo específico ou confirme se devo montar um job no Agent Runtime."
        )
    elif intent == "personal_assistant":
        text = (
            "Claro. Vou atuar como seu assistente pessoal. Posso organizar prioridades, transformar pedidos em tarefas, "
            "consultar documentos, acionar ferramentas corretas e acompanhar pendências. "
            "Para começar, me diga qual resultado você quer obter primeiro."
        )
    else:
        text = (
            f"Entendi seu pedido. Detectei o segmento {seg['label']} e o contexto de banco {db['label']}. "
            "Vou escolher a ferramenta correta conforme a intenção: Agent Runtime para tarefas longas, Business Teams para equipes de agentes, "
            "SaaS Builder para apps/sites, SQL Copilot para consultas, RAG para documentos, Power BI/Zabbix/Grafana para indicadores e monitoramento. "
            "Se faltar algum detalhe, eu pergunto antes de executar."
        )
    return {"ok": True, "answer": text, "intent": intent, "segment": seg, "database": db}


def voice_clone_requirements() -> dict[str, Any]:
    return {
        "ok": True,
        "important": "A voz real do usuário só deve ser usada com autorização explícita e amostra de áudio enviada pelo próprio usuário.",
        "minimum_audio": "3 minutos",
        "recommended_audio": "5 a 10 minutos",
        "formats": ["wav", "mp3", "m4a"],
        "recording_guidelines": [
            "Gravar em local silencioso",
            "Falar em português do Brasil no ritmo natural",
            "Manter microfone na mesma distância",
            "Evitar música, eco e ruído",
            "Ler um roteiro variado com saudações, explicações e frases técnicas",
        ],
        "local_engines": ["Coqui XTTS", "F5-TTS", "OpenVoice"],
        "privacy": "A amostra deve ficar em data/human_voice_assistant/voice_samples/ e não deve ser enviada para nuvem por padrão.",
    }


def implementation_plan() -> dict[str, Any]:
    return {
        "ok": True,
        "phases": [
            {"phase": 1, "name": "Avatar futurístico na tela principal", "status": "implemented_ui_ready"},
            {"phase": 2, "name": "Política de conversa natural e turn-taking", "status": "implemented_config_ready"},
            {"phase": 3, "name": "Modo assistente pessoal 24x7", "status": "implemented"},
            {"phase": 4, "name": "Modo funcionário especialista por área 24x7", "status": "implemented"},
            {"phase": 5, "name": "Perfis de voz pt-BR paulista/neutro", "status": "configured"},
            {"phase": 6, "name": "Voz própria autorizada", "status": "waiting_user_audio_sample"},
            {"phase": 7, "name": "STT local com faster-whisper/whisper.cpp", "status": "adapter_ready"},
            {"phase": 8, "name": "TTS local com Piper/Coqui/F5/OpenVoice", "status": "adapter_ready"},
            {"phase": 9, "name": "Roteamento automático para ferramentas", "status": "integrated_with_hall"},
            {"phase": 10, "name": "Aprovação humana e auditoria", "status": "integrated"},
        ],
    }


def answer_for_human_voice(message: str = "") -> str:
    return (
        "Vou usar o HAL Human Voice Assistant 24x7. "
        "Essa camada entrega avatar futurístico, conversa natural em português do Brasil, saudação por horário, espera do usuário terminar a fala, "
        "interrupção da resposta quando o usuário voltar a falar, modo assistente pessoal e modo funcionário especialista por área. "
        "Para usar sua voz real, preciso de uma amostra autorizada de áudio; até lá, o sistema fica preparado para Piper, Coqui XTTS, F5-TTS e OpenVoice."
    )
