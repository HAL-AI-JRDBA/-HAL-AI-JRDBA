from __future__ import annotations

from typing import Any
import re

MODULES = {
    "arrecadacao": ["arrecadação", "arrecadacao", "receita", "gratuidades", "bilhetagem"],
    "bilheteria": ["bilheteria", "bilhete", "passagem", "venda", "embarque"],
    "viagens": ["viagem", "viagens", "linha", "itinerário", "itinerario", "partida", "chegada"],
    "frota": ["frota", "ônibus", "onibus", "veículo", "veiculo", "garagem"],
    "manutencao": ["manutenção", "manutencao", "os", "ordem de serviço", "ordem de servico"],
    "escala": ["escala", "motorista", "cobrador", "jornada"],
    "frequencia": ["frequência", "frequencia", "ponto"],
    "financeiro": ["financeiro", "controller", "bancos"],
    "crc": ["contas a receber", "crc", "receber"],
    "cpg": ["contas a pagar", "cpg", "pagar"],
    "contabilidade": ["contabilidade", "contábil", "contabil"],
    "folha": ["folha", "pagamento", "rh"],
    "juridico": ["jurídico", "juridico", "processo", "multa"],
    "monitoramento": ["zabbix", "grafana", "monitoramento", "alerta", "servidor"],
}

TABLES = {
    "arrecadacao": "ARRECADACAO_DIARIA",
    "bilheteria": "BILHETERIA_VENDAS",
    "viagens": "VIAGENS_REALIZADAS",
    "frota": "FROTA_MOVIMENTACAO",
    "manutencao": "MANUTENCAO_OS",
    "escala": "ESCALA_OPERACIONAL",
    "frequencia": "FREQUENCIA_FUNCIONARIOS",
    "financeiro": "FINANCEIRO_MOVIMENTOS",
    "crc": "CONTAS_RECEBER",
    "cpg": "CONTAS_PAGAR",
    "contabilidade": "CONTABILIDADE_LANCAMENTOS",
    "folha": "FOLHA_PAGAMENTO",
    "juridico": "JURIDICO_PROCESSOS",
    "monitoramento": "MONITORAMENTO_EVENTOS",
}


def _term_in_text(term: str, text: str) -> bool:
    term = term.lower().strip()
    if len(term) <= 2:
        # termos curtos como "os" devem ser palavra inteira, não substring de "dados"
        return re.search(r"(?<!\w)" + re.escape(term) + r"(?!\w)", text) is not None
    if " " in term:
        return term in text
    return re.search(r"(?<!\w)" + re.escape(term) + r"(?!\w)", text) is not None


def detect_module(message: str) -> str:
    t = (message or "").lower()
    # prioridade para termos financeiros específicos antes de termos genéricos
    priority = ["crc", "cpg", "arrecadacao", "bilheteria", "viagens", "frota", "manutencao", "escala", "frequencia", "financeiro", "folha", "juridico", "monitoramento", "contabilidade"]
    for mod in priority:
        terms = MODULES.get(mod, [])
        if any(_term_in_text(term, t) for term in terms):
            return mod
    return ""


def sql_last_period(message: str) -> dict[str, Any]:
    mod = detect_module(message)
    if not mod:
        return {
            "needs_clarification": True,
            "question": (
                "Entendi que você quer descobrir o último mês/período disponível na base. "
                "De qual módulo estamos falando: arrecadação, bilheteria, viagens, frota, manutenção, escala, financeiro, CRC, CPG, folha ou jurídico?"
            )
        }
    table = TABLES.get(mod, "SUA_TABELA")
    date_field = "DATA_MOVIMENTO"
    if mod in {"crc", "cpg"}:
        date_field = "DATA_VENCIMENTO"
    if mod == "juridico":
        date_field = "DATA_PROCESSO"
    return {
        "needs_clarification": False,
        "module": mod,
        "sql": f"""SELECT
    TO_CHAR(MAX({date_field}), 'YYYY-MM') AS ULTIMO_MES_DISPONIVEL,
    MAX({date_field}) AS ULTIMA_DATA
FROM {table};""",
        "notes": "Ajuste o nome da tabela/campo conforme os metadados reais do ERP."
    }


def sql_crc_overdue() -> dict[str, Any]:
    return {
        "needs_clarification": False,
        "module": "crc",
        "sql": """SELECT
    CLIENTE_ID,
    NOME_CLIENTE,
    COUNT(*) AS QTDE_TITULOS,
    SUM(VALOR_ABERTO) AS VALOR_TOTAL_ABERTO,
    MIN(DATA_VENCIMENTO) AS VENCIMENTO_MAIS_ANTIGO
FROM CONTAS_RECEBER
WHERE STATUS = 'ABERTO'
  AND DATA_VENCIMENTO < TRUNC(SYSDATE)
GROUP BY CLIENTE_ID, NOME_CLIENTE
ORDER BY VALOR_TOTAL_ABERTO DESC;""",
        "notes": "Prioriza clientes com maior valor vencido em aberto."
    }


def build_transport_sql(message: str) -> dict[str, Any]:
    t = (message or "").lower()
    if "último mês" in t or "ultimo mes" in t or "última data" in t or "ultima data" in t or "base de dados" in t:
        return sql_last_period(message)
    if "contas a receber" in t or "crc" in t or "receber vencid" in t:
        return sql_crc_overdue()
    return {
        "needs_clarification": True,
        "question": "Preciso saber qual módulo/tabela e qual indicador você deseja analisar."
    }


def transport_context_prompt() -> str:
    return (
        "Contexto de negócio: empresa de transporte de passageiros urbano e rodoviário. "
        "Módulos críticos: arrecadação, bilheteria, viagens, frota, manutenção, escala, frequência, financeiro, CRC, CPG, bancos, contabilidade, folha, jurídico e monitoramento."
    )
