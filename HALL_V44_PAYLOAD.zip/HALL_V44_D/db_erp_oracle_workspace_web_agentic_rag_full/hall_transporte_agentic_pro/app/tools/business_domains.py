from __future__ import annotations

import re
from typing import Any


DOMAINS: dict[str, dict[str, Any]] = {
    "transporte": {
        "label": "Transporte de Passageiros",
        "description": "Empresas urbanas, rodoviárias, fretamento, garagens, linhas, viagens, frota e bilhetagem.",
        "keywords": ["transporte", "passageiros", "urbano", "rodoviário", "rodoviario", "ônibus", "onibus", "linha", "garagem", "frota", "bilheteria", "arrecadação", "arrecadacao", "escala", "motorista", "cobrador", "viagens"],
        "modules": ["arrecadação", "bilheteria", "viagens", "frota", "manutenção", "escala", "financeiro", "CRC", "CPG", "folha", "jurídico", "monitoramento"],
        "kpis": ["arrecadação diária", "passageiros transportados", "receita por linha", "ocupação", "pontualidade", "frota disponível", "falhas por veículo", "inadimplência"],
    },
    "logistica": {
        "label": "Logística",
        "description": "Operação logística, transporte de cargas, armazéns, entregas, rotas, SLA e fretes.",
        "keywords": ["logística", "logistica", "carga", "entrega", "entregas", "frete", "rota", "roteirização", "roteirizacao", "armazém", "armazem", "estoque", "expedição", "expedicao", "wms", "tms", "sla"],
        "modules": ["pedidos", "coletas", "entregas", "rotas", "fretes", "armazém", "estoque", "SLA", "ocorrências", "faturamento"],
        "kpis": ["OTIF", "SLA de entrega", "custo por entrega", "prazo médio", "ocupação de frota", "devoluções", "avarias"],
    },
    "financeiro_contabil": {
        "label": "Financeiro / Contábil",
        "description": "Contas a receber, contas a pagar, bancos, tesouraria, contabilidade, fiscal e controladoria.",
        "keywords": ["financeiro", "contábil", "contabil", "contabilidade", "fiscal", "controladoria", "tesouraria", "bancos", "contas a receber", "crc", "contas a pagar", "cpg", "dRE".lower(), "balancete", "razão", "razao", "nf", "nota fiscal", "sped"],
        "modules": ["CRC", "CPG", "bancos", "tesouraria", "DRE", "balancete", "razão", "fiscal", "SPED", "notas fiscais"],
        "kpis": ["inadimplência", "fluxo de caixa", "aging de recebíveis", "margem", "EBITDA", "DRE", "saldo bancário", "prazo médio de recebimento"],
    },
    "varejo": {
        "label": "Varejo",
        "description": "Lojas, PDV, vendas, estoque, clientes, promoções, e-commerce e omnichannel.",
        "keywords": ["varejo", "loja", "lojas", "pdv", "ponto de venda", "venda", "vendas", "cupom", "cliente", "produto", "promoção", "promocao", "e-commerce", "ecommerce", "marketplace", "caixa"],
        "modules": ["vendas", "PDV", "estoque", "produtos", "clientes", "promoções", "e-commerce", "marketplace", "trocas", "devoluções"],
        "kpis": ["vendas por loja", "ticket médio", "margem", "ruptura", "giro de estoque", "conversão", "devoluções", "sell-out"],
    },
    "atacado": {
        "label": "Atacado / Distribuição",
        "description": "Distribuidores, vendas B2B, representantes, pedidos, estoque, faturamento e crédito.",
        "keywords": ["atacado", "distribuição", "distribuicao", "distribuidor", "representante", "b2b", "pedido", "pedidos", "tabela de preço", "tabela de preco", "faturamento", "crédito", "credito"],
        "modules": ["pedidos", "representantes", "clientes B2B", "crédito", "estoque", "faturamento", "comissões", "roteiros", "entregas"],
        "kpis": ["faturamento por representante", "margem por cliente", "pedidos em aberto", "crédito bloqueado", "ruptura", "giro", "prazo médio"],
    },
    "generico": {
        "label": "Segmento Genérico",
        "description": "Empresas de qualquer segmento com ERP, CRM, BI, dados, processos e automações.",
        "keywords": ["empresa", "negócio", "negocio", "processo", "erp", "crm", "sistema", "operação", "operacao", "indicador", "dashboard"],
        "modules": ["cadastros", "processos", "vendas", "compras", "financeiro", "estoque", "BI", "CRM", "atendimento"],
        "kpis": ["produtividade", "custo", "receita", "margem", "SLA", "qualidade", "volume", "backlog"],
    },
}


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").lower()).strip()


def detect_domain(message: str) -> dict[str, Any]:
    t = normalize(message)
    # Prioridades explícitas evitam que termos genéricos como "vendas" puxem varejo quando o usuário disse atacado/B2B.
    explicit_priority = [
        ("atacado", ["atacado", "distribuição", "distribuicao", "b2b", "representante"]),
        ("logistica", ["logística", "logistica", "frete", "entrega", "armazém", "armazem", "tms", "wms"]),
        ("transporte", ["transporte", "passageiros", "rodoviário", "rodoviario", "ônibus", "onibus", "bilheteria"]),
        ("financeiro_contabil", ["financeiro", "contábil", "contabil", "crc", "cpg", "dre", "balancete"]),
        ("varejo", ["varejo", "loja", "pdv", "e-commerce", "ecommerce", "cupom"]),
    ]
    for key, terms in explicit_priority:
        if any(term in t for term in terms):
            return {"key": key, **DOMAINS[key], "score": 99}
    scored: list[tuple[int, str]] = []
    for key, data in DOMAINS.items():
        score = 0
        for kw in data.get("keywords", []):
            if kw in t:
                score += 2 if " " in kw else 1
        if score:
            scored.append((score, key))
    if not scored:
        key = "generico"
        score = 0
    else:
        scored.sort(reverse=True)
        score, key = scored[0]
    return {"key": key, **DOMAINS[key], "score": score}


def domain_options() -> list[dict[str, Any]]:
    return [{"key": k, **v} for k, v in DOMAINS.items()]


def business_clarification(message: str) -> str:
    d = detect_domain(message)
    if d["key"] == "generico":
        return (
            "Consigo atender qualquer segmento, mas para responder com precisão me diga o contexto do negócio: "
            "Transporte, Logística, Financeiro/Contábil, Varejo, Atacado/Distribuição ou outro segmento."
        )
    return (
        f"Identifiquei o segmento {d['label']}. Posso trabalhar com módulos como: "
        + ", ".join(d.get("modules", [])[:8])
        + "."
    )


def segment_prompt() -> str:
    lines = []
    for key, data in DOMAINS.items():
        lines.append(f"- {data['label']}: módulos {', '.join(data['modules'])}; KPIs {', '.join(data['kpis'])}.")
    return "Segmentos suportados:\n" + "\n".join(lines)
