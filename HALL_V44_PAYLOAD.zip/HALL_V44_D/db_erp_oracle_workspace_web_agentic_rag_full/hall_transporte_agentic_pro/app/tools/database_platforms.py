from __future__ import annotations

import re
from typing import Any


DATABASES: dict[str, dict[str, Any]] = {
    "oracle": {
        "label": "Oracle",
        "family": "Relacional",
        "keywords": ["oracle", "plsql", "pl/sql", "tablespace", "awr", "ash"],
        "driver_hint": "oracledb / cx_Oracle",
        "date_example": "MAX(DATA_MOVIMENTO)",
        "sample_last_period": "SELECT TO_CHAR(MAX(DATA_MOVIMENTO), 'YYYY-MM') AS ULTIMO_MES, MAX(DATA_MOVIMENTO) AS ULTIMA_DATA FROM SUA_TABELA",
    },
    "sqlserver": {
        "label": "SQL Server",
        "family": "Relacional",
        "keywords": ["sql server", "sqlserver", "mssql", "t-sql", "tsql"],
        "driver_hint": "pyodbc / pymssql",
        "date_example": "MAX(DATA_MOVIMENTO)",
        "sample_last_period": "SELECT FORMAT(MAX(DATA_MOVIMENTO), 'yyyy-MM') AS ULTIMO_MES, MAX(DATA_MOVIMENTO) AS ULTIMA_DATA FROM dbo.SUA_TABELA",
    },
    "postgresql": {
        "label": "PostgreSQL",
        "family": "Relacional",
        "keywords": ["postgresql", "postgres", "pg"],
        "driver_hint": "psycopg / asyncpg",
        "date_example": "MAX(data_movimento)",
        "sample_last_period": "SELECT TO_CHAR(MAX(data_movimento), 'YYYY-MM') AS ultimo_mes, MAX(data_movimento) AS ultima_data FROM sua_tabela",
    },
    "mysql": {
        "label": "MySQL",
        "family": "Relacional",
        "keywords": ["mysql"],
        "driver_hint": "mysql-connector-python / pymysql",
        "date_example": "MAX(data_movimento)",
        "sample_last_period": "SELECT DATE_FORMAT(MAX(data_movimento), '%Y-%m') AS ultimo_mes, MAX(data_movimento) AS ultima_data FROM sua_tabela",
    },
    "mariadb": {
        "label": "MariaDB",
        "family": "Relacional",
        "keywords": ["mariadb", "maria db"],
        "driver_hint": "mariadb / pymysql",
        "date_example": "MAX(data_movimento)",
        "sample_last_period": "SELECT DATE_FORMAT(MAX(data_movimento), '%Y-%m') AS ultimo_mes, MAX(data_movimento) AS ultima_data FROM sua_tabela",
    },
    "sqlite": {
        "label": "SQLite",
        "family": "Relacional embarcado",
        "keywords": ["sqlite", "sqlite3"],
        "driver_hint": "sqlite3",
        "date_example": "MAX(data_movimento)",
        "sample_last_period": "SELECT strftime('%Y-%m', MAX(data_movimento)) AS ultimo_mes, MAX(data_movimento) AS ultima_data FROM sua_tabela",
    },
    "mongodb": {
        "label": "MongoDB",
        "family": "NoSQL Documento",
        "keywords": ["mongodb", "mongo", "documento", "collection", "coleção", "colecao"],
        "driver_hint": "pymongo / motor",
        "date_example": "$max: '$data_movimento'",
        "sample_last_period": "db.sua_collection.aggregate([{ $group: { _id: null, ultima_data: { $max: '$data_movimento' } } }, { $project: { _id: 0, ultima_data: 1 } }])",
    },
    "redis": {
        "label": "Redis",
        "family": "NoSQL Chave-Valor / Cache",
        "keywords": ["redis", "cache", "key value", "chave valor"],
        "driver_hint": "redis-py",
        "date_example": "SCAN/TTL/metadata",
        "sample_last_period": "Use SCAN para localizar chaves por padrão e consultar timestamps armazenados nos valores/metadados.",
    },
    "cassandra": {
        "label": "Cassandra",
        "family": "NoSQL Wide Column",
        "keywords": ["cassandra", "wide column", "colunar"],
        "driver_hint": "cassandra-driver",
        "date_example": "MAX(data_movimento) conforme modelagem",
        "sample_last_period": "SELECT MAX(data_movimento) AS ultima_data FROM keyspace.sua_tabela; -- depende da modelagem/partição",
    },
    "elasticsearch": {
        "label": "Elasticsearch / OpenSearch",
        "family": "Search / Documento",
        "keywords": ["elasticsearch", "opensearch", "elastic", "índice", "indice"],
        "driver_hint": "elasticsearch / opensearch-py",
        "date_example": "max aggregation",
        "sample_last_period": '{"aggs":{"ultima_data":{"max":{"field":"data_movimento"}}},"size":0}',
    },
    "neo4j": {
        "label": "Neo4j",
        "family": "Grafo",
        "keywords": ["neo4j", "grafo", "graph database"],
        "driver_hint": "neo4j",
        "date_example": "max(n.data_movimento)",
        "sample_last_period": "MATCH (n) RETURN max(n.data_movimento) AS ultima_data",
    },
    "firebird": {
        "label": "Firebird", "family": "Relacional", "keywords": ["firebird"],
        "driver_hint": "firebird-driver", "date_example": "MAX(DATA_MOVIMENTO)",
        "sample_last_period": "SELECT MAX(DATA_MOVIMENTO) AS ULTIMA_DATA FROM SUA_TABELA",
    },
    "db2": {
        "label": "IBM Db2", "family": "Relacional", "keywords": ["db2", "ibm db2"],
        "driver_hint": "ibm_db", "date_example": "MAX(DATA_MOVIMENTO)",
        "sample_last_period": "SELECT MAX(DATA_MOVIMENTO) AS ULTIMA_DATA FROM SUA_TABELA",
    },
    "couchdb": {
        "label": "CouchDB", "family": "NoSQL Documento", "keywords": ["couchdb", "couch db"],
        "driver_hint": "couchdb / REST", "date_example": "Mango selector/sort", "sample_last_period": "Use Mango/_find ou view indexada no campo de data.",
    },
    "opensearch": {
        "label": "OpenSearch", "family": "Search / Documento", "keywords": ["opensearch", "open search"],
        "driver_hint": "opensearch-py", "date_example": "max aggregation", "sample_last_period": '{"aggs":{"ultima_data":{"max":{"field":"data_movimento"}}},"size":0}',
    },
    "generic_sql": {
        "label": "Outro SQL (ODBC/JDBC/SQLAlchemy)", "family": "Relacional genérico", "keywords": ["odbc", "jdbc", "sqlalchemy", "outro banco sql"],
        "driver_hint": "ODBC/JDBC/SQLAlchemy", "date_example": "MAX(data_movimento)", "sample_last_period": "SELECT MAX(data_movimento) AS ultima_data FROM sua_tabela",
    },
}


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").lower()).strip()


def detect_database(message: str, default: str = "oracle") -> dict[str, Any]:
    t = normalize(message)
    for key, data in DATABASES.items():
        if any(kw in t for kw in data.get("keywords", [])):
            return {"key": key, **data, "explicit": True}
    return {"key": default, **DATABASES.get(default, DATABASES["oracle"]), "explicit": False}


def database_options() -> list[dict[str, Any]]:
    return [{"key": k, **v} for k, v in DATABASES.items()]


def connection_guidance(db_key: str) -> dict[str, Any]:
    db = DATABASES.get(db_key, DATABASES["oracle"])
    return {
        "database": db["label"],
        "family": db["family"],
        "driver_hint": db["driver_hint"],
        "notes": [
            "Configure credenciais fora do código em variável de ambiente ou arquivo .env local.",
            "Use usuário somente leitura para consultas e diagnóstico.",
            "Ações de escrita devem exigir aprovação humana.",
            "Para NoSQL, a modelagem define como buscar período, coleção/índice e campo de data."
        ],
    }


def last_period_example(db_key: str, table_or_collection: str = "sua_tabela") -> str:
    db = DATABASES.get(db_key, DATABASES["oracle"])
    sample = db["sample_last_period"]
    return sample.replace("SUA_TABELA", table_or_collection).replace("sua_tabela", table_or_collection).replace("sua_collection", table_or_collection)
