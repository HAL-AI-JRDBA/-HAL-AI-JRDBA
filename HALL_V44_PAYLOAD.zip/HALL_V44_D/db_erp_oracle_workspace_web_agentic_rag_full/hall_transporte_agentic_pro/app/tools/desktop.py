from __future__ import annotations

import time
import webbrowser
from pathlib import Path
from typing import Any

from app.core.config import root_dir, load_config

CAPTURES = root_dir() / "data" / "captures"
NOTES = root_dir() / "data" / "notes"
DANGEROUS_TERMS = ["drop ", "truncate ", "delete from", "format ", "shutdown", "rm -rf", "del /s"]


def _ensure() -> None:
    CAPTURES.mkdir(parents=True, exist_ok=True)
    NOTES.mkdir(parents=True, exist_ok=True)


def _has(name: str) -> bool:
    try:
        __import__(name)
        return True
    except Exception:
        return False


def status() -> dict[str, Any]:
    return {
        "ok": True,
        "pyautogui": _has("pyautogui"),
        "mss": _has("mss"),
        "opencv": _has("cv2"),
        "screenshot": _has("pyautogui") or _has("mss"),
        "camera": _has("cv2"),
        "keyboard_mouse": _has("pyautogui"),
        "security": load_config().get("security", {}),
    }


def guard(action: str, payload: dict[str, Any], approved: bool) -> tuple[bool, str]:
    raw = (action + " " + str(payload)).lower()
    if any(term in raw for term in DANGEROUS_TERMS):
        return False, "Ação bloqueada por segurança."
    if action in {"type_text", "open_url", "create_folder", "hotkey", "click"} and not approved:
        return False, "Ação de desktop exige aprovação humana."
    return True, ""


def screenshot() -> dict[str, Any]:
    _ensure()
    if _has("pyautogui"):
        import pyautogui
        img = pyautogui.screenshot()
        path = CAPTURES / f"desktop_{time.strftime('%Y%m%d_%H%M%S')}.png"
        img.save(path)
        return {"ok": True, "relative_path": str(path.relative_to(root_dir())), "path": str(path), "summary": "Screenshot do desktop capturado."}
    if _has("mss"):
        import mss
        from PIL import Image
        with mss.mss() as sct:
            raw = sct.grab(sct.monitors[1])
            img = Image.frombytes("RGB", raw.size, raw.rgb)
            path = CAPTURES / f"desktop_{time.strftime('%Y%m%d_%H%M%S')}.png"
            img.save(path)
            return {"ok": True, "relative_path": str(path.relative_to(root_dir())), "path": str(path), "summary": "Screenshot capturado via MSS."}
    return {"ok": False, "summary": "Instale pyautogui ou mss para capturar tela."}


def camera() -> dict[str, Any]:
    _ensure()
    if not _has("cv2"):
        return {"ok": False, "summary": "Instale opencv-python para câmera."}
    import cv2
    cap = cv2.VideoCapture(0)
    ok, frame = cap.read()
    cap.release()
    if not ok:
        return {"ok": False, "summary": "Não consegui acessar a câmera."}
    path = CAPTURES / f"camera_{time.strftime('%Y%m%d_%H%M%S')}.png"
    cv2.imwrite(str(path), frame)
    return {"ok": True, "relative_path": str(path.relative_to(root_dir())), "path": str(path), "summary": "Foto da câmera capturada."}


def type_text(text: str) -> dict[str, Any]:
    if not _has("pyautogui"):
        return {"ok": False, "summary": "Instale pyautogui para digitar na janela ativa."}
    import pyautogui
    pyautogui.write(text or "", interval=0.005)
    return {"ok": True, "summary": "Texto digitado na janela ativa."}


def open_url(url: str) -> dict[str, Any]:
    url = (url or "").strip()
    if not url.startswith(("http://", "https://")):
        import urllib.parse
        url = "https://www.google.com/search?q=" + urllib.parse.quote(url)
    webbrowser.open(url)
    return {"ok": True, "url": url, "summary": "URL/pesquisa aberta."}


def create_folder(name: str) -> dict[str, Any]:
    desktop = Path.home() / "Desktop"
    safe = "".join(c for c in (name or "Relatorios_Transporte") if c.isalnum() or c in " _-").strip() or "Relatorios_Transporte"
    path = desktop / safe
    path.mkdir(parents=True, exist_ok=True)
    return {"ok": True, "path": str(path), "summary": "Pasta criada na área de trabalho."}


def create_note(text: str) -> dict[str, Any]:
    _ensure()
    path = NOTES / f"nota_{time.strftime('%Y%m%d_%H%M%S')}.txt"
    path.write_text(text or "", encoding="utf-8")
    return {"ok": True, "relative_path": str(path.relative_to(root_dir())), "summary": "Nota local criada."}


def execute(action: str, payload: dict[str, Any], approved: bool = False) -> dict[str, Any]:
    allowed, reason = guard(action, payload, approved)
    if not allowed:
        return {"ok": False, "requires_approval": True, "summary": reason}
    if action == "screenshot":
        return screenshot()
    if action == "camera":
        return camera()
    if action == "type_text":
        return type_text(payload.get("text", ""))
    if action == "open_url":
        return open_url(payload.get("url") or payload.get("query") or "")
    if action == "create_folder":
        return create_folder(payload.get("name", "Relatorios_Transporte"))
    if action == "create_note":
        return create_note(payload.get("text", ""))
    return {"ok": False, "summary": f"Ação não suportada: {action}"}
