from __future__ import annotations

import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
CONFIG_FILE = ROOT / "config.json"


def load_config() -> dict[str, Any]:
    try:
        source = CONFIG_FILE if CONFIG_FILE.is_file() else ROOT / 'config.example.json'
        return json.loads(source.read_text(encoding="utf-8-sig"))
    except Exception:
        return {}


def save_config(data: dict[str, Any]) -> dict[str, Any]:
    current = load_config()
    current.update(data or {})
    CONFIG_FILE.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")
    return current


def root_dir() -> Path:
    return ROOT
