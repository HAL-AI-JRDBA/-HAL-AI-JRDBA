from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from app.core.config import root_dir, load_config, save_config
from app.services import multi_model_router, cyber_defense_shield, enterprise_productization_v13, app_factory_pro, software_builder_center, local_stt_fallback, skills_multi_agent_center, executive_financial_intelligence, omnichannel_voice_text_delivery, meeting_intelligence_gateway, enterprise_integration_team_intelligence, human_conversation_gateway, database_access_wizard, industry_precision_engine, reliable_web_answer, memory
from app.services import model_manager
from app.services import orchestrator
from app.services import vision
from app.services import business_teams
from app.services import saas_builder
from app.services import agent_runtime
from app.services import human_voice_assistant
from app.services import realtime_voice_engine
from app.services import channel_gateway, n8n_workflow_center, browser_automation, cron_enterprise, sandbox_enterprise, agent_framework_bridge, visual_mission_control, universal_erp_connector
from app.services import open_ai_access_center
from app.tools import desktop

ROOT = root_dir()
STATIC = ROOT / "static"

app = FastAPI(title="HAL MultiSegmento Agentic Pro", version="3.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8030", "http://localhost:8030"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")







class MultiModelRequest(BaseModel):
    message: str = ""
    prompt: str = ""
    intent: str = ""
    role: str = ""
    text: str = ""
    test: bool = False
    changes: dict[str, Any] = Field(default_factory=dict)


class CyberDefenseRequest(BaseModel):
    message: str = ""
    changes: dict[str, Any] = Field(default_factory=dict)
    paths: list[str] = Field(default_factory=list)
    email: dict[str, Any] = Field(default_factory=dict)
    scenario: str = "ransomware"
    limit: int = 100


class EnterpriseV13Request(BaseModel):
    message: str = ""
    agent_id: str = ""
    instruction: str = ""
    schedule: str = ""
    task_id: str = ""
    approved: bool = True
    title: str = ""
    text: str = ""
    source: str = "manual"
    query: str = ""
    target: str = "local"
    app_path: str = ""
    repo_name: str = "hall-generated-app"
    changes: dict[str, Any] = Field(default_factory=dict)
    seed: bool = False


class AppFactoryRequest(BaseModel):
    message: str = ""
    app_name: str = ""
    template_id: str = ""
    generate: bool = False
    include_sample_data: bool = True
    changes: dict[str, Any] = Field(default_factory=dict)


class STTConfigRequest(BaseModel):
    changes: dict[str, Any] = Field(default_factory=dict)



class SoftwareBuilderRequest(BaseModel):
    message: str
    generate_project: bool = False
    project_name: str = "hall_financas_pessoais"


class TurnRequest(BaseModel):
    message: str
    approved: bool = False


class DesktopRequest(BaseModel):
    action: str
    approved: bool = False
    payload: dict[str, Any] = Field(default_factory=dict)


class MemoryAddRequest(BaseModel):
    text: str
    tags: list[str] = Field(default_factory=list)
    importance: int = 3


class MemorySearchRequest(BaseModel):
    query: str
    limit: int = 8


class ConfigRequest(BaseModel):
    config: dict[str, Any]


class PullModelRequest(BaseModel):
    model: str

class BusinessTeamCreateRequest(BaseModel):
    goal: str
    segment: str = ""
    database: str = ""
    template: str = ""
    channels: list[str] = Field(default_factory=list)
    company: str = ""
    approval_required: bool = True


class BusinessTeamRunRequest(BaseModel):
    goal: str = ""
    team_id: str = ""
    approved: bool = False
    channel: str = "webchat"


class ApprovalDecisionRequest(BaseModel):
    approval_id: str
    decision: str
    reviewer: str = "humano"





class OpenAIAccessProfileRequest(BaseModel):
    profile: str
    business_mode: str = ""


class OpenAIAccessRecommendRequest(BaseModel):
    profile: str = ""
    use_case: str = "geral"
    business_mode: str = ""


class OpenAIAccessAgentRequest(BaseModel):
    agent_key: str


class OpenAIAccessSecureRequest(BaseModel):
    exposure: str = "vpn"
    domain: str = ""


class OpenAIAccessROIRequest(BaseModel):
    employees: int = 5
    hours_per_week: float = 6
    hourly_cost: float = 60
    reduction_percent: float = 40
    monthly_fee: float = 3500







class IndustryPrecisionAnswerRequest(BaseModel):
    message: str
    context: dict[str, Any] = Field(default_factory=dict)
    approved: bool = False


class IndustryProfileRequest(BaseModel):
    industry_key: str
    company_name: str
    systems: list[dict[str, Any]] = Field(default_factory=list)
    processes: list[str] = Field(default_factory=list)
    approval_level: str = "safe"


class IndustryTestCaseRequest(BaseModel):
    industry_key: str
    question: str
    expected_behavior: str
    expected_tool: str = ""









class SkillsCenterSkillRequest(BaseModel):
    skill_id: str = ""
    name: str = ""
    category: str = "geral"
    body: str = ""
    risk: str = "low"
    agent: str = ""


class SkillsCenterInstallTextRequest(BaseModel):
    file_name: str = "skill.md"
    content: str
    install_to_hub: bool = False


class SkillsCenterRunRequest(BaseModel):
    skill_id: str
    input_text: str = ""
    context: dict[str, Any] = Field(default_factory=dict)
    approved: bool = False


class SkillsCenterAgentRequest(BaseModel):
    name: str
    role: str
    skills: list[str] = Field(default_factory=list)
    enabled: bool = True


class SkillsCenterSessionRequest(BaseModel):
    objective: str
    agents: list[str] = Field(default_factory=list)
    parent_session_id: str = ""
    context: dict[str, Any] = Field(default_factory=dict)


class SkillsCenterTaskRequest(BaseModel):
    objective: str
    agent_id: str = ""
    skill_id: str = ""
    session_id: str = ""
    approved: bool = False


class SkillsCenterCollaborationRequest(BaseModel):
    objective: str
    agents: list[str] = Field(default_factory=list)
    approved: bool = False


class SkillsCenterImageRequest(BaseModel):
    prompt: str
    context: dict[str, Any] = Field(default_factory=dict)
    style: str = "futurista profissional"
    size: str = "1024x1024"


class SkillsCenterConfigRequest(BaseModel):
    changes: dict[str, Any] = Field(default_factory=dict)


class SkillsCenterQuestionRequest(BaseModel):
    message: str
    approved: bool = False


class ExecutiveFinancialSourceRequest(BaseModel):
    name: str = ""
    source_type: str = "database"
    connection_ref: str = ""
    system: str = ""
    company: str = ""
    description: str = ""
    enabled: bool = True


class ExecutiveFinancialSnapshotRequest(BaseModel):
    period: str = "mês atual"
    company: str = ""
    branch: str = ""
    cost_center: str = ""
    values: dict[str, Any] = Field(default_factory=dict)
    source: str = "manual"


class ExecutiveFinancialQuestionRequest(BaseModel):
    message: str
    approved: bool = False
    values: dict[str, Any] | None = None


class ExecutiveFinancialConfigRequest(BaseModel):
    changes: dict[str, Any] = Field(default_factory=dict)


class OmnichannelContactRequest(BaseModel):
    name: str = ""
    channel: str = "whatsapp"
    recipient: str
    user_id: str = ""
    team_id: str = ""
    department: str = ""
    send_text: bool = True
    send_voice: bool = True
    active: bool = True


class OmnichannelDeliveryRequest(BaseModel):
    question: str = ""
    answer: str
    channel: str = ""
    recipient: str = ""
    requester_email: str = ""
    send_text: bool | None = None
    send_voice: bool | None = None
    approved: bool = False
    source: str = "hall"


class OmnichannelConfigRequest(BaseModel):
    changes: dict[str, Any] = Field(default_factory=dict)


class OmnichannelApproveRequest(BaseModel):
    delivery_id: str


class MeetingStartRequest(BaseModel):
    title: str = "Reunião HAL"
    platform: str = "teams"
    meeting_url: str = ""
    mode: str = "qa"
    organizer: str = ""
    participants: list[str] = Field(default_factory=list)
    voice_response: bool | None = None
    text_response: bool | None = None
    consent_confirmed: bool = False


class MeetingConsentRequest(BaseModel):
    meeting_id: str


class MeetingTranscriptRequest(BaseModel):
    meeting_id: str
    speaker: str = ""
    text: str
    timestamp: str = ""


class MeetingQuestionRequest(BaseModel):
    meeting_id: str
    question: str
    speaker: str = ""
    respond_voice: bool = True
    respond_text: bool = True
    approved: bool = False


class MeetingConfigRequest(BaseModel):
    changes: dict[str, Any] = Field(default_factory=dict)


class EnterpriseToolRegisterRequest(BaseModel):
    tool_key: str
    name: str = ""
    env_prefix: str = ""
    owner_team: str = ""
    enabled: bool = True


class EnterpriseTeamCreateRequest(BaseModel):
    department_key: str
    segment_key: str = "generico"
    name: str = ""
    users: list[str] = Field(default_factory=list)
    autonomy_level: int = 2


class EnterpriseUserRegisterRequest(BaseModel):
    name: str
    department_key: str = ""
    role: str = ""
    preferred_channels: list[str] = Field(default_factory=list)
    personal_mode: bool = True


class EnterpriseTaskRequest(BaseModel):
    message: str
    user_id: str = ""
    team_id: str = ""
    approved: bool = False


class HumanConversationRequest(BaseModel):
    message: str
    session_id: str = ""
    user_name: str = ""
    approved: bool = False
    run_tools: bool = True


class HumanConversationPreferenceRequest(BaseModel):
    key: str
    value: str


class DatabaseAccessRegisterConnectionRequest(BaseModel):
    name: str
    database_type: str
    env_prefix: str = ""
    host: str = ""
    port: str | int | None = None
    database_name: str = ""
    schema_or_keyspace: str = ""
    readonly: bool = True
    description: str = ""


class DatabaseAccessDataRequest(BaseModel):
    user_question: str
    connection_id: str = ""
    database_type: str = ""
    entities_or_tables: list[str] = Field(default_factory=list)
    filters: dict[str, Any] = Field(default_factory=dict)
    metrics_or_fields: list[str] = Field(default_factory=list)
    output_format: str = ""
    approved: bool = False


class DatabaseAccessQueryPlanRequest(BaseModel):
    request_id: str = ""
    user_question: str = ""
    connection_id: str = ""
    approved: bool = False


class DatabaseAccessGuidedRequest(BaseModel):
    message: str
    approved: bool = False


class ReliableWebAnswerRequest(BaseModel):
    message: str
    approved: bool = True
    max_sources: int = 5


class UniversalERPConnectionRequest(BaseModel):
    name: str
    connector_type: str
    database: str = ""
    system_name: str = ""
    env_prefix: str = ""
    readonly: bool = True
    description: str = ""


class UniversalERPMappingRequest(BaseModel):
    connection_id: str
    business_entity: str
    physical_target: str
    fields: list[dict[str, Any]] = Field(default_factory=list)
    access_method: str = "read"
    notes: str = ""


class UniversalERPQueryPlanRequest(BaseModel):
    question: str
    connection_id: str = ""
    approved: bool = False


class VisualMissionCreateRequest(BaseModel):
    title: str
    objective: str = ""
    agents: list[str] = Field(default_factory=list)
    priority: str = "normal"
    source: str = "hall"
    requires_approval: bool = False
    presentation: bool = False


class VisualMissionUpdateRequest(BaseModel):
    mission_id: str
    status_value: str = ""
    progress: int | None = None
    result_summary: str = ""


class VisualMissionIdRequest(BaseModel):
    mission_id: str


class VisualMissionApprovalRequest(BaseModel):
    approval_id: str


class VisualMissionNoteRequest(BaseModel):
    text: str


class VisualMissionConfigRequest(BaseModel):
    changes: dict[str, Any] = Field(default_factory=dict)


class ChannelGatewayConfigureRequest(BaseModel):
    channel: str
    enabled: bool = True
    credentials_env: dict[str, str] = Field(default_factory=dict)
    allowed_recipients: list[str] = Field(default_factory=list)


class ChannelGatewayInboundRequest(BaseModel):
    channel: str
    sender: str
    text: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class ChannelGatewayOutboundRequest(BaseModel):
    channel: str
    recipient: str
    text: str
    approved: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)


class N8NConfigureRequest(BaseModel):
    base_url: str
    api_key_env: str = "N8N_API_KEY"
    approval_required: bool = True


class N8NWorkflowRegisterRequest(BaseModel):
    name: str
    workflow_id: str = ""
    webhook_url: str = ""
    intent_keywords: list[str] = Field(default_factory=list)
    critical: bool = True


class N8NExecuteRequest(BaseModel):
    workflow_id: str
    payload: dict[str, Any] = Field(default_factory=dict)
    approved: bool = False


class N8NCallbackRequest(BaseModel):
    execution_id: str
    status_value: str
    result: dict[str, Any] = Field(default_factory=dict)


class BrowserSessionRequest(BaseModel):
    name: str = "Navegação HAL"
    headless: bool = False
    allowed_domains: list[str] = Field(default_factory=list)


class BrowserActionRequest(BaseModel):
    session_id: str
    action: str
    target: str = ""
    value: str = ""
    approved: bool = False


class BrowserActionPlanRequest(BaseModel):
    url: str
    goal: str


class CronCreateRequest(BaseModel):
    name: str
    prompt: str
    frequency: str = "daily"
    cron: str = ""
    channel: str = ""
    enabled: bool = True
    max_retries: int = 3


class CronJobRequest(BaseModel):
    job_id: str
    approved: bool = False
    enabled: bool = True


class SandboxCreateRequest(BaseModel):
    name: str
    purpose: str
    agent: str = "hall"
    network: str = "disabled"
    memory: str = "2g"
    timeout_seconds: int = 300


class SandboxSecretRequest(BaseModel):
    name: str
    env_var: str
    scope: str = "global"
    description: str = ""


class SandboxExecutionPlanRequest(BaseModel):
    command: str
    sandbox_id: str = ""
    approved: bool = False


class FrameworkConfigureRequest(BaseModel):
    framework: str
    enabled: bool = True


class FrameworkRunRequest(BaseModel):
    goal: str
    framework: str = ""
    approved: bool = False

class RealtimeVoiceConfigRequest(BaseModel):
    config: dict[str, Any] = Field(default_factory=dict)


class RealtimeVoiceSessionRequest(BaseModel):
    user_name: str = ""
    mode: str = "assistant"
    channel: str = "web"


class RealtimeVoiceStateRequest(BaseModel):
    session_id: str
    state: str
    partial_transcript: str = ""
    final_transcript: str = ""
    route: str = ""


class RealtimeVoiceStopRequest(BaseModel):
    session_id: str


class RealtimeVoicePresetRequest(BaseModel):
    text: str


class HumanVoiceProfileRequest(BaseModel):
    profile_id: str


class HumanVoicePersonaRequest(BaseModel):
    persona_id: str = ""
    department_role: str = ""


class HumanVoiceSessionRequest(BaseModel):
    user_name: str = ""
    mode: str = "personal_assistant"
    department_role: str = ""
    channel: str = "web"


class HumanVoiceAnswerRequest(BaseModel):
    message: str
    user_name: str = ""
    department_role: str = ""


class AgentRuntimeCreateRequest(BaseModel):
    objective: str
    job_type: str = ""
    priority: str = "normal"
    agents: list[str] = Field(default_factory=list)
    segment: str = ""
    database: str = ""
    requires_approval: bool = True
    estimated_human_minutes: int = 60
    project: str = ""


class AgentRuntimeJobRequest(BaseModel):
    job_id: str


class AgentRuntimeAdvanceRequest(BaseModel):
    job_id: str
    steps_to_advance: int = 1


class AgentRuntimeStartRequest(BaseModel):
    job_id: str
    approved: bool = False


class AgentRuntimeCancelRequest(BaseModel):
    job_id: str
    reason: str = ""


class AgentRuntimeRetryRequest(BaseModel):
    job_id: str
    step_id: str = ""


class SaaSBuilderCreateRequest(BaseModel):
    idea: str
    client_name: str = ""
    company_name: str = ""
    template: str = ""
    segment: str = ""
    database: str = ""
    app_name: str = ""
    domain: str = ""
    primary_color: str = "#ff0060"
    accent_color: str = "#3b82f6"
    logo_text: str = "AJDS"
    billing_provider: str = "manual"
    deploy_target: str = "local"


class SaaSBuilderProjectRequest(BaseModel):
    project_id: str


class SaaSBuilderDeployRequest(BaseModel):
    project_id: str
    target: str = ""


class SaaSBuilderRollbackRequest(BaseModel):
    project_id: str
    version_id: str = ""


class SaaSBuilderClientRequest(BaseModel):
    name: str
    email: str = ""
    company: str = ""
    plan: str = "starter"






@app.get("/", response_class=HTMLResponse)
def home():
    return (STATIC / "index.html").read_text(encoding="utf-8-sig")


@app.get("/api/status")
def status():
    return {
        "ok": True,
        "config": load_config(),
        "models": model_manager.status(),
        "desktop": desktop.status(),
        "memory": memory.list_memories(20),
    }


@app.post("/api/agent/turn")
def agent_turn(payload: TurnRequest):
    # Conversational Runtime V4: a rota principal do Agentic Pro também conversa primeiro.
    # O orchestrator continua disponível por trás, mas não deve substituir a conversa natural.
    try:
        h = human_conversation_gateway.converse(
            payload.message,
            session_id="",
            user_name="",
            approved=payload.approved,
            run_tools=True,
        )
        return {
            "ok": True,
            "answer": h.get("answer", ""),
            "plan": {
                "mode": "live_dialogue_engine_v4",
                "requires_approval": bool(h.get("classification", {}).get("policy") == "approval_required"),
                "intent": h.get("classification", {}).get("intent"),
                "tool": h.get("tool_result", {}).get("tool", ""),
                "tools_in_background": True,
            },
            "human_conversation": h,
            "technical": h,
            "summary": h.get("answer", ""),
        }
    except Exception:
        return orchestrator.run(payload.message, approved=payload.approved)


@app.get("/api/models/status")
def models_status():
    return model_manager.status()


@app.post("/api/models/pull")
def models_pull(payload: PullModelRequest):
    client = model_manager.OllamaClient()
    return client.pull_model(payload.model)


@app.post("/api/desktop/action")
def desktop_action(payload: DesktopRequest):
    return desktop.execute(payload.action, payload.payload, approved=payload.approved)


@app.get("/api/desktop/screenshot")
def desktop_screenshot():
    return desktop.screenshot()


@app.get("/api/desktop/camera")
def desktop_camera():
    return desktop.camera()


@app.post("/api/vision/upload")
async def vision_upload(file: UploadFile = File(...), source: str = Form("browser"), question: str = Form("")):
    data = await file.read()
    meta = vision.save_image(data, file.filename or "capture.png", source=source)
    analysis = vision.analyze(meta["path"], question)
    return {"ok": True, "image": meta, "analysis": analysis}


@app.post("/api/memory/add")
def memory_add(payload: MemoryAddRequest):
    return memory.add_memory(payload.text, payload.tags, "ui", payload.importance)


@app.get("/api/memory/list")
def memory_list(limit: int = 100):
    return memory.list_memories(limit)


@app.post("/api/memory/search")
def memory_search(payload: MemorySearchRequest):
    return memory.search(payload.query, payload.limit)


@app.get("/api/config")
def config_get():
    return {"ok": True, "config": load_config()}


@app.post("/api/config")
def config_save(payload: ConfigRequest):
    return {"ok": True, "config": save_config(payload.config)}


@app.get("/captures/{filename}")
def capture_file(filename: str):
    path = ROOT / "data" / "captures" / filename
    if path.exists():
        return FileResponse(str(path))
    return {"ok": False, "summary": "Captura não encontrada."}


@app.get("/api/business/segments")
def business_segments():
    from app.tools.business_domains import domain_options
    return {"ok": True, "segments": domain_options()}


@app.get("/api/databases/supported")
def databases_supported():
    from app.tools.database_platforms import database_options
    return {"ok": True, "databases": database_options()}


@app.get("/api/databases/guidance/{db_key}")
def database_guidance(db_key: str):
    from app.tools.database_platforms import connection_guidance
    return {"ok": True, "guidance": connection_guidance(db_key)}


@app.get("/api/business-teams/status")
def business_teams_status():
    return business_teams.status()


@app.get("/api/business-teams/templates")
def business_teams_templates():
    return business_teams.templates()


@app.get("/api/business-teams/agents")
def business_teams_agents():
    return business_teams.agents()


@app.get("/api/business-teams/channels")
def business_teams_channels():
    return business_teams.channels()


@app.get("/api/business-teams/nocode")
def business_teams_nocode():
    return business_teams.no_code_spec()


@app.get("/api/business-teams/list")
def business_teams_list(limit: int = 50):
    return business_teams.list_teams(limit)


@app.post("/api/business-teams/create")
def business_teams_create(payload: BusinessTeamCreateRequest):
    return business_teams.create_team(
        goal=payload.goal,
        segment=payload.segment,
        database=payload.database,
        template=payload.template,
        channels_req=payload.channels,
        company=payload.company,
        approval_required=payload.approval_required,
    )


@app.post("/api/business-teams/run")
def business_teams_run(payload: BusinessTeamRunRequest):
    return business_teams.run_team(
        goal=payload.goal,
        team_id=payload.team_id,
        approved=payload.approved,
        channel=payload.channel,
    )


@app.get("/api/business-teams/approvals")
def business_teams_approvals(status: str = "pending", limit: int = 100):
    return business_teams.list_approvals(status, limit)


@app.post("/api/business-teams/approval")
def business_teams_approval(payload: ApprovalDecisionRequest):
    return business_teams.decide_approval(payload.approval_id, payload.decision, payload.reviewer)


@app.get("/api/saas-builder/status")
def saas_builder_status():
    return saas_builder.status()


@app.get("/api/saas-builder/templates")
def saas_builder_templates():
    return saas_builder.templates()


@app.get("/api/saas-builder/deploy-targets")
def saas_builder_deploy_targets():
    return saas_builder.deploy_targets()


@app.get("/api/saas-builder/billing")
def saas_builder_billing():
    return saas_builder.billing_providers()


@app.get("/api/saas-builder/skills")
def saas_builder_skills():
    return saas_builder.skills()


@app.get("/api/saas-builder/nocode")
def saas_builder_nocode():
    return saas_builder.no_code_spec()


@app.get("/api/saas-builder/list")
def saas_builder_list(limit: int = 100):
    return saas_builder.list_projects(limit)


@app.post("/api/saas-builder/client")
def saas_builder_client(payload: SaaSBuilderClientRequest):
    return saas_builder.create_client(payload.name, payload.email, payload.company, payload.plan)


@app.post("/api/saas-builder/create")
def saas_builder_create(payload: SaaSBuilderCreateRequest):
    return saas_builder.create_project(
        idea=payload.idea,
        client_name=payload.client_name,
        company_name=payload.company_name,
        template=payload.template,
        segment=payload.segment,
        database=payload.database,
        app_name=payload.app_name,
        domain=payload.domain,
        primary_color=payload.primary_color,
        accent_color=payload.accent_color,
        logo_text=payload.logo_text,
        billing_provider=payload.billing_provider,
        deploy_target=payload.deploy_target,
    )


@app.post("/api/saas-builder/generate-code")
def saas_builder_generate_code(payload: SaaSBuilderProjectRequest):
    return saas_builder.generate_code(payload.project_id)


@app.post("/api/saas-builder/versions")
def saas_builder_versions(payload: SaaSBuilderProjectRequest):
    return saas_builder.versions(payload.project_id)


@app.post("/api/saas-builder/rollback")
def saas_builder_rollback(payload: SaaSBuilderRollbackRequest):
    return saas_builder.rollback(payload.project_id, payload.version_id)


@app.post("/api/saas-builder/deploy-plan")
def saas_builder_deploy_plan(payload: SaaSBuilderDeployRequest):
    return saas_builder.deploy_plan(payload.project_id, payload.target)


@app.post("/api/saas-builder/preview")
def saas_builder_preview(payload: SaaSBuilderProjectRequest):
    return saas_builder.preview_info(payload.project_id)


@app.get("/api/agent-runtime/status")
def agent_runtime_status():
    return agent_runtime.status()


@app.get("/api/agent-runtime/agents")
def agent_runtime_agents():
    return agent_runtime.agents()


@app.get("/api/agent-runtime/job-types")
def agent_runtime_job_types():
    return agent_runtime.job_types()


@app.get("/api/agent-runtime/nocode")
def agent_runtime_nocode():
    return agent_runtime.no_code_spec()


@app.get("/api/agent-runtime/list")
def agent_runtime_list(status: str = "", limit: int = 100):
    return agent_runtime.list_jobs(status, limit)


@app.post("/api/agent-runtime/create")
def agent_runtime_create(payload: AgentRuntimeCreateRequest):
    return agent_runtime.create_job(
        objective=payload.objective,
        job_type=payload.job_type,
        priority=payload.priority,
        agents=payload.agents,
        segment=payload.segment,
        database=payload.database,
        requires_approval=payload.requires_approval,
        estimated_human_minutes=payload.estimated_human_minutes,
        project=payload.project,
    )


@app.post("/api/agent-runtime/start")
def agent_runtime_start(payload: AgentRuntimeStartRequest):
    return agent_runtime.start_job(payload.job_id, payload.approved)


@app.post("/api/agent-runtime/approve-start")
def agent_runtime_approve_start(payload: AgentRuntimeJobRequest):
    return agent_runtime.approve_and_start(payload.job_id)


@app.post("/api/agent-runtime/advance")
def agent_runtime_advance(payload: AgentRuntimeAdvanceRequest):
    return agent_runtime.advance_job(payload.job_id, payload.steps_to_advance)


@app.post("/api/agent-runtime/run-complete")
def agent_runtime_run_complete(payload: AgentRuntimeStartRequest):
    return agent_runtime.run_to_completion(payload.job_id, payload.approved)


@app.post("/api/agent-runtime/pause")
def agent_runtime_pause(payload: AgentRuntimeJobRequest):
    return agent_runtime.pause_job(payload.job_id)


@app.post("/api/agent-runtime/resume")
def agent_runtime_resume(payload: AgentRuntimeJobRequest):
    return agent_runtime.resume_job(payload.job_id)


@app.post("/api/agent-runtime/cancel")
def agent_runtime_cancel(payload: AgentRuntimeCancelRequest):
    return agent_runtime.cancel_job(payload.job_id, payload.reason)


@app.post("/api/agent-runtime/retry-step")
def agent_runtime_retry_step(payload: AgentRuntimeRetryRequest):
    return agent_runtime.retry_step(payload.job_id, payload.step_id)


@app.post("/api/agent-runtime/scorecard")
def agent_runtime_scorecard(payload: AgentRuntimeJobRequest):
    return agent_runtime.scorecard(payload.job_id)


@app.get("/api/agent-runtime/metrics")
def agent_runtime_metrics():
    return {"ok": True, "metrics": agent_runtime.compute_metrics()}


@app.get("/api/agent-runtime/observability")
def agent_runtime_observability():
    return agent_runtime.observability()


@app.get("/api/agent-runtime/prometheus")
def agent_runtime_prometheus():
    from fastapi.responses import PlainTextResponse
    return PlainTextResponse(agent_runtime.prometheus_metrics_text())


@app.get("/api/agent-runtime/model-advisor")
def agent_runtime_model_advisor(task: str = "", has_gpu: bool = False, vram_gb: int = 0, cpu_only: bool = True):
    return agent_runtime.model_advisor(task, has_gpu, vram_gb, cpu_only)


@app.get("/api/human-voice/status")
def human_voice_status():
    return human_voice_assistant.status()


@app.get("/api/human-voice/profiles")
def human_voice_profiles():
    return human_voice_assistant.voice_profiles()


@app.post("/api/human-voice/profile")
def human_voice_set_profile(payload: HumanVoiceProfileRequest):
    return human_voice_assistant.set_voice_profile(payload.profile_id)


@app.get("/api/human-voice/personas")
def human_voice_personas():
    return human_voice_assistant.personas()


@app.post("/api/human-voice/persona")
def human_voice_set_persona(payload: HumanVoicePersonaRequest):
    return human_voice_assistant.set_persona(payload.persona_id, payload.department_role)


@app.get("/api/human-voice/avatar-themes")
def human_voice_avatar_themes():
    return human_voice_assistant.avatar_themes()


@app.get("/api/human-voice/policy")
def human_voice_policy():
    return human_voice_assistant.conversation_policy()


@app.get("/api/human-voice/clone-requirements")
def human_voice_clone_requirements():
    return human_voice_assistant.voice_clone_requirements()


@app.get("/api/human-voice/implementation-plan")
def human_voice_implementation_plan():
    return human_voice_assistant.implementation_plan()


@app.post("/api/human-voice/session")
def human_voice_session(payload: HumanVoiceSessionRequest):
    return human_voice_assistant.create_session(payload.user_name, payload.mode, payload.department_role, payload.channel)


@app.get("/api/human-voice/sessions")
def human_voice_sessions(limit: int = 50):
    return human_voice_assistant.list_sessions(limit)


@app.post("/api/human-voice/answer")
def human_voice_answer(payload: HumanVoiceAnswerRequest):
    return human_voice_assistant.human_answer(payload.message, payload.user_name, payload.department_role)


@app.get("/api/realtime-voice/status")
def realtime_voice_status():
    return realtime_voice_engine.status()


@app.get("/api/realtime-voice/config")
def realtime_voice_config():
    return realtime_voice_engine.get_config()


@app.post("/api/realtime-voice/config")
def realtime_voice_update_config(payload: RealtimeVoiceConfigRequest):
    return realtime_voice_engine.update_config(payload.config)


@app.get("/api/realtime-voice/policy")
def realtime_voice_policy():
    return realtime_voice_engine.turn_policy()


@app.get("/api/realtime-voice/client-script-spec")
def realtime_voice_client_script_spec():
    return realtime_voice_engine.client_script_spec()


@app.get("/api/realtime-voice/local-install-plan")
def realtime_voice_local_install_plan(cpu_only: bool = True, has_gpu: bool = False, vram_gb: int = 0):
    return realtime_voice_engine.local_install_plan(cpu_only, has_gpu, vram_gb)


@app.get("/api/realtime-voice/voice-sample-requirements")
def realtime_voice_sample_requirements():
    return realtime_voice_engine.voice_sample_requirements()


@app.post("/api/realtime-voice/session")
def realtime_voice_start_session(payload: RealtimeVoiceSessionRequest):
    return realtime_voice_engine.start_session(payload.user_name, payload.mode, payload.channel)


@app.get("/api/realtime-voice/sessions")
def realtime_voice_sessions(limit: int = 50):
    return realtime_voice_engine.list_sessions(limit)


@app.post("/api/realtime-voice/state")
def realtime_voice_state(payload: RealtimeVoiceStateRequest):
    return realtime_voice_engine.update_session_state(
        payload.session_id,
        payload.state,
        payload.partial_transcript,
        payload.final_transcript,
        payload.route,
    )


@app.post("/api/realtime-voice/stop")
def realtime_voice_stop(payload: RealtimeVoiceStopRequest):
    return realtime_voice_engine.stop_session(payload.session_id)


@app.post("/api/realtime-voice/natural-response")
def realtime_voice_natural_response(payload: RealtimeVoicePresetRequest):
    return realtime_voice_engine.natural_response_preset(payload.text)


@app.get("/api/open-ai-access/status")
def open_ai_access_status():
    return open_ai_access_center.status()


@app.get("/api/open-ai-access/hardware-profiles")
def open_ai_access_hardware_profiles():
    return open_ai_access_center.hardware_profiles()


@app.get("/api/open-ai-access/model-catalog")
def open_ai_access_model_catalog():
    return open_ai_access_center.model_catalog()


@app.get("/api/open-ai-access/business-modes")
def open_ai_access_business_modes():
    return open_ai_access_center.business_modes()


@app.get("/api/open-ai-access/marketplace")
def open_ai_access_marketplace():
    return open_ai_access_center.marketplace()


@app.post("/api/open-ai-access/profile")
def open_ai_access_set_profile(payload: OpenAIAccessProfileRequest):
    return open_ai_access_center.set_profile(payload.profile, payload.business_mode)


@app.post("/api/open-ai-access/recommend-stack")
def open_ai_access_recommend_stack(payload: OpenAIAccessRecommendRequest):
    return open_ai_access_center.recommend_stack(payload.profile, payload.use_case, payload.business_mode)


@app.post("/api/open-ai-access/installer-plan")
def open_ai_access_installer_plan(payload: OpenAIAccessProfileRequest):
    return open_ai_access_center.installer_plan(payload.profile, payload.business_mode or "small_business")


@app.post("/api/open-ai-access/enable-agent")
def open_ai_access_enable_agent(payload: OpenAIAccessAgentRequest):
    return open_ai_access_center.enable_agent(payload.agent_key)


@app.post("/api/open-ai-access/secure-access-plan")
def open_ai_access_secure_plan(payload: OpenAIAccessSecureRequest):
    return open_ai_access_center.secure_access_plan(payload.exposure, payload.domain)


@app.post("/api/open-ai-access/roi")
def open_ai_access_roi(payload: OpenAIAccessROIRequest):
    return open_ai_access_center.roi_calculator(
        payload.employees,
        payload.hours_per_week,
        payload.hourly_cost,
        payload.reduction_percent,
        payload.monthly_fee,
    )


@app.get("/api/open-ai-access/update-backup-plan")
def open_ai_access_update_backup_plan():
    return open_ai_access_center.update_and_backup_plan()


@app.get("/api/open-ai-access/health")
def open_ai_access_health():
    return open_ai_access_center.health_check()


# ---------------------------------------------------------------------------
# HAL Channel Gateway
# ---------------------------------------------------------------------------
@app.get("/api/channel-gateway/status")
def channel_gateway_status():
    return channel_gateway.status()


@app.get("/api/channel-gateway/channels")
def channel_gateway_channels():
    return channel_gateway.channels()


@app.post("/api/channel-gateway/configure")
def channel_gateway_configure(payload: ChannelGatewayConfigureRequest):
    return channel_gateway.configure_channel(payload.channel, payload.enabled, payload.credentials_env, payload.allowed_recipients)


@app.post("/api/channel-gateway/inbound")
def channel_gateway_inbound(payload: ChannelGatewayInboundRequest):
    return channel_gateway.inbound_message(payload.channel, payload.sender, payload.text, payload.metadata)


@app.post("/api/channel-gateway/outbound")
def channel_gateway_outbound(payload: ChannelGatewayOutboundRequest):
    return channel_gateway.outbound_message(payload.channel, payload.recipient, payload.text, payload.approved, payload.metadata)


@app.get("/api/channel-gateway/messages")
def channel_gateway_messages(channel: str = "", limit: int = 100):
    return channel_gateway.list_messages(channel, limit)


@app.get("/api/channel-gateway/webhook-spec")
def channel_gateway_webhook_spec(channel: str = ""):
    return channel_gateway.webhook_spec(channel)


@app.post("/api/channel-gateway/webhook/{channel}")
def channel_gateway_webhook(channel: str, payload: dict[str, Any]):
    return channel_gateway.inbound_message(channel, str(payload.get("sender", "")), str(payload.get("text", "")), payload.get("metadata", {}))


# ---------------------------------------------------------------------------
# HAL n8n Workflow Center
# ---------------------------------------------------------------------------
@app.get("/api/n8n/status")
def n8n_status():
    return n8n_workflow_center.status()


@app.post("/api/n8n/configure")
def n8n_configure(payload: N8NConfigureRequest):
    return n8n_workflow_center.configure(payload.base_url, payload.api_key_env, payload.approval_required)


@app.get("/api/n8n/templates")
def n8n_templates():
    return n8n_workflow_center.templates()


@app.post("/api/n8n/register")
def n8n_register(payload: N8NWorkflowRegisterRequest):
    return n8n_workflow_center.register_workflow(payload.name, payload.workflow_id, payload.webhook_url, payload.intent_keywords, payload.critical)


@app.get("/api/n8n/workflows")
def n8n_workflows(limit: int = 100):
    return n8n_workflow_center.list_workflows(limit)


@app.post("/api/n8n/execute")
def n8n_execute(payload: N8NExecuteRequest):
    return n8n_workflow_center.execute_workflow(payload.workflow_id, payload.payload, payload.approved)


@app.post("/api/n8n/callback")
def n8n_callback(payload: N8NCallbackRequest):
    return n8n_workflow_center.callback(payload.execution_id, payload.status_value, payload.result)


@app.get("/api/n8n/executions")
def n8n_executions(limit: int = 100):
    return n8n_workflow_center.list_executions(limit)


@app.get("/api/n8n/map-intent")
def n8n_map_intent(message: str = ""):
    return n8n_workflow_center.map_intent(message)


# ---------------------------------------------------------------------------
# HAL Browser Automation
# ---------------------------------------------------------------------------
@app.get("/api/browser-automation/status")
def browser_automation_status():
    return browser_automation.status()


@app.get("/api/browser-automation/policy")
def browser_automation_policy():
    return browser_automation.policy()


@app.post("/api/browser-automation/session")
def browser_automation_session(payload: BrowserSessionRequest):
    return browser_automation.create_session(payload.name, payload.headless, payload.allowed_domains)


@app.get("/api/browser-automation/sessions")
def browser_automation_sessions(limit: int = 100):
    return browser_automation.list_sessions(limit)


@app.post("/api/browser-automation/action")
def browser_automation_action(payload: BrowserActionRequest):
    return browser_automation.record_action(payload.session_id, payload.action, payload.target, payload.value, payload.approved)


@app.get("/api/browser-automation/actions")
def browser_automation_actions(session_id: str = "", limit: int = 100):
    return browser_automation.list_actions(session_id, limit)


@app.post("/api/browser-automation/action-plan")
def browser_automation_action_plan(payload: BrowserActionPlanRequest):
    return browser_automation.action_plan(payload.url, payload.goal)


@app.get("/api/browser-automation/install-plan")
def browser_automation_install_plan():
    return browser_automation.install_plan()


# ---------------------------------------------------------------------------
# HAL Cron Enterprise
# ---------------------------------------------------------------------------
@app.get("/api/cron-enterprise/status")
def cron_enterprise_status():
    return cron_enterprise.status()


@app.post("/api/cron-enterprise/create")
def cron_enterprise_create(payload: CronCreateRequest):
    return cron_enterprise.create_job(payload.name, payload.prompt, payload.frequency, payload.cron, payload.channel, payload.enabled, payload.max_retries)


@app.get("/api/cron-enterprise/jobs")
def cron_enterprise_jobs(limit: int = 100):
    return cron_enterprise.list_jobs(limit)


@app.post("/api/cron-enterprise/set-enabled")
def cron_enterprise_set_enabled(payload: CronJobRequest):
    return cron_enterprise.set_enabled(payload.job_id, payload.enabled)


@app.post("/api/cron-enterprise/run")
def cron_enterprise_run(payload: CronJobRequest):
    return cron_enterprise.run_job(payload.job_id, payload.approved)


@app.get("/api/cron-enterprise/runs")
def cron_enterprise_runs(limit: int = 100):
    return cron_enterprise.list_runs(limit)


@app.get("/api/cron-enterprise/service-install-plan")
def cron_enterprise_service_install_plan():
    return cron_enterprise.service_install_plan()


# ---------------------------------------------------------------------------
# HAL Sandbox Enterprise
# ---------------------------------------------------------------------------
@app.get("/api/sandbox-enterprise/status")
def sandbox_enterprise_status():
    return sandbox_enterprise.status()


@app.post("/api/sandbox-enterprise/create")
def sandbox_enterprise_create(payload: SandboxCreateRequest):
    return sandbox_enterprise.create_sandbox(payload.name, payload.purpose, payload.agent, payload.network, payload.memory, payload.timeout_seconds)


@app.get("/api/sandbox-enterprise/list")
def sandbox_enterprise_list(limit: int = 100):
    return sandbox_enterprise.list_sandboxes(limit)


@app.post("/api/sandbox-enterprise/secret")
def sandbox_enterprise_secret(payload: SandboxSecretRequest):
    return sandbox_enterprise.register_secret(payload.name, payload.env_var, payload.scope, payload.description)


@app.get("/api/sandbox-enterprise/secrets")
def sandbox_enterprise_secrets(limit: int = 100):
    return sandbox_enterprise.list_secrets(limit)


@app.get("/api/sandbox-enterprise/policy")
def sandbox_enterprise_policy():
    return sandbox_enterprise.policy()


@app.post("/api/sandbox-enterprise/execution-plan")
def sandbox_enterprise_execution_plan(payload: SandboxExecutionPlanRequest):
    return sandbox_enterprise.execution_plan(payload.command, payload.sandbox_id, payload.approved)


@app.get("/api/sandbox-enterprise/install-plan")
def sandbox_enterprise_install_plan():
    return sandbox_enterprise.install_plan()


# ---------------------------------------------------------------------------
# HAL Agent Framework Bridge
# ---------------------------------------------------------------------------
@app.get("/api/framework-bridge/status")
def framework_bridge_status():
    return agent_framework_bridge.status()


@app.get("/api/framework-bridge/frameworks")
def framework_bridge_frameworks():
    return agent_framework_bridge.frameworks()


@app.post("/api/framework-bridge/configure")
def framework_bridge_configure(payload: FrameworkConfigureRequest):
    return agent_framework_bridge.configure_framework(payload.framework, payload.enabled)


@app.get("/api/framework-bridge/recommend")
def framework_bridge_recommend(goal: str = ""):
    return agent_framework_bridge.recommend_framework(goal)


@app.post("/api/framework-bridge/run")
def framework_bridge_run(payload: FrameworkRunRequest):
    return agent_framework_bridge.create_bridge_run(payload.goal, payload.framework, payload.approved)


@app.get("/api/framework-bridge/runs")
def framework_bridge_runs(limit: int = 100):
    return agent_framework_bridge.list_runs(limit)


@app.get("/api/framework-bridge/install-plan")
def framework_bridge_install_plan():
    return agent_framework_bridge.install_plan()


# ---------------------------------------------------------------------------
# HAL Visual Mission Control
# ---------------------------------------------------------------------------
@app.get("/api/visual-mission/status")
def visual_mission_status():
    return visual_mission_control.status()


@app.get("/api/visual-mission/config")
def visual_mission_config():
    return visual_mission_control.config()


@app.post("/api/visual-mission/config")
def visual_mission_update_config(payload: VisualMissionConfigRequest):
    return visual_mission_control.update_config(payload.changes)


@app.get("/api/visual-mission/rooms")
def visual_mission_rooms():
    return visual_mission_control.rooms()


@app.get("/api/visual-mission/agents")
def visual_mission_agents():
    return visual_mission_control.agents()


@app.get("/api/visual-mission/map")
def visual_mission_map():
    return visual_mission_control.visual_map()


@app.post("/api/visual-mission/create")
def visual_mission_create(payload: VisualMissionCreateRequest):
    return visual_mission_control.create_mission(
        title=payload.title,
        objective=payload.objective,
        agents_list=payload.agents,
        priority=payload.priority,
        source=payload.source,
        requires_approval=payload.requires_approval,
        presentation=payload.presentation,
    )


@app.get("/api/visual-mission/list")
def visual_mission_list(status_filter: str = "", limit: int = 100):
    return visual_mission_control.list_missions(status_filter, limit)


@app.post("/api/visual-mission/update")
def visual_mission_update(payload: VisualMissionUpdateRequest):
    return visual_mission_control.update_mission(payload.mission_id, payload.status_value, payload.progress, payload.result_summary)


@app.post("/api/visual-mission/advance")
def visual_mission_advance(payload: VisualMissionIdRequest):
    return visual_mission_control.advance_mission(payload.mission_id)


@app.get("/api/visual-mission/approvals")
def visual_mission_approvals(limit: int = 100):
    return visual_mission_control.list_approvals(limit)


@app.post("/api/visual-mission/approve")
def visual_mission_approve(payload: VisualMissionApprovalRequest):
    return visual_mission_control.approve(payload.approval_id)


@app.get("/api/visual-mission/notes")
def visual_mission_notes():
    return visual_mission_control.notes()


@app.post("/api/visual-mission/note")
def visual_mission_note(payload: VisualMissionNoteRequest):
    return visual_mission_control.add_note(payload.text)


@app.get("/api/visual-mission/metrics")
def visual_mission_metrics():
    return visual_mission_control.metrics()


@app.get("/api/visual-mission/presentation")
def visual_mission_presentation():
    return visual_mission_control.presentation_snapshot()


@app.post("/api/visual-mission/seed-demo")
def visual_mission_seed_demo():
    return visual_mission_control.seed_demo()


# ---------------------------------------------------------------------------
# HAL Universal ERP & Application Connector
# ---------------------------------------------------------------------------
@app.get("/api/universal-erp/status")
def universal_erp_status():
    return universal_erp_connector.status()


@app.get("/api/universal-erp/catalog")
def universal_erp_catalog():
    return universal_erp_connector.catalog()


@app.post("/api/universal-erp/register-connection")
def universal_erp_register_connection(payload: UniversalERPConnectionRequest):
    return universal_erp_connector.register_connection(
        payload.name, payload.connector_type, payload.database, payload.system_name,
        payload.env_prefix, payload.readonly, payload.description
    )


@app.get("/api/universal-erp/connections")
def universal_erp_connections(limit: int = 100):
    return universal_erp_connector.list_connections(limit)


@app.post("/api/universal-erp/register-mapping")
def universal_erp_register_mapping(payload: UniversalERPMappingRequest):
    return universal_erp_connector.register_mapping(
        payload.connection_id, payload.business_entity, payload.physical_target,
        payload.fields, payload.access_method, payload.notes
    )


@app.get("/api/universal-erp/mappings")
def universal_erp_mappings(limit: int = 100):
    return universal_erp_connector.list_mappings(limit)


@app.post("/api/universal-erp/query-plan")
def universal_erp_query_plan(payload: UniversalERPQueryPlanRequest):
    return universal_erp_connector.create_query_plan(payload.question, payload.connection_id, payload.approved)


@app.get("/api/universal-erp/query-plans")
def universal_erp_query_plans(limit: int = 100):
    return universal_erp_connector.list_query_plans(limit)


@app.post("/api/universal-erp/seed-transport-pack")
def universal_erp_seed_transport_pack():
    return universal_erp_connector.seed_transport_pack()


@app.get("/api/universal-erp/safe-policy")
def universal_erp_safe_policy():
    return universal_erp_connector.safe_action_policy()


# ---------------------------------------------------------------------------
# HAL Reliable Web Answer Engine
# ---------------------------------------------------------------------------
@app.get("/api/reliable-web/status")
def reliable_web_status():
    return reliable_web_answer.status()


@app.get("/api/reliable-web/trusted-sources")
def reliable_web_trusted_sources():
    return reliable_web_answer.trusted_sources()


@app.post("/api/reliable-web/answer")
def reliable_web_answer_endpoint(payload: ReliableWebAnswerRequest):
    return reliable_web_answer.answer_question(payload.message, payload.approved, payload.max_sources)


# ---------------------------------------------------------------------------
# HAL Industry Precision Engine
# ---------------------------------------------------------------------------
@app.get("/api/industry-precision/status")
def industry_precision_status():
    return industry_precision_engine.status()


@app.get("/api/industry-precision/catalog")
def industry_precision_catalog():
    return industry_precision_engine.catalog()


@app.post("/api/industry-precision/classify")
def industry_precision_classify(payload: IndustryPrecisionAnswerRequest):
    return industry_precision_engine.classify(payload.message)


@app.post("/api/industry-precision/answer")
def industry_precision_answer(payload: IndustryPrecisionAnswerRequest):
    return industry_precision_engine.answer(payload.message, payload.context, payload.approved)


@app.post("/api/industry-precision/profile")
def industry_precision_profile(payload: IndustryProfileRequest):
    return industry_precision_engine.create_industry_profile(
        payload.industry_key, payload.company_name, payload.systems, payload.processes, payload.approval_level
    )


@app.get("/api/industry-precision/profiles")
def industry_precision_profiles(limit: int = 100):
    return industry_precision_engine.list_profiles(limit)


@app.post("/api/industry-precision/test-case")
def industry_precision_test_case(payload: IndustryTestCaseRequest):
    return industry_precision_engine.create_test_case(payload.industry_key, payload.question, payload.expected_behavior, payload.expected_tool)


@app.post("/api/industry-precision/seed-tests")
def industry_precision_seed_tests():
    return industry_precision_engine.seed_precision_tests()


@app.get("/api/industry-precision/run-tests")
def industry_precision_run_tests(limit: int = 100):
    return industry_precision_engine.run_precision_tests(limit)


# ---------------------------------------------------------------------------
# HAL Database Access Wizard
# ---------------------------------------------------------------------------
@app.get("/api/database-access/status")
def database_access_status():
    return database_access_wizard.status()


@app.get("/api/database-access/catalog")
def database_access_catalog():
    return database_access_wizard.catalog()


@app.post("/api/database-access/register-connection")
def database_access_register_connection(payload: DatabaseAccessRegisterConnectionRequest):
    return database_access_wizard.register_connection(
        payload.name,
        payload.database_type,
        payload.env_prefix,
        payload.host,
        payload.port,
        payload.database_name,
        payload.schema_or_keyspace,
        payload.readonly,
        payload.description,
    )


@app.get("/api/database-access/connections")
def database_access_connections(database_type: str = "", limit: int = 100):
    return database_access_wizard.list_connections(database_type, limit)


@app.post("/api/database-access/data-request")
def database_access_data_request(payload: DatabaseAccessDataRequest):
    return database_access_wizard.create_data_request(
        payload.user_question,
        payload.connection_id,
        payload.database_type,
        payload.entities_or_tables,
        payload.filters,
        payload.metrics_or_fields,
        payload.output_format,
        payload.approved,
    )


@app.get("/api/database-access/requests")
def database_access_requests(limit: int = 100):
    return database_access_wizard.list_requests(limit)


@app.post("/api/database-access/query-plan")
def database_access_query_plan(payload: DatabaseAccessQueryPlanRequest):
    return database_access_wizard.create_query_plan(payload.request_id, payload.user_question, payload.connection_id, payload.approved)


@app.get("/api/database-access/plans")
def database_access_plans(limit: int = 100):
    return database_access_wizard.list_plans(limit)


@app.post("/api/database-access/guided-answer")
def database_access_guided_answer(payload: DatabaseAccessGuidedRequest):
    return database_access_wizard.guided_answer(payload.message, payload.approved)


@app.post("/api/database-access/seed-examples")
def database_access_seed_examples():
    return database_access_wizard.seed_examples()


# ---------------------------------------------------------------------------
# HAL Human Conversation Gateway
# ---------------------------------------------------------------------------
@app.get("/api/human-conversation/status")
def human_conversation_status():
    return human_conversation_gateway.status()


@app.get("/api/human-conversation/policy")
def human_conversation_policy():
    return human_conversation_gateway.conversation_policy()


@app.post("/api/human-conversation/start")
def human_conversation_start(channel: str = "web", user_name: str = ""):
    return human_conversation_gateway.start_session(channel, user_name)


@app.post("/api/human-conversation/converse")
def human_conversation_converse(payload: HumanConversationRequest):
    return human_conversation_gateway.converse(
        payload.message,
        payload.session_id,
        payload.user_name,
        payload.approved,
        payload.run_tools,
    )


@app.get("/api/human-conversation/sessions")
def human_conversation_sessions(limit: int = 50):
    return human_conversation_gateway.list_sessions(limit)


@app.post("/api/human-conversation/preference")
def human_conversation_preference(payload: HumanConversationPreferenceRequest):
    return human_conversation_gateway.set_preference(payload.key, payload.value)


# ---------------------------------------------------------------------------
# HAL Enterprise Integration & Team Intelligence
# ---------------------------------------------------------------------------
@app.get("/api/enterprise-intelligence/status")
def enterprise_intelligence_status():
    return enterprise_integration_team_intelligence.status()


@app.get("/api/enterprise-intelligence/catalog")
def enterprise_intelligence_catalog():
    return enterprise_integration_team_intelligence.catalog()


@app.post("/api/enterprise-intelligence/register-tool")
def enterprise_intelligence_register_tool(payload: EnterpriseToolRegisterRequest):
    return enterprise_integration_team_intelligence.register_tool(
        payload.tool_key, payload.name, payload.env_prefix, payload.owner_team, payload.enabled
    )


@app.get("/api/enterprise-intelligence/tools")
def enterprise_intelligence_tools(category: str = "", limit: int = 100):
    return enterprise_integration_team_intelligence.list_tools(category, limit)


@app.post("/api/enterprise-intelligence/create-team")
def enterprise_intelligence_create_team(payload: EnterpriseTeamCreateRequest):
    return enterprise_integration_team_intelligence.create_team(
        payload.department_key, payload.segment_key, payload.name, payload.users, payload.autonomy_level
    )


@app.get("/api/enterprise-intelligence/teams")
def enterprise_intelligence_teams(limit: int = 100):
    return enterprise_integration_team_intelligence.list_teams(limit)


@app.post("/api/enterprise-intelligence/register-user")
def enterprise_intelligence_register_user(payload: EnterpriseUserRegisterRequest):
    return enterprise_integration_team_intelligence.register_user(
        payload.name, payload.department_key, payload.role, payload.preferred_channels, payload.personal_mode
    )


@app.get("/api/enterprise-intelligence/users")
def enterprise_intelligence_users(limit: int = 100):
    return enterprise_integration_team_intelligence.list_users(limit)


@app.get("/api/enterprise-intelligence/agendas")
def enterprise_intelligence_agendas(owner_type: str = "", limit: int = 100):
    return enterprise_integration_team_intelligence.list_agendas(owner_type, limit)


@app.post("/api/enterprise-intelligence/task")
def enterprise_intelligence_task(payload: EnterpriseTaskRequest):
    return enterprise_integration_team_intelligence.create_task_from_message(
        payload.message, payload.user_id, payload.team_id, payload.approved
    )


@app.get("/api/enterprise-intelligence/tasks")
def enterprise_intelligence_tasks(limit: int = 100):
    return enterprise_integration_team_intelligence.list_tasks(limit)


@app.post("/api/enterprise-intelligence/guided-answer")
def enterprise_intelligence_guided_answer(payload: EnterpriseTaskRequest):
    return enterprise_integration_team_intelligence.guided_answer(payload.message, payload.approved)


@app.post("/api/enterprise-intelligence/seed-enterprise")
def enterprise_intelligence_seed_enterprise():
    return enterprise_integration_team_intelligence.seed_enterprise()


# ---------------------------------------------------------------------------
# HAL Meeting Intelligence Gateway
# ---------------------------------------------------------------------------
@app.get("/api/meeting-intelligence/status")
def meeting_intelligence_status():
    return meeting_intelligence_gateway.status()


@app.get("/api/meeting-intelligence/catalog")
def meeting_intelligence_catalog():
    return meeting_intelligence_gateway.catalog()


@app.post("/api/meeting-intelligence/config")
def meeting_intelligence_config(payload: MeetingConfigRequest):
    return meeting_intelligence_gateway.update_config(payload.changes)


@app.post("/api/meeting-intelligence/start")
def meeting_intelligence_start(payload: MeetingStartRequest):
    return meeting_intelligence_gateway.start_meeting(
        payload.title,
        payload.platform,
        payload.meeting_url,
        payload.mode,
        payload.organizer,
        payload.participants,
        payload.voice_response,
        payload.text_response,
        payload.consent_confirmed,
    )


@app.post("/api/meeting-intelligence/confirm-consent")
def meeting_intelligence_confirm_consent(payload: MeetingConsentRequest):
    return meeting_intelligence_gateway.confirm_consent(payload.meeting_id)


@app.get("/api/meeting-intelligence/meetings")
def meeting_intelligence_meetings(status_filter: str = "", limit: int = 100):
    return meeting_intelligence_gateway.list_meetings(status_filter, limit)


@app.post("/api/meeting-intelligence/transcript")
def meeting_intelligence_transcript(payload: MeetingTranscriptRequest):
    return meeting_intelligence_gateway.add_transcript(payload.meeting_id, payload.speaker, payload.text, payload.timestamp)


@app.post("/api/meeting-intelligence/question")
def meeting_intelligence_question(payload: MeetingQuestionRequest):
    return meeting_intelligence_gateway.ask_question(
        payload.meeting_id,
        payload.question,
        payload.speaker,
        payload.respond_voice,
        payload.respond_text,
        payload.approved,
    )


@app.get("/api/meeting-intelligence/questions")
def meeting_intelligence_questions(meeting_id: str = "", limit: int = 100):
    return meeting_intelligence_gateway.list_questions(meeting_id, limit)


@app.post("/api/meeting-intelligence/minutes")
def meeting_intelligence_minutes(payload: MeetingConsentRequest):
    return meeting_intelligence_gateway.generate_minutes(payload.meeting_id)


@app.get("/api/meeting-intelligence/minutes")
def meeting_intelligence_list_minutes(meeting_id: str = "", limit: int = 100):
    return meeting_intelligence_gateway.list_minutes(meeting_id, limit)


@app.get("/api/meeting-intelligence/actions")
def meeting_intelligence_actions(meeting_id: str = "", status_filter: str = "", limit: int = 100):
    return meeting_intelligence_gateway.list_actions(meeting_id, status_filter, limit)


@app.post("/api/meeting-intelligence/seed-demo")
def meeting_intelligence_seed_demo():
    return meeting_intelligence_gateway.seed_demo()


# ---------------------------------------------------------------------------
# HAL Omnichannel Voice/Text Delivery
# ---------------------------------------------------------------------------
@app.get("/api/omnichannel/status")
def omnichannel_status():
    return omnichannel_voice_text_delivery.status()


@app.get("/api/omnichannel/catalog")
def omnichannel_catalog():
    return omnichannel_voice_text_delivery.catalog()


@app.post("/api/omnichannel/config")
def omnichannel_config(payload: OmnichannelConfigRequest):
    return omnichannel_voice_text_delivery.update_config(payload.changes)


@app.post("/api/omnichannel/contact")
def omnichannel_contact(payload: OmnichannelContactRequest):
    return omnichannel_voice_text_delivery.register_contact(
        payload.name,
        payload.channel,
        payload.recipient,
        payload.user_id,
        payload.team_id,
        payload.department,
        payload.send_text,
        payload.send_voice,
        payload.active,
    )


@app.get("/api/omnichannel/contacts")
def omnichannel_contacts(channel: str = "", department: str = "", limit: int = 100):
    return omnichannel_voice_text_delivery.list_contacts(channel, department, limit)


@app.post("/api/omnichannel/deliver")
def omnichannel_deliver(payload: OmnichannelDeliveryRequest):
    return omnichannel_voice_text_delivery.create_delivery(
        payload.question,
        payload.answer,
        payload.channel or ("email" if payload.requester_email else ""),
        payload.recipient or payload.requester_email,
        None,
        payload.send_text,
        payload.send_voice,
        payload.approved,
        payload.source,
    )


@app.get("/api/omnichannel/deliveries")
def omnichannel_deliveries(status_filter: str = "", channel: str = "", limit: int = 100):
    return omnichannel_voice_text_delivery.list_deliveries(status_filter, channel, limit)


@app.post("/api/omnichannel/approve-send")
def omnichannel_approve_send(payload: OmnichannelApproveRequest):
    return omnichannel_voice_text_delivery.approve_and_send(payload.delivery_id)


@app.post("/api/omnichannel/seed-demo")
def omnichannel_seed_demo():
    return omnichannel_voice_text_delivery.seed_demo()


# ---------------------------------------------------------------------------
# HAL Executive Financial Intelligence
# ---------------------------------------------------------------------------
@app.get("/api/executive-finance/status")
def executive_finance_status():
    return executive_financial_intelligence.status()


@app.get("/api/executive-finance/catalog")
def executive_finance_catalog():
    return executive_financial_intelligence.catalog()


@app.post("/api/executive-finance/config")
def executive_finance_config(payload: ExecutiveFinancialConfigRequest):
    return executive_financial_intelligence.update_config(payload.changes)


@app.post("/api/executive-finance/rules")
def executive_finance_rules(payload: ExecutiveFinancialConfigRequest):
    return executive_financial_intelligence.update_rules(payload.changes)


@app.post("/api/executive-finance/source")
def executive_finance_source(payload: ExecutiveFinancialSourceRequest):
    return executive_financial_intelligence.register_source(
        payload.name,
        payload.source_type,
        payload.connection_ref,
        payload.system,
        payload.company,
        payload.description,
        payload.enabled,
    )


@app.get("/api/executive-finance/sources")
def executive_finance_sources(source_type: str = "", limit: int = 100):
    return executive_financial_intelligence.list_sources(source_type, limit)


@app.post("/api/executive-finance/snapshot")
def executive_finance_snapshot(payload: ExecutiveFinancialSnapshotRequest):
    return executive_financial_intelligence.save_snapshot(
        payload.period,
        payload.company,
        payload.branch,
        payload.cost_center,
        payload.values,
        payload.source,
    )


@app.get("/api/executive-finance/snapshots")
def executive_finance_snapshots(period: str = "", company: str = "", limit: int = 100):
    return executive_financial_intelligence.list_snapshots(period, company, limit)


@app.post("/api/executive-finance/ask")
def executive_finance_ask(payload: ExecutiveFinancialQuestionRequest):
    return executive_financial_intelligence.guided_answer(payload.message, payload.approved, payload.values)


@app.get("/api/executive-finance/requests")
def executive_finance_requests(status_filter: str = "", limit: int = 100):
    return executive_financial_intelligence.list_requests(status_filter, limit)


@app.post("/api/executive-finance/seed-demo")
def executive_finance_seed_demo():
    return executive_financial_intelligence.seed_demo()


# ---------------------------------------------------------------------------
# HAL Skills & Multi-Agent Center
# ---------------------------------------------------------------------------
@app.get("/api/skills-center/status")
def skills_center_status():
    return skills_multi_agent_center.status()


@app.get("/api/skills-center/skills")
def skills_center_skills(category: str = "", query: str = ""):
    return skills_multi_agent_center.list_skills(category, query)


@app.get("/api/skills-center/skill/{skill_id}")
def skills_center_get_skill(skill_id: str):
    return skills_multi_agent_center.get_skill(skill_id)


@app.post("/api/skills-center/skill")
def skills_center_create_skill(payload: SkillsCenterSkillRequest):
    return skills_multi_agent_center.create_skill(payload.skill_id, payload.name, payload.category, payload.body, payload.risk, payload.agent)


@app.post("/api/skills-center/install-text")
def skills_center_install_text(payload: SkillsCenterInstallTextRequest):
    return skills_multi_agent_center.install_skill_from_text(payload.file_name, payload.content, payload.install_to_hub)


@app.get("/api/skills-center/hub")
def skills_center_hub(query: str = ""):
    return skills_multi_agent_center.list_hub(query)


@app.post("/api/skills-center/install-from-hub/{skill_id}")
def skills_center_install_from_hub(skill_id: str):
    return skills_multi_agent_center.install_from_hub(skill_id)


@app.post("/api/skills-center/run")
def skills_center_run(payload: SkillsCenterRunRequest):
    return skills_multi_agent_center.run_skill(payload.skill_id, payload.input_text, payload.context, payload.approved)


@app.get("/api/skills-center/agents")
def skills_center_agents():
    return skills_multi_agent_center.list_agents()


@app.post("/api/skills-center/agent")
def skills_center_agent(payload: SkillsCenterAgentRequest):
    return skills_multi_agent_center.register_agent(payload.name, payload.role, payload.skills, payload.enabled)


@app.post("/api/skills-center/spawn-session")
def skills_center_spawn_session(payload: SkillsCenterSessionRequest):
    return skills_multi_agent_center.spawn_session(payload.objective, payload.agents, payload.parent_session_id, payload.context)


@app.get("/api/skills-center/sessions")
def skills_center_sessions(limit: int = 100):
    return skills_multi_agent_center.list_sessions(limit)


@app.post("/api/skills-center/delegate-task")
def skills_center_delegate_task(payload: SkillsCenterTaskRequest):
    return skills_multi_agent_center.delegate_task(payload.objective, payload.agent_id, payload.skill_id, payload.session_id, payload.approved)


@app.get("/api/skills-center/tasks")
def skills_center_tasks(status_filter: str = "", limit: int = 100):
    return skills_multi_agent_center.list_tasks(status_filter, limit)


@app.post("/api/skills-center/collaborate")
def skills_center_collaborate(payload: SkillsCenterCollaborationRequest):
    return skills_multi_agent_center.collaborate(payload.objective, payload.agents, payload.approved)


@app.post("/api/skills-center/image-brief")
def skills_center_image_brief(payload: SkillsCenterImageRequest):
    return skills_multi_agent_center.create_image_brief(payload.prompt, payload.context, payload.style, payload.size)


@app.get("/api/skills-center/image-briefs")
def skills_center_image_briefs(limit: int = 100):
    return skills_multi_agent_center.list_image_briefs(limit)


@app.post("/api/skills-center/config")
def skills_center_config(payload: SkillsCenterConfigRequest):
    return skills_multi_agent_center.update_config(payload.changes)


@app.post("/api/skills-center/ask")
def skills_center_ask(payload: SkillsCenterQuestionRequest):
    return skills_multi_agent_center.guided_answer(payload.message, payload.approved)


@app.post("/api/skills-center/seed-demo")
def skills_center_seed_demo():
    return skills_multi_agent_center.seed_demo()


# ---------------------------------------------------------------------------
# HAL Local STT Fallback
# ---------------------------------------------------------------------------
@app.get("/api/stt/status")
def stt_status():
    return local_stt_fallback.status()


@app.post("/api/stt/config")
def stt_config(payload: STTConfigRequest):
    return local_stt_fallback.configure(payload.changes)


@app.post("/api/stt/transcribe")
async def stt_transcribe(file: UploadFile = File(...), language: str = Form("pt")):
    data = await file.read()
    suffix = Path(file.filename or "audio.webm").suffix or ".webm"
    path = local_stt_fallback.save_audio(data, suffix=suffix)
    return local_stt_fallback.transcribe_file(path, language=language)


# ---------------------------------------------------------------------------
# HAL Software Builder Center
# ---------------------------------------------------------------------------
@app.get("/api/software-builder/status")
def software_builder_status():
    return software_builder_center.status()


@app.post("/api/software-builder/plan")
def software_builder_plan(payload: SoftwareBuilderRequest):
    res = software_builder_center.build_plan(payload.message)
    if payload.generate_project:
        res["generated_project"] = software_builder_center.generate_personal_finance_project(payload.project_name)
    return res


@app.post("/api/software-builder/generate-personal-finance")
def software_builder_generate_personal_finance(payload: SoftwareBuilderRequest):
    return software_builder_center.generate_personal_finance_project(payload.project_name)


@app.get("/api/software-builder/requests")
def software_builder_requests(limit: int = 50):
    return software_builder_center.list_requests(limit)


# ---------------------------------------------------------------------------
# HAL App Factory Pro
# ---------------------------------------------------------------------------
@app.get("/api/app-factory/status")
def app_factory_status():
    return app_factory_pro.status()


@app.get("/api/app-factory/catalog")
def app_factory_catalog():
    return app_factory_pro.catalog()


@app.post("/api/app-factory/config")
def app_factory_config(payload: AppFactoryRequest):
    return app_factory_pro.configure(payload.changes)


@app.post("/api/app-factory/blueprint")
def app_factory_blueprint(payload: AppFactoryRequest):
    return app_factory_pro.blueprint_from_prompt(payload.message, payload.app_name)


@app.post("/api/app-factory/generate")
def app_factory_generate(payload: AppFactoryRequest):
    return app_factory_pro.generate_app(payload.message, payload.app_name, payload.template_id, payload.include_sample_data)


@app.post("/api/app-factory/quality-gate")
def app_factory_quality_gate(payload: AppFactoryRequest):
    data = app_factory_pro.generate_app(payload.message, payload.app_name, payload.template_id, payload.include_sample_data) if payload.generate else app_factory_pro.blueprint_from_prompt(payload.message, payload.app_name)
    path = data.get("path") or data.get("app", {}).get("path", "")
    if path:
        return app_factory_pro.run_quality_gate(path)
    return {"ok": False, "error": "Nenhum app gerado para validar."}


@app.get("/api/app-factory/requests")
def app_factory_requests(limit: int = 50):
    return app_factory_pro.list_requests(limit)


# ---------------------------------------------------------------------------
# HAL Enterprise Productization V13
# ---------------------------------------------------------------------------
@app.get("/api/enterprise-v13/status")
def enterprise_v13_status():
    return enterprise_productization_v13.status()


@app.get("/api/enterprise-v13/health")
def enterprise_v13_health():
    return enterprise_productization_v13.platform_health()


@app.get("/api/enterprise-v13/integrations")
def enterprise_v13_integrations():
    return enterprise_productization_v13.integration_status()


@app.get("/api/enterprise-v13/skills")
def enterprise_v13_skills(seed: bool = False):
    return enterprise_productization_v13.skills_library(seed=seed)


@app.get("/api/enterprise-v13/templates")
def enterprise_v13_templates():
    return enterprise_productization_v13.template_bank()


@app.get("/api/enterprise-v13/router-tests")
def enterprise_v13_router_tests(run: bool = True):
    return enterprise_productization_v13.router_test_suite(run=run)


@app.get("/api/enterprise-v13/quality-gate")
def enterprise_v13_quality_gate():
    return enterprise_productization_v13.global_quality_gate()


@app.get("/api/enterprise-v13/fleet")
def enterprise_v13_fleet():
    return enterprise_productization_v13.fleet_status()


@app.post("/api/enterprise-v13/fleet/task")
def enterprise_v13_fleet_task(payload: EnterpriseV13Request):
    return enterprise_productization_v13.create_fleet_task(payload.agent_id, payload.instruction or payload.message, payload.schedule, approval_required=payload.approved)


@app.post("/api/enterprise-v13/fleet/task/approve")
def enterprise_v13_fleet_task_approve(payload: EnterpriseV13Request):
    return enterprise_productization_v13.approve_fleet_task(payload.task_id, payload.approved)


@app.get("/api/enterprise-v13/knowledge")
def enterprise_v13_knowledge():
    return enterprise_productization_v13.list_knowledge()


@app.post("/api/enterprise-v13/knowledge/ingest")
def enterprise_v13_knowledge_ingest(payload: EnterpriseV13Request):
    return enterprise_productization_v13.ingest_knowledge(payload.title or "Documento", payload.text or payload.message, payload.source)


@app.post("/api/enterprise-v13/knowledge/search")
def enterprise_v13_knowledge_search(payload: EnterpriseV13Request):
    return enterprise_productization_v13.search_knowledge(payload.query or payload.message)


@app.get("/api/enterprise-v13/white-label")
def enterprise_v13_white_label():
    return enterprise_productization_v13.white_label_config()


@app.post("/api/enterprise-v13/white-label")
def enterprise_v13_white_label_update(payload: EnterpriseV13Request):
    return enterprise_productization_v13.white_label_config(payload.changes)


@app.post("/api/enterprise-v13/deploy-plan")
def enterprise_v13_deploy_plan(payload: EnterpriseV13Request):
    return enterprise_productization_v13.deploy_plan(payload.target, payload.app_path)


@app.post("/api/enterprise-v13/github-manifest")
def enterprise_v13_github_manifest(payload: EnterpriseV13Request):
    return enterprise_productization_v13.github_manifest(payload.repo_name, payload.app_path)


# ---------------------------------------------------------------------------
# HAL Cyber Defense & Ransomware Shield V14
# ---------------------------------------------------------------------------
@app.get("/api/cyber-defense/status")
def cyber_defense_status():
    return cyber_defense_shield.status()


@app.post("/api/cyber-defense/config")
def cyber_defense_config(payload: CyberDefenseRequest):
    return cyber_defense_shield.configure(payload.changes)


@app.get("/api/cyber-defense/integrations")
def cyber_defense_integrations():
    return cyber_defense_shield.integration_status()


@app.post("/api/cyber-defense/email/analyze")
def cyber_defense_email_analyze(payload: CyberDefenseRequest):
    return cyber_defense_shield.analyze_email(payload.email or payload.changes)


@app.post("/api/cyber-defense/canaries")
def cyber_defense_canaries(payload: CyberDefenseRequest):
    return cyber_defense_shield.deploy_canaries(payload.paths)


@app.post("/api/cyber-defense/baseline")
def cyber_defense_baseline(payload: CyberDefenseRequest):
    return cyber_defense_shield.create_baseline(payload.paths)


@app.post("/api/cyber-defense/scan")
def cyber_defense_scan(payload: CyberDefenseRequest):
    return cyber_defense_shield.scan_files(payload.paths)


@app.get("/api/cyber-defense/backup-readiness")
def cyber_defense_backup_readiness():
    return cyber_defense_shield.backup_readiness()


@app.get("/api/cyber-defense/posture")
def cyber_defense_posture():
    return cyber_defense_shield.security_posture()


@app.get("/api/cyber-defense/ransomware-guard-plan")
def cyber_defense_ransomware_guard_plan():
    return cyber_defense_shield.ransomware_guard_plan()


@app.post("/api/cyber-defense/incident-playbook")
def cyber_defense_incident_playbook(payload: CyberDefenseRequest):
    return cyber_defense_shield.incident_playbook(payload.scenario)


@app.get("/api/cyber-defense/alerts")
def cyber_defense_alerts(limit: int = 100):
    return cyber_defense_shield.alerts(limit)


# ---------------------------------------------------------------------------
# HAL Multi-Model Router V15
# ---------------------------------------------------------------------------
@app.get("/api/multi-model/status")
def multi_model_status(test: bool = False):
    return multi_model_router.status(test=test)


@app.get("/api/multi-model/boot-report")
def multi_model_boot_report(test: bool = False):
    return {"ok": True, "report": multi_model_router.boot_report(test=test)}


@app.post("/api/multi-model/route")
def multi_model_route(payload: MultiModelRequest):
    return multi_model_router.route_model(payload.message or payload.prompt, intent=payload.intent, task_type=payload.role)


@app.post("/api/multi-model/generate")
def multi_model_generate(payload: MultiModelRequest):
    return multi_model_router.generate(
        payload.prompt or payload.message,
        message=payload.message,
        intent=payload.intent,
        role=payload.role or None,
    )


@app.post("/api/multi-model/embed")
def multi_model_embed(payload: MultiModelRequest):
    return multi_model_router.embed(payload.text or payload.prompt or payload.message)


@app.post("/api/multi-model/config")
def multi_model_config(payload: MultiModelRequest):
    return multi_model_router.configure(payload.changes)
