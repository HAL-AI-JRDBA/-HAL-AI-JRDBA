# HAL Auto Ollama Setup

Esta versão coloca a configuração do Ollama e do modelo de conversa natural de forma automática na inicialização do HAL.

## O que agora é automático

Ao iniciar o HAL por qualquer launcher principal, o sistema executa:

```text
Verifica se o Ollama está instalado
Tenta instalar via winget se não encontrar
Inicia o serviço Ollama em segundo plano
Configura as variáveis da sessão
Verifica se o modelo qwen2.5:7b existe
Baixa o modelo automaticamente se faltar
Testa uma resposta rápida
Continua abrindo o HAL mesmo que o Ollama falhe
```

## Variáveis configuradas automaticamente

A inicialização agora configura para a sessão atual:

```bat
set OLLAMA_MODEL=qwen2.5:7b
set HALL_DIALOG_MODEL=qwen2.5:7b
set HALL_WEB_SUMMARY_MODEL=qwen2.5:7b
set OLLAMA_URL=http://127.0.0.1:11434
```

Isso evita depender de `setx` manual.

## Arquivos adicionados

```text
HALL_AUTO_OLLAMA.bat
VERIFICAR_HALL_OLLAMA_STATUS.bat
INICIAR_JR_AI_HALL_AUTO_OLLAMA.bat
```

## Como iniciar

Use:

```bat
INICIAR_JR_AI_HALL_AUTO_OLLAMA.bat
```

ou:

```bat
INICIAR_JR_AI_HALL_DIALOGUE_BRAIN_V2.bat
```

ou:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Todos passam pela preparação automática do Ollama.

## Observações importantes

Se o Ollama não estiver instalado e o Windows tiver `winget`, o instalador tenta instalar automaticamente.

Se não houver `winget`, ou se a instalação falhar, o HAL abre mesmo assim em modo fallback. Ele não trava.

O download do modelo pode demorar e consumir alguns GB. Como foi solicitado tudo automático, o `ollama pull qwen2.5:7b` roda automaticamente quando o modelo não existir.

## Como verificar

Execute:

```bat
VERIFICAR_HALL_OLLAMA_STATUS.bat
```

Ele mostra se o Ollama está instalado, quais modelos existem e se a API local responde.

## Modelo padrão

O modelo padrão é:

```text
qwen2.5:7b
```

Para trocar, antes de iniciar o HAL, defina:

```bat
set HALL_OLLAMA_MODEL=llama3.1:8b
```

ou outro modelo instalado/compatível.
