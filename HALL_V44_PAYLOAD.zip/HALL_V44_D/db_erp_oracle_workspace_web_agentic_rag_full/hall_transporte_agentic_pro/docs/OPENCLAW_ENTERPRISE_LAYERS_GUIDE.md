# HAL OpenClaw Enterprise Layers

Este pacote adiciona as seis camadas necessárias para aproximar a JR-AI/HAL de uma arquitetura estilo OpenClaw corporativa: agentes conectados a canais reais, workflows determinísticos, navegador controlado, agendamentos, sandbox e ponte com frameworks de agentes.

## Camadas adicionadas

```text
1. HAL Channel Gateway
WhatsApp, Telegram, Slack, Teams, Discord, e-mail e Web Chat.

2. HAL n8n Workflow Center
Integração com n8n por webhook/API, templates, callbacks e histórico.

3. HAL Browser Automation
Playwright/Selenium, perfil isolado, leitura de página, clique, preenchimento e screenshot.

4. HAL Cron Enterprise
Agendamentos robustos, retry, logs, entrega por canal e execução como serviço.

5. HAL Sandbox Enterprise
Docker, limites de CPU/RAM/rede, logs imutáveis e cofre de credenciais.

6. HAL Agent Framework Bridge
Integra CrewAI, LangGraph, AutoGen, MCP, OpenClaw e runtime nativo JR-AI.
```

## Como o HAL usa isso automaticamente

O usuário pode falar naturalmente:

```text
HAL, envie o relatório pelo WhatsApp depois da minha aprovação.
HAL, crie um workflow no n8n para leads novos.
HAL, abra esse sistema no navegador e capture os dados da tela.
HAL, agende um resumo financeiro todo dia às 8h.
HAL, execute esse teste em sandbox Docker sem rede.
HAL, escolha entre CrewAI, LangGraph ou MCP para esse projeto.
```

O HAL identifica a intenção e roteia para a camada correta.

## Regras de segurança

```text
Mensagens externas exigem aprovação humana.
Workflows críticos do n8n exigem aprovação.
Submit/login/download no navegador exigem aprovação.
Sandbox roda sem rede por padrão.
Segredos ficam por referência/env var, nunca em logs.
Ações são auditadas localmente.
```

## Observação técnica honesta

As camadas entregues incluem estrutura funcional, tela, backend, armazenamento local, políticas, templates e planos de execução. Para produção real, configurar credenciais dos canais, API do n8n, Playwright/Selenium, Docker e dependências dos frameworks no ambiente do cliente.
