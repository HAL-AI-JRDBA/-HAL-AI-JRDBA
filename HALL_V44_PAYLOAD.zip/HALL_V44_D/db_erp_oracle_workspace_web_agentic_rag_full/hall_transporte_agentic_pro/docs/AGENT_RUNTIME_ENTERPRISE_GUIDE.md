# HAL Agent Runtime Enterprise

Esta camada aproxima a JR-AI/HAL da visão moderna de agentes corporativos de longo horizonte: o usuário delega uma tarefa, e o sistema cria um job persistente com plano, agentes, checkpoints, segurança, métricas e observabilidade.

## Funcionalidades adicionadas

```text
Fila persistente de jobs
Tarefas longas
Workers/execução simulada por etapas
Checkpoints
Pausar, retomar e cancelar
Reexecutar etapa com erro
Agentes paralelos por especialidade
Sandbox lógico/local para código
Testes automáticos e scorecard
Patch/diff conceitual
Métricas de produtividade
Observabilidade dos agentes
Métricas estilo Prometheus
Governança, RBAC, LGPD, aprovação humana e auditoria
Model Advisor para escolher modelos open-source por tarefa e hardware
```

## Aba criada

```text
Agent Runtime Enterprise
```

## Agentes disponíveis

```text
CEO Agent / Orquestrador
Agente Planejador
Agente Executor
Agente de Código
Agente de Testes / TDD
Agente de Dados
Agente de Operações
Agente de Segurança / Governança
Agente Avaliador
```

## Tipos de execução

```text
Tarefa longa
Execução paralela por agentes
Sandbox de código
Workflow corporativo
Resposta a incidente
```

## Exemplos de uso pelo HAL

```text
HAL, crie uma tarefa longa para revisar o SaaS Builder com sandbox, testes, patch e scorecard.

HAL, execute agentes paralelos para analisar vendas, banco MongoDB, BI e riscos operacionais.

HAL, crie um job de resposta a incidente para alertas críticos do Zabbix e Grafana.

HAL, gere um workflow corporativo com aprovação humana para cobrança financeira.

HAL, avalie quais modelos open-source usar para código, voz, visão e RAG sem GPU.
```

## Como usar a aba

1. Informe o objetivo da tarefa longa.
2. Escolha o tipo de execução ou deixe automático.
3. Informe prioridade, segmento, banco/contexto e projeto.
4. Marque se exige aprovação humana.
5. Clique em Criar Job.
6. Use Iniciar/Aprovar, Avançar Etapa, Executar Tudo, Pausar, Retomar, Cancelar e Scorecard.
7. Acompanhe Métricas e Observabilidade.

## Arquivos locais

```text
data/agent_runtime/jobs.json
data/agent_runtime/metrics.json
data/agent_runtime/audit.jsonl
data/agent_runtime/sandboxes/
```

## Observação técnica

A versão entregue implementa o runtime persistente local e a simulação controlada das etapas. Para produção em cliente, a evolução recomendada é acoplar workers reais com asyncio/Celery/RQ, Docker sandbox sem privilégios, limites de CPU/RAM/rede, Git real, execução de testes e logs imutáveis.
