# HAL SaaS Builder / White Label Studio

Esta camada adiciona criação de apps/sites com IA, modelo white-label, domínio próprio, código-fonte inicial, preview local, versionamento, rollback, deploy e planos de assinatura.

## Funcionalidades

```text
Criador de apps e sites com IA
White-label com nome, logo, cores e domínio
Projetos por cliente
Código-fonte inicial completo
Preview local
Dockerfile e docker-compose
Plano de deploy local, Docker, VPS, Vercel, Render, Railway ou on-premise
Versionamento e rollback
Planos de assinatura
Gateways preparados: Stripe, Mercado Pago, PagSeguro e cobrança manual
Skills: Code Review, TDD, Debugging, Git Worktrees, Deploy, Rollback, Integrações e Segurança JWT/WebSocket
```

## Como usar no Console Unificado

Exemplos:

```text
HAL, crie um app white-label de vendas para varejo com MongoDB e assinatura mensal.

HAL, crie um portal do cliente para uma empresa de logística com domínio próprio.

HAL, gere um dashboard BI para financeiro usando SQL Server.

HAL, crie um site institucional white-label para um cliente de contabilidade.

HAL, gere um módulo ERP para controle de estoque no PostgreSQL.
```

## Fluxo

```text
1. Descrever ideia
2. Escolher template ou deixar automático
3. Aplicar marca própria
4. Gerar código-fonte inicial
5. Abrir preview local
6. Executar Code Review / TDD
7. Gerar plano de deploy
8. Publicar com aprovação
9. Ativar cobrança
10. Versionar e permitir rollback
```

## Arquivos locais

```text
data/saas_builder/projects.json
data/saas_builder/clients.json
data/saas_builder/billing_plans.json
data/saas_builder/audit.jsonl
data/saas_builder/generated_projects/
```

## Observação

A camada gera base funcional inicial e plano de publicação. Para produção real, configure credenciais, domínio, SSL, banco real, autenticação, gateway de pagamento e revisão técnica.
