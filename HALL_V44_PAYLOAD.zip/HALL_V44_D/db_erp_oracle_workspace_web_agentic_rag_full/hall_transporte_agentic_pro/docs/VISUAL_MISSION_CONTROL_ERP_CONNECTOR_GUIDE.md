# HAL Visual Mission Control + Universal ERP Connector

Esta versão adiciona ao projeto um painel visual no estilo “escritório digital de agentes”, com agentes trabalhando por área, missões, status, aprovações, notas do dia, métricas de produtividade e modo apresentação para clientes.

Também foi adicionada a camada Universal ERP & Application Connector, para conectar o HAL a ERP, bancos relacionais/NoSQL, APIs, arquivos, n8n, navegador/RPA e sistemas individuais, incluindo venda de passagens, bilhetagem e vale-transporte.

## 1. HAL Visual Mission Control

Recursos adicionados:

```text
Painel visual futurístico
Escritório digital de agentes
Salas por área: Executivo, Financeiro, Atendimento, TI/DBA, Dados/BI, Operações, Automações e Sandbox
Avatares dos agentes
Status: disponível, trabalhando, aguardando aprovação, concluído, erro e pausado
Missões ativas
Missões concluídas
Missões com erro
Missões aguardando aprovação
Notas do dia
Fila de aprovações
Indicadores de produtividade
Tempo estimado economizado
Modo operação
Modo apresentação para clientes
Demo pronta para cliente
```

Agentes visuais incluídos:

```text
HAL Orquestrador
Agente Financeiro
Agente Atendimento
Agente TI/DBA
Agente Dados/BI
Agente Operações
Agente Vendas/SDR
Agente n8n
Agente Browser
Agente Cron
Agente Sandbox
Agente Framework
```

## 2. HAL Universal ERP & Application Connector

Recursos adicionados:

```text
Conexão com ERP por banco direto
Conexão por API REST
Conexão por API SOAP
Conexão GraphQL
Conexão por arquivos CSV, Excel, TXT, XML, JSON e CNAB
Conexão via n8n
Conexão via Browser/RPA para sistemas sem API
Conector customizado
Mapeamento de entidades de negócio
Plano seguro de consulta
Consulta somente leitura por padrão
Aprovação humana para escrita, baixa, cancelamento, reembolso, cobrança e envio externo
```

Bancos suportados no catálogo:

```text
Oracle
SQL Server
PostgreSQL
MySQL
MariaDB
SQLite
Firebird
IBM DB2
MongoDB
Redis
Elasticsearch
Cassandra
CouchDB
```

Templates de transporte adicionados:

```text
Venda de Passagens
Vale-Transporte
Bilhetagem / Arrecadação
```

## Exemplos práticos

```text
HAL, abra o Mission Control e mostre meus agentes trabalhando.

HAL, crie uma missão visual para analisar vendas de passagens de hoje.

HAL, quais empresas estão com vale-transporte pendente de pagamento?

HAL, verifique se houve queda de venda por linha e agência.

HAL, mostre agentes com tarefa aguardando aprovação humana.

HAL, registre um ERP Oracle para venda de passagens.

HAL, crie um plano seguro para consultar bilhetagem por veículo.

HAL, coloque essa missão em modo apresentação para cliente.
```

## Como usar

1. Execute o projeto.
2. Acesse `http://127.0.0.1:8000`.
3. Use a aba/área `Universal ERP & Application Connector` para cadastrar conexões e criar planos de consulta.
4. Use a aba/área `Visual Mission Control` para ver agentes, salas, missões, aprovações e produtividade.
5. Clique em `Demo Cliente` para preencher o painel com missões demonstrativas.
6. Use o HAL por texto ou voz para criar missões automaticamente.

## Segurança

```text
Consulta somente leitura por padrão.
Qualquer escrita em ERP ou banco exige aprovação humana.
Cancelamento de passagem exige aprovação.
Reembolso exige aprovação.
Baixa financeira exige aprovação.
Envio de cobrança exige aprovação.
Exportação de dados pessoais exige aprovação.
Senhas e tokens devem ficar em variáveis de ambiente/cofre local.
```

## Observação técnica

As camadas adicionadas entregam estrutura funcional, endpoints, tela, documentação, persistência local e simulações/plano de execução. Para produção real, cada cliente precisa configurar credenciais, drivers de banco, APIs, n8n, Playwright/Selenium ou conectores customizados conforme o sistema usado.
