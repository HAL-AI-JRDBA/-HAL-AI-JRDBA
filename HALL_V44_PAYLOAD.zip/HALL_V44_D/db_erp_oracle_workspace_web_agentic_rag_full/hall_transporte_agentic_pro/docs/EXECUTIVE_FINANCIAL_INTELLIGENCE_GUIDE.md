# HAL Executive Financial Intelligence

Esta versão adiciona ao projeto uma camada completa de indicadores fundamentalistas, financeiros e executivos para gestores, diretoria e sócios.

## Objetivo

Permitir que gestores perguntem naturalmente:

```text
HAL, como está a saúde financeira da empresa?
HAL, qual foi o EBITDA do mês?
HAL, mostre os indicadores fundamentalistas.
HAL, compare este mês com o mês anterior.
HAL, qual filial está piorando a margem?
HAL, onde estamos perdendo dinheiro?
HAL, envie a visão executiva para o diretor por e-mail.
```

O HAL deve responder de forma simples, executiva e sem inventar números.

## Indicadores contemplados

```text
Receita bruta
Receita líquida
Custos
Lucro bruto
Lucro operacional
Lucro líquido
EBITDA
Margem EBITDA
Margem bruta
Margem operacional
Margem líquida
Fluxo de caixa operacional
Saldo de caixa
Contas a pagar
Contas a receber
Inadimplência
Capital de giro
Liquidez corrente
Liquidez seca
Dívida líquida
Dívida líquida / EBITDA
ROE
ROA
ROI
ROIC
Ponto de equilíbrio
Ticket médio
Custo por unidade
Free Cash Flow
EV / EBITDA
```

## Fontes reais

O HAL pode ser configurado para buscar os dados em:

```text
ERP
Banco SQL
Banco NoSQL
Power BI
DRE contábil
Sistema financeiro
Contabilidade
Planilhas autorizadas
CRM
Bilhetagem
Vendas
```

## Regra de segurança

Por padrão, o módulo segue a regra:

```text
Não inventar números.
Se não houver fonte real cadastrada, pedir a fonte.
Se houver fonte demo/snapshot, deixar claro que é demonstração.
Se envolver envio externo, respeitar aprovação.
Se houver acesso remoto, usar perfil, permissão e auditoria.
```

## EBITDA

Regra padrão configurada:

```text
EBITDA = Lucro Operacional + Depreciação + Amortização
```

Mas a regra pode ser ajustada para cada empresa, incluindo EBITDA gerencial com ajustes internos.

## Saúde financeira

O painel calcula um score executivo usando parâmetros como:

```text
Margem EBITDA
Margem líquida
Fluxo de caixa operacional
Liquidez corrente
Dívida líquida / EBITDA
Inadimplência
```

E classifica como:

```text
Saudável
Atenção
Risco
Crítico
```

## Local-first

O módulo continua seguindo a arquitetura do projeto:

```text
Execução local primeiro
Nuvem opcional
Acesso remoto seguro opcional
Dados financeiros dentro da empresa
Integração com ERP/bancos/Power BI locais
```

## Painel adicionado

Foi adicionada a área:

```text
Executive Financial Intelligence
```

com:

```text
Cadastro de fonte real
Pergunta executiva
Período
Escopo
Snapshot demo/manual
Catálogo de indicadores
Saúde financeira
EBITDA
Consultas registradas
```

## Integrações

A camada conversa com:

```text
Human Conversation Gateway V3
Database Access Wizard
Universal ERP Connector
Power BI / fontes registradas
Omnichannel WhatsApp/Telegram/E-mail
Meeting Intelligence
Enterprise Teams
```
