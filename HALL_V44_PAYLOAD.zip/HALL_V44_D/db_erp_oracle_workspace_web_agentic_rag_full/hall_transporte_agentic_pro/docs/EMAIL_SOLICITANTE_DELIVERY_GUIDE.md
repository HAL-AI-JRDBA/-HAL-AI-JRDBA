# HAL Omnichannel Voice/Text Delivery — E-mail ao Solicitante

Esta versão adiciona explicitamente o envio de e-mail ao solicitante dentro da camada Omnichannel.

## O que foi adicionado

Além de WhatsApp e Telegram, o HAL agora pode preparar e/ou enviar:

```text
E-mail para o solicitante
Texto no corpo do e-mail
Áudio anexado quando houver arquivo de voz local
Assunto automático baseado na pergunta
Auditoria da entrega
Aprovação humana antes de envio externo
```

## Como o usuário pode pedir

```text
HAL, explique isso e mande por e-mail para o solicitante.
HAL, envie a resposta para solicitante@empresa.com.br em texto e voz.
HAL, mande por WhatsApp, Telegram e e-mail ao solicitante.
HAL, depois da reunião envie a ata por e-mail ao solicitante.
```

## Variáveis de ambiente para envio real por e-mail

```text
SMTP_HOST
SMTP_PORT
SMTP_USER
SMTP_PASSWORD
SMTP_FROM
```

Também podem ser usadas com prefixo:

```text
HALL_SMTP_HOST
HALL_SMTP_PORT
HALL_SMTP_USER
HALL_SMTP_PASSWORD
HALL_SMTP_FROM
```

## Segurança

Por padrão:

```text
Envio externo exige aprovação humana.
Sem SMTP configurado, a entrega fica preparada.
Sem e-mail do solicitante, o HAL pede o destinatário.
Áudio só é anexado se houver arquivo local gerado.
Todas as entregas ficam registradas em auditoria.
```

## Onde configurar

Na tela:

```text
WhatsApp / Telegram / E-mail — Voz + Texto
```

Campos principais:

```text
Canal: WhatsApp, Telegram ou E-mail ao solicitante
Destinatário
E-mail do solicitante
Enviar texto
Enviar voz
Preparar/enviar
```

## Integração com o fluxo principal

Quando o pedido do usuário mencionar:

```text
e-mail
email
solicitante
requerente
quem pediu
quem solicitou
```

a camada Omnichannel identifica o canal de e-mail e prepara a entrega.
