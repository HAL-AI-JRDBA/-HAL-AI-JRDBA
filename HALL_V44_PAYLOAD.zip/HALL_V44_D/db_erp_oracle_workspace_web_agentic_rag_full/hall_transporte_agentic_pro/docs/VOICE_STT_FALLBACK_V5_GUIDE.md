# HAL Voice STT Fallback V5

Esta versão corrige o problema visível no print:

```text
Não ouvi nada ainda...
```

O problema acontecia porque o navegador entrava no modo "Ouvir", mas não entregava nenhum texto transcrito para o HAL. Assim a pergunta nunca chegava ao backend.

## Correção implementada

Agora o HAL usa dois caminhos:

```text
1. Web Speech API do navegador
2. Se falhar/no-speech: gravação local com MediaRecorder
3. Envio do áudio ao backend
4. Transcrição local com faster-whisper/openai-whisper quando disponível
5. Envio automático da pergunta transcrita ao Live Dialogue Engine
```

## O que muda na prática

Antes:

```text
Não ouvi nada ainda...
```

E ficava parado.

Agora:

```text
Não captei pelo navegador. Vou gravar sua voz agora...
Gravando voz... fale naturalmente
Transcrevendo voz local...
Ouvi sua pergunta. Vou responder agora.
```

Se não conseguir transcrever:

```text
Recebi o áudio, mas não consegui transcrever...
Pode repetir ou digitar a pergunta.
```

## Instalação automática

Foi adicionado:

```text
HALL_AUTO_STT.bat
```

Ele tenta instalar automaticamente:

```text
faster-whisper
av
```

Isso permite STT local sem depender exclusivamente do reconhecimento de voz do navegador.

## Endpoints adicionados

```text
/api/stt/status
/api/stt/transcribe
/api/unified/stt/status
/api/unified/stt/transcribe
```

## Recomendação

Use Chrome ou Edge, permita o microfone no cadeado do navegador e fale depois que aparecer:

```text
Ouvindo... pode falar naturalmente
```

Se o navegador não captar, aguarde o modo:

```text
Gravando voz... fale naturalmente
```

## Observação

A primeira transcrição com faster-whisper pode demorar porque o modelo é carregado/baixado. Depois tende a ficar mais rápido.
