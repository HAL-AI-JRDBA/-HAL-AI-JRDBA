# HAL Voice Safety V10 — Voz Segura, Sem Tela Presa

Esta versão corrige a piora causada pelo modo "gravação primeiro".

## Problema visto no print

A tela ficava em:

```text
Gravando... 1s restantes
Aguardando pedido...
```

e a pergunta não aparecia.

Isso acontecia porque o modo gravado escondia a pergunta até a transcrição. Se o STT local não estivesse pronto ou demorasse, a experiência parecia travada.

## Correção V10

Agora o HAL só usa gravação local se o STT local estiver realmente pronto.

Fluxo novo:

```text
1. Verifica /api/unified/stt/status
2. Se STT local estiver pronto: pode gravar e transcrever
3. Se STT local não estiver pronto: usa voz do navegador
4. Se o navegador não captar: mostra mensagem clara e volta para Pronto
5. Nunca fica preso aguardando pedido
```

## Correções específicas

```text
Modo recorded_first deixou de ser padrão cego
Uso de gravação local agora depende de STT pronto
Contador fecha a gravação também quando chega a zero
Watchdog preservado
Botão Responder agora preservado
Mensagem clara quando STT não está instalado
Campo de texto continua disponível
```

## Como forçar modos manualmente

No console do navegador:

```javascript
localStorage.setItem('hallVoiceCaptureMode','browser_first')
```

ou:

```javascript
localStorage.setItem('hallVoiceCaptureMode','recorded_first')
```

Para voltar ao automático seguro:

```javascript
localStorage.removeItem('hallVoiceCaptureMode')
```

## Recomendação

Execute:

```bat
HALL_AUTO_STT.bat
```

para instalar `faster-whisper` e `av`. Depois a gravação local fica disponível.
