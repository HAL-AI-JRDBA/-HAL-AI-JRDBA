# HAL App Factory Pro V12 — Lovable/Zheus Local White-label

Esta versão adiciona ao projeto uma camada de fábrica de sistemas completos.

## Objetivo

Transformar pedidos em linguagem natural em sistemas completos, não apenas telas bonitas.

Exemplo:

```text
Quero um software em Python com interface web para controle de finanças pessoais, com login, filtros, cálculos, estado vazio, cobrança falhou, teto de custo de IA, GitHub e deploy.
```

O HAL deve reconhecer como:

```text
app_factory
```

E responder com arquitetura e capacidade de gerar scaffold completo.

## Recursos adicionados

```text
Login local
Todas as páginas principais
Componentes funcionais
CRUD funcional
Filtros reais
Cálculos reais de dashboard
Estado vazio quando filtro não acha nada
Configurações
Alerta de cobrança falhou
Teto de custo de IA
Exportação CSV
Preview local
GitHub manifest
Deploy local/Docker manifest
Quality Gate funcional
Templates de sistemas
White-label com marca do cliente
```

## Templates incluídos

```text
Finanças pessoais
CRM
Clínica / Saúde
Loja / Varejo
Escola / Cursos
Transporte / Logística
Estoque / Almoxarifado
Helpdesk
Área de membros
Agendamento
```

## Endpoints Agentic Pro

```text
/api/app-factory/status
/api/app-factory/catalog
/api/app-factory/config
/api/app-factory/blueprint
/api/app-factory/generate
/api/app-factory/quality-gate
/api/app-factory/requests
```

## Endpoints Console Unificado

```text
/api/unified/app-factory/status
/api/unified/app-factory/catalog
/api/unified/app-factory/config
/api/unified/app-factory/blueprint
/api/unified/app-factory/generate
/api/unified/app-factory/requests
```

## App gerado

O app gerado contém:

```text
app/main.py
templates/index.html
static/app.js
static/style.css
requirements.txt
README.md
INICIAR_APP.bat
Dockerfile
docker-compose.yml
quality_gate.py
github/INIT_GIT_PUSH.bat
github/github_manifest.json
deploy/deploy_manifest.json
preview_manifest.json
```

## Observação importante

GitHub e deploy externo são entregues como manifesto/script local. Para publicar em repositório real ou servidor externo, o cliente precisa configurar `GITHUB_REMOTE_URL`, token/credenciais e infraestrutura. O projeto não inventa credenciais nem faz deploy externo sem configuração.
