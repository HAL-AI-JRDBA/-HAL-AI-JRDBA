# HAL Human Voice Assistant 24x7

Esta camada foi criada para aproximar a JR-AI/HAL do comportamento mostrado no vídeo de referência: um assistente visual, futurístico, que conversa com naturalidade, responde como humano, atua como assistente pessoal e também como funcionário especialista 24x7.

## O que foi adicionado

```text
Aba Human Voice Assistant 24x7
Avatar futurístico na tela principal
Perfis de voz pt-BR paulista/neutro
Preparação para voz própria autorizada do usuário
Modo assistente pessoal 24x7
Modo funcionário especialista por área 24x7
Modo atendente humanizado
Modo assessor executivo
Política de conversa natural
Espera do usuário terminar de falar
Barge-in: usuário pode interromper a resposta
Perguntas de esclarecimento antes de agir
Roteamento automático para a ferramenta correta
Aprovação humana para ações sensíveis
Auditoria local
```

## Diferença entre voz configurada e voz real do usuário

A plataforma já fica preparada para voz natural em português do Brasil, mas a voz real do usuário só pode ser usada se o próprio usuário enviar uma amostra autorizada.

Recomendação:

```text
Formato: WAV, MP3 ou M4A
Mínimo: 3 minutos
Ideal: 5 a 10 minutos
Ambiente: silencioso
Idioma: português do Brasil
Estilo: fala natural, clara e objetiva
```

## Motores preparados

```text
STT / fala para texto:
- faster-whisper local
- whisper.cpp local
- Browser Speech Recognition

TTS / texto para fala:
- Piper local
- Coqui XTTS local
- F5-TTS local
- OpenVoice local
- Browser Speech API
```

## Personas

```text
Assistente Pessoal 24x7
Funcionário Especialista 24x7
Atendente Humanizado
Assessor Executivo
```

## Funções por área

```text
Financeiro/Contábil
TI/DBA
Vendas/SDR
Atendimento
Operações
Dados/BI
```

## Exemplos de uso

```text
HAL, bom dia.

HAL, atue como meu assistente pessoal e organize minhas prioridades de hoje.

HAL, trabalhe como funcionário financeiro 24x7 e analise contas a receber vencidas.

HAL, seja um funcionário de TI/DBA e verifique alertas do Zabbix, Grafana e Oracle.

HAL, atue como atendente humanizado para clientes no WhatsApp.

HAL, use minha voz autorizada quando eu enviar a amostra de áudio.
```

## Política de conversa

```text
Não responder enquanto o usuário ainda estiver falando
Aguardar silêncio final antes de responder
Responder de forma clara, humilde e objetiva
Fazer perguntas de esclarecimento quando faltar contexto
Interromper a fala do HAL quando o usuário voltar a falar
Pedir aprovação antes de ações sensíveis
```

## Observação importante

A versão entregue implementa a estrutura, tela, configuração, personas, políticas, roteamento e adaptadores. Para a voz humana real em produção, será necessário instalar/configurar o motor escolhido e fornecer amostra autorizada de voz.
