# HAL Enterprise Productization V13

Esta versão adiciona a camada de produto comercial robusto inspirada na comparação com AIHub, Zheus e Asimov.

## Objetivo

Transformar o HAL de protótipo avançado em uma plataforma mais próxima de um produto comercial local-first/white-label, com:

```text
Painel de saúde da plataforma
Testes automáticos de roteamento
Biblioteca de 60 Skills
Banco com 45 templates de aplicativos
Integrações reais configuráveis
Deploy assistido
Quality Gate global
Agent Fleet Manager 24/7
Knowledge/RAG Center local
Modo venda white-label
```

## 1. Painel de saúde da plataforma

Endpoint:

```text
/api/unified/enterprise-v13/health
/api/enterprise-v13/health
```

Verifica:

```text
Python
Ollama
Git
Docker
STT local
App Factory
Conversation Gateway
Integrações configuradas por variável de ambiente
```

## 2. Roteador com testes automáticos

Endpoint:

```text
/api/unified/enterprise-v13/router-tests
```

Testa perguntas como:

```text
software/app factory
reparo de conversa
buracos negros
almoço/cardápio
EBITDA
banco de dados
WhatsApp
Skills
Enterprise Productization
```

## 3. Biblioteca de 60 Skills

Endpoint:

```text
/api/unified/enterprise-v13/skills?seed=true
```

Categorias:

```text
Marketing
Vendas
Atendimento
Financeiro
Operações
RH / Jurídico / TI
```

Cada skill é local-first, auditável e pode exigir aprovação se envolver ação sensível.

## 4. App Factory com 45 templates

Endpoint:

```text
/api/unified/enterprise-v13/templates
```

Inclui templates como:

```text
Finanças pessoais
CRM
Clínica/Saúde
Loja/Varejo
Escola/Cursos
Transporte/Logística
Estoque/Almoxarifado
Helpdesk
Área de membros
Agendamento
Dashboard Executivo
ERP Financeiro
Banco/Fintech
Agronegócio
Indústria
Venda de passagens
Vale transporte
Assinaturas SaaS
Portal do cliente
```

## 5. Integrações reais configuráveis

Endpoint:

```text
/api/unified/enterprise-v13/integrations
```

Catálogo com 20 integrações:

```text
GitHub
Vercel
Supabase
Stripe
WhatsApp
Telegram
Gmail
Google Workspace
Slack
Discord
n8n
Notion
Trello
Linear
Figma
OpenAI opcional
Ollama local
Zabbix
Grafana
Power BI
```

A integração real depende das variáveis de ambiente/credenciais do cliente.

## 6. Deploy assistido

Endpoint:

```text
/api/unified/enterprise-v13/deploy-plan
```

Suporta planos para:

```text
local
docker
vps
vercel
supabase
```

A execução externa real exige credenciais e aprovação explícita.

## 7. Quality Gate global

Endpoint:

```text
/api/unified/enterprise-v13/quality-gate
```

Verifica:

```text
saúde da plataforma
roteamento
biblioteca de skills
banco de templates
catálogo de integrações
quality gate de app gerado
```

## 8. Agent Fleet Manager

Endpoint:

```text
/api/unified/enterprise-v13/fleet
```

Agentes padrão:

```text
Executivo
Financeiro
Comercial
Marketing
Operações
Atendimento
RH
Jurídico
TI
Dados/BI
App Factory
Knowledge/RAG
```

Permite criar tarefas com aprovação humana.

## 9. Knowledge/RAG Center

Endpoints:

```text
/api/unified/enterprise-v13/knowledge
/api/unified/enterprise-v13/knowledge/ingest
/api/unified/enterprise-v13/knowledge/search
```

Permite indexar documentos textuais locais e buscar conhecimento.

## 10. White-label

Endpoint:

```text
/api/unified/enterprise-v13/white-label
```

Inclui:

```text
marca AJDS
produto HAL
planos piloto/business/enterprise
limite de custo de IA por plano
alerta de cobrança falhou
portal de cliente
```

## Observação importante

Esta versão adiciona as camadas, painéis, endpoints, catálogos, testes e manifests. Integrações externas como GitHub, Vercel, Supabase, Stripe, WhatsApp oficial, Google Workspace e afins exigem credenciais reais e aprovação do cliente para executar ações fora do ambiente local.
