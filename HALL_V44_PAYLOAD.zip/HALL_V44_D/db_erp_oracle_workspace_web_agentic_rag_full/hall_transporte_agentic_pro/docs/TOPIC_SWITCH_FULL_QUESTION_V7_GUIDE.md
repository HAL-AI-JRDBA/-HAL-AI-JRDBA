# HAL Topic Switch & Full Question Capture V7

Esta versão corrige duas falhas graves apontadas no teste real:

```text
1. O HAL não reconhecia bem mudança de assunto.
2. A pergunta por voz podia chegar truncada.
```

## Problema corrigido: mudança de assunto

Exemplo real:

```text
Usuário: me recomende um almoço/cardápio
Usuário depois: me explique buracos negros e horizonte de eventos
```

Antes, o HAL podia ficar preso no contexto anterior ou cair em fallback errado.

Agora o núcleo de diálogo identifica assinatura de tópico:

```text
food_lunch
science_space
education
business_finance
database
personal
open_knowledge
general_chat
```

Quando detecta mudança clara de assunto, ele abandona o contexto anterior e responde o novo tema.

## Exemplo esperado

Usuário:

```text
Me recomenda um cardápio para almoço.
```

HAL responde com sugestão de almoço/cardápio.

Usuário:

```text
Agora me explica buracos negros e horizonte de eventos.
```

HAL responde sobre buracos negros, gravidade e horizonte de eventos, sem ficar preso no almoço.

## Problema corrigido: pergunta truncada

O modo de voz agora usa por padrão:

```text
recorded_first
```

Ou seja:

```text
Grava a pergunta inteira
Transcreve localmente
Só depois envia ao HAL
```

Isso evita o comportamento em que o Web Speech do navegador pegava apenas um pedaço da fala.

## Novo comportamento de voz

```text
Gravando voz completa... fale a pergunta até o fim
Transcrevendo pergunta completa...
Ouvi sua pergunta. Vou responder agora.
```

A gravação automática foi ampliada para até 18 segundos por pergunta. O usuário também pode parar manualmente.

## Domínios adicionados

Foram adicionados fallbacks naturais para:

```text
Recomendação de almoço/cardápio
Buracos negros
Horizonte de eventos
Mudança de tema aberta
Perguntas de ciência/espaço
```

## Regra V7

```text
Se mudou de assunto, muda junto.
Se é pergunta longa por voz, captura inteira.
Se é assunto geral, conversa.
Se precisa de ferramenta, usa por trás.
Se não precisa de ferramenta, responde direto.
```

## Observação

Para respostas abertas profundas em qualquer assunto, o modelo local/Ollama continua recomendado. Mas agora o HAL não deve falhar em perguntas comuns de cardápio, ciência ou mudança clara de assunto.
