# HAL Voice State Machine V9 — Correção de Travamento em "Gravando voz completa..."

Esta versão corrige a falha mostrada no print:

```text
Gravando voz completa... fale a pergunta até o fim
```

e a plataforma ficava parada, sem avançar para transcrever nem responder.

## Causa

O modo de voz dependia do `MediaRecorder.onstop` e de um timeout simples. Em alguns navegadores/condições, a gravação podia ficar em estado aberto ou o usuário não tinha indicação clara de quando ela seria finalizada.

## Correção

Foi criada uma máquina de estados de voz mais rígida:

```text
recording
closing
transcribing
ready
error
```

## O que mudou

```text
Tempo máximo de gravação reduzido para 9 segundos
Watchdog obrigatório em 12 segundos
Botão Conversar vira "Responder agora" durante gravação
Botão Parar vira "Parar e responder" durante gravação
MediaRecorder usa start(1000) para soltar chunks de áudio continuamente
requestData() antes de fechar gravação
Tratamento de erro do MediaRecorder
Controle para não processar o mesmo áudio duas vezes
Limpeza de timers
Limpeza de stream do microfone
Mensagem clara quando áudio fica vazio ou curto
Mensagem clara quando STT local não está pronto
```

## Comportamento esperado

Ao clicar em Conversar:

```text
Gravando... 9s restantes. Clique em “Responder agora” quando terminar.
```

Quando terminar a fala, você pode clicar no próprio botão:

```text
Responder agora
```

ou aguardar o fechamento automático.

Depois:

```text
Fechando gravação para responder...
Transcrevendo pergunta completa...
Ouvi sua pergunta. Vou responder agora.
```

Se o STT local não conseguir transcrever:

```text
Recebi o áudio, mas não consegui transcrever com segurança...
Para evitar erro, não vou inventar o que você disse.
```

## Regra V9

```text
Nunca ficar preso em "Gravando".
Ou fecha sozinho pelo timeout.
Ou fecha pelo botão Conversar.
Ou fecha pelo botão Parar.
Ou o watchdog força o fechamento.
```

## Observação

Para produção com voz totalmente natural e robusta, o ideal é manter o STT local instalado:

```text
faster-whisper
av
```

O projeto já inclui `HALL_AUTO_STT.bat`, que tenta instalar automaticamente.
