# HAL Conversation Repair V8 — Correção de Escuta, Entendimento e Roteamento Errado

Esta versão foi criada a partir do print onde o usuário escreveu:

```text
acredito que você não está me ouvindo
```

e o HAL respondeu como se fosse pedido de:

```text
Skills, agentes, colaboração multiagente, criação de imagem, hub local...
```

Isso estava errado.

## Problema real

O HAL estava confundindo frases de reclamação/conserto de conversa com solicitação de ferramenta.

Exemplos que agora são tratados corretamente:

```text
acredito que você não está me ouvindo
você não me ouviu
você não entendeu
não era isso
não foi isso que perguntei
respondeu errado
está fora do assunto
truncou minha pergunta
não está batendo papo
está parecendo papagaio
```

## Correção implementada

Foi criada a intenção:

```text
conversation_repair
```

Ela tem prioridade sobre ferramentas, Skills, Web, banco, ERP e outros módulos.

## Comportamento esperado

Usuário:

```text
acredito que você não está me ouvindo
```

HAL:

```text
Você tem razão em chamar a atenção. Se a sua frase apareceu escrita aqui, então eu recebi o texto; o problema é que a captação de voz ou a interpretação pode estar chegando incompleta. Vou fazer assim: a partir de agora, vou tratar sua próxima fala como uma pergunta completa, sem tentar adivinhar ferramenta antes de entender o sentido...
```

## O que foi ajustado

```text
Detector is_conversation_repair
Resposta conversation_repair_answer
Prioridade acima de Skills/Multi-Agent
Bloqueio de roteamento errado para Skills quando o usuário reclama da escuta
Campo de texto é limpo após envio
Skills continuam funcionando quando o usuário pede explicitamente Skill, imagem, agente ou ClawHub
```

## Regra V8

```text
Se o usuário reclamar que não foi ouvido, não entendeu, truncou ou respondeu errado:
1. não abrir ferramenta;
2. não roteirizar;
3. não falar de Skills;
4. reconhecer a falha;
5. pedir a pergunta completa;
6. responder primeiro no bate-papo.
```
