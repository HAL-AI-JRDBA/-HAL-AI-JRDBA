# HAL Microphone No-Speech Fix

Esta versão corrige o comportamento em que o navegador retornava:

```text
Erro no microfone: no-speech
```

## O que esse erro significa

`no-speech` não significa necessariamente que o microfone está quebrado. Normalmente significa que o navegador abriu o microfone, mas não detectou fala dentro do tempo esperado.

Causas comuns:

```text
Usuário demorou para começar a falar
Microfone errado selecionado no Windows
Permissão de microfone bloqueada no navegador
Volume de entrada muito baixo
Ruído/driver impedindo detecção
Reconhecimento de voz do navegador instável
```

## O que foi corrigido

```text
O no-speech deixou de ser tratado como erro fatal
O HAL agora tenta ouvir novamente automaticamente
Foi adicionado teste de permissão com getUserMedia
Foi aumentado o tempo de silêncio antes de enviar a pergunta
Foram adicionadas mensagens específicas para permissão negada, microfone ausente e falha de captura
O campo de texto continua disponível como fallback
O modo voz não deve encerrar a conversa se não ouvir de primeira
```

## Comportamento esperado

Antes:

```text
Erro no microfone: no-speech
```

Agora:

```text
Não ouvi nada ainda...
Ouvindo novamente...
```

Se após algumas tentativas o navegador ainda não captar fala:

```text
Ainda não consegui ouvir sua fala. Vou deixar o campo de texto pronto; você também pode digitar a pergunta e apertar Enter.
```

## Recomendações para teste

Use Chrome ou Edge.

Abra em:

```text
http://127.0.0.1:8000
```

Clique no cadeado da barra de endereço e permita o microfone.

No Windows:

```text
Configurações > Sistema > Som > Entrada
```

Confirme se o microfone correto está selecionado e se o volume de entrada se mexe quando você fala.

## Observação

O reconhecimento de voz usado pelo navegador pode variar conforme versão do Chrome/Edge e permissões locais. O HAL agora lida melhor com essa falha, mas para produção robusta o ideal é conectar também um STT local, como Whisper/faster-whisper, como alternativa ao Web Speech API.
