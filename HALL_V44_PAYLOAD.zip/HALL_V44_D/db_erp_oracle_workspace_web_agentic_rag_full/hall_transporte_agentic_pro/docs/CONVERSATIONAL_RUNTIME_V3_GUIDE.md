# HAL Conversational Runtime V3 — Conversa Primeiro

Esta versão corrige o problema em que o HAL parecia um “papagaio” ou um roteador de abas.

## Mudança principal

O modo automático agora funciona assim:

```text
Usuário pergunta
HAL responde naturalmente
Se precisar de ferramenta, ele usa por trás
Ele não joga o usuário para outra tela
Ele não exige botão para continuar
Ele mantém o contexto da conversa
Ele pode fazer perguntas de esclarecimento coerentes
```

## Antes

```text
Usuário: ação prática
HAL: Entendi. Me conta um pouco mais...
Usuário: eu quero que transforme isso numa ação prática
HAL: Entendi. Me conta um pouco mais...
```

## Agora

```text
Usuário: ação prática

HAL:
Pode ser sim — mas eu preciso saber qual assunto você quer transformar em ação prática.
Qual é o tema ou objetivo da ação?

Usuário:
eu quero que transforme isso numa ação prática

HAL:
Sim, pode. Só falta você me dizer o tema dessa ação.
É uma ação comercial, financeira, de banco de dados, reunião, estudo, atendimento ou automação?
```

## O que foi alterado

```text
Modo automático não abre painel técnico sozinho
Checkbox de painel vem desligado por padrão
Conversa usa memória de sessão
Resposta repetida é bloqueada
Ferramentas são usadas em segundo plano
Retorno técnico não substitui a resposta humana
Realtime voice também usa conversa natural
Unified turn em automático força Conversational Runtime V3
```

## Estilo desejado

O HAL deve ser uma IA declarada, mas com presença natural:

```text
Calmo
Seguro
Objetivo
Educado
Inteligente
Sem soar robótico
Sem responder como formulário
Sem forçar módulo ou aba
Sem inventar dado
```

A inspiração é uma presença serena e observadora como assistentes clássicos de ficção científica, mas sem fingir ser humano físico.

## Regras

```text
Responder o que foi perguntado.
Quando faltar contexto, perguntar somente o que falta.
Não repetir a mesma pergunta genérica.
Não abrir painel se o usuário só quer conversar.
Não obrigar o usuário a apertar botão para continuar.
Manter ferramentas nos bastidores.
Mostrar detalhes técnicos apenas como apoio.
```

## Ollama

O Auto Ollama continua funcionando. Se o modelo local responder, o HAL usa o modelo para deixar a conversa mais natural. Se falhar, usa fallback contextual.
