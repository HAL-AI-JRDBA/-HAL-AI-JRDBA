# HAL Meeting Intelligence Gateway

Esta versão adiciona ao projeto a camada para uso do HAL em reuniões, calls e videoconferências.

## Objetivo

Permitir que pessoas em uma reunião no Microsoft Teams, Google Meet ou outra plataforma possam fazer perguntas para o HAL e receber resposta:

```text
Por voz
Por texto no chat da reunião
Na tela do HAL
Na ata da reunião
Como tarefa/ação pendente
```

## Plataformas contempladas

```text
Microsoft Teams
Google Meet
Zoom — preparado para futura integração
Webex — preparado para futura integração
Áudio Local / Desktop Companion
```

## Modos

```text
Modo Ouvinte
- Escuta e transcreve
- Gera ata
- Identifica decisões, riscos e tarefas
- Não responde automaticamente

Modo Perguntas e Respostas
- Participantes chamam “HAL”
- HAL entende a pergunta
- Consulta ferramentas internas
- Responde por voz e/ou texto

Modo Agente de Reunião
- Acompanha a reunião
- Responde perguntas
- Registra decisões
- Cria tarefas
- Gera resumo final
```

## Exemplos

```text
HAL, verifique os alertas do Zabbix e Grafana para TI.
HAL, consulte as vendas de passagens de hoje por linha.
HAL, qual cliente está com maior pendência no CRM?
HAL, gere a ata dessa reunião.
HAL, crie as tarefas com responsáveis e prazos.
```

## Integrações usadas durante a reunião

```text
Human Conversation Gateway
Enterprise Integration & Team Intelligence
Database Access Wizard
Universal ERP Connector
Reliable Web Answer
Power BI
Zabbix
Grafana
ERP
CRM
Calendários
Teams / Google Meet / canais
```

## Importante sobre funcionamento real

Esta camada adiciona estrutura funcional, endpoints, telas, roteamento, ata, perguntas, respostas preparadas por voz/texto e plano de entrega.

Para o HAL realmente falar dentro da reunião, é necessário configurar no cliente uma destas opções:

```text
1. Bot oficial do Teams com permissões corporativas
2. Desktop/Browser Companion autorizado para Teams/Google Meet
3. Áudio local com STT/TTS
4. Integração específica da plataforma quando disponível
```

## Privacidade

Antes de usar em reunião real, a empresa deve avisar os participantes que o HAL poderá transcrever/analisar a reunião.

A camada exige consentimento/aviso quando configurado.
