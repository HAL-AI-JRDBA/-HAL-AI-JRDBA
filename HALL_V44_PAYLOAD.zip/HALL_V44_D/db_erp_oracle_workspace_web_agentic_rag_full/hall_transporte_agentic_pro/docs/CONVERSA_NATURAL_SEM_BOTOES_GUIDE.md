# HAL Human Conversation Gateway — Conversa Natural sem Botões

Esta versão adiciona a camada que faltava para o HAL deixar de parecer mecânico.

O objetivo é simples: o usuário fala ou digita normalmente. O HAL decide sozinho se aquilo é:

```text
Bate-papo amigável
Pergunta geral
Pergunta atual que exige pesquisa web
Demanda de negócio
Consulta a ERP
Consulta a banco SQL/NoSQL
Automação
Missão para agentes
Ação sensível que exige aprovação
```

## Comportamento esperado

O usuário não precisa escolher aba nem apertar botão específico. Em modo automático, a entrada principal passa primeiro pela camada de conversa natural.

### Exemplo 1 — bate-papo

Usuário:

```text
Bom dia, HAL. Tudo bem?
```

HAL:

```text
Bom dia! Tudo bem por aqui. Pode falar comigo naturalmente, sem escolher aba nenhuma.
Se for só para conversar, eu converso. Se for algo do trabalho, eu entendo o pedido e escolho a ferramenta certa nos bastidores.
O que você quer resolver agora?
```

### Exemplo 2 — negócio e banco

Usuário:

```text
HAL, preciso consultar no banco as vendas de passagens de hoje por linha.
```

HAL entende que é banco/negócio, aciona o Database Access Wizard e pergunta somente o que falta:

```text
Certo, isso parece depender de uma base de dados.
Antes de consultar, preciso saber qual banco ou conexão devo usar e exatamente quais dados você quer tirar.

Para eu acessar a base certa e trazer um resultado preciso, preciso dessas informações:
1. Qual banco/conexão devo acessar?
2. Quais tabelas, views, coleções, índices ou entidades devo consultar?
3. Quais campos/métricas precisa retornar?
4. Como quer receber o resultado?
```

### Exemplo 3 — conversa sobre venda

Usuário:

```text
Quero conversar um pouco sobre como vender essa IA.
```

HAL responde como bate-papo e pode transformar a conversa em ação quando o usuário quiser.

## Recursos adicionados

```text
HAL Human Conversation Gateway
Bate-papo natural e educado
Saudações pelo horário
Resposta com tom cordial, objetivo e menos robótico
Classificação de conversa comum versus demanda de negócio
Roteamento invisível para ferramentas
Entrada única sem obrigar escolha de aba
Integração com Database Access Wizard
Integração com Universal ERP Connector
Integração com Reliable Web Answer
Integração com Visual Mission Control
Integração com n8n, browser, cron e canais
Memória leve de sessão
Política de aprovação para ações sensíveis
```

## Regra principal

```text
Conversar primeiro.
Entender a intenção.
Acionar ferramenta só quando necessário.
Perguntar apenas o que falta.
Nunca inventar dados.
Nunca exigir que o usuário escolha aba.
```

## Observação

A IA fica mais natural pela camada de diálogo e roteamento. Para voz realmente humana, ainda depende do motor de STT/TTS configurado no ambiente do cliente.
