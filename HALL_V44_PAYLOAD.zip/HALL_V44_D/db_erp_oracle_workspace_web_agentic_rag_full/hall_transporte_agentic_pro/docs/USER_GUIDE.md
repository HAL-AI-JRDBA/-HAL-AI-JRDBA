# User Guide — HAL MultiSegmento Agentic Pro

## 1. O que é

O HAL é um assistente local para empresas de Transporte, Logística, Financeiro/Contábil, Varejo, Atacado/Distribuição e outros segmentos.

Ele conversa por voz/texto, planeja tarefas, consulta lógica de ERP transporte, gera SQL inicial, analisa tela/câmera, usa memória local e executa automações com aprovação.

## 2. Como conversar

Você pode falar naturalmente:

```text
HAL, bom dia.
HAL, o ERP está lento. Verifique Oracle, Zabbix e bilheteria.
HAL, qual o último mês da base de dados de arrecadação?
HAL, veja minha tela e analise o dashboard.
```

## 3. Orquestração

Cada pedido passa pelo fluxo:

```text
Entender → Planejar → Executar ferramenta → Verificar → Corrigir resposta
```

A aba **Orquestração** mostra o plano técnico.

## 4. Transporte: exemplos práticos

### Arrecadação

```text
HAL, qual o último mês da base de dados de arrecadação?
```

Retorna SQL inicial para descobrir o maior período disponível.

### Contas a receber / CRC

```text
HAL, analise contas a receber vencidas e diga o que priorizar.
```

Prepara consulta para priorizar maiores valores vencidos.

### Monitoramento

```text
HAL, o ERP está lento. Verifique Oracle, Zabbix e bilheteria.
```

Cria plano de diagnóstico operacional.

### Frota

```text
HAL, crie um plano para acompanhar manutenção preventiva da frota.
```

Gera plano de automação/indicadores.

## 5. Visão

Use:

1. Clique em **Tela** ou **Câmera**
2. Autorize no navegador
3. Clique em **Analisar**

Com Ollama multimodal ativo, ele descreve a tela/imagem. Sem Ollama, salva a captura e usa fallback.

## 6. Desktop

Recursos:

- Screenshot desktop
- Foto câmera desktop
- Digitar na janela ativa
- Criar pasta
- Abrir site/pesquisa

Para ações de controle, marque:

```text
Aprovar ações no computador
```

## 7. Memória

Para memorizar:

```text
HAL, lembre que eu prefiro respostas objetivas para diretoria.
```

Para pesquisar:

```text
HAL, o que você lembra sobre minhas preferências?
```

A memória é local e fica em:

```text
data/memory/memories.json
```

## 8. Modelos

Na tela **Modelos locais**, clique em:

```text
Status modelos
```

Você verá se Ollama está online e quais modelos estão instalados.

## 9. Quando ele perguntar mais detalhes

Se você disser:

```text
HAL, último mês da base de dados
```

Ele vai perguntar de qual módulo:

```text
arrecadação, bilheteria, viagens, frota, manutenção, escala, financeiro, CRC, CPG, folha ou jurídico
```

Isso é correto: evita SQL errado.

## 10. Limitações

- O HAL não adivinha tabela real do ERP sem metadados conectados.
- SQL gerado é inicial e deve ser validado.
- Para conversa muito natural, use Ollama ativo com modelo forte.
- Para voz clonada própria, é necessário TTS local avançado.
- Para visão real de alta qualidade, use modelo multimodal local.


## Expansão Multi-Segmento

A plataforma agora não está limitada a transporte. Ela contempla:

```text
Transporte de Passageiros Urbano e Rodoviário
Logística
Financeiro / Contábil
Varejo
Atacado / Distribuição
Segmentos genéricos com ERP, CRM, BI e dados
```

## Bancos Relacionais e NoSQL

Camada conceitual e de roteamento para:

```text
Oracle
SQL Server
PostgreSQL
MySQL
MariaDB
SQLite
MongoDB
Redis
Cassandra
Elasticsearch / OpenSearch
Neo4j
```

Ações de escrita e automações críticas continuam exigindo aprovação humana.


## HAL Business Teams

Foi adicionada a camada de times de agentes empresariais com templates de Atendimento, Vendas/SDR, Conteúdo, Financeiro, Operações, Dados/BI, Automação e Jarvis Executivo, incluindo canais externos e fila de aprovação humana.


## HAL SaaS Builder / White Label Studio

Adicionada camada para criar apps/sites com IA, white-label, domínio próprio, projetos por cliente, preview local, código-fonte inicial, Dockerfile, deploy plan, versionamento, rollback e planos de assinatura.


## HAL Agent Runtime Enterprise

Adicionada camada de runtime para tarefas longas, fila persistente, checkpoints, pausa/retomada/cancelamento, agentes paralelos, sandbox, testes, scorecard, métricas, observabilidade, segurança enterprise e Model Advisor para modelos open-source por hardware.


## HAL Human Voice Assistant 24x7

Adicionada camada para avatar futurístico, conversa natural pt-BR, sotaque paulista/neutro, voz própria autorizada, assistente pessoal 24x7, funcionário especialista por área, política de turn-taking, barge-in e resposta humanizada integrada ao roteamento do HAL.


## HAL Real-Time Voice Engine

Adicionada camada de voz em tempo real com escuta contínua, detecção de silêncio final, barge-in, transcrição parcial/final, TTS mais lento e audível, avatar com estados, roteamento automático para ferramentas e adaptadores para faster-whisper, whisper.cpp, Piper, Coqui XTTS, F5-TTS e OpenVoice.


## HAL Open AI Access Center

Adicionada camada para democratizar IA local: escolha CPU/GPU, catálogo de modelos open-source/open-weight, plano Ollama, marketplace de funcionários digitais, modo empresa pequena/profissional/enterprise local, acesso externo seguro, ROI, backup, atualização e rollback.


## HAL OpenClaw Enterprise Layers

Adicionadas 6 camadas: Channel Gateway, n8n Workflow Center, Browser Automation, Cron Enterprise, Sandbox Enterprise e Agent Framework Bridge. Essas camadas conectam o HAL a canais externos, workflows n8n, navegador controlado, agendamentos, sandbox Docker e frameworks como CrewAI, LangGraph, AutoGen, MCP e OpenClaw.


## HAL Visual Mission Control

Adicionado painel visual futurístico estilo escritório digital de agentes, com salas por área, avatares, missões, aprovações, notas do dia, produtividade, modo operação e modo apresentação para clientes.


## HAL Universal ERP & Application Connector

Adicionada camada universal para conectar ERP, bancos relacionais/NoSQL, APIs, arquivos, n8n, browser/RPA e sistemas individuais, incluindo venda de passagens, bilhetagem e vale-transporte, com consulta somente leitura por padrão e aprovação humana para ações sensíveis.


## HAL Human Conversation Gateway

Adicionada camada de conversa natural sem botões. Em modo automático, o usuário pode falar ou digitar livremente; o HAL responde como bate-papo quando for conversa comum e aciona Database Access, ERP, Web, Mission Control ou automações nos bastidores quando for trabalho.


## HAL Enterprise Integration & Team Intelligence

Adicionada camada corporativa para integrar Power BI, Zabbix, Grafana, ERP, CRM, WhatsApp, Telegram, Teams, Slack, e-mail, calendários, n8n e bancos SQL/NoSQL, com times multiagentes por setor, usuário, agenda e segmento.


## HAL Meeting Intelligence Gateway

Adicionada camada para Teams, Google Meet, Zoom/Webex futuro e áudio local: perguntas por voz/texto durante reuniões, respostas no chat/voz, ata automática, decisões, tarefas e consulta a ERP, CRM, Power BI, Zabbix, Grafana e bancos.


## HAL Omnichannel Voice/Text Delivery

Adicionada camada para entregar respostas do HAL por WhatsApp e Telegram em texto e voz, com contatos, aprovação humana, credenciais por variável de ambiente, auditoria, preparação de roteiro de voz e integração com Conversa Natural, Meeting Intelligence e Enterprise Teams.


## E-mail ao Solicitante

Adicionado envio/preparo de e-mail ao solicitante dentro do HAL Omnichannel Voice/Text Delivery, com corpo em texto, áudio anexado quando disponível, assunto automático, SMTP por variáveis de ambiente e aprovação humana antes de envio externo.


## HAL Dialogue Brain V2

Substituída a conversa natural por uma versão anti-papagaio, com memória de sessão, resposta contextual, fallback para Ollama/modelo local, perguntas de esclarecimento reais e correção do comportamento repetitivo em mensagens curtas ou ambíguas.


## HAL Auto Ollama Setup

Adicionada inicialização automática do Ollama/modelo local. O sistema verifica instalação, tenta instalar via winget quando necessário, inicia o serviço, configura OLLAMA_MODEL/HALL_DIALOG_MODEL/OLLAMA_URL na sessão, baixa `qwen2.5:7b` se faltar e continua em fallback se houver falha.


## HAL Conversational Runtime V3

Adicionado modo “conversa primeiro”: no automático, o HAL responde naturalmente, mantém o contexto, não abre painel técnico sozinho, não repete frases genéricas e usa ferramentas em segundo plano.


## HAL Executive Financial Intelligence

Adicionada camada executiva financeira para gestores e diretoria, com indicadores fundamentalistas, EBITDA, DRE, fluxo de caixa, margens, liquidez, endividamento, rentabilidade, inadimplência, capital de giro, score de saúde financeira, fontes reais ERP/bancos/Power BI/DRE e regra de não inventar números.


## HAL Skills & Multi-Agent Center

Adicionada camada local-first para Skills em Markdown, hub local estilo ClawHub, agentes especializados, delegação de tarefas, sessions_spawn, colaboração multiagente, briefing de geração de imagens, execução governada e auditoria.


## HAL Microphone No-Speech Fix

Corrigido o erro `Erro no microfone: no-speech`: agora o HAL não trata silêncio inicial como falha fatal, testa permissão de microfone, tenta ouvir novamente automaticamente, aumenta o tempo de silêncio antes de enviar e mantém fallback por texto.


## HAL Live Dialogue Engine V4

Corrigida a rota principal para conversa natural real: o HAL responde primeiro, usa ferramentas em segundo plano, não abre painel técnico sozinho, mantém sessão, usa o modelo local com contexto das ferramentas e deixa de se comportar como roteador/papagaio.


## HAL Voice STT Fallback V5

Corrigido o estado “Não ouvi nada ainda...” adicionando gravação local com MediaRecorder e transcrição local por faster-whisper/openai-whisper quando o Web Speech do navegador falhar.


## HAL Live Chat Kernel V6

Corrigido o bate-papo curto e natural: mensagens como “comigo”, “converse comigo”, “sim”, “pode” e frases pequenas agora são tratadas como conversa viva, não como fallback mecânico de formulário.


## HAL Topic Switch & Full Question Capture V7

Corrigida a mudança de assunto e a captura truncada de perguntas por voz. O HAL agora identifica mudança entre temas como almoço/cardápio e ciência/buracos negros, e usa por padrão gravação completa + STT local para evitar cortes na pergunta.


## HAL Conversation Repair V8

Corrigido o roteamento errado de frases como “acredito que você não está me ouvindo”. Agora isso entra em `conversation_repair`, não em Skills/Multi-Agent. O HAL reconhece falha de escuta/entendimento, abandona a interpretação anterior e pede a pergunta completa sem abrir ferramenta errada.


## HAL Voice State Machine V9

Corrigido travamento em “Gravando voz completa...”. Agora o modo voz tem timeout de 9s, watchdog de 12s, botão Conversar vira “Responder agora”, botão Parar fecha a gravação, `MediaRecorder.start(1000)` gera chunks contínuos e a gravação não deve ficar presa.


## HAL Voice Safety V10

Corrigida a piora do modo “gravação primeiro”: agora gravação local só é usada se o STT local estiver pronto; caso contrário usa voz do navegador ou texto. O contador também fecha a gravação ao chegar a zero e a tela não deve ficar presa em “Aguardando pedido”.


## HAL Software Builder & Anti-Parrot V11

Corrigido o caso “Eu quero um software para controlar minhas finanças pessoais”. Agora o HAL reconhece como `software_builder`, responde com arquitetura Python/Web/SQLite, não pede “ponto central” e consegue gerar scaffold local de app de finanças pessoais.


## HAL App Factory Pro V12

Adicionada fábrica de sistemas completos estilo Lovable/Zheus local: login, páginas, CRUD, filtros, cálculos, estado vazio, settings, cobrança falhou, teto de custo de IA, preview, GitHub manifest, deploy Docker/local, templates, white-label e quality gate.


## HAL Enterprise Productization V13

Adicionada camada de produto comercial robusto: saúde da plataforma, testes automáticos de roteamento, 60 Skills, 45 templates, 20 integrações configuráveis, deploy assistido, GitHub manifest, Quality Gate global, Agent Fleet Manager 24/7, Knowledge/RAG Center e white-label com planos, custo de IA e alerta de cobrança.


## HAL Cyber Defense & Ransomware Shield V14

Adicionada camada defensiva contra invasões, phishing, anexos infectados, malware e ransomware: triagem de e-mail, detecção de anexos perigosos, canários, baseline de arquivos, detecção de alteração em massa, verificação de backup, postura de segurança, playbook de incidente, alertas e catálogo EDR/SIEM. Ações reais exigem credenciais e aprovação humana.


## HAL Multi-Model Router V15

Adicionada camada de roteamento automático de modelos Ollama: `qwen2.5:7b` para conversa, `qwen2.5-coder:14b` para software, `qwen2.5-coder:7b` para código rápido, `deepseek-coder-v2:16b` para programação complexa, `sqlcoder:7b-q4_0` para SQL, `embeddinggemma:latest` para RAG/embeddings, `llava:latest` para visão e `phi3:mini` para respostas rápidas. O boot agora verifica todos os modelos especializados.
