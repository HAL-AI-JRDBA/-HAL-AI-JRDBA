# HAL Database Access Wizard

Esta versão adiciona uma camada específica para corrigir o problema de acesso a bases de dados.

O HAL agora não deve simplesmente tentar responder ou abrir uma aba. Quando a pergunta exigir dados internos, ele deve:

```text
1. Identificar que precisa consultar banco SQL ou NoSQL.
2. Perguntar qual banco/conexão deve acessar.
3. Perguntar quais informações o usuário precisa.
4. Perguntar filtros, período, empresa, filial, linha, produto, cliente ou unidade.
5. Perguntar tabelas, views, coleções, índices ou entidades quando necessário.
6. Perguntar campos, métricas e formato de saída.
7. Montar um plano seguro de consulta.
8. Executar somente em modo leitura por padrão.
9. Exigir aprovação humana para qualquer escrita ou ação sensível.
```

## Bancos suportados no catálogo

```text
Oracle
SQL Server
PostgreSQL
MySQL
MariaDB
SQLite
Firebird
IBM DB2
MongoDB
Redis
Elasticsearch
Cassandra
CouchDB
```

## Perguntas obrigatórias quando faltar informação

```text
Qual banco/conexão devo acessar?
Qual pergunta de negócio você quer responder?
Qual período, filtro, empresa, filial, linha, cliente, produto ou unidade devo considerar?
Você sabe quais tabelas, views, coleções, índices ou entidades devo consultar?
Quais campos/métricas precisa retornar?
Como quer receber o resultado?
```

## Exemplo

Usuário:

```text
HAL, consulte no banco de dados as vendas de passagens de hoje por linha.
```

Se não houver conexão cadastrada, o HAL responde:

```text
Para eu acessar a base certa e trazer um resultado preciso, preciso dessas informações:
1. Qual banco/conexão devo acessar? Ex: Oracle ERP Produção, MongoDB BI, SQL Server Financeiro.
2. Quais campos/métricas precisa retornar? Ex: total, quantidade, status, valor, linha, data, cliente.
3. Como quer receber o resultado? Resumo, tabela, ranking, gráfico, CSV/Excel, relatório ou mensagem para aprovação.
```

## Segurança

```text
Consulta somente leitura por padrão.
Não executar UPDATE, DELETE, INSERT, DROP, MERGE, TRUNCATE sem aprovação.
Não escolher banco de produção sozinho.
Não consultar sem período/filtro em produção.
Não exportar dados pessoais sem aprovação.
Não gravar senha/token no JSON.
Credenciais devem ficar em variáveis de ambiente ou cofre local.
```

## Variáveis de ambiente

Cada conexão recebe um prefixo. Exemplo:

```text
ERP_TRANSPORTE_HOST
ERP_TRANSPORTE_PORT
ERP_TRANSPORTE_DATABASE
ERP_TRANSPORTE_USER
ERP_TRANSPORTE_PASSWORD
ERP_TRANSPORTE_SERVICE_NAME_OR_SID
```

Para MongoDB:

```text
BI_MONGO_URI
BI_MONGO_DATABASE
BI_MONGO_USER
BI_MONGO_PASSWORD
```
