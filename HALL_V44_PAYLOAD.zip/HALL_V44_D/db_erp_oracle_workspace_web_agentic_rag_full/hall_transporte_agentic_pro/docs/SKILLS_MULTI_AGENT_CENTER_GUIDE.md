# HAL Skills & Multi-Agent Center

Esta versão adiciona ao projeto uma camada local-first inspirada em ambientes de Skills, ferramentas e agentes de IA.

## Objetivo

Permitir que o HAL tenha um centro próprio para:

```text
Criar Skills em arquivos .md
Instalar Skills de um hub local estilo ClawHub
Manter biblioteca local de Skills
Criar agentes especializados
Delegar tarefas para agentes
Criar sessões paralelas estilo sessions_spawn
Fazer agentes colaborarem entre si
Preparar geração de imagens
Organizar arquivos locais em workspace
Preparar código/automações com política de sandbox
Auditar execuções, tarefas e sessões
```

## Local-first

A camada foi feita para rodar localmente. A nuvem continua opcional.

```text
Skills ficam no disco local
Hub de Skills fica local
Agentes ficam no banco/JSON local
Sessões multiagente ficam locais
Auditoria fica local
Endpoint de imagem pode ser local
Modelos continuam usando Auto Ollama/local quando disponível
```

## Skills em Markdown

As Skills usam arquivos `.md` com frontmatter:

```markdown
---
id: simple_teacher
name: Professor Simples para Leigos e Crianças
category: educacao
version: 1.0
risk: low
agent: agent_educacao
---
# Objetivo
Explicar qualquer assunto de forma simples.

# Procedimento
1. Entender o nível do aluno.
2. Usar exemplos do cotidiano.
3. Explicar passo a passo.
```

## Skills padrão incluídas

```text
executive_finance_review
database_query_planner
simple_teacher
image_generation_brief
workflow_builder
web_research_brief
natural_customer_reply
operations_diagnostics
```

## Hub local estilo ClawHub

O projeto cria um hub local em:

```text
hall_transporte_agentic_pro/data/skills_multi_agent_center/local_skill_hub
```

A partir dele, o usuário pode instalar Skills no runtime local.

## Agentes especializados

Agentes padrão incluídos:

```text
Agente Financeiro
Agente Dados/BI
Agente Operações
Agente Atendimento
Agente Educação
Agente Pesquisa Web
Agente Automação
Agente Design/Imagem
```

## sessions_spawn

A camada cria sessões paralelas para agentes trabalharem em um objetivo.

Exemplo:

```text
HAL, abra uma sessions_spawn com financeiro, dados e operações para analisar a empresa.
```

O HAL cria a sessão, seleciona agentes e registra eventos.

## Colaboração multiagente

Exemplo:

```text
HAL, faça agentes financeiro, dados e operações colaborarem para montar um plano de ação para diretoria.
```

Resposta esperada:

```text
Criei uma colaboração multiagente para o objetivo informado.
Cada agente recebeu uma parte do problema.
O próximo passo é consolidar respostas, validar dados reais e devolver recomendação única.
```

## Geração de imagens

A camada prepara:

```text
Prompt final
Negative prompt
Estilo
Tamanho
Manifesto JSON
Status do endpoint local
```

Sem endpoint local, ela prepara o briefing. Com endpoint local configurado, pode ser integrada a geradores locais como Stable Diffusion/ComfyUI/Automatic1111 ou outro endpoint interno.

## Código e automações

Esta versão prepara execução governada. A regra é:

```text
Código real e ações destrutivas exigem sandbox/aprovação.
Skills sensíveis exigem aprovação.
Operações em banco devem ser somente leitura por padrão.
```

## APIs principais

```text
GET  /api/skills-center/status
GET  /api/skills-center/skills
POST /api/skills-center/skill
POST /api/skills-center/run
GET  /api/skills-center/hub
POST /api/skills-center/install-from-hub/{skill_id}
GET  /api/skills-center/agents
POST /api/skills-center/agent
POST /api/skills-center/spawn-session
POST /api/skills-center/delegate-task
POST /api/skills-center/collaborate
POST /api/skills-center/image-brief
GET  /api/skills-center/image-briefs
POST /api/skills-center/ask
POST /api/skills-center/seed-demo
```

Também existem endpoints equivalentes no Console Unificado:

```text
/api/unified/skills-center/...
```

## Integrações preservadas

A camada foi integrada com:

```text
Conversational Runtime V3
Human Conversation Gateway
Orchestrator
Tool Router
Console Unificado
Agentic Pro
Executive Financial Intelligence
Omnichannel WhatsApp/Telegram/E-mail
Meeting Intelligence
Enterprise Teams
Database Access Wizard
```

## Exemplos de uso

```text
HAL, crie uma skill para analisar contratos de fornecedores.
HAL, instale do hub local a skill simple_teacher.
HAL, rode a skill simple_teacher para explicar equação de primeiro grau.
HAL, abra uma sessions_spawn para financeiro, dados e operações.
HAL, faça uma colaboração multiagente para analisar saúde financeira e riscos.
HAL, gere uma imagem futurista do painel executivo do HAL.
```

## Observação honesta

Esta versão cria a camada funcional local de Skills, agentes, sessões, colaboração e briefing de imagem. Para geração real de imagens ou execução real de código, é necessário configurar o endpoint local correspondente e/ou sandbox de execução no ambiente do cliente.
