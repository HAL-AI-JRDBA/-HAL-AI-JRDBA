# HAL Business Teams — Guia de Uso

Esta camada adiciona o conceito de **time de agentes empresariais**, parecido com uma empresa trabalhando junto com o usuário.

## Times disponíveis

```text
Atendimento
Vendas / SDR
Conteúdo
Financeiro / Contábil
Operações
Dados / BI
Automação
Jarvis Executivo Pessoal
Personalizado
```

## Agentes disponíveis

```text
CEO Agent / Orquestrador
Agente de Governança
Agente de Atendimento
Agente SDR / Vendas
Agente de Conteúdo
Agente Financeiro / Contábil
Agente de Operações
Agente de Dados / BI
Agente de Automação
Jarvis Executivo Pessoal
```

## Canais preparados

```text
Web Chat
WhatsApp via Evolution API / WAHA / Meta Cloud API
Telegram Bot API
Discord Bot
E-mail IMAP/SMTP
iMessage via bridge macOS
Desktop Local
Power BI
Zabbix
Grafana
```

## Como usar

No Console Unificado, escreva por exemplo:

```text
HAL, crie um time de atendimento no WhatsApp para minha empresa de logística.

HAL, monte um time de vendas SDR para atacado B2B.

HAL, crie um time financeiro para priorizar contas a receber no SQL Server.

HAL, crie um time de dados e BI para analisar vendas do varejo no MongoDB.

HAL, crie um Jarvis Executivo para me dar briefing diário de indicadores.
```

O HAL detecta o objetivo, escolhe template, segmento, banco e canais, monta os agentes, cria workflow e coloca ações sensíveis na fila de aprovação humana.

## Aprovação humana

Ações sensíveis, como enviar mensagem para cliente, escrever em ERP/banco, alterar arquivo, abrir canal externo ou executar desktop, exigem aprovação.

## Arquivos locais

```text
data/business_teams/teams.json
data/business_teams/approvals.json
data/business_teams/audit.jsonl
```

## Observação

Os conectores de WhatsApp, Telegram, Discord e E-mail estão preparados como adaptadores. Para usar em produção, é necessário configurar tokens/credenciais do canal escolhido.
