@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo HAL TRANSPORTE AGENTIC PRO - INSTALACAO
echo ============================================================
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Python Launcher "py" nao encontrado.
  echo Instale Python 3.11 ou superior x64.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Criando ambiente virtual .venv...
  py -3 -m venv ".venv"
  if errorlevel 1 (
    echo [ERRO] Falha ao criar ambiente virtual.
    pause
    exit /b 1
  )
)

call ".venv\Scripts\activate.bat"

echo Atualizando pip...
python -m pip install --upgrade pip setuptools wheel

echo Instalando dependencias completas...
pip install -r requirements.txt

if errorlevel 1 (
  echo.
  echo [AVISO] Falha nas dependencias completas.
  echo Tentando instalacao minima...
  pip install -r requirements_minimo.txt
)

echo.
echo [OK] Instalacao concluida.
echo Proximo passo opcional: CONFIGURAR_MODELOS_OLLAMA.bat
echo Para iniciar: INICIAR_HALL_AGENTIC_PRO.bat
pause
endlocal
