@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo [ERRO] Execute install_web.bat primeiro.
  pause
  exit /b 1
)
call ".venv\Scripts\activate.bat"

echo Validando imports...
python -c "import app.main; print('[OK] Backend importou')"
if errorlevel 1 pause

echo.
echo Validando Ollama...
where ollama >nul 2>nul
if errorlevel 1 (
  echo [AVISO] Ollama nao encontrado. O sistema usara fallback deterministico.
) else (
  ollama list
)

pause
endlocal
