@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo HAL TRANSPORTE AGENTIC PRO
echo ============================================================
echo.

if not exist ".venv\Scripts\python.exe" (
  echo [ERRO] Ambiente .venv nao encontrado.
  echo Execute primeiro: install_web.bat
  pause
  exit /b 1
)

call ".venv\Scripts\activate.bat"

echo Abrindo http://127.0.0.1:8030
start "" "http://127.0.0.1:8030"

python -m uvicorn app.main:app --host 127.0.0.1 --port 8030

pause
endlocal
