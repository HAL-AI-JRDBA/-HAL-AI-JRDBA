@echo off
call "%~dp0INICIAR_JR_AI_HALL_V18_2.bat"
