# RL + Schema-Aware SQL Architecture

Esta versão adiciona:

- `schema_registry.py`: registro canônico unindo Oracle vivo + ground truth
- `column_resolver.py`: resolvedor de colunas reais por tabela
- `join_graph.py` / `path_selector.py`: subgrafo relacional para evitar joins inventados
- `feedback_store.py`: armazenamento em SQLite do feedback das SQLs
- `trace_store.py`: trilhas de execução em JSON
- `reward_engine.py`: recompensa por execução/validação/latência
- `policy_bandit.py`: aprendizado online para escolher estratégia de geração
- `preference_export.py`: exportação de preferências para treino offline
- `training/`: scripts-base para Reward/DPO/GRPO

## Caminhos importantes

- Ground truth canônico: `data/ground_truth/Tabelas_Colunas_Relacionamentos.txt`
- Feedback SQLite: `data/learning/feedback.sqlite`
- Policy bandit: `data/policies/policy_bandit.json`
- Preferências exportadas: `training/datasets/sql_preferences.json`

## Endpoints novos

- `GET /api/learning/status`
- `POST /api/learning/export-preferences`

## Fluxo SQL

Pergunta -> intenção -> schema registry -> join graph -> column resolver -> policy bandit -> geração SQL -> review/repair -> validação Oracle -> reward/feedback/trace
