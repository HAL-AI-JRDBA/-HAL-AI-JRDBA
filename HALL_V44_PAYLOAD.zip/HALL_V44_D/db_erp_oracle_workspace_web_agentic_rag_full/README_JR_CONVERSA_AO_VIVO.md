# JR Conversa Ao Vivo — JR-AI

Esta versão adiciona uma nova aba **JR Ao Vivo** para deixar a experiência mais parecida com um assistente conversacional por voz.

## O que foi adicionado

- Nova aba **JR Conversa Ao Vivo / JR Ao Vivo**
- Botão **Iniciar conversa**
- Botão **Parar**
- Transcrição ao vivo
- Resposta por texto
- Resposta por voz
- Animação visual de escuta
- Histórico da sessão
- Roteamento automático para:
  - Chat
  - Web Search
  - RAG
  - SQL Copilot
  - DBA Oracle
  - Zabbix/Grafana
  - Power BI
  - Dev Studio
  - Apresentações IA
  - JR PowerPack
  - Agent Evaluation
  - Segurança/Aprovação humana
- Configuração de idioma, wake word e voz
- Configuração para motores locais open-source:
  - whisper.cpp / Vosk / faster-whisper para STT
  - Piper / Coqui TTS / eSpeak NG para TTS
- Integração com Chat JR-AI
- Integração com JR Voz
- Integração com OpenClaw Runtime

## Importante sobre open-source

A aba funciona em dois modos:

1. **Modo navegador**
   - Usa Web Speech API e SpeechSynthesis disponíveis no Chrome/Edge.
   - Não usa OpenAI nem Anthropic.
   - É bom para protótipo e demonstração.

2. **Modo local open-source**
   - Permite configurar motores locais como whisper.cpp, Vosk, Piper ou Coqui.
   - Indicado para produção quando a empresa quer manter voz e transcrição localmente.

## Segurança

A JR-AI não assume controle irrestrito de mouse e teclado.

Ações destrutivas como apagar tabelas, executar `DROP`, `TRUNCATE` ou remover dados são roteadas para **Segurança/Aprovação humana**.

## Endpoints adicionados

```text
GET  /api/jr-live/status
GET  /api/jr-live/config
POST /api/jr-live/config
POST /api/jr-live/session
GET  /api/jr-live/sessions
GET  /api/jr-live/sessions/{filename}
POST /api/jr-live/route
POST /api/jr-live/turn
GET  /api/jr-live/local-engine-notes
GET  /api/jr-live/audit
```

## Como usar

1. Execute a aplicação.
2. Abra a aba **JR Ao Vivo**.
3. Permita o microfone no navegador.
4. Clique em **Iniciar conversa**.
5. Fale com o JR.
6. A IA transcreve, detecta intenção, responde e pode falar a resposta.

## Exemplos de fala

```text
JR, consulte os problemas do Zabbix e diga quais alertas devo priorizar.
```

```text
JR, gere scripts Power Query M para conectar o Power BI aos dados da JR-AI.
```

```text
JR, crie um sistema web em FastAPI com Oracle para ordens de serviço da frota.
```

```text
JR, execute a suíte de testes do assistente.
```
