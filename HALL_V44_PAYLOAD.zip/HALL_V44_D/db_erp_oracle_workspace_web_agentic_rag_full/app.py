from __future__ import annotations

from pathlib import Path
import json
import time

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components
from requests import exceptions as requests_exceptions

from config import CONFIG
from services.analytics_engine import (
    AnalysisBundle,
    anomaly_detection,
    auto_diagnosis,
    compute_financial_indicators,
    detect_fraud_patterns,
    findings_to_text,
    load_dataframe_from_upload,
    predict_part_replacement,
    prepare_dataframe,
    analyze_fuel_driver_change,
)
from services.document_parser import Chunk, build_chunks, normalize_text, parse_uploaded_file
from services.embedding_cache import EmbeddingCache
from services.domain_catalog import (
    build_catalog_markdown,
    build_module_context_text,
    get_module_definition,
    list_module_names,
    module_options_with_manual,
)
from services.history_store import HistoryStore
from services.ollama_client import OllamaClient
from services.oracle_client import OracleConnectionParams, OracleService
from services.prompt_builder import (
    ANALYST_SYSTEM_PROMPT,
    GENERATOR_SYSTEM_PROMPT,
    REVIEWER_SYSTEM_PROMPT,
    build_analyst_prompt,
    build_generation_prompt,
    build_review_prompt,
)
from services.sql_utils import (
    build_create_view_sql,
    choose_best_payload,
    split_notes,
    to_pretty_json,
    try_extract_json,
    unified_diff_text,
)
from services.vector_store import LocalVectorStore
from services.chartdb_integration import build_chartdb_dbml, build_chartdb_ddl
from services.schema_ground_truth import build_schema_grounding_context, load_ground_truth
from core.catalog.extractor import CatalogExtractor
from core.catalog.store import CatalogStore
from core.dba.assistant import DBAAssistant
from core.dba.tools import DBATools
from core.llm.router import LLMRouter
from core.oracle_client import OracleClient
from core.rag.pipeline import RAGPipeline
from core.security.anomaly import AnomalyScorer
from core.security.summarizer import SecuritySummarizer
from core.sql.executor import SQLExecutor
from core.sql.explainer import SQLExplainer
from core.sql.nl2sql import NL2SQLService
from core.sql.tuning import SQLTuningAdvisor
from core.sql.validator import SQLValidator
from core.synthetic.generator import SyntheticDataGenerator


st.set_page_config(page_title='DB ERP Local Studio V3.3 GenAI', layout='wide')

INDEX_PATH = Path(CONFIG.index_path)
HISTORY_DB = Path(CONFIG.history_db_path)
MODULE_OPTIONS = module_options_with_manual()
GENAI_BASE_DIR = Path('genai_data')
GENAI_CATALOG_DIR = GENAI_BASE_DIR / 'catalog'
GENAI_VECTOR_DIR = GENAI_BASE_DIR / 'vectors'
GENAI_UPLOAD_DIR = GENAI_BASE_DIR / 'uploads'
GENAI_CACHE_DIR = GENAI_BASE_DIR / 'cache'
GENAI_LOG_DIR = GENAI_BASE_DIR / 'logs'
EMBED_CACHE_PATH = GENAI_CACHE_DIR / 'embedding_cache.json'

for _p in [GENAI_BASE_DIR, GENAI_CATALOG_DIR, GENAI_VECTOR_DIR, GENAI_UPLOAD_DIR, GENAI_CACHE_DIR, GENAI_LOG_DIR]:
    _p.mkdir(parents=True, exist_ok=True)


def inject_css() -> None:
    st.markdown(
        """
        <style>
        .block-container {padding-top: 1rem; padding-bottom: 2rem;}
        .small-muted {font-size: 0.9rem; opacity: 0.8;}
        .stCodeBlock code {font-size: 0.85rem;}
        </style>
        """,
        unsafe_allow_html=True,
    )


def init_state() -> None:
    defaults = {
        'vector_store': LocalVectorStore(str(INDEX_PATH)),
        'history_store': HistoryStore(str(HISTORY_DB)),
        'indexed': False,
        'retrieved_chunks': [],
        'schema_metadata': '',
        'schema_package': {},
        'candidate_tables': [],
        'selected_tables': [],
        'join_suggestions_text': '',
        'table_roles': {},
        'table_roles_text': '',
        'table_families': {},
        'table_families_text': '',
        'join_blueprints_text': '',
        'chartdb_payload': '',
        'chartdb_format': 'DDL Oracle',
        'chartdb_url': 'http://localhost:5173',
        'generated_json': None,
        'generated_raw': '',
        'reviewed_json': None,
        'reviewed_raw': '',
        'validation_result': None,
        'oracle_connected': False,
        'oracle_params': None,
        'last_prompt': '',
        'last_review_prompt': '',
        'current_history_id': None,
        'editable_select_sql': '',
        'editable_view_name': '',
        'preview_rows': [],
        'current_stage': 'draft',
        'view_module_context_text': '',
        'view_module_name': 'Manual / sem foco',
        'analysis_module_context_text': '',
        'analysis_module_name': 'Manual / sem foco',
        'analysis_bundle': None,
        'analysis_source_name': '',
        'analysis_result': None,
        'analysis_report_text': '',
        'analysis_executive_text': '',
        'oracle_dataset_sql': '',
        'genai_catalog_cache': None,
        'genai_last_sql': '',
        'genai_sql_explanation': '',
        'genai_sql_tuning': '',
        'genai_last_sql_result': None,
        'ground_truth_loaded': False,
        'genai_dba_last_df': None,
        'genai_dba_answer': '',
        'genai_security_df': None,
        'genai_security_scored': None,
        'genai_security_summary_text': '',
        'genai_synthetic_columns': [],
        'genai_synthetic_df': None,
        'genai_synthetic_sql': '',
        'genai_last_rag_answer': '',
        'genai_last_rag_hits': [],
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def load_existing_index() -> None:
    if st.session_state['vector_store'].load():
        st.session_state['indexed'] = True


def sidebar_connection() -> None:
    st.sidebar.header('Infra local')
    st.sidebar.caption('Ollama + Oracle local para views, diagnósticos, RAG híbrido e análises ERP')

    use_thick = st.sidebar.checkbox('Usar Thick Mode', value=True)
    lib_dir = st.sidebar.text_input('Oracle Client lib_dir', value=CONFIG.default_oracle_lib_dir)
    host = st.sidebar.text_input('Host', value='127.0.0.1')
    port = st.sidebar.number_input('Porta', value=1521, step=1)
    service_name = st.sidebar.text_input('Service Name', value='ORCL')
    user = st.sidebar.text_input('Usuário', value='')
    password = st.sidebar.text_input('Senha', type='password', value='')

    if st.sidebar.button('Conectar Oracle', width='stretch'):
        try:
            params = OracleConnectionParams(
                host=host,
                port=int(port),
                service_name=service_name,
                user=user,
                password=password,
                lib_dir=lib_dir,
                use_thick_mode=use_thick,
            )
            oracle = OracleService(params)
            oracle.connect()
            oracle.close()
            st.session_state['oracle_params'] = params
            st.session_state['oracle_connected'] = True
            st.sidebar.success('Conectado ao Oracle com sucesso.')
        except Exception as exc:  # noqa: BLE001
            st.session_state['oracle_connected'] = False
            st.sidebar.error(f'Falha ao conectar: {exc}')


def get_active_oracle() -> OracleService:
    params = st.session_state.get('oracle_params')
    if not params:
        raise RuntimeError('Parâmetros Oracle não configurados.')
    oracle = OracleService(params)
    oracle.connect()
    return oracle


def _oracle_recoverable_hint(exc: Exception) -> str:
    msg = str(exc)
    upper = msg.upper()
    if 'ORA-12637' in upper or 'PACKET RECEIVE FAILED' in upper:
        return msg + ' | Dica: se persistir, teste também desmarcando Thick Mode na barra lateral e reconecte.'
    return msg


def queue_selected_tables_update(selected_tables) -> None:
    values = []
    for item in (selected_tables or []):
        val = str(item).strip().upper()
        if val and val not in values:
            values.append(val)
    st.session_state["_selected_tables_pending"] = values


def apply_pending_selected_tables(valid_options=None) -> None:
    if "_selected_tables_pending" not in st.session_state:
        return
    pending = st.session_state.pop("_selected_tables_pending", []) or []
    if valid_options is not None:
        valid = set(valid_options or [])
        pending = [item for item in pending if item in valid]
    st.session_state["selected_tables"] = pending


def _build_schema_package_fallback(active_oracle: OracleService, owner: str, search_terms: list[str], table_prefix: str, object_limit: int, selected_tables=None) -> dict:
    owner_filter = (owner or active_oracle.params.user).upper()
    selected_tables = [x.upper() for x in (selected_tables or []) if str(x).strip()]
    candidates = active_oracle.find_relevant_objects(owner_filter, search_terms, table_prefix=table_prefix, limit=object_limit)
    table_names = selected_tables or [item['OBJECT_NAME'] for item in candidates if item.get('OBJECT_TYPE') == 'TABLE']
    column_rows = active_oracle._fetch_columns_for_tables(owner_filter, table_names) if table_names else []
    if not column_rows:
        column_rows = active_oracle._fetch_filtered_columns(owner_filter, search_terms, table_prefix=table_prefix)
    grouped = active_oracle._group_columns(column_rows) if column_rows else {}
    metadata_text = active_oracle._format_metadata_text(owner_filter, grouped, object_limit) if grouped else 'Nenhum metadado encontrado.'
    candidate_tables = []
    for name, cols in list(grouped.items())[:object_limit]:
        candidate_tables.append({
            'table_name': name,
            'module_guess': active_oracle._guess_module_name(name),
            'column_count': len(cols),
            'first_columns': ', '.join([c['COLUMN_NAME'] for c in cols[:8]]),
        })
    return {
        'owner': owner_filter,
        'candidate_objects': candidates,
        'candidate_tables': candidate_tables,
        'grouped_columns': grouped,
        'metadata_text': metadata_text,
        'join_suggestions': [],
        'join_text': 'Sugestões de join indisponíveis nesta sessão.',
        'join_blueprints': [],
        'join_blueprints_text': 'Blueprints indisponíveis nesta sessão.',
        'table_roles': {},
        'table_roles_text': 'Classificação indisponível nesta sessão.',
        'table_families': {},
        'table_families_text': 'Famílias indisponíveis nesta sessão.',
        'warnings': ['Modo compatibilidade ativado: pacote completo de schema não estava disponível nesta instância do serviço Oracle.'],
    }


def safe_get_schema_package(active_oracle: OracleService, owner: str, search_terms: list[str], table_prefix: str, object_limit: int, selected_tables=None, module_name: str = '') -> dict:
    method = getattr(active_oracle, 'get_schema_package', None)
    if callable(method):
        try:
            return method(owner=owner, search_terms=search_terms, table_prefix=table_prefix, object_limit=object_limit, selected_tables=selected_tables or None, module_name=module_name)
        except TypeError:
            return method(owner=owner, search_terms=search_terms, table_prefix=table_prefix, object_limit=object_limit, selected_tables=selected_tables or None)
    return _build_schema_package_fallback(active_oracle, owner=owner, search_terms=search_terms, table_prefix=table_prefix, object_limit=object_limit, selected_tables=selected_tables)


def safe_get_schema_summary(active_oracle: OracleService, owner: str, prefixes: list[str], limit: int) -> list[dict]:
    method = getattr(active_oracle, 'get_schema_summary', None)
    if callable(method):
        return method(owner=owner, prefixes=prefixes, limit=limit)
    owner_filter = (owner or active_oracle.params.user).upper()
    rows = active_oracle.find_relevant_objects(owner_filter, [], table_prefix=(prefixes[0] if prefixes else ''), limit=limit)
    for row in rows:
        row['module_guess'] = active_oracle._guess_module_name(row['OBJECT_NAME'])
    return rows


def ensure_oracle_service_compatibility() -> None:
    if not hasattr(OracleService, 'get_schema_package'):
        def _compat_get_schema_package(self, owner=None, search_terms=None, table_prefix='', object_limit=40, selected_tables=None):
            return _build_schema_package_fallback(
                self,
                owner=owner or getattr(getattr(self, 'params', None), 'user', '') or '',
                search_terms=search_terms or [],
                table_prefix=table_prefix,
                object_limit=object_limit,
                selected_tables=selected_tables,
            )
        setattr(OracleService, 'get_schema_package', _compat_get_schema_package)

    if not hasattr(OracleService, 'get_schema_summary'):
        def _compat_get_schema_summary(self, owner=None, prefixes=None, limit=200):
            owner_filter = (owner or getattr(getattr(self, 'params', None), 'user', '') or '').upper()
            rows = self.find_relevant_objects(owner_filter, [], table_prefix=(prefixes[0] if prefixes else ''), limit=limit)
            for row in rows:
                try:
                    row['module_guess'] = self._guess_module_name(row['OBJECT_NAME'])
                except Exception:
                    row['module_guess'] = ''
            return rows
        setattr(OracleService, 'get_schema_summary', _compat_get_schema_summary)


ensure_oracle_service_compatibility()


def health_panel(client: OllamaClient) -> None:
    with st.sidebar.expander('Diagnóstico do Ollama', expanded=False):
        if st.button('Testar Ollama', width='stretch'):
            try:
                models = client.list_model_names()
                st.success('Ollama respondeu corretamente.')
                st.write(models)
            except Exception as exc:  # noqa: BLE001
                st.error(f'Falha no Ollama: {exc}')


def render_top_metrics() -> None:
    history = st.session_state['history_store'].list_versions()
    total_versions = len(history)
    total_validated = sum(1 for item in history if item.get('validation_ok'))
    total_candidates = len(st.session_state.get('candidate_tables') or [])
    analysis_bundle = st.session_state.get('analysis_bundle')
    analysis_rows = int(analysis_bundle.profile['rows']) if isinstance(analysis_bundle, AnalysisBundle) else 0
    col1, col2, col3, col4, col5, col6 = st.columns(6)
    with col1:
        st.metric('Índice local', 'Carregado' if st.session_state.get('indexed') else 'Vazio')
    with col2:
        st.metric('Oracle', 'Conectado' if st.session_state.get('oracle_connected') else 'Desconectado')
    with col3:
        st.metric('Versões salvas', total_versions)
    with col4:
        st.metric('Validadas', total_validated)
    with col5:
        st.metric('Tabelas candidatas', total_candidates)
    with col6:
        st.metric('Linhas análise', analysis_rows)




def _embed_batch_with_backoff(ollama: OllamaClient, embedding_model: str, texts: list[str], timeout: int, keep_alive: str) -> list[list[float]]:
    if not texts:
        return []
    try:
        return ollama.embed(
            embedding_model,
            texts,
            timeout=timeout,
            keep_alive=keep_alive,
            truncate=True,
        )
    except requests_exceptions.Timeout:
        if len(texts) == 1:
            raise
        mid = max(1, len(texts) // 2)
        return _embed_batch_with_backoff(ollama, embedding_model, texts[:mid], timeout, keep_alive) + _embed_batch_with_backoff(ollama, embedding_model, texts[mid:], timeout, keep_alive)




def _format_duration(seconds: float | None) -> str:
    if seconds is None:
        return 'calculando...'
    seconds = max(0, int(seconds))
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def _rate_text(chars_per_sec: float, chunks_per_sec: float) -> str:
    if chars_per_sec <= 0 or chunks_per_sec <= 0:
        return 'calculando...'
    chunks_per_min = chunks_per_sec * 60.0
    return f"≈ {chars_per_sec:,.0f} caracteres/s | {chunks_per_min:,.1f} chunks/min".replace(',', '.')

def _trim_text_for_embedding(text: str, max_chars: int) -> str:
    clean = (text or '').strip()
    if len(clean) <= max_chars:
        return clean
    cut = clean[:max_chars]
    last_break = max(cut.rfind('\n\n'), cut.rfind('. '), cut.rfind('; '), cut.rfind(' '))
    if last_break > int(max_chars * 0.6):
        cut = cut[:last_break]
    return cut.strip()


def _build_embedding_jobs(missing_positions: list[int], missing_texts: list[str]) -> list[dict]:
    jobs = []
    max_items = max(1, int(CONFIG.embedding_batch_size))
    max_chars = max(2000, int(CONFIG.embedding_max_chars_per_batch))
    current_positions = []
    current_texts = []
    current_chars = 0

    for pos, raw_text in zip(missing_positions, missing_texts):
        text = _trim_text_for_embedding(raw_text, int(CONFIG.embedding_max_chars_per_chunk))
        text_len = max(1, len(text))
        would_overflow_items = len(current_texts) >= max_items
        would_overflow_chars = current_texts and (current_chars + text_len > max_chars)
        if would_overflow_items or would_overflow_chars:
            jobs.append({
                'positions': current_positions,
                'texts': current_texts,
                'chars': current_chars,
            })
            current_positions = []
            current_texts = []
            current_chars = 0
        current_positions.append(pos)
        current_texts.append(text)
        current_chars += text_len

    if current_texts:
        jobs.append({
            'positions': current_positions,
            'texts': current_texts,
            'chars': current_chars,
        })
    return jobs


def _build_parent_chunks(chunks: list[Chunk], group_size: int, max_chars: int) -> tuple[list[Chunk], dict[str, str]]:
    if not chunks:
        return [], {}
    parent_chunks: list[Chunk] = []
    child_to_parent: dict[str, str] = {}
    source_groups: dict[str, list[Chunk]] = {}
    for chunk in chunks:
        source_groups.setdefault(chunk.source, []).append(chunk)

    for source, items in source_groups.items():
        bucket: list[Chunk] = []
        bucket_chars = 0
        parent_idx = 0
        for item in items:
            item_text = normalize_text(item.text)
            projected = bucket_chars + len(item_text) + (2 if bucket else 0)
            if bucket and (len(bucket) >= max(1, group_size) or projected > max_chars):
                parent_idx += 1
                parent_id = f"{source}::parent_{parent_idx}"
                parent_text = "\n\n".join(part.text for part in bucket).strip()
                parent_chunk = Chunk(source=source, chunk_id=parent_id, text=parent_text)
                parent_chunks.append(parent_chunk)
                for child in bucket:
                    child_to_parent[child.chunk_id] = parent_id
                bucket = []
                bucket_chars = 0
            bucket.append(item)
            bucket_chars += len(item_text) + (2 if bucket_chars else 0)
        if bucket:
            parent_idx += 1
            parent_id = f"{source}::parent_{parent_idx}"
            parent_text = "\n\n".join(part.text for part in bucket).strip()
            parent_chunk = Chunk(source=source, chunk_id=parent_id, text=parent_text)
            parent_chunks.append(parent_chunk)
            for child in bucket:
                child_to_parent[child.chunk_id] = parent_id
    return parent_chunks, child_to_parent


def index_files(ollama: OllamaClient, embedding_model: str, uploaded_files, force_reembed: bool = False, clear_cache: bool = False) -> None:
    parsed_docs = [parse_uploaded_file(file) for file in uploaded_files]
    chunks = build_chunks(
        parsed_docs,
        CONFIG.chunk_size,
        CONFIG.chunk_overlap,
        target_chunks=CONFIG.adaptive_chunk_target,
        max_chunk_size=CONFIG.adaptive_chunk_max_size,
        min_overlap=CONFIG.adaptive_chunk_min_overlap,
    )
    if not chunks:
        st.warning('Nenhum chunk foi gerado a partir dos arquivos enviados.')
        return

    parent_chunks, child_to_parent = _build_parent_chunks(
        chunks,
        group_size=CONFIG.hybrid_parent_group_size,
        max_chars=CONFIG.hybrid_parent_max_chars,
    )
    if not parent_chunks:
        st.warning('Nenhum bloco semântico pai foi gerado para indexação híbrida.')
        return

    total = len(parent_chunks)
    total_children = len(chunks)
    progress_holder = st.empty()
    status_holder = st.empty()
    details_holder = st.empty()
    eta_holder = st.empty()
    cache = EmbeddingCache(str(EMBED_CACHE_PATH))
    if clear_cache:
        try:
            cache.data = {}
            cache.save()
        except Exception:
            pass

    all_embeddings: list[list[float] | None] = [None] * total
    missing_positions: list[int] = []
    missing_texts: list[str] = []
    for idx, chunk in enumerate(parent_chunks):
        cached = None if force_reembed else cache.get(chunk.text)
        if cached is not None:
            all_embeddings[idx] = cached
        else:
            missing_positions.append(idx)
            missing_texts.append(chunk.text)

    jobs = _build_embedding_jobs(missing_positions, missing_texts)
    total_missing = len(missing_texts)
    total_jobs = len(jobs)
    cached_total = total - total_missing
    processed = 0
    approx_chars = sum(job['chars'] for job in jobs)
    processed_chars = 0
    ema_chars_per_sec: float | None = None
    cache_flush_every = 20
    start_ts = time.perf_counter()

    status_holder.info(
        f'Preparando indexação híbrida: chunks filhos={total_children} | blocos semânticos={total} | em cache={cached_total} | novos={total_missing} | lotes reais={total_jobs}'
    )
    progress = progress_holder.progress(0.0, text='Iniciando geração de embeddings híbridos...')
    if cached_total:
        progress.progress(min(cached_total / max(1, total), 0.99), text=f'Reaproveitando cache vetorial: {cached_total} de {total} blocos semânticos já estavam prontos.')
    eta_holder.info(
        f'Tempo decorrido: 00:00 | ETA: calculando... | Taxa: calculando... | Caracteres novos≈{approx_chars:,}'.replace(',', '.')
    )

    try:
        if total_missing:
            for job_idx, job in enumerate(jobs, start=1):
                job_started = time.perf_counter()
                batch_positions = job['positions']
                batch_texts = job['texts']
                batch_start = processed + 1
                batch_end = processed + len(batch_texts)
                details_holder.caption(
                    f'Lote {job_idx}/{total_jobs} | chunks {batch_start}-{batch_end} de {total_missing} | tamanho do lote={len(batch_texts)} | caracteres≈{job["chars"]}'
                )
                progress.progress(
                    min((cached_total + processed) / max(1, total), 0.99),
                    text=f'Gerando embeddings vetoriais {batch_start}-{batch_end} de {total_missing} blocos...'
                )
                batch_embeddings = _embed_batch_with_backoff(
                    ollama,
                    embedding_model,
                    batch_texts,
                    timeout=CONFIG.embedding_timeout,
                    keep_alive=CONFIG.embedding_keep_alive,
                )
                if len(batch_embeddings) != len(batch_texts):
                    raise ValueError(f'Quantidade de embeddings inesperada no lote {batch_start}-{batch_end}.')
                for rel_idx, vector in enumerate(batch_embeddings):
                    pos = batch_positions[rel_idx]
                    all_embeddings[pos] = vector
                    cache.set(parent_chunks[pos].text, vector)
                if (job_idx % cache_flush_every == 0) or job_idx == total_jobs:
                    cache.save()

                processed += len(batch_texts)
                processed_chars += int(job['chars'])
                elapsed_total = max(time.perf_counter() - start_ts, 1e-6)
                job_elapsed = max(time.perf_counter() - job_started, 1e-6)
                avg_chars_per_sec = processed_chars / elapsed_total if processed_chars else 0.0
                current_chars_per_sec = float(job['chars']) / job_elapsed if job['chars'] else 0.0
                ema_chars_per_sec = current_chars_per_sec if ema_chars_per_sec is None else (ema_chars_per_sec * 0.7) + (current_chars_per_sec * 0.3)
                remaining_chars = max(0, approx_chars - processed_chars)
                effective_chars_per_sec = ema_chars_per_sec or avg_chars_per_sec
                eta_seconds = (remaining_chars / effective_chars_per_sec) if effective_chars_per_sec > 0 else None
                avg_chunks_per_sec = processed / elapsed_total if processed else 0.0

                progress.progress(
                    min((cached_total + processed) / max(1, total), 1.0),
                    text=f'Embeddings concluídos: {processed} de {total_missing} novos blocos semânticos.'
                )
                eta_holder.info(
                    ' | '.join([
                        f'Tempo decorrido: {_format_duration(elapsed_total)}',
                        f'ETA: {_format_duration(eta_seconds)}',
                        f'Taxa média: {_rate_text(avg_chars_per_sec, avg_chunks_per_sec)}',
                        f'Taxa atual: {_rate_text(current_chars_per_sec, len(batch_texts) / job_elapsed if job_elapsed > 0 else 0.0)}',
                    ])
                )
        else:
            progress.progress(1.0, text='Todos os blocos semânticos já estavam em cache para estes arquivos.')
            eta_holder.info('Nenhum novo embedding foi gerado porque todos os blocos semânticos destes arquivos já existiam no cache. Para medir tempo real de uma nova indexação, use a opção de forçar reindexação.')
            details_holder.caption('Modo cache total: os embeddings vetoriais foram reaproveitados integralmente. O tempo exibido nesta execução representa apenas leitura, validação e gravação do índice híbrido local.')
    except requests_exceptions.Timeout as exc:
        raise TimeoutError(
            'O Ollama excedeu o tempo limite durante a indexação. Tente novamente com menos arquivos, reduza o tamanho dos chunks, aumente EMBEDDING_TIMEOUT ou use um modelo de embedding mais leve.'
        ) from exc
    finally:
        status_holder.empty()
        try:
            cache.save()
        except Exception:
            pass

    final_embeddings = [emb for emb in all_embeddings if emb is not None]
    if len(final_embeddings) != total:
        raise RuntimeError('Nem todos os blocos semânticos receberam embeddings.')
    elapsed_total = max(time.perf_counter() - start_ts, 0.0)
    progress.progress(1.0, text='Indexação híbrida concluída.')
    avg_chars = int(approx_chars / max(1, total_missing)) if total_missing else 0
    details_holder.caption(f'Resumo híbrido: chunks filhos={total_children} | blocos semânticos={total} | cache={cached_total} | novos={total_missing} | lotes={total_jobs} | caracteres novos≈{approx_chars} | média/bloco≈{avg_chars}')
    if total_missing == 0:
        eta_holder.success(f'Reindexação híbrida concluída com cache total em {_format_duration(elapsed_total)} | embeddings vetoriais novos=0 | caracteres novos≈0')
    else:
        eta_holder.success(f'Indexação híbrida finalizada em {_format_duration(elapsed_total)} | blocos vetoriais novos={total_missing} | caracteres novos≈{approx_chars:,}'.replace(',', '.'))
    st.session_state['vector_store'].index_hybrid(chunks, parent_chunks, final_embeddings, child_to_parent)
    st.session_state['indexed'] = True
    if total_missing == 0:
        st.success(f'Arquivos carregados no índice híbrido usando cache já existente. Chunks úteis: {len(chunks)} | blocos semânticos: {len(parent_chunks)} | cache reaproveitado: {cached_total} | lotes processados: 0')
    else:
        st.success(f'Arquivos indexados com sucesso. Chunks úteis: {len(chunks)} | blocos semânticos: {len(parent_chunks)} | cache reaproveitado: {cached_total} | lotes processados: {total_jobs}')


def load_schema_package(owner: str, table_prefix: str, terms: list[str], object_limit: int, selected_tables=None, module_name: str = '') -> None:
    active_oracle = get_active_oracle()
    try:
        package = safe_get_schema_package(
            active_oracle,
            owner=owner,
            search_terms=terms,
            table_prefix=table_prefix,
            object_limit=object_limit,
            selected_tables=selected_tables or None,
            module_name=module_name,
        )
    finally:
        active_oracle.close()

    st.session_state['schema_package'] = package
    st.session_state['schema_metadata'] = package.get('metadata_text', '')
    st.session_state['join_suggestions_text'] = package.get('join_text', '')
    st.session_state['candidate_tables'] = [item.get('table_name') for item in package.get('candidate_tables', [])]
    st.session_state['table_roles'] = package.get('table_roles', {})
    st.session_state['table_roles_text'] = package.get('table_roles_text', '')
    st.session_state['table_families'] = package.get('table_families', {})
    st.session_state['table_families_text'] = package.get('table_families_text', '')
    st.session_state['join_blueprints_text'] = package.get('join_blueprints_text', '')
    st.session_state['ground_truth_loaded'] = bool(package.get('ground_truth_active'))
    if selected_tables:
        queue_selected_tables_update(selected_tables)
    else:
        default_tables = st.session_state['candidate_tables'][: min(12, len(st.session_state['candidate_tables']))]
        queue_selected_tables_update(default_tables)


def build_previous_version_context(previous_version_id: int | None) -> str:
    if not previous_version_id:
        return ''
    row = st.session_state['history_store'].get_version(previous_version_id)
    if not row:
        return ''
    payload = row.get('json_payload') or {}
    parts = [
        f"VERSÃO ANTERIOR SELECIONADA: {row.get('version_label')} | VIEW={row.get('view_name')}",
        f"ETAPA: {row.get('stage', '')}",
        f"RESUMO: {row.get('summary', '')}",
        'SELECT ANTERIOR:',
        row.get('select_sql', ''),
        'JSON ANTERIOR:',
        to_pretty_json(payload if isinstance(payload, dict) else {'payload': str(payload)}),
    ]
    return '\n'.join(parts)


def apply_payload_to_editor(payload: dict, raw_text: str, stage: str) -> None:
    st.session_state['current_stage'] = stage
    st.session_state['editable_view_name'] = payload.get('view_name', st.session_state.get('editable_view_name', ''))
    st.session_state['editable_select_sql'] = payload.get('select_sql', '')
    st.session_state['preview_rows'] = []
    if stage == 'reviewed':
        st.session_state['reviewed_json'] = payload
        st.session_state['reviewed_raw'] = raw_text
    else:
        st.session_state['generated_json'] = payload
        st.session_state['generated_raw'] = raw_text


def _compact_text_for_prompt(text: str, max_chars: int) -> str:
    text = (text or '').strip()
    if max_chars <= 0 or len(text) <= max_chars:
        return text
    head = max_chars // 2
    tail = max_chars - head - 32
    return text[:head] + "\n... [conteúdo resumido] ...\n" + text[-max(0, tail):]


def _prepare_view_prompt_context(retrieved_chunks: list[dict], schema_metadata: str) -> tuple[list[dict], str]:
    limited_chunks = []
    chunk_budget = max(1, CONFIG.view_chunks_for_prompt)
    chunk_chars = max(600, CONFIG.view_chunk_max_chars)
    for item in (retrieved_chunks or [])[:chunk_budget]:
        cloned = dict(item)
        cloned['text'] = _compact_text_for_prompt(str(cloned.get('text', '')), chunk_chars)
        limited_chunks.append(cloned)
    compact_schema = _compact_text_for_prompt(schema_metadata or 'Metadados não carregados.', CONFIG.view_schema_max_chars)
    return limited_chunks, compact_schema


def _generate_with_local_fallback(ollama: OllamaClient, model: str, prompt: str, temperature: float, system_prompt: str, status_placeholder=None) -> str:
    prompt_limits = [
        CONFIG.view_prompt_max_chars,
        CONFIG.view_prompt_retry_chars_1,
        CONFIG.view_prompt_retry_chars_2,
    ]
    ctx_attempts = [
        CONFIG.ollama_num_ctx_primary,
        CONFIG.ollama_num_ctx_retry_1,
        CONFIG.ollama_num_ctx_retry_2,
    ]
    last_error = None

    def _progress(info: dict) -> None:
        if status_placeholder is None:
            return
        elapsed = int(info.get('elapsed_s', 0) or 0)
        minutes, seconds = divmod(elapsed, 60)
        hours, minutes = divmod(minutes, 60)
        status_placeholder.info(
            f"Gerando com {model} | num_ctx={info.get('num_ctx')} | texto gerado≈{info.get('chars', 0)} caracteres | "
            f"tempo {hours:02d}:{minutes:02d}:{seconds:02d}"
        )

    for prompt_limit, ctx in zip(prompt_limits, ctx_attempts):
        compact_prompt = _compact_text_for_prompt(prompt, prompt_limit)
        try:
            if status_placeholder is not None:
                status_placeholder.info(f'Gerando com {model} | prompt compacto={prompt_limit} chars | num_ctx={ctx}')
            return ollama.generate(
                model=model,
                prompt=compact_prompt,
                temperature=temperature,
                system=system_prompt,
                num_ctx=ctx,
                timeout=CONFIG.ollama_generate_timeout,
                keep_alive=CONFIG.ollama_keep_alive,
                retry_num_ctx=[],
                max_tokens=CONFIG.ollama_num_predict,
                progress_callback=_progress,
            )
        except Exception as exc:
            last_error = exc
            continue
    raise RuntimeError(str(last_error) if last_error else 'Falha desconhecida ao gerar no Ollama')


def generate_view(
    ollama: OllamaClient,
    generator_model: str,
    embedding_model: str,
    temperature: float,
    objective: str,
    desired_view_name: str,
    extra_instructions: str,
    retrieval_query: str,
    previous_version_id: int | None,
) -> None:
    retrieved_chunks = []
    retrieval_warning = ''
    if st.session_state['indexed'] and str(retrieval_query or '').strip():
        try:
            query_embedding = ollama.embed(embedding_model, [retrieval_query], timeout=CONFIG.embedding_timeout, keep_alive=CONFIG.embedding_keep_alive)[0]
            retrieved_chunks = st.session_state['vector_store'].search(
                query_embedding=query_embedding,
                query_text=retrieval_query,
                top_k=CONFIG.max_chunks_for_prompt,
                lexical_top_k=CONFIG.hybrid_lexical_top_k,
                vector_top_k=CONFIG.hybrid_vector_top_k,
            )
        except Exception as exc:
            retrieval_warning = f'RAG indisponível nesta geração: {exc}'
    st.session_state['retrieved_chunks'] = retrieved_chunks

    prompt_chunks, prompt_schema_metadata = _prepare_view_prompt_context(retrieved_chunks, st.session_state.get('schema_metadata') or 'Metadados não carregados.')
    compact_join_suggestions = _compact_text_for_prompt(st.session_state.get('join_suggestions_text', ''), 2200)
    compact_table_roles = _compact_text_for_prompt(st.session_state.get('table_roles_text', ''), 1800)
    compact_table_families = _compact_text_for_prompt(st.session_state.get('table_families_text', ''), 1800)
    compact_blueprints = _compact_text_for_prompt(st.session_state.get('join_blueprints_text', ''), 2200)
    compact_module_context = _compact_text_for_prompt(st.session_state.get('view_module_context_text', ''), 1200)
    compact_previous = _compact_text_for_prompt(build_previous_version_context(previous_version_id), 2400)
    if retrieval_warning:
        compact_module_context = (compact_module_context + '\n' + retrieval_warning).strip()

    prompt = build_generation_prompt(
        objective=_compact_text_for_prompt(objective, 1200),
        retrieved_chunks=prompt_chunks,
        schema_metadata=prompt_schema_metadata,
        desired_view_name=(desired_view_name or 'VW_ANALISE_ERP_LOCAL')[:128],
        extra_instructions=_compact_text_for_prompt(extra_instructions, 1600),
        join_suggestions=compact_join_suggestions,
        selected_tables=(st.session_state.get('selected_tables', []) or [])[:25],
        previous_version_context=compact_previous,
        table_roles_text=compact_table_roles,
        table_families_text=compact_table_families,
        join_blueprints_text=compact_blueprints,
        module_context_text=compact_module_context,
    )
    status_placeholder = st.empty()
    raw = _generate_with_local_fallback(ollama, generator_model, prompt, temperature, GENERATOR_SYSTEM_PROMPT, status_placeholder=status_placeholder)
    status_placeholder.success('Geração concluída.')
    parsed = try_extract_json(raw)
    st.session_state['last_prompt'] = prompt
    st.session_state['generated_json'] = parsed
    st.session_state['generated_raw'] = raw
    best = choose_best_payload(parsed, None)
    apply_payload_to_editor(best, raw, 'draft')
    st.success('Draft da View gerado com sucesso.')



def review_current_view(ollama: OllamaClient, reviewer_model: str, temperature: float, objective: str) -> None:
    source_payload = choose_best_payload(st.session_state.get('reviewed_json'), st.session_state.get('generated_json'))
    if not source_payload:
        st.warning('Gere o draft primeiro.')
        return
    _unused_chunks, prompt_schema_metadata = _prepare_view_prompt_context([], st.session_state.get('schema_metadata') or 'Metadados não carregados.')
    prompt = build_review_prompt(
        objective=objective,
        draft_json=_compact_text_for_prompt(to_pretty_json(source_payload), CONFIG.view_prompt_max_chars // 2),
        schema_metadata=prompt_schema_metadata,
        join_suggestions=st.session_state.get('join_suggestions_text', ''),
        validation_error=(st.session_state.get('validation_result') or {}).get('detail', ''),
        table_roles_text=st.session_state.get('table_roles_text', ''),
        table_families_text=st.session_state.get('table_families_text', ''),
        join_blueprints_text=st.session_state.get('join_blueprints_text', ''),
        module_context_text=st.session_state.get('view_module_context_text', ''),
    )
    status_placeholder = st.empty()
    raw = _generate_with_local_fallback(ollama, reviewer_model, prompt, min(temperature, 0.15), REVIEWER_SYSTEM_PROMPT, status_placeholder=status_placeholder)
    status_placeholder.success('Revisão concluída.')
    parsed = try_extract_json(raw)
    st.session_state['last_review_prompt'] = prompt
    best = choose_best_payload(parsed, source_payload)
    apply_payload_to_editor(best, raw, 'reviewed')
    st.success('Revisão/correção concluída.')



def save_current_version(generator_model: str, reviewer_model: str, objective: str) -> None:
    stage = st.session_state.get('current_stage', 'draft')
    payload = choose_best_payload(
        st.session_state.get('reviewed_json') if stage == 'reviewed' else st.session_state.get('generated_json'),
        st.session_state.get('generated_json'),
    )
    if not payload:
        st.warning('Nada para salvar ainda.')
        return

    view_name = (st.session_state.get('editable_view_name') or payload.get('view_name') or 'VW_GERADA_LOCAL').strip().upper()
    select_sql = (st.session_state.get('editable_select_sql') or payload.get('select_sql') or '').strip()
    summary = payload.get('summary', '')
    validation = st.session_state.get('validation_result') or {}
    version_label = st.session_state['history_store'].next_version_label(view_name)

    payload['view_name'] = view_name
    payload['select_sql'] = select_sql

    raw_response = st.session_state.get('reviewed_raw') if stage == 'reviewed' else st.session_state.get('generated_raw')
    prompt_text = st.session_state.get('last_review_prompt') if stage == 'reviewed' else st.session_state.get('last_prompt')
    row_id = st.session_state['history_store'].save_version(
        version_label=version_label,
        view_name=view_name,
        objective=objective,
        summary=summary,
        generator_model=generator_model,
        reviewer_model=reviewer_model,
        stage=stage,
        prompt_text=prompt_text or '',
        raw_response=raw_response or '',
        json_payload=payload,
        select_sql=select_sql,
        validation_ok=bool(validation.get('ok')),
        validation_detail=validation.get('detail', ''),
        selected_tables=st.session_state.get('selected_tables', []),
        table_roles=st.session_state.get('table_roles', {}),
    )
    st.session_state['current_history_id'] = row_id
    st.success(f'Versão {version_label} salva no histórico.')


def render_current_result() -> None:
    payload = choose_best_payload(st.session_state.get('reviewed_json'), st.session_state.get('generated_json'))
    if not payload:
        return

    st.subheader('Resultado atual')
    left, right = st.columns([1.3, 1])
    with left:
        st.text_input('Nome final da View', key='editable_view_name')
        st.text_area('SELECT editável', key='editable_select_sql', height=340)
        create_view_sql = build_create_view_sql(st.session_state.get('editable_view_name', 'VW_GERADA_LOCAL'), st.session_state.get('editable_select_sql', ''))
        st.download_button(
            'Baixar SQL final',
            data=create_view_sql.encode('utf-8'),
            file_name=f"{st.session_state.get('editable_view_name', 'VW_GERADA_LOCAL')}.sql",
            mime='text/sql',
            width='stretch',
        )
        with st.expander('CREATE OR REPLACE VIEW', expanded=False):
            st.code(create_view_sql, language='sql')
    with right:
        st.markdown(f"**Etapa atual:** {st.session_state.get('current_stage', 'draft').upper()}")
        st.json(payload)
        for title, key in [('Regras de negócio', 'business_rules'), ('Suposições', 'assumptions'), ('Notas', 'notes'), ('Notas da revisão', 'review_notes')]:
            values = split_notes(payload.get(key))
            if values:
                st.markdown(f'**{title}**')
                for item in values:
                    st.write(f'- {item}')


def render_retrieved_chunks() -> None:
    if st.session_state.get('retrieved_chunks'):
        with st.expander('Trechos recuperados do índice local', expanded=False):
            for item in st.session_state['retrieved_chunks']:
                st.markdown(f"**{item['source']}** | modo={item.get('mode', 'hybrid')} | score={item['score']:.4f}")
                st.code(item['text'][:2200])


def load_history_into_editor(row_id: int) -> None:
    row = st.session_state['history_store'].get_version(row_id)
    if not row:
        st.warning('Versão não encontrada.')
        return
    payload = row.get('json_payload') or {}
    if not isinstance(payload, dict):
        payload = {'raw_json_payload': str(payload)}
    st.session_state['generated_json'] = payload if row.get('stage') != 'reviewed' else None
    st.session_state['reviewed_json'] = payload if row.get('stage') == 'reviewed' else None
    st.session_state['generated_raw'] = row.get('raw_response', '') if row.get('stage') != 'reviewed' else ''
    st.session_state['reviewed_raw'] = row.get('raw_response', '') if row.get('stage') == 'reviewed' else ''
    st.session_state['editable_view_name'] = row.get('view_name', '')
    st.session_state['editable_select_sql'] = row.get('select_sql', '')
    queue_selected_tables_update(row.get('selected_tables', []) or st.session_state.get('selected_tables', []))
    st.session_state['table_roles'] = row.get('table_roles', {}) or st.session_state.get('table_roles', {})
    st.session_state['current_history_id'] = row_id
    st.session_state['current_stage'] = row.get('stage', 'draft') or 'draft'
    st.session_state['validation_result'] = {'ok': bool(row.get('validation_ok')), 'detail': row.get('validation_detail', '')}
    st.success(f"Versão {row.get('version_label')} carregada para edição.")


def render_history_tab() -> None:
    st.subheader('Histórico e comparação de versões')
    filter_view = st.text_input('Filtrar histórico por nome da View', value=st.session_state.get('editable_view_name', ''))
    rows = st.session_state['history_store'].list_versions(filter_view or None)
    if not rows:
        st.info('Nenhuma versão encontrada no histórico.')
        return

    st.dataframe(pd.DataFrame(rows), width='stretch', hide_index=True)
    ids = [int(item['id']) for item in rows]

    colx, coly = st.columns([1, 1])
    with colx:
        load_id = st.selectbox('Carregar versão para edição', options=ids, index=0, format_func=lambda x: f'ID {x}', key='history_load_id')
        if st.button('Carregar versão', width='stretch'):
            load_history_into_editor(load_id)
    with coly:
        export_id = st.selectbox('Exportar SQL de uma versão', options=ids, index=0, format_func=lambda x: f'ID {x}', key='history_export_id')
        export_row = st.session_state['history_store'].get_version(export_id)
        if export_row:
            st.download_button(
                'Baixar SQL da versão',
                data=build_create_view_sql(export_row.get('view_name', ''), export_row.get('select_sql', '')).encode('utf-8'),
                file_name=f"{export_row.get('view_name', 'VIEW')}_{export_row.get('version_label', 'V')}.sql",
                mime='text/sql',
                width='stretch',
            )

    left_id = st.selectbox('Versão A', options=ids, index=0, format_func=lambda x: f'ID {x}', key='compare_left_id')
    right_id = st.selectbox('Versão B', options=ids, index=min(1, len(ids) - 1), format_func=lambda x: f'ID {x}', key='compare_right_id')
    version_a = st.session_state['history_store'].get_version(left_id)
    version_b = st.session_state['history_store'].get_version(right_id)
    if not version_a or not version_b:
        return

    if st.button('Comparar versões', width='stretch'):
        left_col, right_col = st.columns(2)
        with left_col:
            st.markdown(f"**{version_a['version_label']} | {version_a['view_name']} | {version_a.get('stage', '').upper()}**")
            st.code(version_a.get('select_sql', ''), language='sql')
        with right_col:
            st.markdown(f"**{version_b['version_label']} | {version_b['view_name']} | {version_b.get('stage', '').upper()}**")
            st.code(version_b.get('select_sql', ''), language='sql')
        diff_text = unified_diff_text(version_a.get('select_sql', ''), version_b.get('select_sql', ''), version_a.get('version_label', 'A'), version_b.get('version_label', 'B'))
        st.code(diff_text or 'Sem diferenças relevantes.', language='diff')


def module_selector_ui(key_prefix: str, state_prefix: str) -> tuple[str, str, list[str], str]:
    module_name = st.selectbox(
        'Módulo de negócio',
        options=MODULE_OPTIONS,
        index=0,
        key=f'{key_prefix}_module_name',
    )
    manual_terms = st.text_input(
        'Termos de negócio (vírgula)',
        value='',
        key=f'{key_prefix}_manual_terms',
    )
    defn = get_module_definition(module_name) if module_name != 'Manual / sem foco' else {'prefixes': [], 'terms': [], 'entities': []}
    prefix_default = ', '.join(defn.get('prefixes', []))
    prefix_text = st.text_input(
        'Prefixos esperados (vírgula)',
        value=prefix_default,
        key=f'{key_prefix}_prefix_text',
    )
    terms = [x.strip() for x in manual_terms.split(',') if x.strip()]
    context_text = build_module_context_text(module_name, terms)
    st.session_state[f'{state_prefix}_module_name'] = module_name
    st.session_state[f'{state_prefix}_module_context_text'] = context_text
    st.caption(context_text)
    return module_name, prefix_text, terms, context_text


def load_dataset_from_sql(sql: str) -> None:
    active_oracle = get_active_oracle()
    try:
        rows = active_oracle.fetch_query_rows(sql, limit=CONFIG.analytics_row_limit)
    finally:
        active_oracle.close()
    df = pd.DataFrame(rows)
    bundle = prepare_dataframe(df)
    st.session_state['analysis_bundle'] = bundle
    st.session_state['analysis_source_name'] = 'Consulta Oracle'


def load_dataset_from_upload(uploaded_file) -> None:
    df = load_dataframe_from_upload(uploaded_file)
    bundle = prepare_dataframe(df)
    st.session_state['analysis_bundle'] = bundle
    st.session_state['analysis_source_name'] = uploaded_file.name


def render_analysis_result(result: dict | None) -> None:
    if not result:
        return
    st.subheader(result.get('title', 'Resultado de análise'))
    st.write(result.get('summary', ''))
    findings = result.get('findings') or []
    if findings:
        for item in findings:
            st.write(f'- {item}')
    sample = result.get('sample') or []
    if sample:
        st.dataframe(pd.DataFrame(sample), width='stretch', hide_index=True)


def build_profile_text(bundle: AnalysisBundle) -> str:
    profile = bundle.profile
    semantic = bundle.semantic_map
    lines = [
        f"LINHAS: {profile['rows']}",
        f"COLUNAS: {profile['columns']}",
        f"NUMÉRICAS: {', '.join(profile['numeric_columns'][:12]) or 'nenhuma'}",
        f"DATAS: {', '.join(profile['datetime_columns'][:8]) or 'nenhuma'}",
        f"SEMÂNTICA: {semantic}",
    ]
    return '\n'.join(lines)



def build_genai_runtime_config(ollama_base_url: str, generator_model: str, analyst_model: str, embedding_model: str) -> dict:
    params = st.session_state.get('oracle_params')
    default_schema = (CONFIG.default_owner or (params.user if params else '') or '').upper()
    return {
        'oracle': {
            'host': params.host if params else '127.0.0.1',
            'port': int(params.port) if params else 1521,
            'service_name': params.service_name if params else 'ORCL',
            'username': params.user if params else '',
            'password': params.password if params else '',
            'default_schema': default_schema,
            'mode': 'thick' if (params and getattr(params, 'use_thick_mode', False)) else 'thin',
            'thick_client_lib_dir': params.lib_dir if params else CONFIG.default_oracle_lib_dir,
        },
        'llm': {
            'backend': 'ollama',
            'base_url': ollama_base_url,
            'sql_model': generator_model,
            'chat_model': analyst_model,
            'embedding_backend': 'ollama',
            'embedding_model': embedding_model,
            'temperature': float(CONFIG.temperature),
            'max_tokens': 1800,
            'timeout_seconds': max(180, int(CONFIG.embedding_timeout)),
        },
        'app': {
            'catalog_dir': str(GENAI_CATALOG_DIR),
            'vector_dir': str(GENAI_VECTOR_DIR),
            'upload_dir': str(GENAI_UPLOAD_DIR),
            'cache_dir': str(GENAI_CACHE_DIR),
            'log_dir': str(GENAI_LOG_DIR),
            'max_result_rows': int(CONFIG.preview_limit),
        },
        'rag': {
            'chunk_size': 900,
            'chunk_overlap': 120,
            'top_k': 5,
            'collection_name': 'oracle_view_local_assistant_genai',
        },
        'security': {
            'work_start_hour': 7,
            'work_end_hour': 20,
            'suspicious_row_factor': 5.0,
            'suspicious_object_diversity': 5,
            'ddl_weight': 35,
            'off_hours_weight': 20,
            'volume_weight': 30,
            'tool_weight': 20,
        },
        'synthetic': {
            'locale': 'pt_BR',
            'default_rows': 100,
        },
    }


def get_genai_oracle_client(runtime_config: dict) -> OracleClient:
    return OracleClient(runtime_config)


def get_genai_llm_router(runtime_config: dict) -> LLMRouter:
    return LLMRouter(runtime_config)


def render_genai_catalog_tab(runtime_config: dict) -> None:
    st.subheader('Catálogo semântico GenAI')
    st.caption('Extração e pesquisa de tabelas, views, colunas, índices e relações a partir do Oracle.')
    schema = st.text_input('Schema do catálogo', value=runtime_config.get('oracle', {}).get('default_schema', ''), key='genai_catalog_schema').upper().strip()
    store = CatalogStore(str(GENAI_CATALOG_DIR))

    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button('Extrair catálogo do Oracle', width='stretch', key='genai_extract_catalog'):
            if not st.session_state.get('oracle_connected'):
                st.warning('Conecte ao Oracle primeiro.')
            elif not schema:
                st.warning('Informe o schema.')
            else:
                try:
                    catalog = CatalogExtractor(get_genai_oracle_client(runtime_config)).build_catalog(schema)
                    path = store.save(schema, catalog)
                    st.session_state['genai_catalog_cache'] = catalog
                    st.success(f'Catálogo salvo em {path}')
                except Exception as exc:
                    st.error(f'Falha ao extrair catálogo: {exc}')
    with col2:
        if st.button('Carregar catálogo salvo', width='stretch', key='genai_load_catalog'):
            catalog = store.load(schema)
            st.session_state['genai_catalog_cache'] = catalog
            if catalog:
                st.success(f'{len(catalog)} objeto(s) carregado(s).')
            else:
                st.info('Nenhum catálogo salvo encontrado para esse schema.')
    with col3:
        if st.button('Listar catálogos salvos', width='stretch', key='genai_list_catalogs'):
            st.write(store.list_catalogs())

    catalog = st.session_state.get('genai_catalog_cache') or []
    if not catalog:
        st.info('Extraia ou carregue um catálogo para usar este módulo.')
        return

    search = st.text_input('Pesquisar no catálogo', key='genai_catalog_search').strip().upper()
    rows = []
    for obj in catalog:
        hay = ' '.join([
            obj.get('object_name', ''),
            obj.get('description', ''),
            ' '.join(obj.get('business_terms', [])),
            ' '.join(c.get('name', '') for c in obj.get('columns', [])),
        ]).upper()
        if not search or search in hay:
            rows.append({
                'OWNER': obj.get('owner'),
                'OBJECT_NAME': obj.get('object_name'),
                'TYPE': obj.get('object_type'),
                'DESCRIPTION': obj.get('description'),
                'BUSINESS_TERMS': ', '.join(obj.get('business_terms', [])),
                'COLUMN_COUNT': len(obj.get('columns', [])),
            })
    df = pd.DataFrame(rows)
    st.dataframe(df, width='stretch', hide_index=True)
    st.download_button('Baixar catálogo JSON', data=json.dumps(catalog, ensure_ascii=False, indent=2).encode('utf-8'), file_name=f'{schema.lower() or "catalogo"}_catalog.json', mime='application/json', width='stretch', key='genai_download_catalog')


def render_genai_sql_copilot_tab(runtime_config: dict) -> None:
    st.subheader('SQL Copilot GenAI')
    st.caption('NL2SQL seguro, explain SQL, tuning e execução controlada somente leitura.')
    llm_router = get_genai_llm_router(runtime_config)
    question = st.text_area('Pergunta em linguagem natural', height=120, key='genai_nl_question', placeholder='Ex.: Mostre os 20 veículos com maior custo de manutenção nos últimos 90 dias por garagem.')
    col1, col2, col3 = st.columns(3)
    if col1.button('Gerar SQL', width='stretch', key='genai_btn_generate_sql'):
        catalog = st.session_state.get('genai_catalog_cache') or []
        schema = runtime_config.get('oracle', {}).get('default_schema', '')
        try:
            schema_package = st.session_state.get('schema_package', {}) or {}
            selected_tables = st.session_state.get('selected_tables', []) or []
            sql = NL2SQLService(llm_router).generate_sql(question=question, catalog=catalog, schema=schema, schema_package=schema_package, selected_tables=selected_tables)
            st.session_state['genai_last_sql'] = sql
        except Exception as exc:
            st.error(f'Falha ao gerar SQL: {exc}')
    if col2.button('Explicar SQL', width='stretch', key='genai_btn_explain_sql'):
        sql = st.session_state.get('genai_last_sql', '')
        if sql:
            try:
                st.session_state['genai_sql_explanation'] = SQLExplainer(llm_router).explain(sql)
            except Exception as exc:
                st.error(f'Falha ao explicar SQL: {exc}')
    if col3.button('Analisar tuning', width='stretch', key='genai_btn_tuning_sql'):
        sql = st.session_state.get('genai_last_sql', '')
        if sql:
            try:
                st.session_state['genai_sql_tuning'] = SQLTuningAdvisor(llm_router).analyze(sql)
            except Exception as exc:
                st.error(f'Falha ao analisar tuning: {exc}')

    schema_package = st.session_state.get('schema_package', {}) or {}
    selected_tables = st.session_state.get('selected_tables', []) or []
    if schema_package:
        with st.expander('Contexto estrutural usado na geração', expanded=False):
            st.text_area('Grounding do schema', value=build_schema_grounding_context(schema_package, selected_tables=selected_tables, max_tables=14, max_joins=18), height=280, key='genai_schema_grounding_view')

    current_sql = st.text_area('SQL atual', value=st.session_state.get('genai_last_sql', ''), height=260, key='genai_sql_editor')
    st.session_state['genai_last_sql'] = current_sql

    validator = SQLValidator(allowed_schemas=[runtime_config.get('oracle', {}).get('default_schema', '')])
    executor = SQLExecutor(get_genai_oracle_client(runtime_config), validator, max_rows=int(runtime_config.get('app', {}).get('max_result_rows', 500)))
    if st.button('Executar SQL segura', width='stretch', key='genai_btn_run_sql'):
        if not st.session_state.get('oracle_connected'):
            st.warning('Conecte ao Oracle primeiro.')
        else:
            try:
                validation, df = executor.run_safe_select(current_sql)
                if validation.ok:
                    st.session_state['genai_last_sql_result'] = df
                    st.success(f'{len(df)} linha(s) retornada(s).')
                else:
                    st.error('Validação falhou: ' + ' | '.join(validation.reasons))
            except Exception as exc:
                st.error(f'Falha ao executar SQL: {exc}')

    df = st.session_state.get('genai_last_sql_result')
    if df is not None:
        st.dataframe(df, width='stretch', hide_index=True)

    if st.session_state.get('genai_sql_explanation'):
        st.markdown('**Explicação**')
        st.write(st.session_state['genai_sql_explanation'])
    if st.session_state.get('genai_sql_tuning'):
        st.markdown('**Tuning**')
        st.write(st.session_state['genai_sql_tuning'])


def render_genai_rag_tab(runtime_config: dict) -> None:
    st.subheader('RAG persistente')
    st.caption('Indexação local persistente para PDFs, textos, SQL, logs e planilhas modernas.')
    llm_router = get_genai_llm_router(runtime_config)
    pipeline = RAGPipeline(runtime_config, llm_router)

    uploads = st.file_uploader('Enviar arquivos para o RAG', accept_multiple_files=True, type=['pdf', 'txt', 'md', 'csv', 'xlsx', 'xlsm', 'sql', 'log', 'py'], key='genai_rag_upload')
    if st.button('Indexar arquivos no RAG', width='stretch', key='genai_rag_index'):
        if not uploads:
            st.warning('Envie ao menos um arquivo.')
        else:
            results = []
            try:
                for uploaded in uploads:
                    path = GENAI_UPLOAD_DIR / uploaded.name
                    path.write_bytes(uploaded.read())
                    results.append(pipeline.index_file(path))
                st.success(f'{len(results)} arquivo(s) processado(s).')
                st.json(results)
            except Exception as exc:
                st.error(f'Falha ao indexar no RAG: {exc}')

    st.markdown('**Arquivos indexados**')
    docs = pipeline.vectorstore.list_documents()
    st.write(docs if docs else 'Nenhum documento indexado ainda.')

    question = st.text_area('Pergunta sobre os documentos', height=120, key='genai_rag_question', placeholder='Ex.: O que o manual diz sobre importação de arrecadação?')
    if st.button('Perguntar ao RAG', width='stretch', key='genai_rag_ask'):
        if not question.strip():
            st.warning('Digite uma pergunta.')
        else:
            try:
                answer, hits = pipeline.ask(question)
                st.session_state['genai_last_rag_answer'] = answer
                st.session_state['genai_last_rag_hits'] = hits
            except Exception as exc:
                st.error(f'Falha no RAG: {exc}')

    if st.session_state.get('genai_last_rag_answer'):
        st.markdown('**Resposta**')
        st.write(st.session_state['genai_last_rag_answer'])

    hits = st.session_state.get('genai_last_rag_hits') or []
    if hits:
        st.markdown('**Contexto recuperado**')
        for hit in hits:
            st.caption(f"Fonte: {hit.get('source')} | modo={hit.get('mode', 'hybrid')} | score={round(float(hit.get('score', 0)), 4)}")
            st.write(hit.get('text', '')[:1500] + ('...' if len(hit.get('text', '')) > 1500 else ''))
            st.divider()


def render_genai_dba_tab(runtime_config: dict) -> None:
    st.subheader('Assistente DBA')
    st.caption('Coletas técnicas prontas + interpretação por LLM. A aplicação pode rodar em Servidor Web separado e conectar remotamente no Oracle.')
    if not st.session_state.get('oracle_connected'):
        st.info('Conecte ao Oracle para usar as coletas de DBA.')
        return

    llm_router = get_genai_llm_router(runtime_config)
    tools = DBATools(get_genai_oracle_client(runtime_config))
    assistant = DBAAssistant(llm_router)

    dba_options = {
        'Health Snapshot': 'health_snapshot',
        'Status do Banco': 'database_status',
        'Sessões': 'sessions',
        'Resumo de Conexões': 'session_summary',
        'Limites Sessions/Processes': 'resource_limits',
        'SQL Ativo Agora': 'active_sql',
        'Top SQL por Tempo': 'top_sql',
        'Top SQL por CPU': 'top_sql_cpu',
        'Top SQL por I/O': 'top_sql_io',
        'Operações Longas': 'longops',
        'Wait Events Ativos': 'wait_events',
        'Locks': 'locks',
        'Sessões Bloqueadoras': 'blocking_sessions',
        'Objetos Bloqueados': 'locked_objects',
        'Tablespaces': 'tablespaces',
        'Uso TEMP': 'temp_usage',
        'FRA': 'fra_usage',
        'Geração Archivelog': 'archive_generation',
        'Backups RMAN': 'rman_backups',
        'Resumo de Backup': 'backup_summary',
        'Tabela MON_BACKUP_EXECUCAO': 'backup_control',
        'Data Pump Jobs': 'datapump_jobs',
        'Scheduler Rodando': 'scheduler_running',
        'Scheduler com Erro': 'scheduler_failed',
        'Alert Log ORA/TNS': 'alert_log',
        'Objetos Inválidos': 'invalid_objects',
        'Índices UNUSABLE': 'unusable_indexes',
        'Parâmetros': 'parametros',
        'Demandas Priorizadas': 'monitoring_backlog',
        'Notas Servidor Web Remoto': 'remote_notes',
    }
    option = st.selectbox('Coleta rápida', list(dba_options.keys()), key='genai_dba_option')
    search_term = st.text_input('Filtro / tabela controle', key='genai_param_search', placeholder='Ex.: processes ou MON_BACKUP_EXECUCAO')

    if st.button('Executar coleta', width='stretch', key='genai_run_dba_collection'):
        try:
            df = tools.collect(dba_options.get(option, 'health_snapshot'), search_term)
            st.session_state['genai_dba_last_df'] = df
        except Exception as exc:
            st.error(f'Falha na coleta de DBA: {exc}')

    df = st.session_state.get('genai_dba_last_df')
    if df is not None:
        st.dataframe(df, width='stretch', hide_index=True)

    question = st.text_area('Pergunta ao assistente de DBA', height=120, key='genai_dba_question', placeholder='Ex.: O que os dados coletados indicam e qual a próxima ação?')
    if st.button('Analisar coleta', width='stretch', key='genai_dba_analyze'):
        if df is None or df.empty:
            st.warning('Execute uma coleta antes.')
        else:
            try:
                snapshot_text = df.head(200).to_csv(index=False)
                st.session_state['genai_dba_answer'] = assistant.analyze_snapshot(question=question or 'Analise os dados coletados.', snapshot_text=snapshot_text)
            except Exception as exc:
                st.error(f'Falha ao analisar a coleta: {exc}')
    if st.session_state.get('genai_dba_answer'):
        st.markdown('**Parecer técnico**')
        st.write(st.session_state['genai_dba_answer'])


def render_genai_security_tab(runtime_config: dict) -> None:
    st.subheader('Segurança / anomalias')
    st.caption('Score heurístico para eventos de auditoria e resumo executivo por LLM.')
    llm_router = get_genai_llm_router(runtime_config)
    uploaded = st.file_uploader('Upload CSV de eventos', type=['csv'], key='genai_security_upload')
    if uploaded is not None:
        try:
            st.session_state['genai_security_df'] = pd.read_csv(uploaded)
        except Exception as exc:
            st.error(f'Falha ao ler CSV: {exc}')
            return

    df = st.session_state.get('genai_security_df')
    if df is None or df.empty:
        st.info('Envie um CSV com colunas de usuário, data/hora, operação, objeto e opcionalmente linhas/ferramenta.')
        return

    st.write(list(df.columns))
    col1, col2, col3 = st.columns(3)
    user_col = col1.selectbox('Coluna usuário', df.columns, key='genai_security_user_col')
    ts_col = col2.selectbox('Coluna data/hora', df.columns, key='genai_security_ts_col')
    op_col = col3.selectbox('Coluna operação', df.columns, key='genai_security_op_col')
    col4, col5, col6 = st.columns(3)
    object_col = col4.selectbox('Coluna objeto', df.columns, key='genai_security_object_col')
    rows_col = col5.selectbox('Coluna volume/linhas', [''] + list(df.columns), key='genai_security_rows_col')
    tool_col = col6.selectbox('Coluna ferramenta/programa', [''] + list(df.columns), key='genai_security_tool_col')

    if st.button('Classificar eventos', width='stretch', key='genai_security_score'):
        try:
            scored = AnomalyScorer(runtime_config).score_dataframe(df=df, user_col=user_col, ts_col=ts_col, op_col=op_col, object_col=object_col, rows_col=rows_col or None, tool_col=tool_col or None)
            st.session_state['genai_security_scored'] = scored
        except Exception as exc:
            st.error(f'Falha ao classificar eventos: {exc}')

    scored = st.session_state.get('genai_security_scored')
    if scored is not None:
        st.dataframe(scored, width='stretch', hide_index=True)
        if not scored.empty and st.button('Gerar resumo executivo', width='stretch', key='genai_security_summary'):
            try:
                preview = scored.head(200).to_csv(index=False)
                st.session_state['genai_security_summary_text'] = SecuritySummarizer(llm_router).summarize(preview)
            except Exception as exc:
                st.error(f'Falha ao gerar resumo executivo: {exc}')

    if st.session_state.get('genai_security_summary_text'):
        st.markdown('**Resumo executivo**')
        st.write(st.session_state['genai_security_summary_text'])


def render_genai_synthetic_tab(runtime_config: dict) -> None:
    st.subheader('Dados sintéticos')
    st.caption('Geração de massa para homologação, demos e testes internos.')
    generator = SyntheticDataGenerator(locale=runtime_config.get('synthetic', {}).get('locale', 'pt_BR'))
    mode = st.radio('Modo', ['Informar colunas manualmente', 'Ler estrutura de tabela Oracle'], key='genai_synthetic_mode', horizontal=True)

    columns = []
    if mode == 'Informar colunas manualmente':
        default_json = json.dumps([
            {'name': 'ID_CLIENTE', 'data_type': 'NUMBER'},
            {'name': 'NOME_CLIENTE', 'data_type': 'VARCHAR2'},
            {'name': 'CPF_CLIENTE', 'data_type': 'VARCHAR2'},
            {'name': 'EMAIL_CLIENTE', 'data_type': 'VARCHAR2'},
            {'name': 'DATA_CADASTRO', 'data_type': 'DATE'},
        ], ensure_ascii=False, indent=2)
        raw = st.text_area('Definição das colunas em JSON', value=default_json, height=220, key='genai_synthetic_json')
        try:
            columns = json.loads(raw)
        except Exception as exc:
            st.error(f'JSON inválido: {exc}')
            return
    else:
        owner = st.text_input('Schema', value=runtime_config.get('oracle', {}).get('default_schema', ''), key='genai_synthetic_owner').upper().strip()
        table_name = st.text_input('Tabela', key='genai_synthetic_table').upper().strip()
        if st.button('Carregar colunas da tabela', width='stretch', key='genai_synthetic_load_table'):
            if not st.session_state.get('oracle_connected'):
                st.warning('Conecte ao Oracle primeiro.')
            else:
                try:
                    sql = """
                    select column_name as name, data_type
                      from all_tab_columns
                     where owner = :owner
                       and table_name = :table_name
                     order by column_id
                    """
                    df = get_genai_oracle_client(runtime_config).query(sql, {'owner': owner, 'table_name': table_name}, max_rows=2000)
                    st.session_state['genai_synthetic_columns'] = df.to_dict(orient='records')
                except Exception as exc:
                    st.error(f'Falha ao carregar colunas da tabela: {exc}')
        columns = st.session_state.get('genai_synthetic_columns', [])
        if columns:
            st.json(columns)

    rows = st.number_input('Quantidade de linhas', min_value=1, max_value=100000, value=100, step=10, key='genai_synthetic_rows')
    table_target = st.text_input('Nome da tabela para export SQL', value='TABELA_DESTINO', key='genai_synthetic_target_table')
    if st.button('Gerar dados sintéticos', width='stretch', key='genai_synthetic_generate'):
        try:
            df = generator.generate_from_columns(columns=columns, rows=int(rows))
            st.session_state['genai_synthetic_df'] = df
            st.session_state['genai_synthetic_sql'] = generator.dataframe_to_insert_sql(df, table_target)
        except Exception as exc:
            st.error(f'Falha ao gerar dados sintéticos: {exc}')

    df = st.session_state.get('genai_synthetic_df')
    if df is not None:
        st.dataframe(df, width='stretch', hide_index=True)
        if not df.empty:
            st.download_button('Baixar CSV sintético', df.to_csv(index=False).encode('utf-8'), file_name='dados_sinteticos.csv', mime='text/csv', width='stretch', key='genai_synthetic_download_csv')
            st.download_button('Baixar INSERT SQL sintético', st.session_state.get('genai_synthetic_sql', '').encode('utf-8'), file_name='dados_sinteticos.sql', mime='text/plain', width='stretch', key='genai_synthetic_download_sql')


def render_chartdb_tab() -> None:
    st.subheader('ERD / ChartDB')
    st.caption('Use esta aba para exportar o schema atual em DDL Oracle ou DBML e abrir o ChartDB local sem Docker.')

    chartdb_url = st.text_input(
        'URL do ChartDB local',
        key='chartdb_url',
        help='Se você rodar o ChartDB com npm run dev, ajuste aqui a URL local correspondente.',
    )

    schema_package = st.session_state.get('schema_package', {}) or {}
    grouped = schema_package.get('grouped_columns', {}) or {}
    selected_tables = [t for t in (st.session_state.get('selected_tables', []) or []) if t in grouped]
    effective_tables = selected_tables or list(grouped.keys())
    join_count = len(schema_package.get('join_suggestions', []) or [])

    m1, m2, m3 = st.columns(3)
    with m1:
        st.metric('Tabelas no pacote atual', len(grouped))
    with m2:
        st.metric('Tabelas exportadas', len(effective_tables))
    with m3:
        st.metric('Relações sugeridas', join_count)

    c1, c2 = st.columns([1, 1])
    with c1:
        st.link_button('Abrir ChartDB', chartdb_url, width='stretch')
    with c2:
        show_embed = st.checkbox('Mostrar ChartDB embutido nesta aba', value=False, key='chartdb_show_embed')

    st.markdown('### Exportação para o ChartDB')
    export_format = st.radio(
        'Formato de exportação',
        ['DDL Oracle', 'DBML'],
        horizontal=True,
        key='chartdb_format',
        help='DBML costuma ser o caminho mais simples para colar no File → Import → .dbml. DDL Oracle é útil quando você quer revisar o SQL antes de importar.',
    )

    st.markdown('**Tabelas incluídas**')
    if effective_tables:
        st.code(', '.join(effective_tables), language='text')
    else:
        st.info('Primeiro execute a aba Mapa ERP / Metadados para carregar um pacote de schema.')

    col_gen, col_clear = st.columns([1, 1])
    with col_gen:
        if st.button('Gerar conteúdo para importar no ChartDB', width='stretch'):
            if not grouped:
                st.warning('Analise o schema primeiro na aba Mapa ERP / Metadados.')
            else:
                owner = schema_package.get('owner') or CONFIG.default_owner or 'SCHEMA'
                if export_format == 'DBML':
                    payload = build_chartdb_dbml(schema_package=schema_package, owner=owner, selected_tables=effective_tables)
                    file_name = 'chartdb_import.dbml'
                    mime = 'text/plain'
                else:
                    payload = build_chartdb_ddl(schema_package=schema_package, owner=owner, selected_tables=effective_tables)
                    file_name = 'chartdb_import.sql'
                    mime = 'text/plain'
                st.session_state['chartdb_payload'] = payload
                st.session_state['chartdb_payload_name'] = file_name
                st.session_state['chartdb_payload_mime'] = mime
                st.success('Conteúdo gerado. Cole ou importe no ChartDB.')
    with col_clear:
        if st.button('Limpar conteúdo gerado', width='stretch'):
            st.session_state['chartdb_payload'] = ''

    payload = st.session_state.get('chartdb_payload', '')
    if payload:
        st.text_area('Conteúdo pronto para importar', value=payload, height=360, key='chartdb_payload_view')
        d1, d2 = st.columns([1, 1])
        with d1:
            st.download_button(
                'Baixar arquivo para o ChartDB',
                data=payload,
                file_name=st.session_state.get('chartdb_payload_name', 'chartdb_import.sql'),
                mime=st.session_state.get('chartdb_payload_mime', 'text/plain'),
                width='stretch',
            )
        with d2:
            st.info('DBML: File → Import → .dbml. DDL: crie um diagrama novo e importe o SQL/DDL no ChartDB.')

    with st.expander('Como usar no seu fluxo', expanded=not bool(payload)):
        st.markdown("""
1. Analise o schema na aba **Mapa ERP / Metadados**.
2. Selecione as tabelas que realmente devem entrar no diagrama.
3. Volte aqui e gere **DBML** ou **DDL Oracle**.
4. Abra o ChartDB local e importe o conteúdo gerado.
5. Use o ChartDB para organizar visualmente as entidades e exportar imagem/diagrama quando quiser.

Sugestão prática: para diagramas rápidos, use **DBML**. Para auditoria técnica ou revisão manual, use **DDL Oracle**.
        """)

    if show_embed:
        components.iframe(chartdb_url, height=920, scrolling=True)

def main() -> None:
    inject_css()
    init_state()
    load_existing_index()

    st.title('DB ERP Local Studio V3.3 GenAI')
    st.caption(
        'Versão 3.3 GenAI: mantém o fluxo profissional de Views da V3.2.3 e adiciona catálogo semântico, SQL Copilot seguro, RAG persistente, assistente DBA, segurança/anomalias e dados sintéticos.'
    )

    ollama_base_url = st.sidebar.text_input('Ollama Base URL', value=CONFIG.ollama_base_url)
    profile = st.sidebar.selectbox('Perfil', options=['V2 melhorada', 'V3 profissional', 'V3.1 Globus', 'V3.2 ERP Analytics', 'V3.2.3 Corrigida'], index=4)
    default_generator = CONFIG.generator_model
    default_reviewer = CONFIG.reviewer_model
    default_analyst = CONFIG.analyst_model
    generator_model = st.sidebar.text_input('Modelo gerador', value=default_generator)
    reviewer_model = st.sidebar.text_input('Modelo revisor/corretor', value=default_reviewer)
    analyst_model = st.sidebar.text_input('Modelo analista executivo', value=default_analyst)
    embedding_model = st.sidebar.text_input('Modelo de embedding', value=CONFIG.embedding_model)
    temperature = st.sidebar.slider('Temperature', min_value=0.0, max_value=1.0, value=float(CONFIG.temperature), step=0.05)
    st.sidebar.caption(f'Embedding: lote={CONFIG.embedding_batch_size} | timeout={CONFIG.embedding_timeout}s | keep_alive={CONFIG.embedding_keep_alive}')

    ollama = OllamaClient(ollama_base_url)
    sidebar_connection()
    health_panel(ollama)
    render_top_metrics()

    tabs = st.tabs([
        'Arquivos e contexto',
        'Mapa ERP / Metadados',
        'View Studio',
        'Validar / Finalizar',
        'Análises avançadas',
        'Histórico',
        'Catálogo GenAI',
        'SQL Copilot GenAI',
        'RAG Persistente',
        'Assistente DBA',
        'Segurança / Anomalias',
        'Dados sintéticos',
        'ERD / ChartDB',
    ])

    with tabs[0]:
        st.subheader('Indexação local de relatórios, queries e documentos')
        uploaded_files = st.file_uploader(
            'Envie PDF, TXT, SQL ou MD com relatórios, queries, observações e versões anteriores',
            type=['pdf', 'txt', 'sql', 'md'],
            accept_multiple_files=True,
            key='context_files_uploader',
        )
        reembed_col, clear_col = st.columns([1, 1])
        with reembed_col:
            force_reembed = st.checkbox('Forçar nova indexação (ignorar cache de embeddings)', value=False, key='force_reembed_checkbox')
        with clear_col:
            clear_cache = st.checkbox('Limpar cache antes de indexar', value=False, key='clear_embed_cache_checkbox')

        col_a, col_b, col_c = st.columns([1, 1, 1])
        with col_a:
            if st.button('Indexar arquivos enviados', width='stretch'):
                if not uploaded_files:
                    st.warning('Envie pelo menos um arquivo.')
                else:
                    try:
                        index_files(ollama, embedding_model, uploaded_files, force_reembed=force_reembed, clear_cache=clear_cache)
                    except TimeoutError as exc:
                        st.error(str(exc))
                    except Exception as exc:  # noqa: BLE001
                        st.error(f'Falha ao indexar arquivos: {exc}')
        with col_b:
            if st.button('Recarregar índice local do disco', width='stretch'):
                ok = st.session_state['vector_store'].load()
                st.session_state['indexed'] = ok
                st.success('Índice local carregado.' if ok else 'Nenhum índice local encontrado.')
        with col_c:
            if st.button('Apagar cache de embeddings', width='stretch'):
                try:
                    EMBED_CACHE_PATH.unlink(missing_ok=True)
                    st.success('Cache de embeddings removido.')
                except Exception as exc:  # noqa: BLE001
                    st.error(f'Não foi possível apagar o cache: {exc}')
        st.caption('Se marcar “Forçar nova indexação”, o sistema recalcula os embeddings e o ETA passa a refletir o custo real. Se deixar desmarcado, arquivos já vistos podem ser carregados quase instantaneamente a partir do cache.')
        if INDEX_PATH.exists():
            st.caption(f'Índice atual: {INDEX_PATH.resolve()}')
        st.markdown(build_catalog_markdown())

    with tabs[1]:
        st.subheader('Descoberta de módulos, schema e joins automáticos')
        module_name, prefix_text, terms, _view_context = module_selector_ui('schema_discovery', 'view')
        owner = st.text_input('Owner', value=CONFIG.default_owner)
        object_limit = st.slider('Limite de objetos', min_value=5, max_value=200, value=60, step=5)
        prefixes = [x.strip().upper() for x in prefix_text.split(',') if x.strip()]
        table_prefix = prefixes[0] if prefixes else ''

        col1, col2 = st.columns(2)
        with col1:
            if st.button('Analisar schema', width='stretch'):
                if not st.session_state.get('oracle_connected'):
                    st.warning('Conecte ao Oracle primeiro.')
                else:
                    try:
                        extra_terms = terms + get_module_definition(module_name).get('terms', []) if module_name != 'Manual / sem foco' else terms
                        load_schema_package(owner=owner, table_prefix=table_prefix, terms=extra_terms, object_limit=object_limit, module_name=module_name)
                        st.success('Análise de metadados concluída.')
                    except Exception as exc:  # noqa: BLE001
                        st.error(f"Erro ao ler metadados: {_oracle_recoverable_hint(exc)}")
                        st.info('Modo compatibilidade OracleService ativado automaticamente quando necessário.')
        with col2:
            if st.button('Listar objetos do módulo', width='stretch'):
                if not st.session_state.get('oracle_connected'):
                    st.warning('Conecte ao Oracle primeiro.')
                else:
                    active_oracle = get_active_oracle()
                    try:
                        rows = safe_get_schema_summary(active_oracle, owner=owner, prefixes=prefixes, limit=object_limit)
                        st.dataframe(pd.DataFrame(rows), width='stretch', hide_index=True)
                    except Exception as exc:  # noqa: BLE001
                        st.error(f"Erro ao listar objetos: {_oracle_recoverable_hint(exc)}")
                    finally:
                        active_oracle.close()

        candidate_tables = st.session_state.get('candidate_tables') or []
        apply_pending_selected_tables(candidate_tables)
        if candidate_tables:
            current_selected = [x for x in st.session_state.get('selected_tables', []) if x in candidate_tables]
            if st.session_state.get('selected_tables') != current_selected:
                st.session_state['selected_tables'] = current_selected
            if st.session_state.pop('_schema_refined_success', None):
                st.success('Joins refinados pelas tabelas selecionadas.')
            st.multiselect(
                'Selecione as tabelas que devem guiar joins e a geração da View',
                options=candidate_tables,
                key='selected_tables',
            )
            if st.button('Refinar joins pelas tabelas selecionadas', width='stretch'):
                try:
                    extra_terms = terms + get_module_definition(module_name).get('terms', []) if module_name != 'Manual / sem foco' else terms
                    load_schema_package(owner=owner, table_prefix=table_prefix, terms=extra_terms, object_limit=object_limit, selected_tables=st.session_state.get('selected_tables', []), module_name=module_name)
                    st.session_state['_schema_refined_success'] = True
                    st.rerun()
                except Exception as exc:  # noqa: BLE001
                    st.error(f"Erro ao refinar joins: {_oracle_recoverable_hint(exc)}")

        schema_warnings = st.session_state.get('schema_package', {}).get('warnings', []) or []
        if st.session_state.get('ground_truth_loaded'):
            st.info('Camada canônica ativa: o app está reforçando a descoberta com o arquivo Tabelas_Colunas_Relacionamentos (PK/FK, módulos e caminhos de join).')
        for warn in schema_warnings:
            st.warning(warn)
        role_df = pd.DataFrame(st.session_state.get('schema_package', {}).get('candidate_tables', []))
        if not role_df.empty:
            st.markdown('**Candidatas com papel/família estimados**')
            st.dataframe(role_df, width='stretch', hide_index=True)
        st.text_area('Sugestões automáticas de joins', value=st.session_state.get('join_suggestions_text', ''), height=220)
        st.text_area('Detecção de tabelas mestre x movimento', value=st.session_state.get('table_roles_text', ''), height=160)
        st.text_area('Famílias operacionais das tabelas', value=st.session_state.get('table_families_text', ''), height=180)
        st.text_area('Blueprints de relacionamento ERP', value=st.session_state.get('join_blueprints_text', ''), height=220)
        with st.expander('Metadados resumidos do schema', expanded=False):
            st.text_area('Metadados', value=st.session_state.get('schema_metadata', ''), height=340)

    with tabs[2]:
        st.subheader('Fluxo profissional: gerar -> revisar/corrigir -> salvar versão')
        history_rows = st.session_state['history_store'].list_versions()
        history_options = [None] + [int(item['id']) for item in history_rows]
        previous_version_id = st.selectbox('Usar uma versão anterior como base', options=history_options, format_func=lambda x: 'Nenhuma' if x is None else f'ID {x}', key='view_previous_version_id')
        default_objective = (
            'Montar uma View Oracle aderente ao processo do ERP, respeitando joins compostos, evitando duplicidade, '
            'distinguindo cadastro, cabeçalho, item, movimento, histórico e lookup, e podendo ser usada em qualquer módulo relevante.'
        )
        objective = st.text_area('Objetivo da View', height=110, value=default_objective)
        desired_view_name = st.text_input('Nome desejado da View', value='VW_ANALISE_ERP_LOCAL')
        retrieval_query = st.text_input('Consulta para buscar contexto no índice', value='relatório query view joins filtros agrupamentos regra negócio ERP')
        extra_instructions = st.text_area(
            'Instruções extras',
            height=120,
            value='Priorize joins seguros, Oracle SQL puro, aliases legíveis, coerência com o módulo escolhido, chaves compostas completas e evite duplicidade por joins incompletos.',
        )

        col1, col2, col3 = st.columns(3)
        with col1:
            if st.button('Gerar draft da View', width='stretch'):
                try:
                    generate_view(ollama, generator_model, embedding_model, temperature, objective, desired_view_name, extra_instructions, retrieval_query, previous_version_id)
                except Exception as exc:  # noqa: BLE001
                    st.error(f'Falha ao gerar draft: {exc}')
        with col2:
            if st.button('Revisar / corrigir com 2º modelo', width='stretch'):
                try:
                    review_current_view(ollama, reviewer_model, temperature, objective)
                except Exception as exc:  # noqa: BLE001
                    st.error(f'Falha ao revisar/corrigir: {exc}')
        with col3:
            if st.button('Salvar versão atual', width='stretch'):
                try:
                    save_current_version(generator_model, reviewer_model, objective)
                except Exception as exc:  # noqa: BLE001
                    st.error(f'Falha ao salvar versão: {exc}')

        render_current_result()
        render_retrieved_chunks()

    with tabs[3]:
        st.subheader('Validação no Oracle e geração final')
        current_select = st.session_state.get('editable_select_sql', '').strip()
        current_view_name = st.session_state.get('editable_view_name', '').strip() or 'VW_GERADA_LOCAL'
        col1, col2, col3 = st.columns(3)
        with col1:
            if st.button('Validar no Oracle', width='stretch'):
                if not current_select:
                    st.warning('Gere ou edite o SELECT primeiro.')
                elif not st.session_state.get('oracle_connected'):
                    st.warning('Conecte ao Oracle primeiro.')
                else:
                    active_oracle = get_active_oracle()
                    try:
                        ok, detail = active_oracle.validate_select_sql(current_select)
                        st.session_state['validation_result'] = {'ok': ok, 'detail': detail}
                        if st.session_state.get('current_history_id'):
                            st.session_state['history_store'].update_validation(st.session_state['current_history_id'], ok, detail)
                        if ok:
                            st.success(detail)
                        else:
                            st.error(detail)
                    finally:
                        active_oracle.close()
        with col2:
            if st.button('Visualizar amostra', width='stretch'):
                if not current_select:
                    st.warning('Gere ou edite o SELECT primeiro.')
                elif not st.session_state.get('oracle_connected'):
                    st.warning('Conecte ao Oracle primeiro.')
                else:
                    active_oracle = get_active_oracle()
                    try:
                        rows = active_oracle.preview_select_sql(current_select, limit=CONFIG.preview_limit)
                        st.session_state['preview_rows'] = rows
                        st.success(f'Amostra carregada: {len(rows)} linha(s).')
                    except Exception as exc:  # noqa: BLE001
                        st.error(f'Erro ao consultar amostra: {exc}')
                    finally:
                        active_oracle.close()
        with col3:
            if st.button('Gerar View final', width='stretch'):
                create_sql = build_create_view_sql(current_view_name, current_select)
                st.session_state['final_view_sql'] = create_sql
                st.success('SQL final da View preparado.')

        validation = st.session_state.get('validation_result')
        if validation:
            st.markdown('**Último resultado de validação**')
            if validation.get('ok'):
                st.success(validation.get('detail', 'SQL válido.'))
            else:
                st.error(validation.get('detail', 'Falha na validação.'))

        if st.session_state.get('preview_rows'):
            st.markdown('**Amostra do SELECT**')
            st.dataframe(pd.DataFrame(st.session_state['preview_rows']), width='stretch', hide_index=True)

        final_sql = st.session_state.get('final_view_sql', build_create_view_sql(current_view_name, current_select))
        st.code(final_sql, language='sql')
        st.download_button('Baixar CREATE VIEW final', data=final_sql.encode('utf-8'), file_name=f'{current_view_name}.sql', mime='text/sql', width='stretch')
        confirm_execute = st.checkbox('Confirmo que desejo executar CREATE OR REPLACE VIEW no Oracle')
        if st.button('Executar CREATE OR REPLACE VIEW', width='stretch', disabled=not confirm_execute):
            if not st.session_state.get('oracle_connected'):
                st.warning('Conecte ao Oracle primeiro.')
            elif not current_select:
                st.warning('Não há SELECT para executar.')
            else:
                active_oracle = get_active_oracle()
                try:
                    ok, detail = active_oracle.execute_sql(final_sql)
                    if ok:
                        st.success(detail)
                    else:
                        st.error(detail)
                finally:
                    active_oracle.close()

    with tabs[4]:
        st.subheader('Análises preditivas, fraude, operação e controller')
        analysis_module_name, _, analysis_terms, analysis_context_text = module_selector_ui('advanced_analysis', 'analysis')
        source_type = st.radio('Fonte dos dados', options=['Consulta Oracle', 'Upload CSV/XLSX', 'Relatório PDF/TXT/SQL'], horizontal=True)

        if source_type == 'Consulta Oracle':
            sql_default = st.session_state.get('oracle_dataset_sql') or 'SELECT * FROM SUA_TABELA WHERE ROWNUM <= 500'
            sql_text = st.text_area('SQL para trazer dataset analítico', height=180, value=sql_default)
            st.session_state['oracle_dataset_sql'] = sql_text
            if st.button('Carregar dataset do Oracle', width='stretch'):
                if not st.session_state.get('oracle_connected'):
                    st.warning('Conecte ao Oracle primeiro.')
                else:
                    try:
                        load_dataset_from_sql(sql_text)
                        st.success('Dataset carregado do Oracle.')
                    except Exception as exc:  # noqa: BLE001
                        st.error(f'Erro ao carregar dataset: {exc}')
        elif source_type == 'Upload CSV/XLSX':
            uploaded_table = st.file_uploader('Envie CSV ou XLSX para análise', type=['csv', 'xlsx', 'xls'], key='analysis_table_uploader')
            if st.button('Carregar dataset do arquivo', width='stretch'):
                if not uploaded_table:
                    st.warning('Envie um arquivo CSV ou XLSX.')
                else:
                    try:
                        load_dataset_from_upload(uploaded_table)
                        st.success('Dataset carregado do arquivo.')
                    except Exception as exc:  # noqa: BLE001
                        st.error(f'Erro ao carregar arquivo: {exc}')
        else:
            uploaded_report = st.file_uploader('Envie PDF, TXT, SQL ou MD para parecer executivo', type=['pdf', 'txt', 'sql', 'md'], key='analysis_report_uploader')
            if st.button('Ler relatório', width='stretch'):
                if not uploaded_report:
                    st.warning('Envie um relatório.')
                else:
                    try:
                        parsed = parse_uploaded_file(uploaded_report)
                        st.session_state['analysis_report_text'] = parsed.text[:60000]
                        st.success('Relatório lido com sucesso.')
                    except Exception as exc:  # noqa: BLE001
                        st.error(f'Erro ao ler relatório: {exc}')
            if st.session_state.get('analysis_report_text'):
                st.text_area('Texto do relatório', value=st.session_state.get('analysis_report_text', ''), height=260)

        bundle = st.session_state.get('analysis_bundle')
        if isinstance(bundle, AnalysisBundle):
            st.markdown(f"**Fonte carregada:** {st.session_state.get('analysis_source_name', 'dataset')}"
                        f" | linhas={bundle.profile['rows']} | colunas={bundle.profile['columns']}")
            st.dataframe(bundle.normalized_dataframe.head(100), width='stretch', hide_index=True)
            with st.expander('Semântica inferida e perfil', expanded=False):
                st.json(bundle.semantic_map)
                st.write(bundle.profile)

        analysis_type = st.selectbox(
            'Tipo de análise',
            options=[
                'Auto diagnóstico',
                'Anomalias e inconsistências',
                'Previsão de troca de peça',
                'Consumo de combustível x troca de motorista',
                'Fraude e padrões suspeitos',
                'Indicadores financeiros / controller',
                'Parecer executivo com LLM',
            ],
            index=0,
            key='analysis_type_select',
        )

        colx, coly = st.columns([1, 1])
        with colx:
            if st.button('Executar análise', width='stretch'):
                try:
                    if analysis_type == 'Parecer executivo com LLM':
                        base_result = st.session_state.get('analysis_result')
                        findings_text = findings_to_text(base_result) if base_result else 'Sem análise heurística prévia.'
                        profile_text = build_profile_text(bundle) if isinstance(bundle, AnalysisBundle) else 'Sem dataset tabular carregado.'
                        objective = (
                            'Explique ao controller ou gestor os principais indicadores, riscos, inconsistências, causas prováveis e prioridades '
                            'de investigação, considerando operação, manutenção, financeiro e fraude conforme o material disponível.'
                        )
                        prompt = build_analyst_prompt(
                            objective=objective,
                            module_context_text=analysis_context_text,
                            profile_text=profile_text,
                            findings_text=findings_text,
                            report_text=st.session_state.get('analysis_report_text', ''),
                        )
                        st.session_state['analysis_executive_text'] = ollama.generate(
                            model=analyst_model,
                            prompt=prompt,
                            temperature=min(temperature, 0.2),
                            system=ANALYST_SYSTEM_PROMPT,
                        )
                    else:
                        if not isinstance(bundle, AnalysisBundle):
                            st.warning('Carregue primeiro um dataset do Oracle ou de arquivo.')
                        else:
                            if analysis_type == 'Auto diagnóstico':
                                st.session_state['analysis_result'] = auto_diagnosis(bundle)
                            elif analysis_type == 'Anomalias e inconsistências':
                                st.session_state['analysis_result'] = anomaly_detection(bundle)
                            elif analysis_type == 'Previsão de troca de peça':
                                st.session_state['analysis_result'] = predict_part_replacement(bundle)
                            elif analysis_type == 'Consumo de combustível x troca de motorista':
                                st.session_state['analysis_result'] = analyze_fuel_driver_change(bundle)
                            elif analysis_type == 'Fraude e padrões suspeitos':
                                st.session_state['analysis_result'] = detect_fraud_patterns(bundle)
                            elif analysis_type == 'Indicadores financeiros / controller':
                                st.session_state['analysis_result'] = compute_financial_indicators(bundle)
                except Exception as exc:  # noqa: BLE001
                    st.error(f'Falha na análise: {exc}')
        with coly:
            if st.button('Gerar parecer executivo a partir do último resultado', width='stretch'):
                base_result = st.session_state.get('analysis_result')
                findings_text = findings_to_text(base_result) if base_result else 'Sem análise heurística prévia.'
                profile_text = build_profile_text(bundle) if isinstance(bundle, AnalysisBundle) else 'Sem dataset tabular carregado.'
                prompt = build_analyst_prompt(
                    objective='Produzir um parecer executivo para controller, operação ou auditoria.',
                    module_context_text=analysis_context_text,
                    profile_text=profile_text,
                    findings_text=findings_text,
                    report_text=st.session_state.get('analysis_report_text', ''),
                )
                try:
                    st.session_state['analysis_executive_text'] = ollama.generate(
                        model=analyst_model,
                        prompt=prompt,
                        temperature=min(temperature, 0.2),
                        system=ANALYST_SYSTEM_PROMPT,
                    )
                except Exception as exc:  # noqa: BLE001
                    st.error(f'Falha ao gerar parecer: {exc}')

        render_analysis_result(st.session_state.get('analysis_result'))
        if st.session_state.get('analysis_executive_text'):
            st.subheader('Parecer executivo')
            st.markdown(st.session_state.get('analysis_executive_text', ''))

    with tabs[5]:
        render_history_tab()


    with tabs[6]:
        runtime_config = build_genai_runtime_config(ollama_base_url, generator_model, analyst_model, embedding_model)
        render_genai_catalog_tab(runtime_config)

    with tabs[7]:
        runtime_config = build_genai_runtime_config(ollama_base_url, generator_model, analyst_model, embedding_model)
        render_genai_sql_copilot_tab(runtime_config)

    with tabs[8]:
        runtime_config = build_genai_runtime_config(ollama_base_url, generator_model, analyst_model, embedding_model)
        render_genai_rag_tab(runtime_config)

    with tabs[9]:
        runtime_config = build_genai_runtime_config(ollama_base_url, generator_model, analyst_model, embedding_model)
        render_genai_dba_tab(runtime_config)

    with tabs[10]:
        runtime_config = build_genai_runtime_config(ollama_base_url, generator_model, analyst_model, embedding_model)
        render_genai_security_tab(runtime_config)

    with tabs[11]:
        runtime_config = build_genai_runtime_config(ollama_base_url, generator_model, analyst_model, embedding_model)
        render_genai_synthetic_tab(runtime_config)

    with tabs[12]:
        render_chartdb_tab()


if __name__ == '__main__':
    main()
