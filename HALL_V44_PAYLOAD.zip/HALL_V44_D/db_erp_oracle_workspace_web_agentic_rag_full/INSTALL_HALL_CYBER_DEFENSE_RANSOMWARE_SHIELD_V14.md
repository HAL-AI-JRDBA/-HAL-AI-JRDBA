# Instalação — HAL Cyber Defense & Ransomware Shield V14

Execute:

```bat
INICIAR_JR_AI_HALL_CYBER_DEFENSE_V14.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Teste rápido no chat

Digite:

```text
Quero que a IA previna invasões e ataques que criptografam arquivos em servidores e desktops.
```

O HAL deve escolher:

```text
intent: cyber_defense
tool: cyber_defense_shield
```

## Teste de e-mail suspeito via API

```text
POST /api/unified/cyber-defense/email/analyze
```

JSON:

```json
{
  "email": {
    "sender": "financeiro@exemplo.com",
    "subject": "URGENTE boleto vencido clique aqui",
    "body": "Atualize sua senha para evitar bloqueio",
    "attachments": [
      {"filename": "boleto.pdf.exe"},
      {"filename": "contrato.docm"}
    ]
  }
}
```

## Monitoramento de arquivos

1. No painel Cyber Defense, informe caminhos de pastas críticas.
2. Clique em `Salvar caminhos`.
3. Clique em `Criar Canários`.
4. Clique em `Criar Baseline`.
5. Depois clique em `Vasculhar agora`.

## Observação

Para proteção corporativa real, conecte EDR/SIEM/antivírus/firewall/gateway de e-mail com credenciais autorizadas. Sem essas credenciais, o HAL entrega triagem local, baseline, canários, alertas, playbook e recomendações.
