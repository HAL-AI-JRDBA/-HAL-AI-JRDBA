# Instalação — HAL Live Dialogue Engine V4

Execute:

```bat
INICIAR_JR_AI_HALL_LIVE_DIALOGUE_V4.bat
```

ou:

```bat
INICIAR_JR_AI_HALL_MICROFONE_CORRIGIDO.bat
```

ou:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Teste obrigatório

Na tela principal, sem escolher aba, pergunte:

```text
Bom dia Hall, tudo bem?
```

Depois:

```text
HAL, qual é o EBITDA da empresa?
```

Depois:

```text
Por filial.
```

O HAL deve continuar o contexto da conversa, perguntar fonte real se faltar dado e não abrir painel técnico sozinho.

## Importante

Para conversa aberta sobre qualquer assunto, confirme se o Ollama/modelo local está ativo:

```bat
VERIFICAR_HALL_OLLAMA_STATUS.bat
```

Se o modelo não estiver ativo, o HAL avisa de forma clara que precisa do modelo local para responder perguntas abertas com naturalidade.
