@echo off
call "%~dp0..\INICIAR_JR_AI_HALL_V32_4.bat"
exit /b %ERRORLEVEL%
