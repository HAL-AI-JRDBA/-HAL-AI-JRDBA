# JR-AI

Projeto web novo, instalável do zero em pasta separada, com navegação horizontal no topo.

## Instalação
1. Execute `install_web.bat`
2. Execute `run_web.bat`
3. Abra `http://127.0.0.1:8010`

## Recursos principais
- Navegação horizontal por mouse
- Conexão Oracle
- Configuração de modelos/Ollama
- Mapa de módulos ERP
- Mapa ERP / Metadados
- SQL Copilot com Prompt Composer e Context Panel
- View Studio
- RAG Persistente (Traditional / Vectorless / Hybrid / Auto)
- Assistente DBA
- Segurança / Anomalias
- Dados sintéticos
- ERD / ChartDB
- Workspace com Pins, Timeline e Process Panel

## Pastas importantes
- `web_app/frontend`: interface web
- `web_app/backend/main.py`: API FastAPI
- `services/`: serviços Oracle, RAG, Ground Truth e utilitários
- `data/ground_truth`: arquivo canônico de tabelas/colunas/relacionamentos
