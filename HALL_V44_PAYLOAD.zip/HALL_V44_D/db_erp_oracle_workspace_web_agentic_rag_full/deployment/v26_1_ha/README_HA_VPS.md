# HAL V26.1 — HA / VPS

## Single VPS / servidor Docker

O `docker-compose.ha.yml` sobe duas instâncias HAL (`hall-a` e `hall-b`) atrás do Caddy. O Caddy usa `lb_policy first` e health check em `/api/health`: normalmente envia tráfego ao `hall-a` e muda para `hall-b` quando o primeiro fica indisponível.

As duas instâncias usam o volume `hall-data`. Como parte do estado atual da HAL é baseado em arquivos locais, o modo **active-passive** evita escrita concorrente regular entre as instâncias.

## Dois hosts / VPS

Use `Caddyfile.multi-vps.example` e substitua os IPs. Para failover entre hosts, providencie **storage persistente compartilhado ou replicado** para `data/` (por exemplo NFS corporativo, storage distribuído ou replicação operacional). Não use duas cópias independentes de `data/` e espere consistência automática.

## Segurança

- Nenhum shell irrestrito da HAL é habilitado por este perfil.
- Publique somente 80/443 pelo proxy.
- Restrinja 8000/11434 à rede privada.
- Use HTTPS e DNS corporativo em produção.
- Mantenha IAM/RBAC, AI Governance, Safety Supervisor e aprovação humana habilitados.
