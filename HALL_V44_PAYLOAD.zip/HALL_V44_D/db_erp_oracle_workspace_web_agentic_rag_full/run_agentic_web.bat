
if not "%HALL_OLLAMA_AUTO_DONE%"=="1" (
  if exist "HALL_AUTO_OLLAMA.bat" call "HALL_AUTO_OLLAMA.bat"
)
@echo off
setlocal
cd /d %~dp0

if not exist .venv_agentic\Scripts\activate.bat (
  echo Ambiente .venv_agentic nao encontrado. Rode primeiro install_agentic.bat
  pause
  exit /b 1
)

call .venv_agentic\Scripts\activate.bat

echo ============================================================
echo INICIALIZANDO DB ERP ORACLE WORKSPACE AGENTIC RAG
echo ============================================================
echo URL local: http://127.0.0.1:8010
echo.
start "" http://127.0.0.1:8010
python -m uvicorn web_app.backend.main:app --host 127.0.0.1 --port 8010

endlocal
