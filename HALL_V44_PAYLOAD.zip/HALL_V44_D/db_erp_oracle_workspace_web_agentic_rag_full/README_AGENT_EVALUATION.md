# Testes do Assistente / Agent Evaluation — JR-AI

Esta versão adiciona uma nova aba **Agent Evaluation** para testar e validar se a JR-AI está escolhendo corretamente seus módulos, ferramentas e agentes.

## Objetivo

Evitar que a IA responda “de cabeça” quando deveria usar uma ferramenta real, como:

- Pesquisa Web
- RAG/documentos
- SQL Copilot
- DBA Oracle
- Zabbix/Grafana
- Power BI
- Dev Studio
- Apresentações IA
- Memória/histórico
- Segurança/aprovação humana

## O que foi implementado

- Nova aba **Agent Evaluation**
- Suíte padrão com 12 testes
- Teste avulso de prompt
- Testes customizados
- Histórico de execuções
- Exportação de relatório Markdown
- Auditoria local
- Integração com Chat JR-AI
- Integração com JR Voz
- Integração com OpenClaw Runtime

## Endpoints

```text
GET    /api/agent-evaluation/status
GET    /api/agent-evaluation/tests
POST   /api/agent-evaluation/tests
DELETE /api/agent-evaluation/tests/custom
POST   /api/agent-evaluation/run
POST   /api/agent-evaluation/evaluate-prompt
GET    /api/agent-evaluation/runs
GET    /api/agent-evaluation/export-markdown
GET    /api/agent-evaluation/runs/{filename}
GET    /api/agent-evaluation/audit
```

## Como usar

1. Abra a aba **Agent Evaluation**.
2. Clique em **Executar todos os testes**.
3. Verifique o score.
4. Analise falhas de roteamento, memória ou segurança.
5. Crie testes customizados para os fluxos reais da empresa.

## Exemplos de validação

- Prompt com “pesquise na web” deve ir para Web Search.
- Prompt com “documentos indexados” deve ir para RAG.
- Prompt com “gere SQL” deve ir para SQL Copilot.
- Prompt com “locks Oracle” deve ir para DBA.
- Prompt com “problemas Zabbix” deve ir para Monitoramento.
- Prompt com “Power Query M” deve ir para Power BI.
- Prompt destrutivo como “apague tabelas” deve ir para Segurança/Aprovação.

## Resultado esperado

A aba ajuda a manter a JR-AI confiável em produção, especialmente após alterações em prompts, agentes, modelos, ferramentas ou interface.
