# JR-AI / HAL — Console Unificado

Esta versão coloca a plataforma em **um único lugar visual**, com a tela limpa do HAL como entrada principal.

## O que mudou

Antes, a interface principal mostrava muitas abas e ficava poluída. Agora:

- A raiz `http://127.0.0.1:8000` abre o **HAL Unified Console**.
- O usuário conversa com uma única tela.
- O HAL escolhe automaticamente a ferramenta certa.
- Também é possível escolher manualmente a área no seletor **Destino**.
- O painel clássico antigo continua preservado e pode abrir embutido apenas quando necessário.
- A tela antiga completa continua acessível em `/legacy.html`.

## Como executar

Na raiz do ZIP extraído:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Ou dentro da pasta do projeto:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Abra:

```text
http://127.0.0.1:8000
```

## Como usar

### Automático

Deixe o campo **Destino** como:

```text
Automático — HAL escolhe
```

Exemplos:

```text
HAL, gere uma SQL para contas a receber vencidas.
HAL, o ERP está lento. Verifique Oracle, Zabbix e bilheteria.
HAL, veja minha tela e analise o dashboard de arrecadação.
HAL, crie um sistema web para controle de frota.
HAL, gere uma apresentação para diretoria.
```

### Manual

Selecione uma área, por exemplo:

```text
SQL Copilot
DBA Oracle
Monitoramento
Power BI
Dev Studio
RAG / Documentos
HAL Filme
Voz Natural
```

Depois envie o pedido. O HAL direciona para a área escolhida e abre o painel clássico se necessário.

## Onde estão as abas antigas?

As abas antigas continuam preservadas em:

```text
http://127.0.0.1:8000/legacy.html
```

O objetivo é não deixar mais o usuário final perdido com dezenas de abas. A tela nova funciona como uma camada de atendimento e roteamento por intenção.

## Resumo técnico

Foram adicionados:

- `web_app/frontend/index.html` novo, limpo e unificado.
- `web_app/frontend/legacy.html` preservando a interface antiga.
- `web_app/frontend/unified_app.js`.
- `web_app/frontend/unified_styles.css`.
- Endpoints `/api/unified/status`, `/api/unified/modules` e `/api/unified/turn`.
- Launcher `INICIAR_JR_AI_CONSOLE_UNIFICADO.bat`.

