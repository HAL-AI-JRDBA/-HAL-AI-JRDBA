# Integração Agent Gateway Local / OpenClaw

Esta versão adiciona uma camada segura para uso com OpenClaw, PenClaw-like local, MCP HTTP tools ou qualquer agente externo que consiga chamar endpoints HTTP.

## Objetivo

O agente externo **não acessa o Oracle diretamente** e **não executa shell**. Ele chama o NeoAI por endpoints controlados em `/api/agent/...`.

Fluxo recomendado:

```text
Usuário / OpenClaw
  -> Agent Gateway HTTP local
  -> módulos internos do NeoAI
     -> RAG local
     -> busca de schema Oracle
     -> geração de SQL
     -> validação SQL somente leitura
     -> execução SELECT limitada
     -> coletas DBA read-only
```

## Tela web

Foi adicionada a aba:

```text
Agente Local/OpenClaw
```

Nela é possível:

- habilitar/desabilitar o gateway;
- configurar token local;
- exigir ou não token;
- habilitar/desabilitar ferramentas;
- definir máximo de linhas para SELECT;
- exigir confirmação humana antes de executar SELECT;
- testar as ferramentas diretamente pela interface web;
- visualizar auditoria das chamadas.

## Endpoints principais

```text
GET  /api/agent/status
GET  /api/agent/config
POST /api/agent/config
GET  /api/agent/tools
GET  /api/agent/audit
POST /api/agent/ask
POST /api/agent/tools/rag_search
POST /api/agent/tools/find_tables
POST /api/agent/tools/generate_sql
POST /api/agent/tools/validate_sql
POST /api/agent/tools/run_select
POST /api/agent/tools/suggest_indexes
POST /api/agent/tools/dba_collect
```

## Segurança implementada

Sempre bloqueado nesta integração:

- shell, `.bat`, `.ps1`, `.exe`;
- `INSERT`, `UPDATE`, `DELETE`, `MERGE`;
- `CREATE`, `ALTER`, `DROP`, `TRUNCATE`;
- PL/SQL `BEGIN`, `DECLARE`, `EXECUTE`, `CALL`;
- chamadas `DBMS_` e `UTL_`;
- múltiplas instruções SQL;
- escrita em arquivos sensíveis.

A execução permitida é apenas `SELECT` ou `WITH`, validada por `SQLValidator`.

## Token

Por padrão, a opção `require_token` fica desabilitada para facilitar testes locais.

Para uso com agente externo, recomenda-se habilitar **Exigir token nas chamadas externas** na aba `Agente Local/OpenClaw`.

Header esperado:

```text
x-neoai-agent-token: seu-token-local
```

## Exemplo cURL

```powershell
curl -X POST http://127.0.0.1:8010/api/agent/tools/validate_sql ^
  -H "Content-Type: application/json" ^
  -H "x-neoai-agent-token: local-dev-change-me" ^
  -d "{\"sql\":\"select * from dual\",\"limit\":100}"
```

## Exemplo de ferramenta para OpenClaw/HTTP Tool

Configure uma ferramenta HTTP que envie JSON para:

```text
POST http://127.0.0.1:8010/api/agent/ask
```

Payload sugerido:

```json
{
  "question": "Gere uma SQL para veículos com manutenção preventiva no último mês",
  "owner": "GLOBUS",
  "module_name": "Manutenção",
  "selected_tables": ["MAN_OS", "MAN_OSPREVISTO", "FRT_CADVEICULOS"],
  "dry_run": true,
  "execute_after_generate": false,
  "require_confirmation": true,
  "limit": 200
}
```

## Execução de SELECT com confirmação

Quando `require_human_confirmation_for_execute=true`, chamadas externas para `/api/agent/tools/run_select` retornam erro 409 até o agente reenviar:

```json
{
  "sql": "select * from dual",
  "require_confirmation": false
}
```

Use isso somente depois de autorização explícita do usuário.

## Arquivos adicionados/alterados

- `web_app/backend/main.py`
  - novos modelos `AgentConfigRequest` e `AgentToolRequest`;
  - novos helpers de configuração, permissão, auditoria e validação;
  - novos endpoints `/api/agent/...`.
- `web_app/frontend/index.html`
  - nova aba `Agente Local/OpenClaw`.
- `web_app/frontend/app.js`
  - funções de status, configuração, auditoria e execução de ferramentas.
- `web_app/frontend/styles.css`
  - ajustes visuais da aba nova.
- `data/agent_gateway/agent_config.json`
  - criado automaticamente quando a configuração é salva.
- `data/agent_gateway/agent_audit.jsonl`
  - criado automaticamente quando houver chamadas auditadas.

## Como rodar

Use o mesmo comando atual do projeto:

```powershell
.\run_web.bat
```

Depois abra a interface web e acesse a aba `Agente Local/OpenClaw`.
