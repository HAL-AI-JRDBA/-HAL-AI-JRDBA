@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist "HALL_AUTO_MODELS_V15.bat" call "HALL_AUTO_MODELS_V15.bat"
if exist "HALL_AUTO_STT.bat" call "HALL_AUTO_STT.bat"

echo ============================================================
echo JR-AI / HAL - CONSOLE UNIFICADO
echo ============================================================
echo.
echo Esta versao abre tudo em um unico lugar:
echo http://127.0.0.1:8000
echo.
echo A tela limpa fica na raiz.
echo O modo classico completo fica em /legacy.html
echo.

rem ============================================================
rem HAL - variaveis de modelo local para esta sessao
rem ============================================================
if "%HALL_OLLAMA_MODEL%"=="" set "HALL_OLLAMA_MODEL=qwen2.5:7b"
if "%OLLAMA_URL%"=="" set "OLLAMA_URL=http://127.0.0.1:11434"
set "OLLAMA_MODEL=%HALL_OLLAMA_MODEL%"
set "HALL_DIALOG_MODEL=%HALL_OLLAMA_MODEL%"
set "HALL_WEB_SUMMARY_MODEL=%HALL_OLLAMA_MODEL%"
if not "%HALL_OLLAMA_AUTO_DONE%"=="1" if exist "HALL_AUTO_OLLAMA.bat" call "HALL_AUTO_OLLAMA.bat"

call "run_web_dev_studio.bat"
endlocal
