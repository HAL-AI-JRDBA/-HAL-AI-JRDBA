# HAL Meeting Intelligence Gateway

Esta versão adiciona ao projeto a camada para uso do HAL em reuniões, calls e videoconferências.

## Objetivo

Permitir que pessoas em uma reunião no Microsoft Teams, Google Meet ou outra plataforma possam fazer perguntas para o HAL e receber resposta:

```text
Por voz
Por texto no chat da reunião
Na tela do HAL
Na ata da reunião
Como tarefa/ação pendente
```

## Plataformas contempladas

```text
Microsoft Teams
Google Meet
Zoom — preparado para futura integração
Webex — preparado para futura integração
Áudio Local / Desktop Companion
```

## Modos

```text
Modo Ouvinte
- Escuta e transcreve
- Gera ata
- Identifica decisões, riscos e tarefas
- Não responde automaticamente

Modo Perguntas e Respostas
- Participantes chamam “HAL”
- HAL entende a pergunta
- Consulta ferramentas internas
- Responde por voz e/ou texto

Modo Agente de Reunião
- Acompanha a reunião
- Responde perguntas
- Registra decisões
- Cria tarefas
- Gera resumo final
```

## Exemplos

```text
HAL, verifique os alertas do Zabbix e Grafana para TI.
HAL, consulte as vendas de passagens de hoje por linha.
HAL, qual cliente está com maior pendência no CRM?
HAL, gere a ata dessa reunião.
HAL, crie as tarefas com responsáveis e prazos.
```

## Integrações usadas durante a reunião

```text
Human Conversation Gateway
Enterprise Integration & Team Intelligence
Database Access Wizard
Universal ERP Connector
Reliable Web Answer
Power BI
Zabbix
Grafana
ERP
CRM
Calendários
Teams / Google Meet / canais
```

## Importante sobre funcionamento real

Esta camada adiciona estrutura funcional, endpoints, telas, roteamento, ata, perguntas, respostas preparadas por voz/texto e plano de entrega.

Para o HAL realmente falar dentro da reunião, é necessário configurar no cliente uma destas opções:

```text
1. Bot oficial do Teams com permissões corporativas
2. Desktop/Browser Companion autorizado para Teams/Google Meet
3. Áudio local com STT/TTS
4. Integração específica da plataforma quando disponível
```

## Privacidade

Antes de usar em reunião real, a empresa deve avisar os participantes que o HAL poderá transcrever/analisar a reunião.

A camada exige consentimento/aviso quando configurado.


## HAL Omnichannel Voice/Text Delivery

Adicionada camada para entregar respostas do HAL por WhatsApp e Telegram em texto e voz, com contatos, aprovação humana, credenciais por variável de ambiente, auditoria, preparação de roteiro de voz e integração com Conversa Natural, Meeting Intelligence e Enterprise Teams.


## E-mail ao Solicitante

Adicionado envio/preparo de e-mail ao solicitante dentro do HAL Omnichannel Voice/Text Delivery, com corpo em texto, áudio anexado quando disponível, assunto automático, SMTP por variáveis de ambiente e aprovação humana antes de envio externo.


## HAL Dialogue Brain V2

Substituída a conversa natural por uma versão anti-papagaio, com memória de sessão, resposta contextual, fallback para Ollama/modelo local, perguntas de esclarecimento reais e correção do comportamento repetitivo em mensagens curtas ou ambíguas.
