@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist "HALL_AUTO_MODELS_V15.bat" call "HALL_AUTO_MODELS_V15.bat"
call "INICIAR_JR_AI_HALL_DIALOGUE_BRAIN_V2.bat"
endlocal
