# OpenClaw Teams / Equipes de Agentes — JR-AI

Esta versão adiciona a aba **OpenClaw Teams**, permitindo criar equipes de agentes IA trabalhando juntas dentro da JR-AI, de forma local, governada e integrada ao ecossistema atual.

## Recursos implementados

- Nova aba **OpenClaw Teams**
- Cadastro visual de agentes
- Cadastro visual de equipes
- Ferramentas permitidas por agente
- Ferramentas permitidas por equipe
- Nível de autonomia:
  - somente leitura
  - guiado
  - supervisionado
  - sempre com aprovação
- Escopo de memória:
  - nenhuma
  - equipe
  - domínio
  - projeto
  - global
- Nível de risco por agente
- Contrato de saída por agente
- Executor visual de equipe
- Timeline por agente
- Logs por agente
- Histórico de execuções
- Aprovação humana
- Blueprint exportável da equipe
- Geração automática de testes para Agent Evaluation
- Integração com:
  - Chat JR-AI
  - JR Voz / JR Ao Vivo
  - OpenClaw Runtime
  - Agent Evaluation
  - JR-Evolve Lab
  - Runtime Local CPU/GPU

## Equipes padrão incluídas

### Equipe DBA + Monitoramento

Agentes:
- Coordenador
- DBA Oracle
- Monitoramento Zabbix/Grafana
- SQL Copilot
- Segurança
- Revisor

Uso:
```text
JR, o ERP está lento. Verifique Oracle, locks, jobs, Zabbix/Grafana e diga o que devo priorizar.
```

### Equipe Financeiro + BI

Agentes:
- Coordenador
- Financeiro ERP
- SQL Copilot
- Power BI
- Segurança
- Revisor

Uso:
```text
JR, analise o contas a receber vencido, gere SQL e proponha indicadores para Power BI.
```

### Equipe Desenvolvimento + Qualidade

Agentes:
- Coordenador
- Dev Studio
- SQL Copilot
- Segurança
- Revisor

Uso:
```text
JR, crie um sistema web em FastAPI com Oracle para ordens de serviço da frota.
```

## Segurança

Por padrão, as equipes executam em modo **simulado/governado**.

As equipes podem:
- consultar
- analisar
- gerar SQL
- gerar código
- gerar dashboard
- gerar relatório
- gerar plano de ação

Mas não devem executar automaticamente:
- DROP
- TRUNCATE
- DELETE massivo
- ALTER em produção
- deploy em produção
- refresh crítico
- envio externo
- alteração em Zabbix/Grafana/Power BI

Essas ações exigem aprovação humana.

## Endpoints adicionados

```text
GET    /api/openclaw-teams/status
GET    /api/openclaw-teams/agents
POST   /api/openclaw-teams/agents
DELETE /api/openclaw-teams/agents/{agent_id}
GET    /api/openclaw-teams/teams
POST   /api/openclaw-teams/teams
DELETE /api/openclaw-teams/teams/{team_id}
POST   /api/openclaw-teams/plan
POST   /api/openclaw-teams/run
GET    /api/openclaw-teams/runs
GET    /api/openclaw-teams/runs/{filename}
GET    /api/openclaw-teams/approvals
POST   /api/openclaw-teams/approval-decision
POST   /api/openclaw-teams/evaluation-tests
POST   /api/openclaw-teams/blueprint
GET    /api/openclaw-teams/blueprints/{filename}
GET    /api/openclaw-teams/audit
```

## Como validar

1. Abra a aba **OpenClaw Teams**.
2. Clique em **Status**.
3. Clique em **Listar agentes**.
4. Clique em **Listar equipes**.
5. Preencha um prompt técnico.
6. Clique em **Planejar equipe**.
7. Clique em **Executar equipe**.
8. Veja a timeline por agente.
9. Clique em **Gerar testes Agent Evaluation**.
10. Rode a aba **Agent Evaluation**.

## Observação

O módulo foi implementado preservando a proposta da JR-AI:

```text
100% local
Open-source
Sem OpenAI
Sem Anthropic
Ollama local
CPU no notebook
GPU nos clientes que tiverem infraestrutura
```
