# HAL — Conversa Humana + Pesquisa Confiável

Esta atualização adiciona ao JR Avatar/HAL duas capacidades importantes:

1. **Conversa mais humana e educada**
2. **Fallback automático para Pesquisa Web em fontes confiáveis quando a pergunta não estiver no conhecimento local/modelos**

## Conversa humana

O HAL agora reconhece saudações simples, por exemplo:

```text
Bom dia
Boa tarde
Boa noite
Olá
Oi
Tudo bem?
```

E responde de forma natural:

```text
Bom dia! Tudo bem? Como posso te ajudar hoje?
```

## Não interromper o usuário

O botão **Falar** foi ajustado para não enviar a pergunta assim que o navegador detecta a primeira frase.

Agora ele usa:

```text
continuous = true
interimResults = true
listen_silence_ms = 2800
botão Terminei
```

Fluxo:

```text
Usuário começa a falar
HAL transcreve em tempo real
HAL aguarda silêncio configurável
Usuário pode continuar falando
Usuário pode clicar em Terminei
Somente depois o HAL responde
```

## Pesquisa confiável

Quando a pergunta for geral, atual ou não estiver claramente vinculada aos módulos internos, o HAL roteia para:

```text
Pesquisa Web
```

A pesquisa foi desenhada para usar **SearXNG local**, mantendo a filosofia local/open-source.

Endpoint:

```text
POST /api/jr-avatar/trusted-search
```

Exemplo de configuração:

```text
SearXNG local:
http://127.0.0.1:8081/search
```

## Domínios confiáveis padrão

```text
docs.oracle.com
learn.microsoft.com
support.microsoft.com
grafana.com
zabbix.com
prometheus.io
python.org
fastapi.tiangolo.com
ollama.com
github.com
gov.br
inpi.gov.br
postgresql.org
mysql.com
mariadb.org
mongodb.com
```

## Como o HAL decide

Se o usuário perguntar algo como:

```text
Qual é a versão atual do Python?
Como configurar uma regra atual no Zabbix?
Pesquise em sites confiáveis a documentação do Oracle 19c.
```

O HAL entende que pode depender de informação externa e usa a rota:

```text
Pesquisa Web confiável
```

Se for algo interno, ele continua roteando para:

```text
DBA
SQL Copilot
RAG
Power BI
Zabbix/Grafana
OpenClaw Teams
JR-Evolve
Runtime Local
Dev Studio
Agent Evaluation
```

## Observação importante

A JR-AI continua sem usar OpenAI ou Anthropic.

Para pesquisa web mantendo a proposta local, configure SearXNG dentro do ambiente do cliente. A IA continua local; o SearXNG apenas consulta a web conforme política da empresa.
