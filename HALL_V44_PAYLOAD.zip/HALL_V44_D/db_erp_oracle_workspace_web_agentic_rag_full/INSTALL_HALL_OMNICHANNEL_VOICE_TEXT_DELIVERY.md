# Instalação — HAL WhatsApp/Telegram Voz + Texto

Execute:

```bat
INICIAR_JR_AI_HALL_OMNICHANNEL_VOZ_TEXTO.bat
```

ou:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Acesse:

```text
http://127.0.0.1:8000
```

## Variáveis de ambiente

WhatsApp:

```text
WHATSAPP_TOKEN
WHATSAPP_PHONE_NUMBER_ID
```

ou:

```text
HALL_WHATSAPP_TOKEN
HALL_WHATSAPP_PHONE_NUMBER_ID
```

Telegram:

```text
TELEGRAM_BOT_TOKEN
```

ou:

```text
HALL_TELEGRAM_BOT_TOKEN
```

## TTS opcional

Para tentar gerar arquivo de áudio local:

```bash
pip install pyttsx3
```

Em produção, recomenda-se conectar o TTS padrão do cliente ou o módulo de voz do HAL.

## Observações

Sem credenciais, a camada deixa tudo preparado:
- texto
- roteiro de voz
- manifesto de áudio
- auditoria
- pendência de aprovação
