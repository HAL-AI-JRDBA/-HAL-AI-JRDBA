# Insights Preditivos e Prescritivos — NeoAI Oracle/ERP

Esta versão adiciona uma camada local/open-source para a IA deixar de ser apenas reativa e passar a ser **preditiva e prescritiva**.

Ela responde perguntas como:

- O que pode dar problema nos próximos dias?
- Qual risco devo priorizar agora?
- Qual SQL/tablespace/job/backup está virando gargalo?
- O que o Controller, DBA, Estoque, Compras, Manutenção ou Arrecadação devem fazer?
- Quais coletas/consultas devo executar em seguida?

## Arquivos adicionados

```text
services/predictive_insights.py
README_INSIGHTS_PREDITIVOS.md
```

## Arquivos integrados

```text
services/multi_agent_system.py
services/tool_registry.py
web_app/backend/main.py
web_app/frontend/index.html
web_app/frontend/app.js
web_app/frontend/styles.css
```

## Nova aba da interface

```text
Insights Preditivos
```

Essa aba permite informar uma pergunta de decisão e gerar:

- resumo executivo;
- lista de insights;
- severidade;
- confiança;
- horizonte previsto;
- evidências;
- impacto no negócio;
- ações recomendadas;
- próximas consultas/coletas.

## Novo agente multiagente

```text
Advisor Preditivo/Prescritivo
```

Ele entra no fluxo multiagente para transformar evidências em decisão.

## Novo workflow multiagente

```text
Insights Preditivos/Prescritivos
```

Fluxo típico:

```text
Supervisor
→ Roteador de modelo local
→ Engenheiro de contexto
→ Memória/cache/RAG
→ DBA read-only
→ Advisor Preditivo
→ Segurança/Governança
```

## Novos endpoints

```text
GET  /api/predictive/status
GET  /api/predictive/audit
POST /api/predictive/insights
```

Exemplo de payload:

```json
{
  "question": "Analise riscos dos próximos 7 dias no Oracle e diga o que devo priorizar",
  "module_name": "DBA",
  "horizon_days": 7,
  "collect_dba": true,
  "collect_options": [
    "health_snapshot",
    "resource_limits",
    "tablespaces",
    "top_sql",
    "wait_events",
    "backup_summary",
    "blocking_sessions",
    "scheduler_failed",
    "alert_log"
  ]
}
```

## Segurança

A camada preditiva é somente leitura.

Bloqueado:

```text
DROP
ALTER
TRUNCATE
CREATE
INSERT
UPDATE
DELETE
MERGE
PL/SQL
Shell
PowerShell
BAT/EXE
alteração automática de produção
```

A IA recomenda ações, mas não executa mudanças destrutivas.

## Exemplos de uso

### DBA

```text
Analise riscos dos próximos 7 dias no Oracle e diga o que devo priorizar.
```

A IA pode responder com riscos de tablespace, FRA, backup, locks, wait events, top SQL, jobs e alert log.

### Estoque/Compras

```text
Quero insights de estoque: baixo giro, ruptura, compras emergenciais e aumento de custo médio.
```

A IA orienta ações como ranking de valor imobilizado, ruptura, transferência entre almoxarifados, bloqueio de nova compra e análise de preço de compra.

### Financeiro/Controller

```text
Analise a saúde financeira e diga o que o Controller deve fazer primeiro.
```

A IA sugere visão de caixa projetado, contas a pagar/receber, inadimplência, cobertura de caixa e margem.

### Frota/Manutenção

```text
Diga quais riscos operacionais devo antecipar na frota e manutenção.
```

A IA recomenda analisar OS corretivas recorrentes, custo por KM, consumo fora da curva e veículos com risco de parada.

### Bilheteria/Arrecadação

```text
Gere insights de anomalias de arrecadação e possível perda de receita.
```

A IA propõe comparação por linha, veículo, validador, motorista, cartão e média histórica.

## Observação importante

As previsões iniciais são baseadas em regras e evidências técnicas/ERP. Conforme o usuário aprova/rejeita insights, a memória e o autoaprendizado governado ajudam a melhorar a precisão e a utilidade das recomendações.
