@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist "HALL_AUTO_STT.bat" call "HALL_AUTO_STT.bat"
if exist "INICIAR_JR_AI_HALL_MICROFONE_CORRIGIDO.bat" (
  call "INICIAR_JR_AI_HALL_MICROFONE_CORRIGIDO.bat"
) else if exist "INICIAR_JR_AI_HALL_SKILLS_MULTI_AGENT.bat" (
  call "INICIAR_JR_AI_HALL_SKILLS_MULTI_AGENT.bat"
) else (
  call "INICIAR_JR_AI_CONSOLE_UNIFICADO.bat"
)
endlocal
