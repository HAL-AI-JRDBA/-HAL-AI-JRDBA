# Sistema Multiagente Local/Open-source para NeoAI Oracle/ERP

Esta versão adiciona uma camada multiagente ao projeto, sem APIs pagas e sem dependência obrigatória de frameworks externos.

## Filosofia

A arquitetura segue o padrão de agentes de produção: objetivo, planejamento, ferramentas, observação, memória/episódios e governança. A camada foi implementada como framework leve próprio para evitar dependência de serviços pagos. O LLM continua sendo o Ollama local configurado no projeto.

## Agentes implementados

- **Supervisor**: classifica o objetivo e monta o plano.
- **Pesquisador RAG**: consulta documentos locais indexados.
- **Mapeador Oracle/ERP**: identifica tabelas, colunas e joins reais.
- **Gerador SQL**: gera SQL SELECT com base no schema real.
- **Revisor SQL**: bloqueia DML, DDL, PL/SQL, shell e SQL inseguro.
- **DBA Oracle**: coleta informações read-only de saúde do banco.
- **Tuning Advisor**: sugere índices e melhorias para SQL validada.
- **Auditor de Segurança**: consolida risco e exigência de aprovação humana.
- **Coach de Autoaprendizado**: consulta/roda autonomia governada e propostas.

## Workflows

- `auto`: escolhe os agentes automaticamente.
- `sql_copilot`: RAG + schema + SQL + revisão + tuning.
- `dba_monitoring`: DBA read-only + RAG + safety + autonomia.
- `rag_research`: pesquisa multiagente em documentos locais.
- `security_review`: auditoria/validação de risco.
- `self_improvement`: autoaprendizado governado.

## Arquivos principais

```text
services/multi_agent_system.py
web_app/backend/main.py
web_app/frontend/index.html
web_app/frontend/app.js
web_app/frontend/styles.css
data/multi_agent/multi_agent_audit.jsonl
```

## Novos endpoints

```text
GET  /api/multi-agent/status
GET  /api/multi-agent/agents
GET  /api/multi-agent/workflows
GET  /api/multi-agent/audit
POST /api/multi-agent/run
```

Payload básico:

```json
{
  "question": "Gere uma SQL para baixo giro de estoque e peça revisão de tuning",
  "workflow": "sql_copilot",
  "top_k": 8,
  "limit": 200,
  "enable_rag": true,
  "enable_schema": true,
  "enable_sql": true,
  "enable_dba": true,
  "enable_tuning": true,
  "enable_autonomy": true,
  "dry_run": true,
  "require_confirmation": true
}
```

## Segurança

A camada multiagente não executa automaticamente ações destrutivas. Continuam bloqueados:

```text
DROP, ALTER, TRUNCATE, CREATE, INSERT, UPDATE, DELETE, MERGE,
PL/SQL, DBMS_, UTL_, shell, BAT, PowerShell e EXE.
```

A execução de SELECT continua dependente das regras do Agent Gateway e da confirmação humana.

## Como usar

1. Rode o projeto normalmente:

```bat
run_agentic_web.bat
```

ou:

```bat
run_web.bat
```

2. Abra a aba **Multiagentes**.
3. Escolha o workflow.
4. Informe a pergunta.
5. Clique em **Executar multiagentes**.

## Observação

A implementação não usa CrewAI, LangGraph, LangSmith, Pinecone ou qualquer serviço pago. Caso queira no futuro, a camada foi feita com interface de ferramentas/callbacks para permitir plugar frameworks open-source opcionais, mantendo o mesmo padrão de segurança.
