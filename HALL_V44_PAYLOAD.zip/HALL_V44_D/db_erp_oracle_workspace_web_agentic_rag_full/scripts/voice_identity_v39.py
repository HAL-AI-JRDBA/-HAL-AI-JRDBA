"""Local voice matching. Similarity is not authentication or source separation."""
import ctypes, hashlib, json, os, threading
from pathlib import Path


def dpapi(data, decrypt=False):
    if os.name != 'nt':
        raise RuntimeError('O cadastro protegido desta versão requer Windows.')
    from ctypes import wintypes
    class Blob(ctypes.Structure):
        _fields_=[('size',wintypes.DWORD),('data',ctypes.POINTER(ctypes.c_byte))]
    buf=ctypes.create_string_buffer(data);src=Blob(len(data),ctypes.cast(buf,ctypes.POINTER(ctypes.c_byte)));dst=Blob()
    crypt=ctypes.WinDLL('crypt32',use_last_error=True);kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    fn=crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
    fn.argtypes=[ctypes.POINTER(Blob),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(Blob)]
    fn.restype=wintypes.BOOL;kernel.LocalFree.argtypes=[ctypes.c_void_p];kernel.LocalFree.restype=ctypes.c_void_p
    if not fn(ctypes.byref(src),None,None,None,None,1,ctypes.byref(dst)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:return ctypes.string_at(dst.data,dst.size)
    finally:kernel.LocalFree(ctypes.cast(dst.data,ctypes.c_void_p))


class VoiceIdentity:
    def __init__(self,folder,owner,encoder=None,preprocess=None,protect=dpapi):
        import numpy as np
        self.np=np;self.lock=threading.RLock();self.protect=protect
        self.path=Path(folder)/(hashlib.sha256(owner.encode()).hexdigest()+'.dpapi')
        self.path.parent.mkdir(parents=True,exist_ok=True)
        if encoder is None:
            import torch
            torch.set_num_threads(2)
            from resemblyzer import VoiceEncoder,preprocess_wav
            encoder=VoiceEncoder(device='cpu');preprocess=preprocess_wav
            encoder.embed_utterance(np.zeros(16000,dtype=np.float32)) # warm up before opening microphone
        self.encoder=encoder;self.preprocess=preprocess;self.vector=None;self.threshold=.78
        if self.path.exists():
            d=json.loads(protect(self.path.read_bytes(),True));v=np.asarray(d['vector'],dtype=np.float32)
            if v.shape!=(256,) or not np.all(np.isfinite(v)) or np.linalg.norm(v)<.1:raise ValueError('Cadastro de voz inválido. Cadastre novamente.')
            self.vector=v/np.linalg.norm(v)
            self.threshold=max(.72,min(.86,float(d['threshold'])))
    def embed(self,audio):
        np=self.np
        with self.lock:
            x=np.asarray(audio,dtype=np.float32)
            if len(x)<9600 or not np.all(np.isfinite(x)):raise ValueError('Trecho curto ou inválido para identificar a voz.')
            x=self.preprocess(x,source_sr=16000)
            if len(x)<8000:raise ValueError('Pouca fala utilizável.')
            v=np.asarray(self.encoder.embed_utterance(x),dtype=np.float32)
            if v.shape!=(256,) or not np.all(np.isfinite(v)) or np.linalg.norm(v)<.1:raise ValueError('Representação vocal inválida.')
            return v/np.linalg.norm(v)
    def enroll(self,clips,valid=lambda:True):
        np=self.np
        if len(clips)!=3 or any(len(x)<32000 for x in clips):raise ValueError('São necessárias três amostras com ao menos dois segundos de fala cada.')
        with self.lock:
            vectors=[self.embed(x) for x in clips]
            similarity=min(float(np.dot(vectors[i],vectors[j])) for i,j in [(0,1),(0,2),(1,2)])
            if similarity<.72:raise ValueError('Amostras inconsistentes. Grave novamente, sozinho e próximo ao microfone.')
            centroid=np.mean(vectors,axis=0);centroid/=np.linalg.norm(centroid)
            threshold=max(.72,min(.86,similarity-.08))
            data=json.dumps({'schema':1,'vector':centroid.tolist(),'threshold':threshold}).encode()
            if not valid():raise ValueError("Cadastro cancelado.")
            encrypted=self.protect(data,False)
            tmp=self.path.with_suffix('.tmp');tmp.write_bytes(encrypted);os.replace(tmp,self.path)
            self.vector=centroid;self.threshold=threshold
            return {'registered':True,'threshold':threshold}
    def match(self,audio):
        with self.lock:
            if self.vector is None:return False,0.0
            try:score=float(self.np.dot(self.embed(audio),self.vector))
            except ValueError:return False,0.0
            return score>=self.threshold,score
    def delete(self):
        with self.lock:
            self.vector=None;self.path.unlink(missing_ok=True)


class TurnBuffer:
    """20 ms frames, short pauses retained, prefix for speaker verification."""
    def __init__(self,pause_ms=1400,max_seconds=45):
        self.pause=max(40,min(125,int(pause_ms/20)));self.limit=int(max_seconds*50)
        self.frames=[];self.voiced=[];self.silence=0;self.prefix_sent=False;self.uid=0
        self.preroll=[]
    def push(self,frame,speech):
        events=[]
        if not self.frames:
            if not speech:
                self.preroll=(self.preroll+[frame])[-10:];return events
            self.uid+=1;self.frames=self.preroll[:];self.preroll=[]
            events.append(('start',self.uid,None))
        self.frames.append(frame)
        if speech:self.voiced.append(frame);self.silence=0
        else:self.silence+=1
        if len(self.voiced)>=60 and not self.prefix_sent:
            self.prefix_sent=True;events.append(('prefix',self.uid,self.voiced[:]))
        if self.silence>=self.pause or len(self.frames)>=self.limit:
            if len(self.voiced)>=30:events.append(('end',self.uid,(self.frames[:],self.voiced[:])))
            else:events.append(('reject',self.uid,None))
            self.frames=[];self.voiced=[];self.silence=0;self.prefix_sent=False
        return events
