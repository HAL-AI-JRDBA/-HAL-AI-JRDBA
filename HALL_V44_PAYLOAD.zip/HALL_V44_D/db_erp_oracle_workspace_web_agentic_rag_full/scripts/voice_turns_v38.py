"""Latest request wins; microphone never waits for inference."""
import threading, uuid
class VoiceTurns:
    def __init__(self,request,speaker,cancel):
        self.request=request;self.speaker=speaker;self.cancel=cancel
        self.lock=threading.RLock();self.changed=threading.Condition(self.lock)
        self.active=False;self.seq=0;self.sid=str(uuid.uuid4());self.pending=None
        # Two bounded workers let a new topic start while an old HTTP call unwinds.
        for _ in range(2):threading.Thread(target=self._worker,daemon=True).start()
    def activate(self):
        with self.lock:self.active=True
    def interrupt(self):
        with self.lock:
            old=self.seq;self.seq+=1;self.pending=None;self.speaker.stop()
            sid=self.sid
        if old:threading.Thread(target=self._cancel,args=(sid,old),daemon=True).start()
    def _cancel(self,sid,seq):
        try:self.cancel(sid,seq)
        except Exception:pass # Local suppression still prevents obsolete speech.
    def deactivate(self):
        with self.lock:
            self.active=False
            self.interrupt()
    def submit(self,text):
        with self.lock:
            if not self.active:return False
            self.interrupt();self.seq+=1
            self.pending=(self.sid,self.seq,text);self.changed.notify()
            return True
    def _worker(self):
        while True:
            with self.changed:
                while self.pending is None:self.changed.wait()
                item=self.pending;self.pending=None
            sid,seq,text=item
            try:data=self.request(sid,seq,text)
            except Exception as exc:data={'answer':'Não consegui acessar a HAL. Verifique a conexão local.','error':str(exc)}
            with self.lock:
                if self.active and self.seq==seq and not data.get('discarded'):
                    self.speaker.say(str(data.get('answer') or ''))
