"""Install/activate or diagnose Gemma 4 in a user's local HAL installation."""
import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from services.gemma4_v42 import ALLOWED, Gemma4, profile


def main():
    parser = argparse.ArgumentParser(description='Gemma 4 local para HAL V42')
    parser.add_argument('--model', choices=sorted(ALLOWED))
    parser.add_argument('--install', action='store_true')
    parser.add_argument('--activate', action='store_true')
    parser.add_argument('--disable', action='store_true')
    parser.add_argument('--status', action='store_true')
    parser.add_argument('--num-ctx', type=int, default=4096)
    parser.add_argument('--num-thread', type=int, default=4)
    parser.add_argument('--num-gpu', type=int, default=0)
    parser.add_argument('--thinking', action='store_true')
    args = parser.parse_args()
    manager = Gemma4(ROOT)
    try:
        if args.disable:
            if args.install or args.activate:
                raise ValueError('Use --disable sozinho.')
            result = manager.disable('local-cli')
        elif args.status:
            result = manager.status()
        else:
            model = args.model or ('gemma4:e2b' if args.install else profile(ROOT)['model'])
            settings = {'model': model, 'num_ctx': args.num_ctx, 'num_thread': args.num_thread,
                        'num_gpu': args.num_gpu, 'thinking': args.thinking}
            if args.install:
                print('Baixando pesos oficiais no Ollama local. Esta etapa precisa de Internet.')
                last = [0., '']
                def progress(message):
                    if time.monotonic() - last[0] >= 1 or message == 'success':
                        print(message, flush=True); last[:] = [time.monotonic(), message]
                manager.install(model, progress)
            result = manager.activate(settings, 'local-cli') if args.activate else manager.diagnose(model, settings)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get('ok') else 2
    except (OSError, ValueError) as exc:
        print('[ERRO] ' + str(exc), file=sys.stderr)
        print('Abra o Ollama local. Se a arquitetura nao for reconhecida, atualize em https://ollama.com/download/windows.', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
