from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from services.hall_safety import HallSafetySupervisor


def main():
    ap=argparse.ArgumentParser(description="HAL Safety & Alignment V18 CLI")
    sub=ap.add_subparsers(dest="cmd",required=True)
    k=sub.add_parser("kill"); k.add_argument("--reason",default="Emergency stop"); k.add_argument("--actor",default="local_admin")
    r=sub.add_parser("resume"); r.add_argument("--actor",default="local_admin"); r.add_argument("--role",default="admin"); r.add_argument("--approved",action="store_true")
    s=sub.add_parser("status")
    q=sub.add_parser("quarantine"); q.add_argument("agent_id"); q.add_argument("--reason",default="Manual quarantine")
    rel=sub.add_parser("release"); rel.add_argument("agent_id"); rel.add_argument("--actor",default="local_admin"); rel.add_argument("--role",default="admin"); rel.add_argument("--approved",action="store_true")
    args=ap.parse_args()
    root=Path(__file__).resolve().parents[1]
    sup=HallSafetySupervisor(root)
    if args.cmd=="kill": out=sup.activate_kill_switch(args.reason,args.actor)
    elif args.cmd=="resume": out=sup.deactivate_kill_switch(args.actor,args.role,args.approved)
    elif args.cmd=="status": out=sup.status()
    elif args.cmd=="quarantine": out=sup.quarantine_agent(args.agent_id,args.reason,"local_admin","high")
    else: out=sup.release_agent(args.agent_id,args.actor,args.role,args.approved)
    print(json.dumps(out,ensure_ascii=False,indent=2,default=str))

if __name__=="__main__": main()
