from pathlib import Path
from voice_browser_v39 import Bridge
from voice_policy_v41 import preferences


class ConversationBridge(Bridge):
    def __init__(self,folder,port=8769,settings=None):
        super().__init__(folder,port)
        self.root=Path(__file__).parent/'voice_v41_web'
        self.audio_dir=Path(folder)/'tts_v41';self.audio_dir.mkdir(parents=True,exist_ok=True)
        self.info['preferences']={'pause_ms':1200,'tts_rate':0,**preferences(settings or {})}
        self.info['environment']='Aguardando fala';self.info['version']='41.0'

    def set_preferences(self,data):
        values=preferences(data)
        with self.lock:self.controls.put_nowait(('preferences',values))
