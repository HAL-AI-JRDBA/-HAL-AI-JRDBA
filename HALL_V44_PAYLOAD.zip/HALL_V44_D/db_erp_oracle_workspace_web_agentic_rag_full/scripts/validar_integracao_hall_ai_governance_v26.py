from __future__ import annotations
import json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

checks={}
def ok(name, cond):
    checks[name]=bool(cond)
    if not cond: raise AssertionError(name)

# Backend route surface (static inspection keeps this validator dependency-free)
source=(ROOT/'web_app/backend/main.py').read_text(encoding='utf-8')
required=[
'/api/ai-governance/status','/api/ai-governance/dashboard','/api/ai-governance/config',
'/api/ai-governance/registry/{kind}','/api/ai-governance/registry/{kind}/{item_id}',
'/api/ai-governance/prompt/assess','/api/ai-governance/policy/simulate','/api/ai-governance/gateway/evaluate',
'/api/ai-governance/telemetry/ingest','/api/ai-governance/telemetry/import','/api/ai-governance/telemetry',
'/api/ai-governance/approvals','/api/ai-governance/approvals/{approval_id}/decision',
'/api/ai-governance/incidents','/api/ai-governance/incidents/{incident_id}',
'/api/ai-governance/audit','/api/ai-governance/providers/{provider_id}/assessment','/api/ai-governance/report']
for path in required:
    ok('route_'+path.replace('/','_').replace('{','').replace('}',''), path in source)

# IAM: default deny + explicit admin rule
from services import identity_access
ok('iam_admin_rule', any(x[0]=='/api/ai-governance' and x[1]=='ai_governance' and x[2]=='admin' for x in identity_access.PLATFORM_PATH_RULES))

# Prompt flow is integrated, but exceptions never break internal chat.
source=(ROOT/'web_app/backend/main.py').read_text(encoding='utf-8')
ok('prompt_firewall_integrated','request.state.ai_governance = gov' in source)
ok('health_integrated',"'ai_governance_v26': _ensure_ai_governance().status()" in source)
ok('startup_integrated','_ensure_ai_governance()' in source[source.index("def _startup"):source.index("@app.get('/')")])
ok('module_catalog','"id": "ai_governance"' in source)
ok('external_web_guard','_ai_governance_external_guard(request, payload.message' in source)

html=(ROOT/'web_app/frontend/index.html').read_text(encoding='utf-8')
js=(ROOT/'web_app/frontend/unified_app.js').read_text(encoding='utf-8')
for marker in ['btnAdminGovernanceTab','adminGovernanceView','govSummary','govPrompt','govTelemetryUrl','govAppList','govApprovalList','govIncidentList','govVendorSelect','govRiskList']:
    ok('html_'+marker, marker in html)
for marker in ['govRefresh','govSimulate','govGateway','govIngest','govImport','govAddApp','govApproval','govCloseIncident','govAssessVendor','govAddRisk']:
    ok('js_'+marker, marker in js)
ok('cache_v26','unified_app.js?v=hall_v26' in html)
ok('admin_show_governance',"view==='governance'" in js and 'adminGovernanceView' in js)

# Seed/operational docs expected.
ok('service_exists',(ROOT/'services/ai_governance_v26.py').exists())
ok('unit_validator_exists',(ROOT/'scripts/validar_hall_ai_governance_v26.py').exists())

print(json.dumps({'ok':all(checks.values()),'passed':sum(checks.values()),'total':len(checks),'checks':checks},ensure_ascii=False,indent=2))
