from __future__ import annotations
import json, sys, tempfile, types
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
try:
    import oracledb  # noqa
except Exception:
    stub=types.ModuleType('oracledb'); stub.Connection=object; stub.Cursor=object
    stub.init_oracle_client=lambda **kwargs: None; stub.connect=lambda **kwargs: None; stub.makedsn=lambda *a,**k:'dsn'
    sys.modules['oracledb']=stub

from fastapi.testclient import TestClient
from services.identity_access import IdentityAccessService
from services.enterprise_web_access import EnterpriseWebAccessManager
import web_app.backend.main as webmain

checks=[]
def ck(name,cond,detail=''):
    checks.append({'test':name,'ok':bool(cond),'detail':detail})
    if not cond: raise AssertionError(f'{name}: {detail}')

class DummyConversation:
    def __init__(self): self.language=''
    def converse(self,*args,**kwargs):
        self.language=kwargs.get('language','')
        return {'ok':True,'answer':'Respuesta localizada','session_id':'v22','language':self.language}

dummy=DummyConversation()
with tempfile.TemporaryDirectory(prefix='hall-v22-http-') as td:
    t=Path(td)
    webmain.STATE.identity_access=IdentityAccessService(t/'iam')
    webmain.STATE.web_access=EnterpriseWebAccessManager(t,t/'web')
    webmain._human_conversation_service=lambda:dummy
    admin=TestClient(webmain.app,base_url='http://127.0.0.1:8000')

    r=admin.get('/api/auth/status')
    ck('public_language_catalog',r.status_code==200 and len(r.json().get('languages',[]))==5,r.text)
    r=admin.post('/api/auth/bootstrap',json={'username':'admin','password':'AdminSecure#2026','display_name':'Administrator','preferred_language':'en-US'})
    ck('bootstrap_english',r.status_code==200 and r.json().get('user',{}).get('preferred_language')=='en-US',r.text)
    r=admin.put('/api/auth/language',json={'preferred_language':'ja-JP'})
    ck('admin_changes_language',r.status_code==200 and r.json().get('user',{}).get('preferred_language')=='ja-JP',r.text)
    r=admin.get('/api/hall-iam/catalog')
    ck('admin_catalog_has_languages',r.status_code==200 and [x['code'] for x in r.json().get('languages',[])]==['pt-BR','en-US','es-ES','zh-CN','ja-JP'],r.text)
    r=admin.post('/api/hall-iam/users',json={
        'username':'maria','display_name':'Maria','password':'SecurePass#2026','preferred_language':'es-ES',
        'modules':['dashboard','modules','human_conversation_gateway'],'erp_modules':['Arrecadação'],
        'permissions':['view','chat'],'module_permissions':{}
    })
    ck('create_spanish_user',r.status_code==200 and r.json().get('user',{}).get('preferred_language')=='es-ES',r.text)

    user=TestClient(webmain.app,base_url='http://127.0.0.1:8000')
    r=user.post('/api/auth/login',json={'username':'maria','password':'SecurePass#2026'})
    ck('login_preserves_language',r.status_code==200 and r.json().get('user',{}).get('preferred_language')=='es-ES',r.text)
    r=user.post('/api/unified/human-conversation/converse',json={'message':'Analiza la recaudación de hoy'})
    ck('conversation_receives_user_language',r.status_code==200 and dummy.language=='es-ES' and r.json().get('language')=='es-ES',r.text)
    r=user.post('/api/unified/human-conversation/converse',json={'message':'Show me the payroll for this month'})
    ck('multilingual_rbac_denies_payroll',r.status_code==403 and 'Folha de Pagamento' in r.text,r.text)
    r=user.put('/api/auth/language',json={'preferred_language':'zh-CN'})
    ck('user_changes_to_mandarin',r.status_code==200 and r.json().get('user',{}).get('preferred_language')=='zh-CN',r.text)
    r=user.get('/api/auth/me')
    ck('language_persists_in_session',r.status_code==200 and r.json().get('user',{}).get('preferred_language')=='zh-CN',r.text)

out={'ok':all(x['ok'] for x in checks),'passed':sum(x['ok'] for x in checks),'total':len(checks),'tests':checks}
print(json.dumps(out,ensure_ascii=False,indent=2))
