"""Interruptible Windows companion. Headset required: no acoustic echo cancellation."""
import base64, queue, subprocess, threading, time
import hall_voice_presence_windows_v31_3 as base
from voice_turns_v38 import VoiceTurns
base.RUNTIME=base.DATA/"native_runtime_v38.json"
base.LOGFILE=base.DATA/"native_voice_v38.log"

class Speaker:
    def __init__(self,cfg=None):
        self.lock=threading.RLock();self.epoch=0;self.process=None
        self.q=queue.Queue();self.speaking=threading.Event()
        self.backend='windows_sapi';self.last_finished=0;self.last_error=''
        threading.Thread(target=self._run,daemon=True).start()
    def say(self,text):
        if text:
            with self.lock:self.q.put((self.epoch,text))
    def stop(self):
        with self.lock:
            self.epoch+=1
            if self.process and self.process.poll() is None:self.process.terminate()
            self.speaking.clear()
    def _run(self):
        while True:
            epoch,text=self.q.get()
            encoded=base64.b64encode(text.encode()).decode()
            script=("Add-Type -AssemblyName System.Speech;"+
                    "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"+
                    "$t=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+encoded+"'));"+
                    "$s.Speak($t);$s.Dispose();")
            proc=None
            try:
                with self.lock:
                    if epoch!=self.epoch:continue
                    proc=subprocess.Popen(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                    self.process=proc;self.speaking.set()
                proc.wait(timeout=180)
                if proc.returncode and epoch==self.epoch:raise RuntimeError('Windows SAPI não produziu áudio.')
            except Exception as exc:
                if proc and proc.poll() is None:proc.kill();proc.wait()
                self.last_error=str(exc);base._log('[TTS V38] '+str(exc))
            finally:
                with self.lock:
                    if self.process is proc:self.process=None;self.speaking.clear();self.last_finished=time.time()

class HallNativeVoice(base.HallNativeVoice):
    def __init__(self,cfg):
        base.Speaker=Speaker
        super().__init__(cfg)
        self.active=False
        self.turns=VoiceTurns(self._request_turn,self.speaker,self._cancel_turn)
        # Separate HTTP sessions prevent heartbeat/cancel from blocking generation.
        self._heartbeat(force=True)
    def _request_turn(self,sid,seq,text):
        session=self.requests.Session();session.cookies.update(self.http.cookies)
        endpoint='/api/v30/voice-screen/analyze' if base.is_voice_screen_command(text) else '/api/v38/conversation/turn'
        payload={'session_id':sid,'seq':seq,'message':text,'transcript':text,'source':getattr(self,'voice_source','windows_native_v38')}
        try:
            r=session.post(self.cfg['url']+endpoint,json=payload,timeout=300)
        finally:session.close()
        if r.status_code==401:
            return {'ok':False,'answer':'Minha sessão expirou. Reinicie o cliente de voz da HAL para entrar novamente.'}
        r.raise_for_status();return r.json()
    def _cancel_turn(self,sid,seq):
        s=self.requests.Session();s.cookies.update(self.http.cookies)
        try:
            r=s.post(self.cfg['url']+'/api/v38/conversation/cancel',json={'session_id':sid,'seq':seq},timeout=10)
            r.raise_for_status()
        finally:s.close()
    def _handle_text(self,text):
        lang=base.LANG.get(self.language,base.LANG['pt-BR'])
        sleep,_,_=base.phrase_match(text,self.sleep_phrases or lang['sleep'])
        wake,remainder,_=base.phrase_match(text,self.wake_phrases or lang['wake'])
        if sleep:
            self.active=False;self.turns.deactivate()
            base._runtime(active=False,status='standby',last_transcript=text)
        elif wake:
            self.active=True;self.turns.activate()
            if remainder:self.turns.submit(remainder)
            else:self.speaker.say(lang['on'])
            base._runtime(active=True,status='ready',last_transcript=text)
        elif self.active:
            self.turns.submit(text);base._runtime(active=True,last_transcript=text)
    def run(self):
        sr=int(self.cfg.get('sample_rate',16000));ms=int(self.cfg.get('block_ms',100))
        block=max(320,int(sr*ms/1000));threshold=float(self.cfg.get('vad_rms_threshold',.01))
        pause=max(3,int(int(self.cfg.get('conversation_silence_ms',900))/ms))
        min_voice=max(2,int(250/ms));max_blocks=max(20,int(60000/ms))
        speech=[];silence=voiced=0;interrupted=False
        base._log("[V38] Use fones com microfone. Diga HAL ativar / HAL desativar.")
        # Heartbeat has its own worker: a slow server cannot stop microphone capture.
        def heartbeat():
            while self.running:
                self._heartbeat();time.sleep(5)
        threading.Thread(target=heartbeat,daemon=True).start()
        with self.sd.InputStream(samplerate=sr,channels=1,dtype='float32',blocksize=block,callback=self._callback,device=self.input_device):
            while self.running:
                chunk=self.audio_q.get()
                voice=base.rms(self.np,chunk)>=threshold
                if voice or speech:
                    speech.append(chunk[:,0]);silence=0 if voice else silence+1
                    if voice:voiced+=1
                    # Stop ongoing speech and reject pending answers as soon as speech begins.
                    if self.active and voiced>=min_voice and not interrupted:
                        self.turns.interrupt();interrupted=True
                if speech and (silence>=pause or len(speech)>=max_blocks):
                    if voiced>=min_voice:
                        try:
                            text=self._transcribe(self.np.concatenate(speech).astype('float32'))
                            if text:base._log('[STT V38] '+text);self._handle_text(text)
                        except Exception as exc:base._log('[STT V38] '+str(exc))
                    speech=[];silence=voiced=0;interrupted=False

def main():
    try:HallNativeVoice(base.load_config()).run()
    except KeyboardInterrupt:return 0
    except Exception as exc:base._log('[V38 ERROR] '+str(exc));base._runtime(status='error',last_error=str(exc));return 2
    return 0
if __name__=='__main__':raise SystemExit(main())
