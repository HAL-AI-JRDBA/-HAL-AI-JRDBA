from __future__ import annotations
import json, py_compile, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
AGENTIC=ROOT/'hall_transporte_agentic_pro'
if str(AGENTIC) not in sys.path: sys.path.insert(0,str(AGENTIC))

checks=[]
def check(name, ok, detail=''):
    checks.append({'name':name,'ok':bool(ok),'detail':str(detail)})

for rel in [
    'services/conversation_intelligence_v29.py',
    'services/screen_assist_v29.py',
    'web_app/backend/main.py',
    'hall_transporte_agentic_pro/app/services/human_conversation_gateway.py',
]:
    try:
        py_compile.compile(str(ROOT/rel),doraise=True)
        check('python_compile:'+rel,True)
    except Exception as exc: check('python_compile:'+rel,False,exc)

try:
    from services import language_manager
    catalog=language_manager.language_catalog()
    check('languages_70_plus',len(catalog)>=70,f'{len(catalog)} languages')
    names=[x.get('label_english') or x.get('label') or x.get('name') for x in catalog]
    check('language_labels_english', all(bool(x) for x in names), f'{len(names)} labels')
except Exception as exc: check('languages',False,exc)

try:
    from services import conversation_intelligence_v29 as ci
    turns=[
      {'assistant':'Se quiser seguir, preciso que você me envie seu CPF ou CNPJ completo para continuar.'},
      {'assistant':'Vamos focar em resolver sua situação. Preciso que você me envie seu CPF ou CNPJ completo para seguir com o atendimento.'},
    ]
    r=ci.analyze_candidate('Burra ou burro','Entendi que você está insatisfeito, mas para seguir preciso que você me envie seu CPF ou CNPJ completo.',turns,'validation')
    check('parrot_semantic_detection',r.get('should_rewrite') is True,f"score={r.get('parrot_score')}")
    check('frustration_detection',(r.get('sentiment') or {}).get('state')=='frustrated',r.get('sentiment'))
    r2=ci.analyze_candidate('Repita por favor','O procedimento é reiniciar o serviço e verificar o log.',[{'assistant':'O procedimento é reiniciar o serviço e verificar o log.'}],'validation_repeat')
    check('explicit_repeat_allowed',r2.get('should_rewrite') is False and r2.get('user_requested_repeat') is True,r2)
except Exception as exc: check('conversation_intelligence',False,exc)

try:
    from services import screen_assist_v29 as screen
    st=screen.status()
    check('screen_assist_status',st.get('ok') is True,{'vision_ready':st.get('vision_ready'),'model':st.get('selected_vision_model')})
    cfg=st.get('config') or {}
    check('screen_explicit_permission',cfg.get('require_explicit_browser_permission') is True,cfg.get('require_explicit_browser_permission'))
    check('screen_ephemeral_default',cfg.get('retain_captures') is False,cfg.get('retain_captures'))
    check('screen_no_auto_actions',(cfg.get('privacy') or {}).get('do_not_execute_screen_actions_automatically') is True,(cfg.get('privacy') or {}))
    first=screen.analyze_capture('validation.jpg',b'\xff\xd8validation\xff\xd9','same question',session_id='validation_screen',source='validator')
    second=screen.analyze_capture('validation.jpg',b'\xff\xd8validation\xff\xd9','same question',session_id='validation_screen',source='validator')
    check('screen_duplicate_frame_skip',second.get('mode')=='unchanged',second.get('mode'))
except Exception as exc: check('screen_assist',False,exc)

for rel in ['web_app/frontend/index.html','web_app/frontend/unified_app.js']:
    text=(ROOT/rel).read_text(encoding='utf-8-sig')
    check('screen_ui:'+rel,'Screen Assist' in text or 'screenAssist' in text)

report={
  'product':'JR-AI / HAL V29 Conversation Intelligence + Screen Assist',
  'version':'29.0',
  'ok':all(c['ok'] for c in checks),
  'checks':checks,
  'notes':[
    'Full FastAPI startup still depends on the target Windows environment and installed database drivers.',
    'Screen analysis requires an installed local Ollama vision-capable model; screen sharing itself works without it.',
    'Screen captures are ephemeral by default and browser permission is mandatory.'
  ]
}
(ROOT.parent/'VALIDACAO_HALL_V29.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(0 if report['ok'] else 1)
