from __future__ import annotations
import json, sqlite3, sys, tempfile, types
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

from services.language_manager import language_catalog, normalize_language, response_instruction
from services.identity_access import IdentityAccessService

checks=[]
def ok(name,cond,detail=''):
    checks.append({'test':name,'ok':bool(cond),'detail':str(detail)})
    if not cond: raise AssertionError(f'{name}: {detail}')

codes=[x['code'] for x in language_catalog()]
ok('five_languages',codes==['pt-BR','en-US','es-ES','zh-CN','ja-JP'],codes)
ok('aliases',normalize_language('English')=='en-US' and normalize_language('mandarin')=='zh-CN' and normalize_language('日本語')=='ja-JP')
ok('prompt_instructions',all(response_instruction(x) for x in codes))

with tempfile.TemporaryDirectory() as td:
    td=Path(td); iam=IdentityAccessService(td)
    admin,_=iam.bootstrap_admin_with_session('admin','AdminSecure#2026','Admin','test','en-US')
    ok('bootstrap_language',admin['preferred_language']=='en-US',admin)
    u=iam.create_user({'username':'arruser','display_name':'Arrecadacao','password':'SecurePass#2026','preferred_language':'es-ES','modules':['dashboard','modules','human_conversation_gateway'],'erp_modules':['Arrecadação'],'permissions':['view','chat']})
    ok('create_user_language',u['preferred_language']=='es-ES',u)
    u=iam.set_preferred_language(u['id'],'ja-JP','arruser')
    ok('user_changes_own_language',u['preferred_language']=='ja-JP',u)
    ok('rbac_english_payroll',iam.infer_erp_module('Show me the payroll for this month')=='Folha de Pagamento')
    ok('rbac_chinese_accounting',iam.infer_erp_module('请显示会计总账')=='Contabilidade')
    ok('rbac_japanese_payroll',iam.infer_erp_module('今月の給与計算を表示して')=='Folha de Pagamento')
    ok('arrecadacao_denies_payroll',not iam.can_erp(u,'Folha de Pagamento'))

html=(ROOT/'web_app/frontend/index.html').read_text(encoding='utf-8')
js=(ROOT/'web_app/frontend/unified_app.js').read_text(encoding='utf-8')
ok('login_language_selector','id="hallAuthLanguage"' in html)
ok('top_language_selector','id="hallLanguageSelect"' in html)
ok('admin_language_selector','id="iamLanguage"' in html)
ok('frontend_five_languages',all(x in js for x in codes))
ok('stt_is_dynamic','hallSTTLang()' in js and "fd.append('language', hallWhisperLang())" in js)
ok('tts_is_dynamic','hallTTSLang()' in js)
ok('bootstrap_sends_language','preferred_language:hallCurrentLanguage' in js)

# Prompt-level validation without a real Ollama download.
sys.path.insert(0,str(ROOT/'hall_transporte_agentic_pro'))
from app.services import human_conversation_gateway as h
capt=[]
class Resp:
    def __enter__(self): return self
    def __exit__(self,*a): return False
    def read(self): return json.dumps({'response':'VALID'}).encode()
def fake(req,timeout=0):
    capt.append(json.loads(req.data.decode())['prompt']); return Resp()
h.urllib.request.urlopen=fake
needles={'pt-BR':'português do Brasil','en-US':'Answer in English','es-ES':'Responde en español','zh-CN':'简体中文','ja-JP':'日本語'}
for lang,needle in needles.items():
    s={'turns':[]}; h.call_local_llm('test',s,{'intent':'knowledge'},language=lang)
    ok('llm_prompt_'+lang,needle in capt[-1] and s.get('_llm_runtime',{}).get('language')==lang)

# Forced/legacy modules receive a final localization pass before UI/omnichannel delivery.
translation_ok=True
for lang,target in [('en-US','English'),('es-ES','Español'),('zh-CN','中文（简体）'),('ja-JP','日本語')]:
    out=h.translate_answer('Resposta técnica com SELECT * FROM GLOBUS.TABELA;',lang)
    translation_ok = translation_ok and out=='VALID' and target in capt[-1] and 'Preserve exatamente blocos de código' in capt[-1]
ok('forced_module_translation_layer',translation_ok)

print(json.dumps({'ok':True,'passed':sum(1 for x in checks if x['ok']),'total':len(checks),'tests':checks},ensure_ascii=False,indent=2))
