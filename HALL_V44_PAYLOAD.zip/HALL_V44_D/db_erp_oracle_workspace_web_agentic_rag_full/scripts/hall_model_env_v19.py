from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CFG = ROOT / 'hall_transporte_agentic_pro' / 'data' / 'multi_model_router' / 'config.json'
ENV = {
    'chat': 'HALL_MODEL_CHAT',
    'dialog': 'HALL_MODEL_DIALOG',
    'code': 'HALL_MODEL_CODE',
    'fast_code': 'HALL_MODEL_FAST_CODE',
    'deep_code': 'HALL_MODEL_DEEP_CODE',
    'sql': 'HALL_MODEL_SQL',
    'embed': 'HALL_MODEL_EMBED',
    'vision': 'HALL_MODEL_VISION',
    'fast': 'HALL_MODEL_FAST',
}
try:
    data=json.loads(CFG.read_text(encoding='utf-8-sig'))
except Exception:
    data={}
models=data.get('models') or {}
for role,var in ENV.items():
    val=str(models.get(role) or '').strip()
    if val:
        # saída deliberadamente no formato CMD para uso via FOR /F
        print(f'set "{var}={val}"')
chat=str(models.get('chat') or models.get('dialog') or '').strip()
if chat:
    print(f'set "HALL_OLLAMA_MODEL={chat}"')
    print(f'set "OLLAMA_MODEL={chat}"')
    print(f'set "HALL_DIALOG_MODEL={str(models.get("dialog") or chat)}"')
