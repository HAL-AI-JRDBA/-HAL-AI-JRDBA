"""Validate the immutable source inventory before the first Windows install."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[2]


def verify(root=ROOT):
    root = Path(root).resolve()
    manifest = json.loads((root / 'MANIFEST_RECONSTRUCAO_HALL_V42.json').read_text(encoding='utf-8-sig'))
    missing, altered = [], []
    for name, expected in manifest['source_sha256'].items():
        relative = PurePosixPath(name)
        if relative.is_absolute() or '..' in relative.parts or '\\' in name or ':' in name:
            raise ValueError('Caminho invalido no inventario de codigo.')
        path = root.joinpath(*relative.parts)
        if not path.resolve().is_relative_to(root):
            raise ValueError('O codigo aponta para fora de C:\\AI_HALL.')
        if not path.is_file():
            missing.append(name)
        elif hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            altered.append(name)
    if missing or altered:
        raise ValueError('Arquivos ausentes: ' + ', '.join(missing[:12]) + '\nArquivos alterados: ' + ', '.join(altered[:12]))
    print('[OK] Codigo completo conferido: ' + str(len(manifest['source_sha256'])) + ' arquivos.')
    return len(manifest['source_sha256'])


if __name__ == '__main__':
    try:
        verify()
    except Exception as exc:
        print('[ERRO] ' + str(exc))
        raise SystemExit(1)
