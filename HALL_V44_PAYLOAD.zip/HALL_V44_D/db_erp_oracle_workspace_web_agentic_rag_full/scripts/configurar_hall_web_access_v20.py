from __future__ import annotations
import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
from services.enterprise_web_access import EnterpriseWebAccessManager


def csv_lines(value: str):
    return [x.strip() for x in value.replace(',', '\n').splitlines() if x.strip()]


def main():
    ap=argparse.ArgumentParser(description='Configura URL corporativa da JR-AI/HAL V20')
    ap.add_argument('--mode', choices=['LOCAL','INTRANET','INTERNET'])
    ap.add_argument('--url')
    ap.add_argument('--tls', choices=['off','automatic','internal','custom'])
    ap.add_argument('--allowed-networks', default='')
    ap.add_argument('--non-interactive', action='store_true')
    args=ap.parse_args()
    mgr=EnterpriseWebAccessManager(ROOT, ROOT/'data'/'enterprise_web_access_v20')
    cfg=mgr.config()
    if args.non_interactive:
        mode=args.mode or cfg.get('mode','LOCAL')
        url=args.url or cfg.get('public_url','http://127.0.0.1:8000')
        tls=args.tls or cfg.get('tls_mode','off')
        nets=csv_lines(args.allowed_networks) or cfg.get('allowed_networks',[])
    else:
        print('\nHALL V20 - CONFIGURACAO DE URL CORPORATIVA')
        print('Modos: LOCAL, INTRANET, INTERNET')
        mode=(input(f"Modo [{cfg.get('mode','LOCAL')}]: ").strip().upper() or cfg.get('mode','LOCAL'))
        suggested='https://hall.suaempresa.com.br' if mode!='LOCAL' else 'http://127.0.0.1:8000'
        url=(input(f"URL publica [{cfg.get('public_url') or suggested}]: ").strip() or cfg.get('public_url') or suggested)
        default_tls='automatic' if mode=='INTERNET' else ('internal' if mode=='INTRANET' and url.startswith('https://') else 'off')
        tls=(input(f"TLS off/automatic/internal/custom [{default_tls}]: ").strip().lower() or default_tls)
        current=';'.join(cfg.get('allowed_networks') or [])
        raw=input(f"Redes permitidas CIDR separadas por virgula [{current}]: ").strip()
        nets=csv_lines(raw) if raw else cfg.get('allowed_networks',[])
    changes={
        'mode':mode,'public_url':url,'tls_mode':tls,
        'network_whitelist_enabled': mode=='INTRANET',
        'allowed_networks':nets,
        'trust_proxy_headers': mode!='LOCAL',
        'trusted_proxies':['127.0.0.1/32','::1/128'],
        'rate_limit_enabled':True,'rate_limit_per_minute':300,'auth_rate_limit_per_minute':30,
        'security_headers_enabled':True,'csrf_origin_check':True,'access_log_enabled':True,
        'hsts_enabled': mode=='INTERNET' and url.startswith('https://'),
    }
    saved=mgr.save_config(changes,'local_admin_cli')
    print('\n[OK] Configuracao salva.')
    print('Modo:',saved['mode'])
    print('URL :',saved['public_url'])
    print('TLS :',saved['tls_mode'])
    print('Caddyfile:',mgr.caddyfile_path)
    if saved['mode']=='INTERNET':
        print('\nIMPORTANTE: DNS deve apontar o dominio para este servidor e TCP 80/443 devem chegar ao Caddy.')
    elif saved['mode']=='INTRANET' and saved['tls_mode']=='internal':
        print('\nIMPORTANTE: distribua a CA raiz do Caddy aos computadores corporativos para evitar alerta de certificado.')
    print('Reinicie a HAL depois de alterar a configuracao.')

if __name__=='__main__': main()
