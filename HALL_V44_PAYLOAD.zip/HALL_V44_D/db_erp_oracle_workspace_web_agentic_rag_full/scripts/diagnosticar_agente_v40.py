"""Read local runtime/model metadata without sending prompts or printing secrets."""
from pathlib import Path
import json
import sqlite3
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from services.autonomy_tools_v36 import Tools

def main():
    for title, url in [('Backend', 'http://127.0.0.1:8000/api/health'), ('V40', 'http://127.0.0.1:8000/api/v40/runtime-status')]:
        try:
            data = Tools.local_json(url, timeout=5)
            print(title + ': ' + ('OK' if data.get('ok', data.get('status') == 'ok') else 'verificar') + ' ' + str(data.get('version', '')))
        except Exception as exc:
            print(title + ': indisponivel (' + str(exc)[:180] + ')')
    config_path = ROOT/'data/autonomy_v36/config.json'
    if config_path.exists():
        cfg = json.loads(config_path.read_text(encoding='utf-8-sig'))
        model = cfg.get('model', '')
        print('Modelo configurado: ' + model)
        try:
            info = Tools.local_json(cfg.get('ollama_url', 'http://127.0.0.1:11435').rstrip('/') + '/api/show', {'model': model}, timeout=10)
            remote = bool(info.get('remote_host') or info.get('remote_model') or ':cloud' in model.lower() or model.lower().endswith('-cloud'))
            print('Origem do modelo: ' + ('REMOTA - recusada pelo agente V40' if remote else 'local, segundo metadados Ollama'))
        except Exception as exc:
            print('Modelo nao confirmado: ' + str(exc)[:180])
    db_path = ROOT/'data/autonomy_v36/runtime.sqlite3'
    if db_path.exists():
        c = sqlite3.connect(db_path.as_uri()+'?mode=ro', uri=True)
        print('Estados das missoes: ' + json.dumps(dict(c.execute('SELECT state,count(*) FROM tasks GROUP BY state')), ensure_ascii=False))
        print('Novas acoes pausadas: ' + c.execute("SELECT value FROM control WHERE key='paused'").fetchone()[0])
        c.close()
    print('Este diagnostico nao executa missoes e nao valida a qualidade do modelo nem o microfone.')

if __name__ == '__main__':
    main()
