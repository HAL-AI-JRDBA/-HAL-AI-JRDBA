from __future__ import annotations
import json, tempfile, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from services.ai_governance_v26 import AIGovernanceManager

checks={}
def ok(name, cond):
    checks[name]=bool(cond)
    if not cond: raise AssertionError(name)

with tempfile.TemporaryDirectory(prefix='hall_v26_') as td:
    mgr=AIGovernanceManager(ROOT, Path(td))
    st=mgr.status()
    ok('status_v26',st['version']=='V26' and st['enabled'])
    for comp in ['shadow_ai_discovery','ai_inventory','enterprise_ai_gateway','prompt_firewall','dlp','data_classification','risk_engine','policy_engine','approvals','incident_response','audit_trail','policy_simulator','telemetry_ingest']:
        ok('component_'+comp, st['components'].get(comp) is True)

    apps=mgr.registry('applications')
    ok('hall_approved', any(a['id']=='hall' and a['status']=='approved' and not a['external'] for a in apps))
    ok('chatgpt_catalog', any(a['id']=='chatgpt' and 'chatgpt.com' in a['domains'] for a in apps))
    ok('claude_catalog', any(a['id']=='claude' for a in apps))
    ok('gemini_catalog', any(a['id']=='gemini' for a in apps))
    ok('copilot_catalog', any(a['id']=='copilot' for a in apps))
    ok('connectors_seeded', len(mgr.registry('connectors'))>=6)
    va=mgr.vendor_assessment('hall-local')
    ok('vendor_assessment_local', va['score']>=85 and va['grade']=='A')
    ok('risk_intel_registry', isinstance(mgr.registry('risk_intel'), list))

    # DLP / classification
    d=mgr.dlp_scan('CPF 529.982.247-25')
    ok('dlp_cpf', 'cpf' in d['finding_types'] and d['data_class']=='confidential')
    d=mgr.dlp_scan('CNPJ 04.252.011/0001-10')
    ok('dlp_cnpj', 'cnpj' in d['finding_types'])
    d=mgr.dlp_scan('contato financeiro@empresa.com')
    ok('dlp_email', 'email' in d['finding_types'])
    d=mgr.dlp_scan('Authorization: Bearer abcdefghijklmnopqrstuvwxyz123456')
    ok('dlp_bearer', 'bearer_token' in d['finding_types'] and d['contains_secret'])
    d=mgr.dlp_scan('AWS AKIAABCDEFGHIJKLMNOP')
    ok('dlp_aws', 'aws_access_key' in d['finding_types'])
    d=mgr.dlp_scan('password=SuperSecreta123')
    ok('dlp_password', 'generic_secret' in d['finding_types'])
    d=mgr.dlp_scan('postgresql://user:SenhaSecreta@db:5432/base')
    ok('dlp_connection_string', 'oracle_connect' in d['finding_types'])
    d=mgr.dlp_scan('-----BEGIN PRIVATE KEY-----\nabc')
    ok('dlp_private_key', 'private_key' in d['finding_types'])
    d=mgr.dlp_scan('cartao 4111 1111 1111 1111')
    ok('dlp_credit_card', 'credit_card' in d['finding_types'])
    d=mgr.dlp_scan('folha de pagamento dos funcionarios')
    ok('classification_payroll_restricted', d['data_class']=='restricted')
    d=mgr.dlp_scan('contrato confidencial do cliente XPTO')
    ok('classification_contract_confidential', d['data_class'] in {'confidential','restricted'})
    ok('redaction_present', '[REDACTED:' in mgr.dlp_scan('password=SuperSecreta123')['redacted_text'])

    # Internal HAL must keep sensitive data local and controlled.
    r=mgr.evaluate_prompt('folha de pagamento CPF 529.982.247-25',app_id='hall',provider_id='hall-local',external=False,persist=True,actor='rh')
    ok('hall_sensitive_not_external', r['local_only'] is True)
    ok('hall_sensitive_allowed_controls', r['decision'] in {'allow','allow_with_controls'} and r['allowed'])

    # External policy cases
    r=mgr.evaluate_prompt('folha de pagamento CPF 529.982.247-25',app_id='chatgpt',provider_id='openai',external=True,account_type='personal',action='upload')
    ok('external_restricted_block', r['decision']=='block' and not r['allowed'])
    ok('external_restricted_high_risk', r['risk_score']>=80 and r['risk_level']=='critical')
    r=mgr.evaluate_prompt('contrato do cliente para revisar',app_id='claude',provider_id='anthropic',external=True,account_type='corporate')
    ok('external_confidential_approval', r['decision']=='approval' and r['approval_required'])
    r=mgr.evaluate_prompt('qual a capital do japao?',app_id='chatgpt',provider_id='openai',external=True,account_type='corporate')
    ok('external_public_conditional_allowed', r['decision'] in {'allow','allow_with_controls'})
    r=mgr.evaluate_prompt('pesquisa pública',app_id='nao-cadastrada',provider_id='desconhecido',external=True,account_type='corporate')
    ok('unknown_external_approval', r['decision']=='approval')
    r=mgr.evaluate_prompt('password=SuperSecreta123',app_id='chatgpt',provider_id='openai',external=True)
    ok('secret_external_block', r['decision']=='block')

    # Gateway approval and incident
    before_ap=len(mgr.list_approvals())
    g=mgr.gateway_decision({'prompt':'contrato do cliente','app_id':'claude','provider_id':'anthropic','external':True,'account_type':'corporate'},actor='junior')
    ok('gateway_approval_route',g['route']=='approval_queue' and bool(g.get('approval_id')))
    ok('gateway_approval_created',len(mgr.list_approvals())==before_ap+1)
    before_inc=len(mgr.list_incidents())
    g=mgr.gateway_decision({'prompt':'password=SuperSecreta123','app_id':'chatgpt','provider_id':'openai','external':True,'account_type':'personal'},actor='junior')
    ok('gateway_block_route',g['route']=='blocked')
    ok('gateway_incident_created',len(mgr.list_incidents())==before_inc+1)

    # Approval decision
    pending=mgr.list_approvals('pending')
    ok('pending_approval_exists',bool(pending))
    dec=mgr.decide_approval(pending[0]['id'],True,'admin','caso aprovado')
    ok('approval_decision',dec['status']=='approved' and dec['reviewer']=='admin')

    # Telemetry / shadow AI
    ev=mgr.ingest_telemetry([{
        'user':'maria','department':'RH','url':'https://chatgpt.com/c/123','account_type':'personal',
        'action':'upload','data_class':'restricted','source':'proxy'
    }],source='proxy',actor='collector')
    ok('telemetry_ingested',ev['ingested']==1)
    e=ev['events'][0]
    ok('shadow_ai_detected',e['shadow_ai'] is True and e['app_id']=='chatgpt')
    ok('shadow_ai_critical',e['risk_level']=='critical')
    ok('shadow_ai_blocked',e['decision']=='block')
    ok('shadow_ai_replacement_hall',e['replacement']=='HAL')
    ok('shadow_incident_created',ev['incidents_created']>=1)

    ev2=mgr.ingest_telemetry([{'user':'joao','department':'TI','url':'https://hall.empresa.local','app_id':'hall','account_type':'corporate','action':'prompt','data_class':'internal'}],source='browser',actor='collector')
    ok('hall_not_shadow',ev2['events'][0]['shadow_ai'] is False)

    # Batch imports
    imp=mgr.ingest_text('{"user":"ana","url":"https://claude.ai","account_type":"personal","action":"access","data_class":"internal"}\n','jsonl','siem','admin')
    ok('jsonl_import',imp['ingested']==1)
    imp=mgr.ingest_text('user,url,account_type,action,data_class\nluiz,https://gemini.google.com,corporate,access,public\n','csv','proxy','admin')
    ok('csv_import',imp['ingested']==1)

    # Dashboard
    dash=mgr.dashboard()
    ok('dashboard_shadow_count',dash['summary']['shadow_ai_events']>=2)
    ok('dashboard_open_incidents',dash['summary']['open_incidents']>=1)
    ok('dashboard_top_apps',len(dash['top_shadow_apps'])>=1)
    ok('dashboard_connectors',dash['connectors']['configured']>=6)

    # Registry CRUD
    app=mgr.upsert_registry('applications',{'id':'corp-ai','name':'Corp AI','status':'approved','external':False,'domains':['ai.corp.local']},'admin')
    ok('registry_upsert',app['id']=='corp-ai')
    ok('registry_resolve_domain',mgr.resolve_shadow_app({'url':'https://ai.corp.local/chat'})[0]['id']=='corp-ai')
    ok('registry_delete',mgr.delete_registry('applications','corp-ai','admin') is True)

    # Connectors configurable
    conn=mgr.registry('connectors')[0]
    conn['enabled']=True
    mgr.upsert_registry('connectors',conn,'admin')
    ok('connector_enable',any(x['id']==conn['id'] and x['enabled'] for x in mgr.registry('connectors')))

    # Incident response
    inc=mgr.list_incidents()[0]
    upd=mgr.update_incident(inc['id'],{'status':'resolved','owner':'SOC','resolution':'Usuário orientado e upload bloqueado'},'admin')
    ok('incident_resolved',upd['status']=='resolved' and upd['owner']=='SOC')

    # Simulator must not create approval/incident
    ap_count=len(mgr.list_approvals()); inc_count=len(mgr.list_incidents())
    sim=mgr.simulate({'prompt':'contrato do cliente','app_id':'claude','provider_id':'anthropic','external':True})
    ok('simulator_decision',sim['decision']=='approval')
    ok('simulator_no_side_effect_approval',len(mgr.list_approvals())==ap_count)
    ok('simulator_no_side_effect_incident',len(mgr.list_incidents())==inc_count)

    # Audit must not persist raw prompt secrets.
    mgr.evaluate_prompt('password=NaoPodeAparecerNoAudit123',app_id='hall',provider_id='hall-local',external=False,persist=True,actor='auditor')
    audit_raw=(Path(td)/'audit.jsonl').read_text(encoding='utf-8')
    ok('audit_no_raw_password', 'NaoPodeAparecerNoAudit123' not in audit_raw)
    ok('audit_has_prompt_hash', 'prompt_sha256' in audit_raw)

    rep=mgr.report()
    ok('report_complete',rep['title'].startswith('HAL V26') and 'applications' in rep and 'open_incidents' in rep)
    ok('report_risk_intel','risk_intel' in rep)

print(json.dumps({'ok':all(checks.values()),'passed':sum(checks.values()),'total':len(checks),'checks':checks},ensure_ascii=False,indent=2))
