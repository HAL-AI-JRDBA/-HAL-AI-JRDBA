from voice_identity_v39 import VoiceIdentity
from voice_policy_v41 import classify_scores


class ConsistentVoice(VoiceIdentity):
    def analyse(self,audio):
        np=self.np
        with self.lock:
            x=np.asarray(audio,dtype=np.float32)
            if self.vector is None:return {'label':'unregistered','score':0,'windows':0}
            if len(x)<9600:return {'label':'short','score':0,'windows':0}
            if len(x)>720000 or not np.all(np.isfinite(x)) or np.mean(np.abs(x)>=.99)>.04:
                return {'label':'uncertain','score':0,'windows':0}
            try:
                x=self.preprocess(x,source_sr=16000)
                if len(x)<8000:return {'label':'short','score':0,'windows':0}
                whole,parts,_=self.encoder.embed_utterance(x,return_partials=True,rate=1.3,min_coverage=.6)
                whole=np.asarray(whole,dtype=np.float32);parts=np.asarray(parts,dtype=np.float32)
                if whole.shape!=(256,) or parts.ndim!=2 or parts.shape[1]!=256 or not 1<=len(parts)<=100:
                    raise ValueError('Janelas de identificação inválidas.')
                if not np.all(np.isfinite(whole)) or not np.all(np.isfinite(parts)):raise ValueError('Identificação inválida.')
                norms=np.linalg.norm(parts,axis=1)
                if np.any(norms<.1) or np.linalg.norm(whole)<.1:raise ValueError('Pouca informação vocal.')
                scores=(parts/norms[:,None])@self.vector
                overall=float(np.dot(whole/np.linalg.norm(whole),self.vector))
                return {'label':classify_scores(scores.tolist(),overall,self.threshold),'score':round(overall,4),'windows':len(parts),'minimum':float(min(scores))}
            except ValueError:return {'label':'uncertain','score':0,'windows':0}
