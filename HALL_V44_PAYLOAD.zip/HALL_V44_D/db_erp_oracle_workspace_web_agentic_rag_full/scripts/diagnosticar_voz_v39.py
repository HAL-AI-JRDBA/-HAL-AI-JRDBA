"""Dependency/model-load checks; does not claim acoustic recognition accuracy."""
import importlib,json,os,sys
from pathlib import Path
def main():
    result={'python':sys.version,'windows':os.name=='nt','checks':{},'microphone_tested':False,'echo_tested':False,'speaker_accuracy_tested':False}
    try:
        for name in ['numpy','scipy','librosa','webrtcvad','torch','resemblyzer','faster_whisper','keyring','requests']:
            mod=importlib.import_module(name);result['checks'][name]=getattr(mod,'__version__','import ok')
        from resemblyzer import VoiceEncoder
        import numpy as np,torch
        torch.set_num_threads(2)
        encoder=VoiceEncoder(device='cpu')
        vector=encoder.embed_utterance(np.zeros(16000,dtype=np.float32))
        assert vector.shape==(256,) and np.all(np.isfinite(vector))
        result['checks']['voice_encoder_weights']='loaded; synthetic forward ok'
        if os.name=='nt':
            from voice_identity_v39 import dpapi
            sample=b'HAL voice profile self-test'
            assert dpapi(dpapi(sample),True)==sample
            result['checks']['windows_dpapi']='roundtrip ok'
        result['ok']=True
    except Exception as exc:result['ok']=False;result['error']=str(exc)
    folder=Path(__file__).resolve().parents[1]/'data/voice_presence_v23';folder.mkdir(parents=True,exist_ok=True)
    (folder/'diagnostico_v39.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2));return 0 if result['ok'] else 2
if __name__=='__main__':raise SystemExit(main())
