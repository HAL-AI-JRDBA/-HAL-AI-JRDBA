from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

checks = {}
def ok(name, cond):
    checks[name] = bool(cond)
    if not cond:
        raise AssertionError(name)

# Static integration surface. This validator intentionally avoids opening a real
# camera/browser/network connection; operational dependencies are validated by
# the installer on the target Windows host.
backend = (ROOT / "web_app/backend/main.py").read_text(encoding="utf-8")
identity = (ROOT / "services/identity_access.py").read_text(encoding="utf-8")
runtime = (ROOT / "services/openclaw_runtime/runtime.py").read_text(encoding="utf-8")
skills = (ROOT / "services/openclaw_runtime/skill_manager.py").read_text(encoding="utf-8")
browser = (ROOT / "hall_transporte_agentic_pro/app/services/browser_automation.py").read_text(encoding="utf-8")
desktop = (ROOT / "desktop_agent/hall_desktop_agent.py").read_text(encoding="utf-8")
html = (ROOT / "web_app/frontend/index.html").read_text(encoding="utf-8")
js = (ROOT / "web_app/frontend/unified_app.js").read_text(encoding="utf-8")

routes = [
    "/api/openclaw-runtime/plan",
    "/api/openclaw-runtime/skills",
    "/api/openclaw-runtime/skills/import-markdown",
    "/api/openclaw-runtime/memory",
    "/api/openclaw-runtime/memory/search",
    "/api/openclaw-runtime/agent-bus/send",
    "/api/openclaw-runtime/agent-bus/messages",
    "/api/openclaw-runtime/supervisor/start",
    "/api/openclaw-runtime/supervisor/stop",
    "/api/openclaw-runtime/supervisor/status",
    "/api/unified/browser-automation/session/{session_id}/close",
    "/api/unified/continuous-vision/start",
    "/api/unified/continuous-vision/analyze",
    "/api/unified/continuous-vision/stop",
    "/api/unified/ha/status",
    "/api/unified/ha/docker-status",
]
for route in routes:
    ok("route_" + route.replace("/", "_"), route in backend)

ok("runtime_dynamic_planner", "DynamicPlanner" in runtime and "self.planner.replan" in runtime)
ok("runtime_persistent_memory", "AgentMemoryV261" in runtime and "self.memory.context" in runtime)
ok("runtime_agent_bus", "AgentBusV261" in runtime)
ok("runtime_supervisor", "AutonomousSupervisorV261" in runtime and "HALL_OPENCLAW_AUTORUN" in runtime)
ok("runtime_declarative", "DeclarativeSkillExecutor" in runtime)
ok("skill_browser", "browser_open" in skills and "browser_submit" in skills)
ok("skill_vision", "continuous_vision_start" in skills and "continuous_vision_analyze" in skills)
ok("skill_agent_bus", "agent_send" in skills and "agent_inbox" in skills)
ok("browser_real_playwright", "sync_playwright" in browser and "launch_persistent_context" in browser and "page.goto" in browser)
ok("browser_approval", "approval_required_before_submit" in browser and "waiting_approval" in browser)
ok("browser_no_host_shell", '"host_shell_access": False' in browser and '"desktop_control": False' in browser)
ok("desktop_unrestricted_blocked", '"unrestricted_windows_access": False' in desktop)
ok("desktop_run_hotkey_blocked", '("win", "r")' in desktop)
ok("iam_vision", '"/api/unified/continuous-vision"' in identity)
ok("iam_ha", '"/api/unified/ha"' in identity)
ok("ui_planner", "Dynamic Planner & Replanner V26.1" in html)
ok("ui_declarative", "Declarative Skills Runtime V26.1" in html)
ok("ui_vision", "Continuous Vision V26.1" in html)
ok("ui_ha", "HA / VPS V26.1" in html)
ok("frontend_browser_real", "browserOpenReal" in js and "browserReadReal" in js)
ok("frontend_vision", "continuousVisionAnalyze" in js)
ok("frontend_ha", "haDockerStatus" in js)
ok("cache_buster", ("hall_v26_1_openclaw_completion" in html) or ("hall_v26_2_autonomous_software_studio" in html))
ok("installer_exists", (ROOT.parent / "INSTALAR_HALL_OPENCLAW_COMPLETION_V26_1.bat").exists())
ok("ha_start_bat", (ROOT.parent / "INICIAR_HALL_HA_V26_1.bat").exists())
ok("ha_stop_bat", (ROOT.parent / "PARAR_HALL_HA_V26_1.bat").exists())

# A capability is counted as complete only when implementation + UI/API +
# safety boundary exist. Runtime dependencies are installed separately.
coverage = {
    "browser_automation_real": checks["browser_real_playwright"] and checks["frontend_browser_real"],
    "dynamic_planning_replanning": checks["runtime_dynamic_planner"] and checks["ui_planner"],
    "declarative_skills": checks["runtime_declarative"] and checks["ui_declarative"],
    "continuous_video_context": checks["skill_vision"] and checks["ui_vision"],
    "persistent_multi_scope_memory": checks["runtime_persistent_memory"],
    "autonomous_background_execution": checks["runtime_supervisor"],
    "agent_to_agent_messaging": checks["runtime_agent_bus"] and checks["skill_agent_bus"],
    "ha_vps_profile": checks["ui_ha"] and checks["ha_start_bat"],
    "unrestricted_windows_blocked": checks["desktop_unrestricted_blocked"] and checks["desktop_run_hotkey_blocked"] and checks["browser_no_host_shell"],
}
for k, v in coverage.items():
    ok("coverage_" + k, v)

print(json.dumps({"ok": all(checks.values()), "passed": sum(checks.values()), "total": len(checks), "coverage": coverage, "checks": checks}, ensure_ascii=False, indent=2))
