"""Keep this installation's model weights and child-process caches below HAL.

Explicit migration only; no network requests, no deletion of source files.
Ollama must be stopped before importing its model store.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile

PROJECT = Path(__file__).resolve().parents[1]
DIGEST = re.compile(r'^sha256:([a-f0-9]{64})$')


def storage_paths(hall_home=None):
    home = Path(hall_home or PROJECT.parent).resolve()
    return {name: home / relative for name, relative in {
        'ollama': 'models/ollama', 'whisper': 'models/whisper',
        'hf_home': 'models/huggingface', 'torch': 'models/torch',
        'transformers': 'models/transformers', 'cache': 'cache',
        'pip': 'cache/pip', 'tmp': 'cache/tmp',
    }.items()}


def whisper_cache():
    path = storage_paths()['whisper']
    path.mkdir(parents=True, exist_ok=True)
    return str(path)


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _contained(path, root):
    if not path.resolve().is_relative_to(root.resolve()):
        raise ValueError('Link aponta para fora da pasta de modelos: ' + str(path))


def _plan_file(source, target, link=False, digest=None, allowed_root=None):
    source, target = Path(source), Path(target)
    if allowed_root is not None:
        _contained(source, Path(allowed_root))
    if not source.is_file():
        raise ValueError('Arquivo de modelo ausente: ' + str(source))
    if digest is not None and file_hash(source) != digest:
        raise ValueError('Peso incompleto ou hash incorreto: ' + str(source))
    if target.exists() or target.is_symlink():
        if not target.is_file() or (not os.path.samefile(source, target)
                                  and file_hash(source) != file_hash(target)):
            raise ValueError('Destino possui arquivo diferente; nada sera sobrescrito: ' + str(target))
        return None
    return (source, target, link)


def _apply(plan):
    result = {'hardlinks': 0, 'copied': 0, 'copied_bytes': 0}
    for source, target, link in plan:
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            _plan_file(source, target)
            continue
        handle, temporary = tempfile.mkstemp(prefix='.hall-import-', dir=target.parent)
        os.close(handle)
        temporary = Path(temporary)
        try:
            temporary.unlink()
            linked = False
            if link:
                try:
                    os.link(source.resolve(), temporary)
                    linked = True
                except OSError:
                    pass
            if not linked:
                size = source.stat().st_size
                if shutil.disk_usage(target.parent).free < size + 64 * 1024 * 1024:
                    raise OSError('Espaco insuficiente para copiar o modelo: ' + str(target))
                shutil.copy2(source, temporary)
                if file_hash(source) != file_hash(temporary):
                    raise OSError('Falha na verificacao da copia: ' + str(target))
            if target.exists():
                _plan_file(source, target)
            else:
                os.replace(temporary, target)
                result['hardlinks' if linked else 'copied'] += 1
                if not linked:
                    result['copied_bytes'] += source.stat().st_size
        finally:
            temporary.unlink(missing_ok=True)
    return result


def import_ollama(sources, destination):
    """Check all stores first, then publish blobs before their manifests.

    Immutable, digest-checked blobs can share disk blocks through hard links.
    Manifests are always independent copies. Source stores remain usable.
    """
    destination = Path(destination).resolve()
    blobs, manifests, planned = [], [], {}
    tags = 0
    for source in dict.fromkeys(Path(s).expanduser().resolve() for s in sources):
        if source == destination or not (source / 'manifests').exists():
            continue
        for manifest in sorted((source / 'manifests').rglob('*')):
            if not manifest.is_file():
                continue
            _contained(manifest, source)
            relative = manifest.relative_to(source)
            if manifest.is_symlink():
                raise ValueError('Manifesto com link nao suportado: ' + str(manifest))
            data = json.loads(manifest.read_text(encoding='utf-8-sig'))
            layers = [data['config'], *data['layers']]
            references = []
            for layer in layers:
                match = DIGEST.fullmatch(str(layer.get('digest', '')))
                if not match:
                    raise ValueError('Digest invalido no manifesto: ' + str(manifest))
                blob = source / 'blobs' / ('sha256-' + match[1])
                if not blob.is_file() or blob.stat().st_size != int(layer['size']):
                    raise ValueError('Peso ausente ou tamanho incorreto: ' + str(blob))
                references.append((blob, Path('blobs') / blob.name, True, match[1]))
            references.append((manifest, relative, False, None))
            for old, rel, link, digest in references:
                target = destination / rel
                _contained(target, destination)
                if rel in planned:
                    if file_hash(old) != file_hash(planned[rel]):
                        raise ValueError('Fontes contem versoes diferentes do mesmo arquivo: ' + str(rel))
                    continue
                entry = _plan_file(old, target, link, digest, source)
                planned[rel] = old
                if entry:
                    (blobs if link else manifests).append(entry)
            tags += 1
    result = _apply(blobs + manifests)
    result['tags_checked'] = tags
    return result


def import_whisper(sources, destination):
    """Import only faster-whisper repositories, never HF tokens or user files."""
    destination = Path(destination).resolve()
    plan, planned = [], {}
    for source in dict.fromkeys(Path(s).expanduser().resolve() for s in sources):
        if source == destination or not source.is_dir():
            continue
        for repo in sorted(source.glob('models--Systran--faster-whisper-*')):
            if not repo.is_dir() or repo.is_symlink():
                continue
            for old in sorted(repo.rglob('*')):
                if not old.is_file():
                    continue
                rel = old.relative_to(source)
                if any(part.startswith('.') for part in rel.parts):
                    continue
                target = destination / rel
                _contained(target, destination)
                _contained(old, repo)
                if rel in planned:
                    if file_hash(old) != file_hash(planned[rel]):
                        raise ValueError('Caches Whisper diferentes para o mesmo arquivo: ' + str(rel))
                    continue
                # Resolve snapshot symlinks inside the repository; the new store
                # works on Windows without symlink creation privileges.
                entry = _plan_file(old, target, 'refs' not in rel.parts, allowed_root=repo)
                planned[rel] = old
                if entry:
                    plan.append(entry)
    return _apply(plan)


@contextmanager
def migration_lock(home):
    folder = Path(home) / 'cache'
    folder.mkdir(parents=True, exist_ok=True)
    with (folder / 'storage_v42.lock').open('a+b') as stream:
        stream.seek(0)
        if stream.read(1) == b'':
            stream.write(b'0'); stream.flush()
        stream.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            if os.name == 'nt':
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def default_hub_sources():
    sources = [Path.home() / '.cache' / 'huggingface' / 'hub']
    if os.environ.get('XDG_CACHE_HOME'):
        sources.append(Path(os.environ['XDG_CACHE_HOME']) / 'huggingface' / 'hub')
    for key in ('HF_HUB_CACHE', 'HUGGINGFACE_HUB_CACHE', 'TRANSFORMERS_CACHE'):
        if os.environ.get(key):
            sources.append(Path(os.environ[key]))
    if os.environ.get('HF_HOME'):
        sources.append(Path(os.environ['HF_HOME']) / 'hub')
    return sources


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ollama-source', action='append', default=[])
    parser.add_argument('--hub-source', action='append', default=[])
    parser.add_argument('--whisper-only', action='store_true')
    args = parser.parse_args(argv)
    paths = storage_paths()
    with migration_lock(PROJECT.parent):
        for path in paths.values():
            _contained(path, PROJECT.parent)
            path.mkdir(parents=True, exist_ok=True)
        report = {'paths': {k: str(v) for k, v in paths.items()}}
        if not args.whisper_only:
            sources = [Path.home() / '.ollama' / 'models', *args.ollama_source]
            if os.environ.get('OLLAMA_MODELS'):
                sources.append(Path(os.environ['OLLAMA_MODELS']))
            report['ollama'] = import_ollama(sources, paths['ollama'])
        report['whisper'] = import_whisper([*default_hub_sources(), *args.hub_source], paths['whisper'])
        folder = PROJECT / 'data' / 'storage_v42'
        folder.mkdir(parents=True, exist_ok=True)
        (folder / 'last_import.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError) as exc:
        print('Armazenamento HAL: ' + str(exc), file=sys.stderr)
        raise SystemExit(2)
