"""Live readiness check. It does not send messages, read mail or operate desktop."""
import importlib.util,json,shutil,subprocess,sys,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from services.autonomy_tools_v36 import Tools

def run():
 tools=Tools(ROOT);cfg=tools.config();result={'capabilities':tools.readiness(),'checks':{},'note':'Diagnóstico não equivale a teste completo de uma missão nem valida serviços externos.'}
 try:
  models=tools.local_json(cfg['ollama_url'].rstrip('/')+'/api/tags',timeout=10).get('models',[])
  names={m.get('name') for m in models};result['checks']['ollama']={'ok':cfg['model'] in names and cfg['code_model'] in names,'configured_models_present':{cfg[k]:cfg[k] in names for k in ('model','code_model')}}
 except Exception as exc:result['checks']['ollama']={'ok':False,'error':str(exc)[:300]}
 if shutil.which('docker'):
  try:
   r=subprocess.run(['docker','run','--rm','--pull','never','--network','none','--memory','128m','--cpus','1','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges',cfg['docker_image'],'python','-c','print("HALL_SANDBOX_READY")'],capture_output=True,text=True,timeout=30)
   result['checks']['sandbox']={'ok':r.returncode==0 and 'HALL_SANDBOX_READY' in r.stdout,'exit_code':r.returncode}
  except Exception as exc:result['checks']['sandbox']={'ok':False,'error':str(exc)[:300]}
 else:result['checks']['sandbox']={'ok':False,'error':'Docker não instalado.'}
 out=ROOT/'data'/'autonomy_v36'/'diagnostico_local.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(result,ensure_ascii=False,indent=2));print('Relatório:',out)
 return 0 if all(x.get('ok') for x in result['checks'].values()) else 2
if __name__=='__main__':sys.exit(run())
