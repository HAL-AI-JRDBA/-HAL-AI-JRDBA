from __future__ import annotations

import importlib.util
import json
import os
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
TRANSPORT_ROOT = ROOT / "hall_transporte_agentic_pro"
if str(TRANSPORT_ROOT) not in sys.path:
    sys.path.insert(0, str(TRANSPORT_ROOT))

checks: dict[str, bool] = {}

def ok(name: str, cond: bool) -> None:
    checks[name] = bool(cond)
    if not cond:
        raise AssertionError(name)

# ---------------------------------------------------------------------------
# 1) Dynamic planner: LLM selects only allowlisted skills and never expands
#    privileges when agent has no explicit allowlist.
# ---------------------------------------------------------------------------
from services.openclaw_runtime.dynamic_planner import DynamicPlanner, PlannerConfig

skills = [
    {"id": "browser_open", "name": "Browser", "description": "abre pagina", "read_only": True},
    {"id": "notify_log", "name": "Notify", "description": "log", "read_only": True},
    {"id": "memory_record", "name": "Memory", "description": "memoria", "read_only": True},
    {"id": "dangerous_magic", "name": "Danger", "description": "nao permitido", "read_only": False},
]
planner = DynamicPlanner(PlannerConfig(base_url="http://127.0.0.1:1", timeout_seconds=0.1, max_steps=8))
planner._post_json = lambda path, payload: {
    "message": {"content": json.dumps({"steps": [
        {"skill_id": "browser_open", "reason": "navegar"},
        {"skill_id": "dangerous_magic", "reason": "tentar ampliar privilegio"},
        {"skill_id": "notify_log", "reason": "registrar"},
    ]})}
}
plan = planner.plan({"agent_id": "a1", "allowed_skills": ["browser_open", "notify_log"]}, "abra o site", {}, skills)
ok("planner_allowlist", [x["skill_id"] for x in plan] == ["browser_open", "notify_log"])
plan_no_acl = planner.plan({"agent_id": "a2", "allowed_skills": []}, "faça algo", {}, skills)
ok("planner_empty_acl_fail_safe", all(x["skill_id"] in {"notify_log", "memory_record"} for x in plan_no_acl))
ok("planner_host_shell_false", planner.status()["host_shell_access"] is False)

# ---------------------------------------------------------------------------
# 2) Declarative skills: tool/template/condition and scripts only in Docker.
# ---------------------------------------------------------------------------
from services.openclaw_runtime.declarative_skill_runtime import DeclarativeSkillExecutor
from services.openclaw_runtime.skill_manager import SkillManager

with tempfile.TemporaryDirectory(prefix="hall_v261_skill_") as td:
    calls = []
    def runner(name, args):
        calls.append((name, args))
        return {"ok": True, "echo": args}

    ex = DeclarativeSkillExecutor(td, runner)
    skill = {
        "id": "demo",
        "workflow": [
            {"id": "s1", "type": "template", "template": "Objetivo={{question}}", "save_as": "titulo"},
            {"id": "s2", "type": "tool", "tool": "notify_log", "args": {"message": "{{vars.titulo}}"}},
            {"id": "s3", "type": "condition", "path": "steps.s2.ok", "equals": True},
        ],
    }
    res = ex.execute(skill, "teste", {}, {"agent_id": "a1"}, approved=False, tool_guard=lambda t,a: {"ok": True})
    ok("declarative_exec", res.get("ok") is True and calls and calls[0][0] == "notify_log")
    script_skill = {"id": "script", "workflow": [{"type": "script", "language": "python", "sandbox": True, "code": "print('x')"}]}
    denied = ex.execute(script_skill, "", {}, {"agent_id": "a1"}, approved=False)
    ok("script_requires_approval", denied.get("requires_approval") is True or any(x.get("requires_approval") for x in denied.get("results", [])))
    ok("script_no_host_execution", "Docker" in json.dumps(denied, ensure_ascii=False) or "sandbox" in json.dumps(denied, ensure_ascii=False).lower())

    sm = SkillManager(td)
    imported = sm.import_markdown('''---\nid: analise_csv\nname: Analise CSV\nrisk: low\n---\nSkill exemplo.\n\n```hall-workflow\n[{"type":"tool","tool":"notify_log","args":{"message":"{{question}}"}}]\n```\n''', "analise_csv.md")
    ok("markdown_skill_import", imported.get("id") == "analise_csv" and imported.get("runtime") == "declarative_v26_1")
    ok("skill_delete_custom", sm.delete_custom("analise_csv").get("deleted") is True)

# ---------------------------------------------------------------------------
# 3) Browser real executor semantics with a fake Playwright page. This proves
#    the code actually invokes page methods, without requiring Chromium here.
# ---------------------------------------------------------------------------
import app.services.browser_automation as ba

class FakeResponse:
    status = 200

class FakeLocator:
    def __init__(self, page, selector):
        self.page, self.selector = page, selector
    def inner_text(self, **kwargs):
        self.page.calls.append(("inner_text", self.selector)); return "conteudo real"
    def click(self): self.page.calls.append(("click", self.selector))
    def fill(self, value): self.page.calls.append(("fill", self.selector, value))
    def press(self, value): self.page.calls.append(("press", self.selector, value))
    def hover(self): self.page.calls.append(("hover", self.selector))
    def select_option(self, value): self.page.calls.append(("select", self.selector, value)); return [value]
    def check(self): self.page.calls.append(("check", self.selector))
    def uncheck(self): self.page.calls.append(("uncheck", self.selector))

class FakePage:
    def __init__(self):
        self.url = "about:blank"; self.calls = []
    def goto(self, url, wait_until=None): self.url=url; self.calls.append(("goto",url,wait_until)); return FakeResponse()
    def title(self): return "Titulo"
    def locator(self, selector): return FakeLocator(self, selector)
    def wait_for_load_state(self, *a, **k): self.calls.append(("wait_for_load_state",))
    def wait_for_timeout(self, ms): self.calls.append(("wait",ms))
    def screenshot(self, path, full_page=True): Path(path).parent.mkdir(parents=True, exist_ok=True); Path(path).write_bytes(b"PNG"); self.calls.append(("screenshot",path))

with tempfile.TemporaryDirectory(prefix="hall_v261_browser_") as td:
    troot = Path(td)
    ba.root_dir = lambda: troot
    ba.DATA_DIR = troot / "data" / "browser_automation"
    ba.SESSIONS_FILE = ba.DATA_DIR / "browser_sessions.json"
    ba.ACTIONS_FILE = ba.DATA_DIR / "actions.json"
    ba.AUDIT_FILE = ba.DATA_DIR / "audit.jsonl"
    ba.PROFILES_DIR = ba.DATA_DIR / "profiles"
    ba.SCREENSHOTS_DIR = ba.DATA_DIR / "screenshots"
    ba.DOWNLOADS_DIR = ba.DATA_DIR / "downloads"
    page = FakePage()
    ba._RUNTIME.clear()
    created = ba.create_session(headless=True)
    sid = created["session"]["id"]
    ba._ensure_runtime = lambda session_id: {"page": page}
    r = ba.execute_action(sid, "open", "https://example.com")
    ok("browser_real_open", r.get("ok") is True and any(x[0] == "goto" for x in page.calls))
    r = ba.execute_action(sid, "read", "body")
    ok("browser_real_read", r.get("result", {}).get("text") == "conteudo real")
    r = ba.execute_action(sid, "fill", "#q", "teste")
    ok("browser_real_fill", r.get("ok") is True and ("fill", "#q", "teste") in page.calls)
    r = ba.execute_action(sid, "submit", "#send", approved=False)
    ok("browser_sensitive_approval", r.get("requires_approval") is True and not r.get("ok"))
    r = ba.execute_action(sid, "open", "https://gov.br/receita/teste")
    ok("browser_blocklist", r.get("ok") is False)
    r = ba.execute_action(sid, "screenshot")
    ok("browser_screenshot", r.get("ok") is True and "screenshot" in r.get("result", {}))
    st = ba.status()
    ok("browser_no_host_shell", st["policy"]["host_shell_access"] is False and st["policy"]["desktop_control"] is False)
    ok("browser_mode_real", st["mode"] == "real_playwright_executor")

# ---------------------------------------------------------------------------
# 4) Persistent memory + inter-agent bus.
# ---------------------------------------------------------------------------
from services.openclaw_runtime.agent_memory_v261 import AgentMemoryV261
from services.openclaw_runtime.agent_bus_v261 import AgentBusV261

with tempfile.TemporaryDirectory(prefix="hall_v261_mem_") as td:
    mem = AgentMemoryV261(td)
    rec = mem.record("Banco Oracle está saudável", agent_id="dba", scope="agent", title="Saúde Oracle", tags=["oracle"])
    found = mem.search("Oracle saudável", agent_id="dba")
    ok("memory_persistent_record", rec.get("ok") is True and bool(found))
    ok("memory_scope", found[0].get("scope") == "agent")
    bus = AgentBusV261(td)
    sent = bus.send("researcher", "analyst", "delegation", {"topic": "mercado"}, session_id="s1")
    inbox = bus.list(agent_id="analyst", session_id="s1")
    ok("agent_bus_send_receive", sent.get("ok") is True and inbox and inbox[-1]["from_agent"] == "researcher")
    ok("agent_bus_correlation_fields", "correlation_id" in sent["message"])

# ---------------------------------------------------------------------------
# 5) Autonomous supervisor leader election for HA.
# ---------------------------------------------------------------------------
from services.openclaw_runtime.autonomous_supervisor_v261 import AutonomousSupervisorV261
class FakeRuntime:
    def __init__(self, root): self.root_dir = Path(root); self.cycles = 0
    def run_cycle(self, **kwargs): self.cycles += 1; return {"ok": True, "executed_count": 0}

with tempfile.TemporaryDirectory(prefix="hall_v261_sup_") as td:
    rt1, rt2 = FakeRuntime(td), FakeRuntime(td)
    os.environ["HALL_INSTANCE_ID"] = "hall-a"
    s1 = AutonomousSupervisorV261(rt1, interval_seconds=15)
    os.environ["HALL_INSTANCE_ID"] = "hall-b"
    s2 = AutonomousSupervisorV261(rt2, interval_seconds=15)
    ok("ha_leader_election_first", s1._try_leader() is True)
    ok("ha_leader_election_second_blocked", s2._try_leader() is False)
    ok("ha_safety_status", s1.status()["safety_enforced"] is True and s1.status()["ha_leader_election"] is True)
    try: s1.lock_path.unlink(missing_ok=True)
    except Exception: pass
os.environ.pop("HALL_INSTANCE_ID", None)

# ---------------------------------------------------------------------------
# 6) Continuous vision privacy/safety and HA deployment assets.
# ---------------------------------------------------------------------------
from services import continuous_vision_v261 as cv
from services import ha_manager_v261 as ha
cst = cv.status()
ok("vision_privacy_no_retention", cst["privacy"]["retention_default"] is False)
ok("vision_local_only", cst["privacy"]["external_cloud"] is False and cst["privacy"]["local_vision_only"] is True)
hst = ha.status()
ok("ha_assets", hst["compose_present"] and hst["caddy_present"] and hst["multi_vps_template_present"])
ok("ha_no_host_shell", hst["host_shell_access"] is False)
ok("ha_failover_declared", hst["single_vps"]["automatic_process_failover"] is True)

# ---------------------------------------------------------------------------
# 7) Connector integrations and secret hygiene.
# ---------------------------------------------------------------------------
from services.openclaw_runtime.connector_hub import ConnectorHub
with tempfile.TemporaryDirectory(prefix="hall_v261_conn_") as td:
    hub = ConnectorHub(td)
    ids = {x["id"] for x in hub.list()}
    ok("connectors_real_catalog", {"email_smtp","telegram_bot","slack_webhook","teams_webhook","discord_webhook"}.issubset(ids))
    try:
        hub.upsert({"id":"bad","type":"telegram","config":{"token":"secret"}})
        secret_rejected = False
    except ValueError:
        secret_rejected = True
    ok("connectors_secret_rejected", secret_rejected)

# ---------------------------------------------------------------------------
# 8) Desktop agent keeps unrestricted Windows access blocked.
# ---------------------------------------------------------------------------
desk_path = ROOT / "desktop_agent" / "hall_desktop_agent.py"
spec = importlib.util.spec_from_file_location("hall_desktop_agent_v261_test", desk_path)
desk = importlib.util.module_from_spec(spec); spec.loader.exec_module(desk)
dst = desk.status()
ok("desktop_unrestricted_windows_blocked", dst["security"]["unrestricted_windows_access"] is False)
ok("desktop_shell_hotkeys_blocked", dst["security"]["shell_launch_hotkeys_blocked"] is True and ("win", "r") in desk.BLOCKED_HOTKEYS)
ok("desktop_shell_tokens_blocked", "powershell" in desk.BLOCKED_TEXT_TOKENS and "cmd.exe" in desk.BLOCKED_TEXT_TOKENS)
# Test scoping before pyautogui is needed.
blocked_folder = desk.create_folder({"folder":"x", "base": str(Path.home()), "approved": True})
ok("desktop_filesystem_scoped", blocked_folder.get("ok") is False)

# ---------------------------------------------------------------------------
# 9) Deployment/docs and product integration markers.
# ---------------------------------------------------------------------------
compose = (ROOT / "deployment" / "v26_1_ha" / "docker-compose.ha.yml").read_text(encoding="utf-8")
caddy = (ROOT / "deployment" / "v26_1_ha" / "Caddyfile").read_text(encoding="utf-8")
ok("ha_two_app_instances", "hall-a:" in compose and "hall-b:" in compose)
ok("ha_healthcheck", "/api/health" in compose and "health_uri /api/health" in caddy)
ok("ha_supervisor_both_instances", compose.count('HALL_OPENCLAW_AUTORUN: "1"') >= 2)

backend = (ROOT / "web_app" / "backend" / "main.py").read_text(encoding="utf-8")
for route in [
    "/api/openclaw-runtime/plan", "/api/openclaw-runtime/skills/import-markdown",
    "/api/openclaw-runtime/agent-bus/send", "/api/openclaw-runtime/supervisor/status",
    "/api/unified/browser-automation/actions", "/api/unified/continuous-vision/status",
    "/api/unified/ha/status",
]:
    ok("route_" + route.replace("/", "_"), route in backend)

html = (ROOT / "web_app" / "frontend" / "index.html").read_text(encoding="utf-8")
js = (ROOT / "web_app" / "frontend" / "unified_app.js").read_text(encoding="utf-8")
for marker in ["Dynamic Planner & Replanner V26.1", "Declarative Skills Runtime V26.1", "Continuous Vision V26.1", "HA / VPS V26.1"]:
    ok("ui_" + marker.split()[0].lower(), marker in html)
for marker in ["dynamicPlannerPlan", "declarativeSkillSave", "continuousVisionStart", "haStatus"]:
    ok("js_" + marker, marker in js)

print(json.dumps({"ok": all(checks.values()), "passed": sum(checks.values()), "total": len(checks), "checks": checks}, ensure_ascii=False, indent=2))
