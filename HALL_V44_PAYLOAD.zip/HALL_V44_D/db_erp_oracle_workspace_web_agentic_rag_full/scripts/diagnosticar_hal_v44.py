"""Read-only diagnostics, without LLM, microphone or real tax filing."""
from pathlib import Path
import json,sys,urllib.request
PROJECT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PROJECT))

def main():
    from services.tax_v44.model import calculate,specification
    from services.tax_v44.workbook import workbook_bytes
    sample={'regime':'presumido','receita':100000,'ano':2033,'iss':5,'cbs_referencia':9,'ibs_referencia':18}
    result=calculate(sample);raw,_=workbook_bytes(sample)
    assert result['totals']['total_antes']==17530 and result['totals']['total_depois']==35880
    assert raw[:2]==b'PK'
    status={'ok':True,'product':'HAL','version':'44.0','project':str(PROJECT),'python':sys.version.split()[0],
            'formula_rows':len(specification()['rows']),'native_xlsx_bytes':len(raw),'sample_before':17530,'sample_after':35880,
            'sample_rates_are_hypotheses':True,'real_llm_tested':False,'real_microphone_tested':False}
    try:
        with urllib.request.urlopen('http://127.0.0.1:8000/api/v44/runtime-status',timeout=3) as r:status['backend']=json.load(r)
    except (OSError,ValueError):status['backend']='Não está aberto na porta 8000. Execute INICIAR_HAL.bat ou ABRIR_SIMULADOR_HAL.bat.'
    print(json.dumps(status,ensure_ascii=False,indent=2))
    return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as exc:print('[ERRO] '+str(exc));raise SystemExit(1)
