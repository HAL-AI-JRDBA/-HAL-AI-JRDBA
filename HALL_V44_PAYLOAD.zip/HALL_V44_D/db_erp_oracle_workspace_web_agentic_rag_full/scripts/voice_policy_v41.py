"""Bounded listening and speaker consistency; no source separation claim."""
from collections import deque
import time


class NaturalTurnBuffer:
    def __init__(self, pause_ms=1200, max_seconds=45):
        self.pause=max(30,min(125,int(pause_ms)//20));self.limit=int(max_seconds*50)
        self.uid=0;self.preroll=deque(maxlen=10);self.candidate=[];self.blocked=False
        self.frames=[];self.voiced=[];self.silence=0;self.next_prefix=36

    def reset(self):
        self.frames=[];self.voiced=[];self.silence=0;self.next_prefix=36;self.candidate=[]

    def finish(self):
        if not self.frames:return []
        event=('end',self.uid,(self.frames[:],self.voiced[:])) if len(self.voiced)>=8 else ('reject',self.uid,None)
        self.reset();return [event]

    def push(self,frame,speech,directed=False):
        events=[]
        if self.blocked:
            self.silence=0 if speech else self.silence+1
            if self.silence>=self.pause:self.blocked=False;self.reset()
            return events
        if not self.frames:
            if not speech:
                self.preroll.extend(self.candidate);self.candidate=[];self.preroll.append(frame);return events
            self.candidate.append(frame)
            if len(self.candidate)<6:return events  # 120 ms of stable VAD, not a click.
            self.uid+=1;self.frames=list(self.preroll)+self.candidate;self.voiced=self.candidate[:]
            self.preroll.clear();self.candidate=[];events.append(('start',self.uid,None))
        else:
            self.frames.append(frame)
            if speech:self.voiced.append(frame);self.silence=0
            else:self.silence+=1
        if len(self.voiced)>=self.next_prefix:
            events.append(('prefix',self.uid,self.voiced[-80:]))
            self.next_prefix=len(self.voiced)+60
        if len(self.frames)>=self.limit:
            events.append(('overflow',self.uid,None));self.reset();self.blocked=True
        elif not directed and self.silence>=self.pause:events+=self.finish()
        return events


class SpeechFloor:
    """Only the current capture can release a provisional playback hold."""
    def __init__(self,clock=time.monotonic):
        self.clock=clock;self.uid=-1;self.started=0;self.label='waiting';self.confirmed=False
    def start(self,uid):
        self.uid=uid;self.started=self.clock();self.label='checking';self.confirmed=False
    def verdict(self,uid,label):
        if uid!=self.uid:return False
        self.label=label
        if label=='owner':self.confirmed=True
        return True
    def expired(self):
        return not self.confirmed and self.label in {'checking','uncertain','short','unregistered'} and self.clock()-self.started>2


def classify_scores(scores,overall,threshold):
    """Reject alternating owner/other windows instead of transcribing both."""
    if not scores:return 'uncertain'
    strong=sum(s>=threshold for s in scores)
    far=sum(s<threshold-.12 for s in scores)
    if strong and far:return 'mixed'
    if overall>=threshold and strong/len(scores)>=.75 and min(scores)>=threshold-.06:return 'owner'
    if overall<threshold-.06 and max(scores)<threshold-.04:return 'other'
    return 'uncertain'


def preferences(data):
    if not isinstance(data,dict) or set(data)-{'pause_ms','tts_rate'}:raise ValueError('Ajustes de voz inválidos.')
    result={}
    for key,lo,hi in [('pause_ms',600,2500),('tts_rate',-4,4)]:
        if key in data:
            value=data[key]
            if isinstance(value,bool) or not isinstance(value,int) or not lo<=value<=hi:raise ValueError('Ajuste fora do intervalo: '+key)
            result[key]=value
    return result
