from __future__ import annotations
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'scripts' / 'hall_voice_presence_windows_v24_2.py'
spec = importlib.util.spec_from_file_location('hall_voice_v242', SCRIPT)
mod = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(mod)

tests = []
def check(name, cond, detail=''):
    tests.append({'test': name, 'ok': bool(cond), 'detail': detail})

samples = [
    ('Hall ativar', True),
    ('HAL, ativar.', True),
    ('hall... ativar!', True),
    ('Hal ativar', True),
    ('Ral ativar', True),
    ('Hall ativar qual a hora', True),
    ('quero ativar', False),
    ('ativar', False),
]
for text, expected in samples:
    ok, remainder, matched = mod.phrase_match(text, mod.LANG['pt-BR']['wake'])
    check(f'wake::{text}', ok is expected, f'matched={matched!r}, remainder={remainder!r}')

sleep_samples = [
    ('Hall desativar', True),
    ('HAL, desativar.', True),
    ('Hal desativar', True),
    ('desativar', False),
]
for text, expected in sleep_samples:
    ok, remainder, matched = mod.phrase_match(text, mod.LANG['pt-BR']['sleep'])
    check(f'sleep::{text}', ok is expected, f'matched={matched!r}')

cfg = mod.load_config()
check('config_has_auto_calibrate', 'auto_calibrate' in cfg)
check('config_has_input_device', 'input_device' in cfg)
check('runtime_path_defined', mod.RUNTIME.name == 'native_runtime_v24_2.json')
check('log_path_defined', mod.LOGFILE.name == 'native_voice_v24_2.log')

payload = {'ok': all(t['ok'] for t in tests), 'passed': sum(t['ok'] for t in tests), 'total': len(tests), 'tests': tests}
print(json.dumps(payload, ensure_ascii=False, indent=2))
raise SystemExit(0 if payload['ok'] else 1)
