from __future__ import annotations
import json, sys, tempfile, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from services import voice_presence_v23 as vp

tmp=Path(tempfile.mkdtemp(prefix="hall_v241_unit_"))
vp.DATA_DIR=tmp
vp.CONFIG_FILE=tmp/"config.json";vp.PREFERENCES_FILE=tmp/"preferences.json";vp.SESSIONS_FILE=tmp/"sessions.json";vp.AUDIT_FILE=tmp/"audit.jsonl"
tests=[]
def ck(n,c,d=""):
 tests.append({"test":n,"ok":bool(c),"detail":d})
 if not c: raise AssertionError(n+" "+d)

u="admin"
r=vp.interpret(u,"HAL ativar","pt-BR","test");ck("wake activates",r.get("active") is True,str(r))
h=vp.native_heartbeat(u,True,"windows_native_v24_1");ck("heartbeat accepted",h.get("native_online") is True,str(h))
st=vp.status(u,"pt-BR");ck("native companion online",st.get("native_companion",{}).get("online") is True,str(st.get("native_companion")))
ck("native active mirrored",st.get("native_companion",{}).get("active") is True,str(st.get("native_companion")))
r=vp.interpret(u,"HAL desativar","pt-BR","test");ck("sleep deactivates",r.get("active") is False,str(r))
html=(ROOT/"web_app/frontend/index.html").read_text(encoding="utf-8")
js=(ROOT/"web_app/frontend/unified_app.js").read_text(encoding="utf-8")
comp=(ROOT/"scripts/hall_voice_presence_windows_v23.py").read_text(encoding="utf-8")
ck("browser detects native", "native_companion?.online" in js)
ck("browser avoids double listener", "o companion nativo é o listener primário" in js)
ck("companion heartbeat", "/api/voice-presence/native-heartbeat" in comp)
ck("companion syncs voice commands", "/api/voice-presence/interpret" in comp and "_sync_command" in comp)
ck("cache bust current", "hall_v24_1" in html or "hall_v25" in html)
print(json.dumps({"ok":all(t["ok"] for t in tests),"passed":sum(t["ok"] for t in tests),"total":len(tests),"tests":tests},ensure_ascii=False,indent=2))
