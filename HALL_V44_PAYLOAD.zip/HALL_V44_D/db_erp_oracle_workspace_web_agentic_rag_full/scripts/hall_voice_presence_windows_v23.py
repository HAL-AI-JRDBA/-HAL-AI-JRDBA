from __future__ import annotations

"""HAL V24.1 - companion de voz nativo para Windows (Voice Presence V23 + Natural Voice V24).

Objetivos:
- ficar em modo de espera sem navegador aberto;
- processar áudio localmente;
- só enviar texto ao servidor quando HAL está ativo;
- usar Windows Credential Manager via keyring, sem salvar senha em texto puro.

Dependências opcionais são instaladas por INSTALAR_HALL_VOICE_PRESENCE_V23.bat.
"""

import argparse
import json
import queue
import re
import sys
import threading
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "voice_presence_v23"
CONFIG = DATA / "native_client.json"
SERVICE_NAME = "JR-AI-HAL-V24"

LANG = {
    "pt-BR": {"whisper": "pt", "wake": ["hall ativar", "hall ativa"], "sleep": ["hall desativar", "hall desativa"], "on": "Estou aqui. Pode falar normalmente.", "off": "Certo. Vou ficar em espera."},
    "en-US": {"whisper": "en", "wake": ["hall activate", "hall wake up"], "sleep": ["hall deactivate", "hall go to sleep"], "on": "I'm here. You can speak naturally.", "off": "Okay. I'll stay on standby."},
    "es-ES": {"whisper": "es", "wake": ["hall activar", "hall actívate"], "sleep": ["hall desactivar", "hall desactívate"], "on": "Estoy aquí. Puedes hablar normalmente.", "off": "De acuerdo. Quedaré en espera."},
    "zh-CN": {"whisper": "zh", "wake": ["hall 启动", "hall 激活"], "sleep": ["hall 停用", "hall 关闭"], "on": "我在。你可以自然地和我说话。", "off": "好的。我会待机。"},
    "ja-JP": {"whisper": "ja", "wake": ["hall 起動", "hall 起きて"], "sleep": ["hall 停止", "hall 無効化"], "on": "ここにいます。普通に話してください。", "off": "わかりました。待機します。"},
}


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", str(s or "").lower().strip())


def load_config() -> dict[str, Any]:
    DATA.mkdir(parents=True, exist_ok=True)
    default = {
        "url": "http://127.0.0.1:8000",
        "username": "",
        "stt_model": "small",
        "device": "cpu",
        "compute_type": "int8",
        "sample_rate": 16000,
        "block_ms": 100,
        "vad_rms_threshold": 0.018,
        "silence_ms": 1100,
        "min_speech_ms": 300,
        "max_speech_seconds": 60,
        "tray_icon": True,
    }
    if CONFIG.exists():
        try:
            default.update(json.loads(CONFIG.read_text(encoding="utf-8-sig")))
        except Exception:
            pass
    return default


def save_config(cfg: dict[str, Any]) -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    CONFIG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def configure() -> int:
    try:
        import keyring
    except Exception:
        print("[ERRO] Instale as dependências com INSTALAR_HALL_VOICE_PRESENCE_V23.bat")
        return 2
    cfg = load_config()
    print("HAL V24 - Configuração do companion de voz")
    url = input(f"URL da HAL [{cfg['url']}]: ").strip() or cfg["url"]
    username = input(f"Usuário [{cfg.get('username','')}]: ").strip() or cfg.get("username", "")
    if not username:
        print("Usuário é obrigatório.")
        return 2
    import getpass
    password = getpass.getpass("Senha (será protegida pelo Windows Credential Manager): ")
    if not password:
        print("Senha vazia não é permitida.")
        return 2
    cfg["url"], cfg["username"] = url.rstrip("/"), username
    save_config(cfg)
    keyring.set_password(SERVICE_NAME, username, password)
    print("[OK] Configuração salva. A senha não foi gravada no JSON.")
    return 0


class Speaker:
    def __init__(self):
        self.q: queue.Queue[tuple[str, str] | None] = queue.Queue()
        self.speaking = threading.Event()
        self.stop_requested = threading.Event()
        self.engine = None
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        try:
            import pyttsx3
            self.engine = pyttsx3.init()
        except Exception as exc:
            print(f"[TTS] fallback Windows indisponível: {exc}")
            self.engine = None
        try:
            import winsound
        except Exception:
            winsound = None
        while True:
            item = self.q.get()
            if item is None:
                return
            kind, payload = item
            try:
                self.stop_requested.clear()
                self.speaking.set()
                if kind == "wav" and winsound is not None:
                    winsound.PlaySound(payload, winsound.SND_FILENAME)
                elif self.engine:
                    self.engine.say(payload)
                    self.engine.runAndWait()
                else:
                    print("HAL:", payload)
            except Exception as exc:
                print("[TTS]", exc)
            finally:
                self.speaking.clear()

    def say(self, text: str):
        if text:
            self.q.put(("text", text))

    def play_wav(self, path: str):
        if path:
            self.q.put(("wav", path))

    def stop(self):
        self.stop_requested.set()
        try:
            if self.engine:
                self.engine.stop()
        except Exception:
            pass
        try:
            import winsound
            winsound.PlaySound(None, winsound.SND_PURGE)
        except Exception:
            pass
        while not self.q.empty():
            try: self.q.get_nowait()
            except Exception: break


class HallNativeVoice:
    def __init__(self, cfg: dict[str, Any]):
        try:
            import keyring, requests, numpy as np, sounddevice as sd
            from faster_whisper import WhisperModel
        except Exception as exc:
            raise RuntimeError("Dependências ausentes. Execute INSTALAR_HALL_VOICE_PRESENCE_V23.bat") from exc
        self.keyring, self.requests, self.np, self.sd = keyring, requests, np, sd
        self.cfg = cfg
        self.http = requests.Session()
        self.active = False
        self.wake_phrases = []
        self.sleep_phrases = []
        self.last_heartbeat = 0.0
        self.conversation_id = ""
        self.language = "pt-BR"
        self.speaker = Speaker()
        self.running = True
        self.tray = None
        self.audio_q: queue.Queue[Any] = queue.Queue(maxsize=400)
        self.model = WhisperModel(cfg.get("stt_model", "small"), device=cfg.get("device", "cpu"), compute_type=cfg.get("compute_type", "int8"))
        self._login()

    def _login(self):
        username = self.cfg.get("username", "")
        password = self.keyring.get_password(SERVICE_NAME, username)
        if not username or not password:
            raise RuntimeError("Credenciais não configuradas. Rode CONFIGURAR_HALL_VOICE_PRESENCE_V23.bat")
        r = self.http.post(self.cfg["url"] + "/api/auth/login", json={"username": username, "password": password}, timeout=30)
        r.raise_for_status()
        me = self.http.get(self.cfg["url"] + "/api/auth/me", timeout=30)
        me.raise_for_status()
        user = me.json().get("user") or {}
        self.language = user.get("preferred_language") or "pt-BR"
        print(f"[OK] Autenticado como {user.get('display_name') or username} • {self.language}")
        self._load_server_voice_state()
        self._heartbeat(force=True)


    def _load_server_voice_state(self):
        try:
            r = self.http.get(self.cfg["url"] + "/api/voice-presence/status", timeout=20)
            r.raise_for_status()
            data = r.json()
            prefs = data.get("preferences") or {}
            phrases = data.get("phrases") or {}
            self.wake_phrases = list(prefs.get("wake_phrases") or phrases.get("activate") or LANG.get(self.language, LANG["pt-BR"])["wake"])
            self.sleep_phrases = list(prefs.get("sleep_phrases") or phrases.get("deactivate") or LANG.get(self.language, LANG["pt-BR"])["sleep"])
            self.active = bool(data.get("active", False))
        except Exception as exc:
            print("[VOICE PREFS] fallback local:", exc)
            self.wake_phrases = list(LANG.get(self.language, LANG["pt-BR"])["wake"])
            self.sleep_phrases = list(LANG.get(self.language, LANG["pt-BR"])["sleep"])

    def _heartbeat(self, force: bool = False):
        now = time.time()
        if not force and now - self.last_heartbeat < 8.0:
            return
        try:
            r = self.http.post(
                self.cfg["url"] + "/api/voice-presence/native-heartbeat",
                json={"active": bool(self.active), "source": "windows_native_v24_1"},
                timeout=10,
            )
            if r.status_code == 401:
                self._login()
                return
            r.raise_for_status()
            self.last_heartbeat = now
        except Exception:
            pass

    def _sync_command(self, text: str):
        try:
            r = self.http.post(
                self.cfg["url"] + "/api/voice-presence/interpret",
                json={"transcript": text, "source": "windows_native_v24_1"},
                timeout=20,
            )
            if r.status_code == 401:
                self._login()
                r = self.http.post(
                    self.cfg["url"] + "/api/voice-presence/interpret",
                    json={"transcript": text, "source": "windows_native_v24_1"},
                    timeout=20,
                )
            r.raise_for_status()
            data = r.json()
            self.active = bool(data.get("active", self.active))
            self._heartbeat(force=True)
            return data
        except Exception as exc:
            print("[VOICE COMMAND]", exc)
            return {}


    def _start_tray(self):
        if not self.cfg.get("tray_icon", True):
            return
        try:
            import pystray
            from PIL import Image, ImageDraw
            img=Image.new("RGB",(64,64),(8,15,35));d=ImageDraw.Draw(img);d.ellipse((5,5,59,59),outline=(99,211,255),width=4);d.text((22,16),"H",fill=(255,255,255))
            def toggle(icon,item):
                self.active=not self.active
                self.speaker.say(LANG.get(self.language,LANG["pt-BR"])["on" if self.active else "off"])
            def quit_app(icon,item):
                self.running=False
                try: icon.stop()
                except Exception: pass
            menu=pystray.Menu(pystray.MenuItem("Ativar / Desativar HAL",toggle),pystray.MenuItem("Sair",quit_app))
            self.tray=pystray.Icon("HALL_V24",img,"HAL V24 Natural Voice",menu)
            threading.Thread(target=self.tray.run,daemon=True).start()
        except Exception as exc:
            print(f"[TRAY] indisponível: {exc}")

    def _callback(self, indata, frames, time_info, status):
        if status:
            pass
        try:
            self.audio_q.put_nowait(indata.copy())
        except queue.Full:
            try: self.audio_q.get_nowait()
            except Exception: pass

    def _transcribe(self, audio) -> str:
        lang = LANG.get(self.language, LANG["pt-BR"])["whisper"]
        segments, _ = self.model.transcribe(audio, language=lang, beam_size=1, vad_filter=True, condition_on_previous_text=False)
        return " ".join(s.text.strip() for s in segments if s.text.strip()).strip()

    def _phrase(self, text: str, kind: str) -> tuple[bool, str]:
        t = _norm(text)
        phrases = self.wake_phrases if kind == "wake" else self.sleep_phrases
        if not phrases:
            phrases = LANG.get(self.language, LANG["pt-BR"])[kind]
        for phrase in sorted(phrases, key=lambda x: len(str(x)), reverse=True):
            p = _norm(phrase)
            if t == p:
                return True, ""
            if t.startswith(p + " "):
                return True, t[len(p):].strip()
        return False, ""

    def _turn(self, text: str):
        if not text: return
        print("Você:", text)
        payload = {"message": text, "session_id": self.conversation_id, "approved": False, "run_tools": True}
        r = self.http.post(self.cfg["url"] + "/api/unified/human-conversation/converse", json=payload, timeout=300)
        if r.status_code == 401:
            self._login(); r = self.http.post(self.cfg["url"] + "/api/unified/human-conversation/converse", json=payload, timeout=300)
        r.raise_for_status()
        data = r.json()
        self.conversation_id = data.get("session_id") or self.conversation_id
        answer = str(data.get("answer") or "")
        print("HAL:", answer)
        # V24: tenta o motor natural/neural do backend. Se não houver áudio neural,
        # usa o texto falado reduzido e cai para a voz local do Windows.
        try:
            vr = self.http.post(self.cfg["url"] + "/api/natural-voice-v24/synthesize", json={"text": answer}, timeout=240)
            if vr.status_code == 401:
                self._login(); vr = self.http.post(self.cfg["url"] + "/api/natural-voice-v24/synthesize", json={"text": answer}, timeout=240)
            vr.raise_for_status()
            voice = vr.json()
            audio_url = str(voice.get("audio_url") or "")
            spoken = str((voice.get("spoken") or {}).get("spoken_text") or answer)
            if audio_url:
                ar = self.http.get(self.cfg["url"] + audio_url, timeout=120)
                ar.raise_for_status()
                outdir = DATA / "generated_audio_v24"; outdir.mkdir(parents=True, exist_ok=True)
                wav = outdir / (Path(audio_url).name or "hall_v24.wav")
                wav.write_bytes(ar.content)
                self.speaker.play_wav(str(wav))
            else:
                self.speaker.say(spoken)
        except Exception as exc:
            print("[VOICE V24] fallback:", exc)
            self.speaker.say(answer)

    def run(self):
        sr = int(self.cfg.get("sample_rate", 16000))
        block_ms = int(self.cfg.get("block_ms", 100))
        block = max(320, int(sr * block_ms / 1000))
        threshold = float(self.cfg.get("vad_rms_threshold", 0.018))
        silence_blocks = max(3, int(self.cfg.get("silence_ms", 1100) / block_ms))
        min_blocks = max(2, int(self.cfg.get("min_speech_ms", 300) / block_ms))
        max_blocks = max(20, int(float(self.cfg.get("max_speech_seconds", 60)) * 1000 / block_ms))
        speech: list[Any] = []
        silence = 0
        print("[HAL V24.1] Sempre ouvindo localmente. Diga a frase de ativação.")
        self._start_tray()
        with self.sd.InputStream(samplerate=sr, channels=1, dtype="float32", blocksize=block, callback=self._callback):
            while self.running:
                chunk = self.audio_q.get()
                self._heartbeat()
                rms = float(self.np.sqrt(self.np.mean(self.np.square(chunk))))
                voice = rms >= threshold
                if self.speaker.speaking.is_set() and voice:
                    # Barge-in best effort: cancela a fila e começa a captar o usuário.
                    self.speaker.stop()
                if voice or speech:
                    speech.append(chunk[:, 0])
                    silence = 0 if voice else silence + 1
                if speech and (silence >= silence_blocks or len(speech) >= max_blocks):
                    if len(speech) >= min_blocks:
                        audio = self.np.concatenate(speech).astype("float32")
                        try: text = self._transcribe(audio)
                        except Exception as exc:
                            print("[STT]", exc); text = ""
                        if text:
                            wake, remainder = self._phrase(text, "wake")
                            sleep, _ = self._phrase(text, "sleep")
                            if not self.active:
                                if wake:
                                    data = self._sync_command(text)
                                    self.active = bool(data.get("active", True))
                                    self.speaker.say(str(data.get("reply") or LANG.get(self.language, LANG["pt-BR"])["on"]))
                                    query = str(data.get("query") or remainder or "").strip()
                                    if query: self._turn(query)
                            elif sleep:
                                data = self._sync_command(text)
                                self.active = bool(data.get("active", False))
                                self.speaker.say(str(data.get("reply") or LANG.get(self.language, LANG["pt-BR"])["off"]))
                            else:
                                self._turn(text)
                    speech, silence = [], 0
        if self.tray:
            try: self.tray.stop()
            except Exception: pass


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--configure", action="store_true")
    args = ap.parse_args()
    if args.configure:
        return configure()
    try:
        HallNativeVoice(load_config()).run()
        return 0
    except KeyboardInterrupt:
        return 0
    except Exception as exc:
        print("[ERRO]", exc)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
