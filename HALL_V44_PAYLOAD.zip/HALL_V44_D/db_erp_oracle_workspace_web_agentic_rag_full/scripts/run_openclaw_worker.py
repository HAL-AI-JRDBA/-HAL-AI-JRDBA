from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from services.openclaw_runtime import OpenClawRuntime


def main() -> int:
    parser = argparse.ArgumentParser(description='Executa o OpenClaw Local Runtime Governado em modo worker cooperativo.')
    parser.add_argument('--once', action='store_true', help='Executa apenas um ciclo e encerra.')
    parser.add_argument('--interval', type=int, default=300, help='Intervalo em segundos entre ciclos quando não usar --once.')
    parser.add_argument('--limit', type=int, default=10, help='Máximo de tarefas executadas por ciclo.')
    parser.add_argument('--no-events', action='store_true', help='Não checar gatilhos/eventos.')
    parser.add_argument('--no-schedules', action='store_true', help='Não checar agendas.')
    parser.add_argument('--no-execute', action='store_true', help='Só enfileira tarefas; não executa fila.')
    args = parser.parse_args()

    runtime = OpenClawRuntime(ROOT_DIR)
    while True:
        result = runtime.run_cycle(
            run_due=not args.no_schedules,
            check_events=not args.no_events,
            execute_queued=not args.no_execute,
            limit=args.limit,
            snapshots={},
        )
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
        if args.once:
            return 0
        time.sleep(max(30, int(args.interval or 300)))


if __name__ == '__main__':
    raise SystemExit(main())
