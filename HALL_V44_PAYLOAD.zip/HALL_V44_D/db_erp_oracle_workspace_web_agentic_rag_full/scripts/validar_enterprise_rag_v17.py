from __future__ import annotations

from pathlib import Path
import json
import shutil
import tempfile
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.document_parser import Chunk
from services.enterprise_rag import EnterpriseRAGManager, RAGAccessContext


def assert_true(value, message: str) -> None:
    if not value:
        raise AssertionError(message)


def main() -> int:
    root = Path(tempfile.mkdtemp(prefix="hall_enterprise_rag_v17_"))
    results = []
    try:
        manager = EnterpriseRAGManager(root)
        ctx_dba = RAGAccessContext(backend="local", tenant_id="empresa_a", user_id="alice", roles=["dba"], collection="oracle_docs")
        metadata = {"visibility": "tenant", "allowed_roles": ["dba"], "tags": ["oracle"]}
        chunks = [
            Chunk(source="oracle_manual.txt", chunk_id="oracle::1", text="Oracle 19c AWR mostra wait events e SQL de maior custo."),
            Chunk(source="rman.txt", chunk_id="rman::1", text="RMAN realiza backup e recuperação do banco Oracle."),
        ]
        unique, dedup = manager.deduplicate(ctx_dba, "local", chunks, base_metadata=metadata)
        assert_true(len(unique) == 2, "Primeira carga não deveria deduplicar os dois textos.")
        results.append({"test": "dedup_first_ingestion", "ok": True, "detail": dedup})

        idx = manager.index_vectors(ctx_dba, "local", unique, [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], {"oracle_manual.txt": "doc1", "rman.txt": "doc2"}, metadata)
        assert_true(idx["indexed_vectors"] == 2, "Indexação local deveria gravar 2 vetores.")
        results.append({"test": "local_index", "ok": True, "detail": idx})

        search = manager.search(ctx_dba, [1.0, 0.0, 0.0], "AWR performance", top_k=2)
        assert_true(search["hits"] and search["hits"][0]["source"] == "oracle_manual.txt", "Busca semântica local não retornou a fonte esperada.")
        results.append({"test": "semantic_search", "ok": True, "detail": {"hits": len(search["hits"])}})

        ctx_fin = RAGAccessContext(backend="local", tenant_id="empresa_a", user_id="bob", roles=["financeiro"], collection="oracle_docs")
        denied = manager.search(ctx_fin, [1.0, 0.0, 0.0], "AWR performance", top_k=2)
        assert_true(len(denied["hits"]) == 0 and denied["filtered_by_acl"] >= 1, "ACL por role não bloqueou documentos DBA.")
        results.append({"test": "role_acl", "ok": True})

        ctx_other = RAGAccessContext(backend="local", tenant_id="empresa_b", user_id="alice", roles=["dba"], collection="oracle_docs")
        isolated = manager.search(ctx_other, [1.0, 0.0, 0.0], "AWR performance", top_k=2)
        assert_true(len(isolated["hits"]) == 0, "Tenant isolation falhou.")
        results.append({"test": "tenant_isolation", "ok": True})

        assert_true(manager.document_status(ctx_dba, "local", "oracle_manual.txt", "doc1") == "unchanged", "Manifest incremental não reconheceu documento inalterado.")
        assert_true(manager.document_status(ctx_dba, "local", "oracle_manual.txt", "doc1_changed") == "changed", "Manifest incremental não detectou alteração.")
        results.append({"test": "incremental_manifest", "ok": True})

        same_unique, same_dedup = manager.deduplicate(ctx_dba, "local", [chunks[0]], base_metadata=metadata)
        assert_true(len(same_unique) == 0 and same_dedup["exact_duplicates"] == 1, "Deduplicação contra corpus existente falhou.")
        results.append({"test": "existing_dedup", "ok": True, "detail": same_dedup})

        near_a = Chunk(source="near_a.txt", chunk_id="near::1", text="Oracle 19c AWR mostra wait events e SQL de maior custo.")
        near_b = Chunk(source="near_b.txt", chunk_id="near::2", text="Oracle 19c AWR mostra wait events e SQL com maior custo.")
        near_unique, near_stats = manager.deduplicate(
            RAGAccessContext(backend="local", tenant_id="empresa_a", user_id="alice", roles=["dba"], collection="near_docs"),
            "local", [near_a, near_b], base_metadata=metadata
        )
        assert_true(len(near_unique) == 1 and near_stats["near_duplicates"] == 1, "Deduplicação aproximada SimHash falhou.")
        results.append({"test": "near_duplicate_simhash", "ok": True, "detail": near_stats})

        metrics = manager.observability.summary()
        assert_true(metrics["totals"].get("events", 0) >= 4, "Observabilidade não registrou eventos.")
        results.append({"test": "observability", "ok": True, "detail": metrics["totals"]})

        status = manager.status()
        assert_true(status["selected_backend"] == "local", "Backend default deveria ser local.")
        results.append({"test": "backend_router", "ok": True, "detail": status["selected_backend"]})

        print(json.dumps({"ok": True, "tests": results}, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc), "tests": results}, ensure_ascii=False, indent=2))
        return 1
    finally:
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
