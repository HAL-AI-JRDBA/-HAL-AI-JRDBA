class HallCapture extends AudioWorkletProcessor {
  constructor(){super();this.buffer=new Float32Array(1600);this.offset=0;}
  process(inputs,outputs){
    const input=inputs[0]&&inputs[0][0];
    if(input)for(let i=0;i<input.length;i++){
      this.buffer[this.offset++]=input[i];
      if(this.offset===1600){this.port.postMessage(this.buffer.buffer,[this.buffer.buffer]);this.buffer=new Float32Array(1600);this.offset=0;}
    }
    // The microphone graph is silent; only generated speech reaches speakers.
    return true;
  }
}
registerProcessor('hall-capture',HallCapture);
