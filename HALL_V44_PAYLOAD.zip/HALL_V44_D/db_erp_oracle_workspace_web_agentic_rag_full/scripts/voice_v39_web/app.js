'use strict';
const $=id=>document.getElementById(id);
const token=location.hash.slice(1);history.replaceState(null,'',location.pathname);
let stream=null,ctx=null,node=null,seq=0,backlog=0,chain=Promise.resolve(),capturing=false;
let audio=new Audio(),audioId=null,epoch=-1,paused=false,requestId=0,objectURL=null;
let sendGeneration=0;
async function api(path,body,extra={}){
  const opts={headers:{Authorization:'Bearer '+token,...extra}};
  if(body!==undefined){opts.method='POST';opts.body=body instanceof ArrayBuffer?body:JSON.stringify(body);}
  const response=await fetch(path,opts);
  if(!response.ok){let data={};try{data=await response.json();}catch(_){}throw Error(data.error||'Falha na conexão local: '+response.status);}
  return response;
}
const control=(action,extra={})=>api('/control',{action,...extra});
function clearAudio(){requestId++;audio.pause();audio.removeAttribute('src');audio.load();audioId=null;if(objectURL){URL.revokeObjectURL(objectURL);objectURL=null;}}
async function stopCapture(){
  capturing=false;sendGeneration++;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;
  if(ctx){await ctx.close();ctx=null;}node=null;
  clearAudio();$('start').disabled=false;$('stop').disabled=true;$('enroll').disabled=true;
  try{await control('disconnect');}catch(_){}
}
async function startCapture(){
  $('error').textContent='';$('start').disabled=true;
  try{
    stream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});
    ctx=new AudioContext({sampleRate:16000});await ctx.resume();
    if(ctx.sampleRate!==16000)throw Error('Este navegador não ofereceu áudio de 16 kHz. Use Edge ou Chrome atualizado.');
    const track=stream.getAudioTracks()[0];
    try{await track.applyConstraints({echoCancellation:{exact:'all'}});}catch(_){}
    const settings=track.getSettings();
    await control('settings',{settings:{echoCancellation:settings.echoCancellation===true||typeof settings.echoCancellation==='string',noiseSuppression:settings.noiseSuppression===true,autoGainControl:settings.autoGainControl===true,sampleRate:settings.sampleRate}});
    await control('start');await ctx.audioWorklet.addModule('/capture.js');
    const input=ctx.createMediaStreamSource(stream);node=new AudioWorkletNode(ctx,'hall-capture');input.connect(node);node.connect(ctx.destination);
    seq=0;backlog=0;chain=Promise.resolve();capturing=true;const generation=++sendGeneration;
    node.port.onmessage=e=>{
      if(!capturing||generation!==sendGeneration)return;
      const packet=e.data,current=++seq;backlog++;
      if(backlog>8){$('error').textContent='Áudio atrasado. Reinicie o microfone.';stopCapture();return;}
      chain=chain.then(async()=>{
        if(generation!==sendGeneration)return;
        await api('/capture',packet,{'X-Audio-Sequence':String(current)});
      }).catch(error=>{if(generation===sendGeneration){$('error').textContent=error.message;stopCapture();}}).finally(()=>{if(generation===sendGeneration)backlog--;});
    };
    $('stop').disabled=false;$('enroll').disabled=false;
  }catch(error){await stopCapture();$('error').textContent=error.message;}
}
async function poll(){
  try{
    const state=await(await api('/state')).json();
    $('status').textContent=state.status||'Em espera';$('mode').textContent=state.active?'Conversa ativa':'Aguardando “HAL ativar”';
    $('profile').textContent=state.registered?'Sua voz está cadastrada.':'Cadastre sua voz antes de conversar.';
    $('heard').textContent=state.transcript||'—';$('answer').textContent=state.answer||'—';
    if(state.error||state.tts_error)$('error').textContent=state.error||state.tts_error;
    const settings=state.settings||{};
    $('processing').textContent='Eco: '+(settings.echoCancellation?'ativado pelo navegador':'não confirmado — use fones')+' · Ruído: '+(settings.noiseSuppression?'redução ativada':'não confirmada');
    if(state.epoch!==epoch){epoch=state.epoch;clearAudio();}
    paused=Boolean(state.paused);
    if(!state.audio&&audioId)clearAudio();
    if(state.audio&&state.audio!==audioId){
      clearAudio();audioId=state.audio;const id=audioId,version=++requestId;
      const blob=await(await api('/wav/'+encodeURIComponent(id))).blob();
      if(version!==requestId)return;
      objectURL=URL.createObjectURL(blob);audio.src=objectURL;
      audio.onended=()=>{control('finished',{id}).catch(()=>{});};
      if(!paused&&capturing)await audio.play();
    }else if(audioId){
      if(paused||!capturing)audio.pause();
      else if(audio.paused&&!audio.ended)await audio.play();
    }
  }catch(error){$('error').textContent=error.message;clearAudio();}
  finally{setTimeout(poll,150);}
}
$('start').onclick=startCapture;$('stop').onclick=stopCapture;
$('standby').onclick=()=>{clearAudio();control('standby').catch(e=>$('error').textContent=e.message);};
$('enroll').onclick=()=>{clearAudio();$('error').textContent='';control('enroll').catch(e=>$('error').textContent=e.message);};
$('delete').onclick=()=>{clearAudio();control('delete').catch(e=>$('error').textContent=e.message);};
window.addEventListener('pagehide',()=>{if(stream)stream.getTracks().forEach(t=>t.stop());clearAudio();});
if(token)poll();else{$('start').disabled=true;$('error').textContent='Abra esta janela pelo INICIAR_JR_AI_HALL_V39.bat.';}
