from __future__ import annotations

import json
import sys
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.model_lifecycle import ModelLifecycleManager


def main():
    router = ROOT / 'hall_transporte_agentic_pro' / 'data' / 'multi_model_router' / 'config.json'
    mgr = ModelLifecycleManager(ROOT, ROOT / 'data' / 'model_lifecycle_v19', router)
    cfg = mgr.config()
    report = {
        'ok': True,
        'enabled': cfg.get('enabled'),
        'auto_check_enabled': cfg.get('auto_check_enabled'),
        'check_interval_hours': cfg.get('check_interval_hours'),
        'require_admin_approval': cfg.get('require_admin_approval'),
        'hf_api_base': cfg.get('hf_api_base'),
        'watch_roles': sorted((cfg.get('watch') or {}).keys()),
        'connectivity': {'ok': False, 'detail': ''},
    }
    try:
        base = str(cfg.get('hf_api_base') or 'https://huggingface.co/api').rstrip('/')
        q = urllib.parse.urlencode({'search':'coder GGUF','limit':1,'sort':'lastModified','direction':-1})
        req = urllib.request.Request(f'{base}/models?{q}', headers={'User-Agent':'JR-AI-HAL/32 HF Validator'})
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read().decode('utf-8-sig'))
        report['connectivity'] = {'ok': isinstance(data, list), 'results': len(data) if isinstance(data, list) else 0}
    except Exception as exc:
        report['connectivity'] = {'ok': False, 'detail': str(exc)}
        report['ok'] = False
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['ok'] else 2

if __name__ == '__main__':
    raise SystemExit(main())
