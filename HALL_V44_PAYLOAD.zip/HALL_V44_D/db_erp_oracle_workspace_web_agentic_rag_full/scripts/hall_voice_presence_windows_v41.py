"""Owner-focused local dialogue with bounded, confidence-aware turn taking."""
import hashlib
import json
import os
import queue
import threading
import time
from pathlib import Path
from storage_paths_v42 import whisper_cache
from voice_identity_v41 import ConsistentVoice
from voice_policy_v41 import NaturalTurnBuffer,SpeechFloor,preferences
from voice_bridge_v41 import ConversationBridge
from voice_speaker_v41 import ConversationSpeaker
from voice_turns_v41 import ConversationalTurns
import hall_voice_presence_windows_v39 as previous
base=previous.base
base.RUNTIME=base.DATA/'native_runtime_v41.json';base.LOGFILE=base.DATA/'native_voice_v41.log'


class HallVoice(previous.HallVoice):
    def __init__(self,cfg):
        import numpy as np,requests,keyring,webrtcvad
        os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
        from faster_whisper import WhisperModel
        self.np=np;self.requests=requests;self.keyring=keyring;self.cfg=cfg
        self.voice_source='windows_native_v41';self.http=requests.Session();self.active=False;self.language='pt-BR';self.running=True
        self.wake_phrases=[];self.sleep_phrases=[];self.last_heartbeat=0;self.conversation_id=''
        self.input_name='Navegador WebRTC V41';self.input_device=None
        self._login();self.active=False
        self.pref_path=base.DATA/'voice_preferences_v41'/(hashlib.sha256(str(cfg.get('username') or '').encode()).hexdigest()+'.json')
        self.prefs={'pause_ms':1200,'tts_rate':0}
        if self.pref_path.exists():self.prefs.update(preferences(json.loads(self.pref_path.read_text(encoding='utf-8'))))
        self.bridge=ConversationBridge(base.DATA,settings=self.prefs)
        self.speaker=ConversationSpeaker(self.bridge,self.prefs['tts_rate'],self.language,self._playback_event);self.bridge.speaker=self.speaker
        self.turns=ConversationalTurns(self._request_turn,self.speaker,self._cancel_turn)
        # Installation populates the cache; microphone operation never downloads a model.
        try:self.model=WhisperModel(cfg.get('stt_model','small'),device='cpu',compute_type='int8',cpu_threads=2,num_workers=2,local_files_only=True,download_root=whisper_cache())
        except Exception as exc:raise RuntimeError('Modelo de voz não encontrado no cache local. Execute INSTALAR_VOZ_HALL_V41.bat. '+str(exc)) from exc
        self.identity=ConsistentVoice(base.DATA/'voice_profiles_v39',str(cfg.get('username') or ''))
        self.vad=webrtcvad.Vad(2);self.noise=.002
        self.state_lock=threading.RLock();self.generation=0;self.accepted_uid=-1;self.capture_uid=0
        self.floor=SpeechFloor();self.buffer=NaturalTurnBuffer(self.prefs['pause_ms'])
        self.enrolling=False;self.enrollment_busy=False;self.enroll_frames=[]
        self.prefix_q=queue.Queue(maxsize=1);self.utterance_q=queue.Queue(maxsize=4)
        self.directed=False;self.directed_end=0;self.directed_uids=set();self.last_clarification=0
        self.bridge.update(registered=self.identity.vector is not None,status='Ligue o microfone e confira seu cadastro de voz.')
        threading.Thread(target=self._prefix_worker,daemon=True).start()
        for _ in range(2):threading.Thread(target=self._utterance_worker,daemon=True).start()

    def _heartbeat(self, force=False):
        # A running window is not necessarily recording its microphone.
        now=time.time()
        if not force and now-self.last_heartbeat<8.0:return
        listening=bool(getattr(getattr(self,'bridge',None),'connected',False))
        try:
            response=self.http.post(self.cfg['url']+'/api/voice-presence/native-heartbeat',
                json={'active':bool(self.active),'source':self.voice_source,'listening':listening},timeout=10)
            if response.status_code==401:
                self._login();return
            response.raise_for_status();self.last_heartbeat=now
            base._runtime(status='ready',active=self.active,heartbeat_at=base._now(),
                microphone=self.input_name,microphone_open=listening)
        except Exception as exc:base._runtime(status='degraded',last_error='heartbeat: '+str(exc))

    def _playback_event(self,sid,seq,status):
        session=self.requests.Session();session.cookies.update(self.http.cookies)
        try:
            response=session.post(self.cfg['url']+'/api/v38/conversation/playback',json={'session_id':sid,'seq':seq,'status':status},timeout=5)
            response.raise_for_status()
        finally:session.close()

    def _refresh(self,status=None,**extra):
        super()._refresh(status,enrolling=self.enrolling,enrollment_busy=self.enrollment_busy,**extra)

    def _transcribe_checked(self,audio,valid=lambda:True):
        if not valid():return ''
        lang=base.LANG.get(self.language,base.LANG['pt-BR'])['whisper']
        segments,_=self.model.transcribe(audio,language=lang,beam_size=1,vad_filter=True,condition_on_previous_text=False)
        good=[]
        for segment in segments:
            if not valid():return ''
            if float(getattr(segment,'no_speech_prob',0))>.65:continue
            if float(getattr(segment,'avg_logprob',0))<-1.0:continue
            if float(getattr(segment,'compression_ratio',1))>2.4:continue
            good.append(segment.text.strip())
        return ' '.join(good).strip() if valid() else ''

    def _standby(self):
        super()._standby()
        with self.state_lock:
            self.buffer=NaturalTurnBuffer(self.prefs['pause_ms']);self.floor=SpeechFloor()
            self.directed=False;self.directed_end=0;self.directed_uids.clear()

    def _release(self,uid):
        with self.state_lock:
            if uid==self.capture_uid:self.speaker.hold(False)

    def _prefix_worker(self):
        while self.running:
            uid,generation,frames=self.prefix_q.get()
            try:
                verdict=self.identity.analyse(self.np.concatenate(frames))
                with self.state_lock:
                    if generation!=self.generation or uid!=self.capture_uid:continue
                    self.floor.verdict(uid,verdict['label'])
                    if verdict['label']=='owner':
                        self._owner(uid,generation);self._refresh('Estou ouvindo você.',environment='Voz principal provável',voice_match=verdict['score'])
                    elif verdict['label']=='other':
                        self._release(uid);self._refresh('Conversa paralela ignorada.',environment='Outra voz provável',voice_match=verdict['score'])
                    elif verdict['label']=='mixed':
                        self._release(uid);self._refresh('O trecho tem vozes diferentes; aguardando.',environment='Vozes diferentes ou trecho misturado')
            except Exception as exc:
                self._release(uid);self._refresh(error='Identificação de voz: '+str(exc),environment='Voz incerta')

    def _clarify(self,uid,text):
        with self.state_lock:
            # Never answer an unconfirmed background speaker, or interrupt a newer owner turn.
            if not self.active or uid!=self.accepted_uid or uid!=self.capture_uid:return
            if time.monotonic()-self.last_clarification<5:return
            self.last_clarification=time.monotonic();self.speaker.hold(False);self.speaker.say(text)

    def _process_turn(self,uid,generation,frames,voiced):
        with self.state_lock:
            if generation!=self.generation or uid<self.accepted_uid:return
            directed=uid in self.directed_uids;self.directed_uids.discard(uid)
        audio=self.np.concatenate(voiced)
        verdict=self.identity.analyse(audio)
        # A short explicit button press expresses direction; it is not biometric authentication.
        short_directed=directed and verdict['label']=='short' and len(audio)>=2560
        if verdict['label']!='owner' and not short_directed:
            with self.state_lock:
                if generation!=self.generation:return
                self._release(uid)
                self._refresh('Aguardando uma fala clara da voz principal.',environment={'mixed':'Vozes diferentes ou trecho misturado','other':'Outra voz provável','short':'Fala curta; use Falar agora se necessário'}.get(verdict['label'],'Voz incerta'),voice_match=verdict['score'])
                if verdict['label'] in {'mixed','uncertain'}:self._clarify(uid,'Ouvi esse trecho misturado. Pode repetir só a última parte?')
            return
        with self.state_lock:
            if generation!=self.generation or not self._owner(uid,generation):return
        text=self._transcribe_checked(self.np.concatenate(frames),valid=lambda:generation==self.generation and uid==self.accepted_uid)
        with self.state_lock:
            if generation!=self.generation or uid!=self.accepted_uid:return
            # Unlike V39, a late result cannot deactivate a newer conversation.
            lang=base.LANG.get(self.language,base.LANG['pt-BR'])
            sleep,_,_=base.phrase_match(text,self.sleep_phrases or lang['sleep'])
            if sleep:self._standby();self._refresh(transcript=text,error='');return
            self._release(uid)
            if not text:
                self._refresh('Não consegui entender a última parte.',environment='Fala pouco clara')
                self._clarify(uid,'Não entendi a última parte. Pode repetir esse trecho?');return
            self._handle_text(text)
            self._refresh('Conversa ativa.' if self.active else 'Em espera. Diga HAL ativar.',transcript=text,error='',environment='Fala dirigida por botão' if short_directed else 'Voz principal provável')

    def _utterance_worker(self):
        while self.running:
            kind,uid,generation,frames,voiced=self.utterance_q.get()
            try:
                if kind=='enroll':
                    clips=[self.np.concatenate(x) if x else self.np.array([],dtype='float32') for x in voiced]
                    with self.state_lock:
                        if generation!=self.generation:continue
                    self.identity.enroll(clips,valid=lambda:generation==self.generation)
                    with self.state_lock:
                        if generation!=self.generation:continue
                        self.enrolling=False;self.enrollment_busy=False;self._refresh('Voz cadastrada. Diga HAL ativar.',error='')
                else:self._process_turn(uid,generation,frames,voiced)
            except Exception as exc:
                with self.state_lock:
                    if generation==self.generation:
                        self.enrolling=False;self.enrollment_busy=False;self._release(uid);self._refresh(error=str(exc),status='Não consegui processar esse trecho.')

    def _control(self,action):
        with self.state_lock:
            if isinstance(action,tuple) and action[0]=='preferences':
                values=preferences(action[1]);self.prefs.update(values);self.buffer.pause=self.prefs['pause_ms']//20;self.speaker.rate=self.prefs['tts_rate']
                self.pref_path.parent.mkdir(parents=True,exist_ok=True);tmp=self.pref_path.with_suffix('.tmp')
                tmp.write_text(json.dumps(self.prefs),encoding='utf-8');tmp.replace(self.pref_path);self._refresh(preferences=self.prefs);return
            if action=='push_start':
                if self.enrolling or self.enrollment_busy or not self.bridge.connected:return
                self.directed=True;self.directed_end=0
                if self.buffer.frames:self.directed_uids.add(self.buffer.uid)
                if self.active:self.turns.interrupt()
                self._refresh('Pode falar. Solte o botão ao terminar.');return
            if action=='push_end':
                self.directed_end=time.monotonic()+.25;return
            super()._control(action)

    def _events(self,events):
        for event,uid,data in events:
            if event=='start':
                self.capture_uid=uid;self.floor.start(uid)
                if self.directed:self.directed_uids.add(uid)
                if self.active:self.speaker.hold(True)
            elif event=='prefix':self._queue_latest(self.prefix_q,(uid,self.generation,data))
            elif event=='reject':self._release(uid);self.directed_uids.discard(uid)
            elif event=='overflow':
                self._release(uid);self._refresh('Fala muito longa. Faça uma pausa para concluir o pedido.',environment='Limite de fala contínua atingido')
                self._clarify(uid,'Faça uma pausa para eu acompanhar o pedido.');self.directed_uids.discard(uid)
            elif event=='end':
                try:self.utterance_q.put_nowait(('turn',uid,self.generation,*data))
                except queue.Full:
                    self.directed_uids.discard(uid);self._release(uid);self._refresh('Processamento de voz ocupado. Aguarde um instante.',error='Trecho não enviado; nada foi executado.')

    def _frame(self,frame):
        np=self.np
        if len(frame)!=320 or not np.all(np.isfinite(frame)):return
        with self.state_lock:
            pcm=(np.clip(frame,-1,1)*32767).astype('<i2').tobytes();speech=self.vad.is_speech(pcm,16000)
            level=float(np.sqrt(np.mean(frame*frame)))
            if not speech:self.noise=.98*self.noise+.02*level
            speech=speech and level>=max(.003,min(.018,self.noise*2))
            if self.enrollment_busy:return
            if self.enrolling:
                # Keep the established, protected three-sample enrollment contract.
                self.enroll_frames.append((frame,speech));count=len(self.enroll_frames)
                if count%50==0:self._refresh('Cadastro: '+str(max(0,18-count//50))+' segundos restantes.')
                if count==900:
                    clips=[[f for f,v in self.enroll_frames[i:i+300] if v] for i in [0,300,600]]
                    self.enroll_frames=[];self.enrolling=False;self.enrollment_busy=True
                    self._queue_latest(self.utterance_q,('enroll',0,self.generation,[],clips));self._refresh('Analisando o cadastro de voz…')
                return
            if self.identity.vector is None and not self.directed:return
            if self.directed_end and time.monotonic()>=self.directed_end:
                self.directed=False;self.directed_end=0;self._events(self.buffer.finish())
            self._events(self.buffer.push(frame,speech,self.directed))
            if self.floor.expired():self.speaker.hold(False);self.floor.label='uncertain'


def main():
    client=None
    try:client=HallVoice(base.load_config());client.run()
    except KeyboardInterrupt:return 0
    except Exception as exc:base._log('[V41] '+str(exc));base._runtime(status='error',last_error=str(exc));return 2
    finally:
        if client:client.running=False;client.speaker.stop();client.bridge.server.shutdown();client.bridge.server.server_close()
    return 0
if __name__=='__main__':raise SystemExit(main())
