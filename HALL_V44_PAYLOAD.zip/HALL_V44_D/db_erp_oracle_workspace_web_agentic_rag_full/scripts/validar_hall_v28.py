from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from services.language_manager import language_catalog, language_count
from services.hall_v28_enterprise_conversational import HallV28EnterpriseConversational
assert language_count() >= 70, language_count()
langs=language_catalog()
assert all(x['label'] == x['native'] for x in langs)
assert any(x['code']=='pt-BR' and x['label']=='Português (Brasil)' for x in langs)
assert any(x['code']=='ja-JP' and x['label']=='日本語' for x in langs)
assert any(x['code']=='zh-CN' and x['label']=='中文（简体）' for x in langs)
svc=HallV28EnterpriseConversational(ROOT)
st=svc.status(); assert st['languages']['count'] >= 70
assert st['languages']['display_names']=='native'
assert 'lv-LV' in st['languages']['ui_core_bundled_for']
assert st['languages']['other_ui_fallback'] is None
emo=svc.analyze_emotion({'text':'This is urgent, help me now'}); assert emo['emotion']=='urgent'
conv=svc.resolve_conversation({'customer_key':'validation-user','channel':'web'}); assert conv['ok']
print(json.dumps({'ok':True,'version':'28.1','languages':language_count(),'emotion_test':emo['emotion'],'conversation_id':conv['conversation']['id'],'connectors':len(svc.connector_catalog())},ensure_ascii=False,indent=2))
