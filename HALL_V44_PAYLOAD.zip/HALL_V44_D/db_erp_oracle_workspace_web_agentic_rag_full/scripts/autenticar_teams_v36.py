from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from services.autonomy_tools_v36 import Tools
from services.teams_auth_v36 import acquire
if __name__=='__main__':
    try:
        acquire(ROOT,Tools(ROOT).config().get('channels',{}).get('teams',{}),interactive=True)
        print('Teams autenticado. O token não será exibido.')
    except Exception as exc:
        print('Falha:',str(exc));sys.exit(1)
