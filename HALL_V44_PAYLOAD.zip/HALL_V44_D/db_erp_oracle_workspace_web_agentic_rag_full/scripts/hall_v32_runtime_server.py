from __future__ import annotations

import argparse
import importlib
import os
import sys
from pathlib import Path

REQUIRED_ROUTES = {
    "/api/health",
    "/api/v32/runtime-status",
    "/api/v32/status",
    "/api/software-engineering/status",
}
if os.getenv('HAL_TAX_V44') == '1':
    REQUIRED_ROUTES.update({'/api/v44/runtime-status','/api/v44/tax/status','/api/v44/tax/calculate','/api/v44/tax/export.xlsx','/tributos'})
if os.getenv('HALL_SSOT_V43') == '1':
    REQUIRED_ROUTES.update({'/api/v43/runtime-status', '/api/v43/ssot/status', '/api/v43/ssot/documents', '/ssot'})
if os.getenv('HALL_LOCAL_AGENT_V40') == '1':
    REQUIRED_ROUTES.update({'/api/v40/runtime-status', '/api/v40/tasks', '/api/v40/memory', '/local-agent'})
if os.getenv('HALL_V41_VOICE') == '1':
    REQUIRED_ROUTES.update({'/api/v41/runtime-status','/api/v38/conversation/playback'})
if os.getenv('HALL_GEMMA4_V42') == '1':
    REQUIRED_ROUTES.update({'/api/v42/runtime-status', '/api/v42/gemma4/status', '/gemma4'})


def load_local_app():
    project = Path(__file__).resolve().parents[1]
    expected_main = (project / "web_app" / "backend" / "main.py").resolve()
    sys.path.insert(0, str(project))

    module = importlib.import_module("web_app.backend.main")
    loaded_main = Path(module.__file__).resolve()
    if loaded_main != expected_main:
        raise RuntimeError(
            f"Backend incorreto carregado. Esperado={expected_main} Carregado={loaded_main}"
        )

    app = getattr(module, "app", None)
    if app is None:
        raise RuntimeError("FastAPI app nao encontrado em web_app.backend.main")

    routes = {getattr(route, "path", "") for route in getattr(app, "routes", [])}
    missing = sorted(REQUIRED_ROUTES - routes)
    if missing:
        raise RuntimeError(
            "Backend local nao contem todas as rotas V32 requeridas: " + ", ".join(missing)
        )

    return project, loaded_main, app, routes


def main() -> int:
    parser = argparse.ArgumentParser(description="HAL V32.4 local backend bootstrap")
    parser.add_argument("--check-only", action="store_true")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()

    project, loaded_main, app, routes = load_local_app()
    label = "HAL-V44" if os.getenv("HAL_TAX_V44") == "1" else "HAL-V43" if os.getenv("HALL_SSOT_V43") == "1" else "HAL-V42" if os.getenv("HALL_GEMMA4_V42") == "1" else "HAL-V41" if os.getenv("HALL_V41_VOICE") == "1" else "HAL-V40" if os.getenv("HALL_LOCAL_AGENT_V40") == "1" else "HAL-V32.4"
    print(f"[{label}] PROJECT={project}", flush=True)
    print(f"[{label}] MAIN={loaded_main}", flush=True)
    print(f"[{label}] REQUIRED_ROUTES_OK={len(REQUIRED_ROUTES)}", flush=True)

    if args.check_only:
        return 0

    import uvicorn

    uvicorn.run(
        app,
        host=args.host,
        port=args.port,
        proxy_headers=True,
        forwarded_allow_ips="127.0.0.1,::1",
        log_level=os.getenv("HALL_UVICORN_LOG_LEVEL", "info"),
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
