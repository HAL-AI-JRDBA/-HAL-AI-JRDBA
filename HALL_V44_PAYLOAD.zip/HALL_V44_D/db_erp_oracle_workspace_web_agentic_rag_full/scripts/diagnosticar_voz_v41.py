"""Offline load checks, explicitly distinct from acoustic accuracy tests."""
import importlib
import json
import os
import sys
from pathlib import Path
from storage_paths_v42 import whisper_cache

def main():
    os.environ['HF_HUB_OFFLINE']='1';os.environ['TRANSFORMERS_OFFLINE']='1'
    root=Path(__file__).resolve().parents[1]
    result={'ok':False,'version':'41.0','windows':os.name=='nt','checks':{},'real_microphone_tested':False,'real_speaker_accuracy_tested':False,'real_overlap_tested':False,'real_llm_tested':False}
    try:
        for name in ['numpy','librosa','webrtcvad','torch','resemblyzer','faster_whisper','keyring','requests']:
            mod=importlib.import_module(name);result['checks'][name]=getattr(mod,'__version__','import ok')
        from faster_whisper import WhisperModel
        cfg=root/'data/voice_presence_v23/native_client.json'
        data=json.loads(cfg.read_text(encoding='utf-8-sig')) if cfg.exists() else {}
        model=WhisperModel(data.get('stt_model','small'),device='cpu',compute_type='int8',cpu_threads=2,local_files_only=True,download_root=whisper_cache())
        result['checks']['stt_cache']='loaded offline'
        from resemblyzer import VoiceEncoder
        import numpy as np,torch
        torch.set_num_threads(2);encoder=VoiceEncoder(device='cpu')
        whole,parts,slices=encoder.embed_utterance(np.zeros(32000,dtype=np.float32),return_partials=True,rate=1.3,min_coverage=.6)
        if whole.shape!=(256,) or parts.shape[1]!=256 or not np.all(np.isfinite(parts)):raise ValueError('Saída do identificador inválida.')
        result['checks']['speaker_windows']='synthetic forward ok; not an accuracy test'
        result['ok']=True
    except Exception as exc:result['error']=str(exc)
    folder=root/'data/voice_presence_v23';folder.mkdir(parents=True,exist_ok=True)
    (folder/'diagnostico_v41.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2));return 0 if result['ok'] else 2
if __name__=='__main__':raise SystemExit(main())
