from __future__ import annotations
import argparse, json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from services import natural_voice_engine_v24 as nv
from services import jr_voice_profile

p=argparse.ArgumentParser()
p.add_argument('--username',required=True)
p.add_argument('--profile-id',required=True)
a=p.parse_args()
prof=jr_voice_profile.get_profile(a.profile_id)
if not prof.get('ok'):
    raise SystemExit('Perfil não encontrado.')
if not prof.get('profile',{}).get('consent',{}).get('confirmed'):
    raise SystemExit('Perfil sem consentimento confirmado.')
cfg=nv.read_config(); mapping=dict(cfg.get('xtts',{}).get('user_voice_profiles',{}) or {})
mapping[a.username.strip().lower()]=a.profile_id
out=nv.update_config({'xtts':{'user_voice_profiles':mapping}})
print(json.dumps({'ok':True,'username':a.username.strip().lower(),'profile_id':a.profile_id},ensure_ascii=False,indent=2))
