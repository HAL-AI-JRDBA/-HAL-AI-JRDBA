from __future__ import annotations

import argparse
from pathlib import Path

UTF8_BOM = b"\xef\xbb\xbf"
TEXT_EXTENSIONS = {
    ".json", ".jsonl", ".py", ".js", ".html", ".css", ".md", ".txt",
    ".bat", ".cmd", ".ps1", ".yml", ".yaml", ".toml", ".ini", ".cfg",
    ".conf", ".env", ".example", ".sql", ".xml", ".svg", ".webmanifest",
}
SKIP_DIRS = {".git", ".venv", ".venv_web", "venv", "node_modules", "__pycache__", "models", "modelos"}


def eligible(path: Path) -> bool:
    if not path.is_file():
        return False
    if any(part in SKIP_DIRS for part in path.parts):
        return False
    return path.suffix.lower() in TEXT_EXTENSIONS or path.name.lower().endswith(".env.example")


def strip_bom_tree(root: Path) -> tuple[int, int]:
    scanned = 0
    fixed = 0
    for path in root.rglob("*"):
        if not eligible(path):
            continue
        scanned += 1
        try:
            data = path.read_bytes()
        except OSError:
            continue
        if data.startswith(UTF8_BOM):
            path.write_bytes(data[len(UTF8_BOM):])
            fixed += 1
    return scanned, fixed


def main() -> int:
    parser = argparse.ArgumentParser(description="HAL V18.2 - remove UTF-8 BOM de arquivos textuais")
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument("--quiet", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    scanned, fixed = strip_bom_tree(root)
    if not args.quiet or fixed:
        print(f"[UTF8] Arquivos verificados: {scanned}; BOM removidos: {fixed}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
