from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from services.autonomy_manager import AutonomyManager


def main() -> int:
    parser = argparse.ArgumentParser(description='Executa um ciclo de autoaprendizado governado.')
    parser.add_argument('--focus', default='', help='Foco do ciclo, por exemplo: reduzir ORA-00904 em Estoque.')
    parser.add_argument('--limit', type=int, default=600, help='Quantidade máxima de feedbacks recentes a analisar.')
    parser.add_argument('--no-lab-files', action='store_true', help='Não gerar arquivos em data/autonomy_lab.')
    args = parser.parse_args()

    manager = AutonomyManager(
        root_dir=ROOT_DIR,
        feedback_db=ROOT_DIR / 'data' / 'learning' / 'feedback.sqlite',
        learning_path=ROOT_DIR / 'data' / 'learning' / 'sql_learning.json',
        policy_path=ROOT_DIR / 'data' / 'policies' / 'policy_bandit.json',
        trace_dir=ROOT_DIR / 'data' / 'learning' / 'traces',
        agent_audit_path=ROOT_DIR / 'data' / 'agent_gateway' / 'agent_audit.jsonl',
    )
    result = manager.run_cycle(focus=args.focus, write_lab_files=not args.no_lab_files, limit=args.limit)
    print(json.dumps({
        'ok': result.get('ok'),
        'cycle_at': result.get('cycle_at'),
        'insights': result.get('insights'),
        'proposal_count': len(result.get('proposals') or []),
        'pending': sum(1 for p in result.get('proposals') or [] if p.get('status') == 'pending'),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
