from __future__ import annotations

"""HAL V30 - Windows native always-on voice + screen companion.

Key goals:
- real wake/sleep by voice without pressing the browser button;
- isolated voice runtime, diagnostics and microphone auto-calibration;
- robust wake phrase normalization (punctuation/accents/common Whisper variants);
- visible runtime/log state so failures are never silent;
- privacy: while sleeping, ordinary speech is processed locally and never sent to HAL.
"""

import argparse
import base64
import getpass
import json
import subprocess
import math
import os
import queue
import re
import sys
import threading
import time
import traceback
import unicodedata
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "voice_presence_v23"
CONFIG = DATA / "native_client.json"
RUNTIME = DATA / "native_runtime_v30.json"
LOGFILE = DATA / "native_voice_v30.log"
SERVICE_NAME = "JR-AI-HAL-V24"  # credential namespace preserved for compatibility

LANG = {
    "pt-BR": {
        "whisper": "pt",
        "wake": ["hall ativar", "hall ativa", "hall acordar", "hall acorda"],
        "sleep": ["hall desativar", "hall desativa", "hall dormir", "hall pode dormir"],
        "on": "Estou aqui. Pode falar normalmente.",
        "off": "Certo. Vou ficar em espera.",
    },
    "en-US": {
        "whisper": "en",
        "wake": ["hall activate", "hall wake up", "hey hall activate"],
        "sleep": ["hall deactivate", "hall go to sleep", "hall sleep"],
        "on": "I'm here. You can speak naturally.",
        "off": "Okay. I'll stay on standby.",
    },
    "es-ES": {
        "whisper": "es",
        "wake": ["hall activar", "hall activate", "hall despierta"],
        "sleep": ["hall desactivar", "hall deactivate", "hall dormir"],
        "on": "Estoy aquí. Puedes hablar normalmente.",
        "off": "De acuerdo. Quedaré en espera.",
    },
    "zh-CN": {
        "whisper": "zh",
        "wake": ["hall 启动", "hall 激活", "hall 唤醒", "hall启动", "hall激活"],
        "sleep": ["hall 停用", "hall 关闭", "hall 休眠", "hall停用", "hall关闭"],
        "on": "我在。你可以自然地和我说话。",
        "off": "好的。我会待机。",
    },
    "ja-JP": {
        "whisper": "ja",
        "wake": ["hall 起動", "hall 起きて", "hall 有効化", "hall起動"],
        "sleep": ["hall 停止", "hall 無効化", "hall 休んで", "hall停止"],
        "on": "ここにいます。普通に話してください。",
        "off": "わかりました。待機します。",
    },
}

# Common local STT spellings for the name HAL. These are only accepted when
# immediately followed by an explicit wake/sleep verb, minimizing false wakes.
HALL_ALIASES = {"hall", "hal", "hau", "ral", "all", "al", "au", "aum", "haum", "rau", "rall", "hol", "haul"}


def _now() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _norm(text: str) -> str:
    raw = unicodedata.normalize("NFKC", str(text or "")).lower().strip()
    decomp = unicodedata.normalize("NFD", raw)
    raw = "".join(ch for ch in decomp if unicodedata.category(ch) != "Mn")
    # Keep Latin word chars + CJK, normalize punctuation to spaces.
    raw = re.sub(r"[^\w\u3400-\u9fff\u3040-\u30ff\s]", " ", raw, flags=re.UNICODE)
    return re.sub(r"\s+", " ", raw).strip()


def _phrase_variants(phrase: str) -> set[str]:
    p = _norm(phrase)
    out = {p}
    words = p.split()
    if words and words[0] == "hall" and len(words) >= 2:
        tail = " ".join(words[1:])
        out.update(f"{a} {tail}" for a in HALL_ALIASES)
    return {x for x in out if x}


def _transcribe_with_wake_hint(model, audio, language: str = "pt", beam_size: int = 3):
    """Bias STT toward HAL activate/deactivate while preserving fallback compatibility."""
    prompts = {
        "pt": "HAL ativar. HAL desativar. HAL acordar. HAL dormir.",
        "en": "HAL activate. HAL deactivate. HAL wake up. HAL sleep.",
        "es": "HAL activar. HAL desactivar. HAL despierta. HAL dormir.",
        "zh": "HAL 启动。HAL 停用。",
        "ja": "HAL 起動。HAL 停止。",
    }
    kwargs = dict(
        language=language,
        beam_size=max(1, int(beam_size)),
        vad_filter=True,
        condition_on_previous_text=False,
    )
    try:
        kwargs["initial_prompt"] = prompts.get(language, prompts["pt"])
        return model.transcribe(audio, **kwargs)
    except TypeError:
        # Compatibilidade com versões antigas do faster-whisper.
        kwargs.pop("initial_prompt", None)
        return model.transcribe(audio, **kwargs)


def phrase_match(text: str, phrases: list[str]) -> tuple[bool, str, str]:
    t = _norm(text)
    for phrase in sorted(phrases or [], key=lambda x: len(str(x)), reverse=True):
        for p in sorted(_phrase_variants(str(phrase)), key=len, reverse=True):
            if t == p:
                return True, "", p
            if t.startswith(p + " "):
                return True, t[len(p):].strip(), p
    return False, "", ""


VOICE_SCREEN_PHRASES = [
    "capture minha tela", "captura minha tela", "capture a tela", "captura a tela",
    "veja minha tela", "ve a minha tela", "olhe minha tela", "olha minha tela",
    "analise minha tela", "analisa minha tela", "analise a tela", "analisa a tela",
    "o que esta na minha tela", "o que aparece na minha tela", "me ajude com esse erro na tela",
    "veja esse erro na tela", "olhe esse erro na tela",
]

def is_voice_screen_command(text: str) -> bool:
    t = _norm(text)
    t = re.sub(r"^(hall|hal|hau|ral|all)\s+", "", t).strip()
    return any(_norm(p) in t for p in VOICE_SCREEN_PHRASES)


def _runtime(**changes: Any) -> None:
    try:
        DATA.mkdir(parents=True, exist_ok=True)
        current = {}
        if RUNTIME.exists():
            try:
                current = json.loads(RUNTIME.read_text(encoding="utf-8-sig"))
            except Exception:
                current = {}
        current.update({"pid": os.getpid(), "updated_at": _now(), **changes})
        RUNTIME.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def _log(message: str) -> None:
    line = f"[{_now()}] {message}"
    print(line, flush=True)
    try:
        DATA.mkdir(parents=True, exist_ok=True)
        with LOGFILE.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def load_config() -> dict[str, Any]:
    DATA.mkdir(parents=True, exist_ok=True)
    default = {
        "version": "30.0",
        "url": "http://127.0.0.1:8000",
        "username": "",
        "stt_model": "base",
        "wake_stt_model": "base",
        "device": "cpu",
        "compute_type": "int8",
        "sample_rate": 16000,
        "block_ms": 100,
        "input_device": None,
        "auto_calibrate": True,
        "vad_rms_threshold": 0.010,
        "vad_floor": 0.004,
        "vad_ceiling": 0.035,
        "vad_noise_multiplier": 3.0,
        "silence_ms": 2200,
        "min_speech_ms": 250,
        "max_speech_seconds": 60,
        "tray_icon": True,
        "setup_completed": False,
        # V24.2.5: saída de voz e proteção contra auto-interrupção.
        "tts_backend": "windows_sapi",
        "native_barge_in": False,
        "post_tts_ignore_ms": 650,
    }
    if CONFIG.exists():
        try:
            data = json.loads(CONFIG.read_text(encoding="utf-8-sig"))
            if isinstance(data, dict):
                default.update(data)
        except Exception as exc:
            _log(f"[CONFIG] Falha ao ler {CONFIG}: {exc}")
    return default


def save_config(cfg: dict[str, Any]) -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    cfg["version"] = "30.0"
    CONFIG.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")


def _deps():
    import keyring
    import numpy as np
    import requests
    import sounddevice as sd
    from faster_whisper import WhisperModel
    return keyring, np, requests, sd, WhisperModel


def list_microphones(sd) -> list[tuple[int, str, int]]:
    out = []
    for idx, dev in enumerate(sd.query_devices()):
        try:
            channels = int(dev.get("max_input_channels") or 0)
        except Exception:
            channels = 0
        if channels > 0:
            out.append((idx, str(dev.get("name") or f"Device {idx}"), channels))
    return out


def _resolve_device(cfg: dict[str, Any], sd) -> int | None:
    configured = cfg.get("input_device")
    if configured not in (None, "", "default"):
        try:
            return int(configured)
        except Exception:
            pass
    try:
        default_in = sd.default.device[0]
        if default_in is not None and int(default_in) >= 0:
            return int(default_in)
    except Exception:
        pass
    mics = list_microphones(sd)
    return mics[0][0] if mics else None


def capture_seconds(sd, np, seconds: float, sample_rate: int, device: int | None = None):
    frames = max(1, int(float(seconds) * sample_rate))
    audio = sd.rec(frames, samplerate=sample_rate, channels=1, dtype="float32", device=device)
    sd.wait()
    return np.asarray(audio[:, 0], dtype="float32")


def rms(np, audio) -> float:
    if audio is None or len(audio) == 0:
        return 0.0
    return float(np.sqrt(np.mean(np.square(audio))))


def calibrate_microphone(cfg: dict[str, Any], interactive: bool = True) -> tuple[dict[str, Any], dict[str, Any]]:
    _, np, _, sd, _ = _deps()
    sr = int(cfg.get("sample_rate", 16000))
    device = _resolve_device(cfg, sd)
    if device is None:
        raise RuntimeError("Nenhum dispositivo de entrada (microfone) foi encontrado.")
    info = sd.query_devices(device)
    if interactive:
        print("\n[CALIBRACAO] Fique em silêncio por 2 segundos...")
    ambient = capture_seconds(sd, np, 2.0, sr, device)
    ambient_rms = rms(np, ambient)
    floor = float(cfg.get("vad_floor", 0.004))
    ceiling = float(cfg.get("vad_ceiling", 0.035))
    mult = float(cfg.get("vad_noise_multiplier", 3.0))
    threshold = max(floor, min(ceiling, ambient_rms * mult))
    cfg["input_device"] = int(device)
    cfg["vad_rms_threshold"] = round(threshold, 6)
    save_config(cfg)
    result = {
        "device": int(device),
        "device_name": str(info.get("name") or device),
        "ambient_rms": round(ambient_rms, 6),
        "threshold": round(threshold, 6),
    }
    _log(f"[CALIBRACAO] mic={result['device']} {result['device_name']} ambient={ambient_rms:.6f} threshold={threshold:.6f}")
    return cfg, result


def doctor(interactive: bool = True, test_wake: bool = False) -> int:
    print("=" * 66)
    print("HAL V30 - DIAGNOSTICO DE VOZ + TELA SEM BOTAO")
    print("=" * 66)
    try:
        keyring, np, requests, sd, WhisperModel = _deps()
    except Exception as exc:
        print(f"[ERRO] Dependencias de voz ausentes: {exc}")
        print("Execute PREPARAR_HALL_VOZ_SEM_BOTAO_V24_2.bat")
        _runtime(status="error", last_error=f"dependencias: {exc}")
        return 2

    cfg = load_config()
    mics = list_microphones(sd)
    if not mics:
        print("[ERRO] Nenhum microfone encontrado pelo sounddevice.")
        _runtime(status="error", last_error="nenhum microfone")
        return 3
    print(f"[OK] Microfones encontrados: {len(mics)}")
    current_device = _resolve_device(cfg, sd)
    for idx, name, ch in mics:
        mark = "*" if idx == current_device else " "
        print(f" {mark} [{idx}] {name} ({ch} canal/canais)")
    if interactive:
        # V24.2.1: seleção robusta. ENTER/A/auto usam o dispositivo já marcado com *.
        # Entrada inválida não encerra mais o diagnóstico: apenas pede novamente.
        valid_ids = {x[0] for x in mics}
        while True:
            choice = input(
                f"Microfone a usar [{current_device}] "
                "(ENTER/A=automatico, numero ou parte do nome): "
            ).strip()
            normalized = _norm(choice)

            if not choice or normalized in {
                "a", "auto", "automatico", "automatic", "default", "padrao"
            }:
                print(f"[AUTO] Usando o microfone marcado [{current_device}].")
                break

            if normalized.isdigit():
                chosen = int(normalized)
                if chosen in valid_ids:
                    cfg["input_device"] = chosen
                    save_config(cfg)
                    current_device = chosen
                    print(f"[OK] Microfone [{chosen}] selecionado.")
                    break
                print(
                    f"[AVISO] O indice {chosen} nao pertence a um dispositivo de entrada. "
                    "Digite um dos numeros mostrados acima, A ou ENTER."
                )
                continue

            # Também aceita parte do nome do dispositivo.
            matches = [
                (idx, name) for idx, name, _ch in mics
                if normalized and normalized in _norm(name)
            ]
            if len(matches) == 1:
                chosen = matches[0][0]
                cfg["input_device"] = chosen
                save_config(cfg)
                current_device = chosen
                print(f"[OK] Microfone [{chosen}] {matches[0][1]} selecionado.")
                break
            if len(matches) > 1:
                print("[AVISO] Nome corresponde a mais de um microfone:")
                for idx, name in matches:
                    print(f"  [{idx}] {name}")
                print("Digite o numero exato, A ou ENTER.")
                continue

            print(
                f"[AVISO] Opcao {choice!r} nao reconhecida. "
                "Digite A/ENTER para automatico ou um numero da lista."
            )

    try:
        cfg, cal = calibrate_microphone(cfg, interactive=interactive)
        print(f"[OK] Microfone: {cal['device_name']}")
        print(f"[OK] Ruido ambiente RMS: {cal['ambient_rms']}")
        print(f"[OK] Threshold VAD: {cal['threshold']}")
    except Exception as exc:
        print(f"[ERRO] Falha ao capturar audio: {exc}")
        _runtime(status="error", last_error=f"captura: {exc}")
        return 4

    username = str(cfg.get("username") or "").strip()
    if not username:
        print("[AVISO] Usuario ainda nao configurado.")
    else:
        try:
            pwd = keyring.get_password(SERVICE_NAME, username)
            print("[OK] Credencial no Windows Credential Manager." if pwd else "[ERRO] Senha não encontrada no Windows Credential Manager.")
        except Exception as exc:
            print(f"[AVISO] Credential Manager: {exc}")

    if test_wake:
        print("\n[TESTE WAKE] Quando aparecer 'FALE AGORA', diga claramente: HAL ativar")
        input("Pressione ENTER para iniciar o teste de 5 segundos...")
        print("FALE AGORA: HAL ativar")
        try:
            audio = capture_seconds(sd, np, 5.0, int(cfg.get("sample_rate", 16000)), _resolve_device(cfg, sd))
            voice_rms = rms(np, audio)
            print(f"[AUDIO] RMS do teste: {voice_rms:.6f}")
            model_name = str(cfg.get("stt_model") or "base")
            print(f"[STT] Carregando {model_name}. Na primeira vez pode baixar o modelo...")
            model = WhisperModel(model_name, device=cfg.get("device", "cpu"), compute_type=cfg.get("compute_type", "int8"))
            lang = "pt"
            segments, _ = _transcribe_with_wake_hint(model, audio, language=lang, beam_size=5)
            text = " ".join(s.text.strip() for s in segments if s.text.strip()).strip()
            print(f"[STT] Reconhecido: {text!r}")
            wake, _, matched = phrase_match(text, LANG["pt-BR"]["wake"])
            if wake:
                print(f"[OK] Wake phrase reconhecida ({matched}).")
                cfg["setup_completed"] = True
                save_config(cfg)
                _runtime(status="doctor_ok", last_transcript=text, threshold=cfg.get("vad_rms_threshold"))
                return 0
            print("[ERRO] O áudio foi capturado, mas 'HAL ativar' não foi reconhecido.")
            print("Tente falar mais próximo do microfone ou escolher outro dispositivo.")
            _runtime(status="error", last_error="wake phrase nao reconhecida", last_transcript=text)
            return 5
        except Exception as exc:
            print(f"[ERRO] Teste de wake falhou: {exc}")
            _runtime(status="error", last_error=f"wake test: {exc}")
            return 6

    _runtime(status="doctor_ok", threshold=cfg.get("vad_rms_threshold"))
    return 0


def configure() -> int:
    try:
        keyring, _, requests, _, _ = _deps()
    except Exception:
        print("[ERRO] Dependências ausentes. Execute PREPARAR_HALL_VOZ_SEM_BOTAO_V24_2.bat")
        return 2
    cfg = load_config()
    print("HAL V24.2 - Configuração do companion de voz")
    url = input(f"URL da HAL [{cfg['url']}]: ").strip() or cfg["url"]
    username = input(f"Usuário [{cfg.get('username','')}]: ").strip() or cfg.get("username", "")
    if not username:
        print("Usuário é obrigatório.")
        return 2
    password = getpass.getpass("Senha (Windows Credential Manager): ")
    if not password:
        print("Senha vazia não é permitida.")
        return 2
    cfg["url"] = url.rstrip("/")
    cfg["username"] = username
    save_config(cfg)
    keyring.set_password(SERVICE_NAME, username, password)
    print("[OK] Credenciais protegidas no Windows Credential Manager.")
    # Validate login immediately so bad credentials don't fail silently later.
    try:
        s = requests.Session()
        r = s.post(cfg["url"] + "/api/auth/login", json={"username": username, "password": password}, timeout=30)
        r.raise_for_status()
        me = s.get(cfg["url"] + "/api/auth/me", timeout=30)
        me.raise_for_status()
        print(f"[OK] Login validado: {(me.json().get('user') or {}).get('display_name') or username}")
    except Exception as exc:
        print(f"[ERRO] Não consegui autenticar na HAL: {exc}")
        print("Confirme se o backend está iniciado e se usuário/senha estão corretos.")
        return 3
    return 0


class Speaker:
    """Saída de voz robusta para o companion Windows.

    V24.2.5:
    - Windows SAPI via PowerShell é o backend padrão no Windows;
    - pyttsx3 permanece como fallback;
    - mantém timestamp de fim da fala para impedir que o microfone interprete
      o eco da própria HAL como uma nova fala/barge-in.
    """

    def __init__(self, cfg: dict[str, Any] | None = None):
        self.cfg = cfg or {}
        self.q: queue.Queue[tuple[str, str] | None] = queue.Queue()
        self.speaking = threading.Event()
        self.engine = None
        self.last_started = 0.0
        self.last_finished = 0.0
        self.last_error = ""
        self.backend = str(self.cfg.get("tts_backend") or "windows_sapi").strip().lower()
        threading.Thread(target=self._run, daemon=True).start()

    def _init_pyttsx3(self):
        if self.engine is not None:
            return
        try:
            import pyttsx3
            self.engine = pyttsx3.init()
            try:
                self.engine.setProperty("rate", 178)
            except Exception:
                pass
        except Exception as exc:
            self.last_error = str(exc)
            _log(f"[TTS] pyttsx3 indisponível: {exc}")
            self.engine = None

    def _windows_sapi_speak(self, payload: str) -> bool:
        if os.name != "nt":
            return False
        encoded = base64.b64encode(payload.encode("utf-8")).decode("ascii")
        script = (
            "$ErrorActionPreference='Stop';"
            "Add-Type -AssemblyName System.Speech;"
            f"$b='{encoded}';"
            "$t=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b));"
            "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
            "$s.Volume=100;$s.Rate=0;"
            "$s.Speak($t);"
            "$s.Dispose();"
        )
        try:
            r = subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
                capture_output=True,
                text=True,
                timeout=max(15, min(180, 8 + len(payload) // 10)),
            )
            if r.returncode == 0:
                return True
            self.last_error = (r.stderr or r.stdout or f"PowerShell rc={r.returncode}").strip()
            _log(f"[TTS/SAPI] {self.last_error}")
            return False
        except Exception as exc:
            self.last_error = str(exc)
            _log(f"[TTS/SAPI] {exc}")
            return False

    def _pyttsx3_speak(self, payload: str) -> bool:
        self._init_pyttsx3()
        if not self.engine:
            return False
        try:
            self.engine.say(payload)
            self.engine.runAndWait()
            return True
        except Exception as exc:
            self.last_error = str(exc)
            _log(f"[TTS/pyttsx3] {exc}")
            return False

    def _speak_text(self, payload: str) -> None:
        ok = False
        if self.backend in {"windows_sapi", "sapi", "auto"}:
            ok = self._windows_sapi_speak(payload)
        if not ok:
            ok = self._pyttsx3_speak(payload)
        if not ok and self.backend not in {"windows_sapi", "sapi", "auto"}:
            ok = self._windows_sapi_speak(payload)
        if not ok:
            _log("HAL (sem áudio): " + payload)

    def _run(self):
        try:
            import winsound
        except Exception:
            winsound = None
        while True:
            item = self.q.get()
            if item is None:
                return
            kind, payload = item
            try:
                self.last_started = time.time()
                self.speaking.set()
                if kind == "wav" and winsound is not None:
                    winsound.PlaySound(payload, winsound.SND_FILENAME)
                else:
                    self._speak_text(payload)
            except Exception as exc:
                self.last_error = str(exc)
                _log(f"[TTS] {exc}")
            finally:
                self.last_finished = time.time()
                self.speaking.clear()

    def say(self, text: str):
        if text:
            self.q.put(("text", text))

    def play_wav(self, path: str):
        if path:
            self.q.put(("wav", path))

    def wait_until_idle(self, timeout: float = 60.0) -> bool:
        deadline = time.time() + max(0.5, float(timeout))
        # Espera a fila começar a ser processada.
        while time.time() < deadline and not self.q.empty() and not self.speaking.is_set():
            time.sleep(0.03)
        while time.time() < deadline:
            if not self.speaking.is_set() and self.q.empty():
                return True
            time.sleep(0.05)
        return False

    def stop(self):
        try:
            if self.engine:
                self.engine.stop()
        except Exception:
            pass
        try:
            import winsound
            winsound.PlaySound(None, winsound.SND_PURGE)
        except Exception:
            pass
        while not self.q.empty():
            try:
                self.q.get_nowait()
            except Exception:
                break



class HallNativeVoice:
    def __init__(self, cfg: dict[str, Any]):
        keyring, np, requests, sd, WhisperModel = _deps()
        self.keyring, self.np, self.requests, self.sd, self.WhisperModel = keyring, np, requests, sd, WhisperModel
        self.cfg = cfg
        self.http = requests.Session()
        self.active = False
        self.wake_phrases: list[str] = []
        self.sleep_phrases: list[str] = []
        self.last_heartbeat = 0.0
        self.conversation_id = ""
        self.language = "pt-BR"
        self.speaker = Speaker(cfg)
        self.running = True
        self.ignore_mic_until = 0.0
        self.audio_q: queue.Queue[Any] = queue.Queue(maxsize=400)
        self.input_device = _resolve_device(cfg, sd)
        if self.input_device is None:
            raise RuntimeError("Nenhum microfone de entrada foi encontrado.")
        try:
            devinfo = sd.query_devices(self.input_device)
            self.input_name = str(devinfo.get("name") or self.input_device)
        except Exception:
            self.input_name = str(self.input_device)
        _runtime(status="starting", microphone=self.input_name, input_device=self.input_device)

        if bool(cfg.get("auto_calibrate", True)):
            try:
                self.cfg, _ = calibrate_microphone(self.cfg, interactive=False)
            except Exception as exc:
                _log(f"[CALIBRACAO] Usando threshold salvo; calibração automática falhou: {exc}")

        model_name = str(cfg.get("stt_model") or "small")
        _log(f"[STT] Carregando faster-whisper {model_name} em {cfg.get('device','cpu')}/{cfg.get('compute_type','int8')}...")
        self.model = WhisperModel(model_name, device=cfg.get("device", "cpu"), compute_type=cfg.get("compute_type", "int8"))
        self._login()
        _runtime(status="ready", microphone=self.input_name, input_device=self.input_device, threshold=self.cfg.get("vad_rms_threshold"), language=self.language)

    def _login(self):
        username = str(self.cfg.get("username") or "").strip()
        password = self.keyring.get_password(SERVICE_NAME, username)
        if not username or not password:
            raise RuntimeError("Credenciais não configuradas. Rode PREPARAR_HALL_VOZ_SEM_BOTAO_V24_2.bat")
        r = self.http.post(self.cfg["url"] + "/api/auth/login", json={"username": username, "password": password}, timeout=30)
        r.raise_for_status()
        me = self.http.get(self.cfg["url"] + "/api/auth/me", timeout=30)
        me.raise_for_status()
        user = me.json().get("user") or {}
        self.language = user.get("preferred_language") or "pt-BR"
        _log(f"[OK] Autenticado como {user.get('display_name') or username} • {self.language}")
        self._load_server_voice_state()
        self._heartbeat(force=True)

    def _load_server_voice_state(self):
        local = LANG.get(self.language, LANG["pt-BR"])
        try:
            r = self.http.get(self.cfg["url"] + "/api/voice-presence/status", timeout=20)
            r.raise_for_status()
            data = r.json()
            prefs = data.get("preferences") or {}
            phrases = data.get("phrases") or {}
            self.wake_phrases = list(prefs.get("wake_phrases") or phrases.get("activate") or local["wake"])
            self.sleep_phrases = list(prefs.get("sleep_phrases") or phrases.get("deactivate") or local["sleep"])
            self.active = bool(data.get("active", False))
        except Exception as exc:
            _log(f"[VOICE PREFS] fallback local: {exc}")
            self.wake_phrases = list(local["wake"])
            self.sleep_phrases = list(local["sleep"])

    def _heartbeat(self, force: bool = False):
        now = time.time()
        if not force and now - self.last_heartbeat < 8.0:
            return
        try:
            r = self.http.post(self.cfg["url"] + "/api/voice-presence/native-heartbeat", json={"active": bool(self.active), "source": "windows_native_v30"}, timeout=10)
            if r.status_code == 401:
                self._login()
                return
            r.raise_for_status()
            self.last_heartbeat = now
            _runtime(status="ready", active=self.active, heartbeat_at=_now(), microphone=self.input_name, threshold=self.cfg.get("vad_rms_threshold"))
        except Exception as exc:
            _runtime(status="degraded", last_error=f"heartbeat: {exc}")

    def _sync_command(self, text: str) -> dict[str, Any]:
        try:
            r = self.http.post(self.cfg["url"] + "/api/voice-presence/interpret", json={"transcript": text, "source": "windows_native_v30"}, timeout=20)
            if r.status_code == 401:
                self._login()
                r = self.http.post(self.cfg["url"] + "/api/voice-presence/interpret", json={"transcript": text, "source": "windows_native_v30"}, timeout=20)
            r.raise_for_status()
            data = r.json()
            self.active = bool(data.get("active", self.active))
            self._heartbeat(force=True)
            return data
        except Exception as exc:
            _log(f"[VOICE COMMAND] {exc}")
            return {}

    def _flush_audio_queue(self):
        while True:
            try:
                self.audio_q.get_nowait()
            except Exception:
                break

    def _say_and_settle(self, message: str, timeout: float = 90.0):
        """Fala e elimina o eco residual antes de voltar a ouvir."""
        if not message:
            return
        self.speaker.say(message)
        self.speaker.wait_until_idle(timeout=timeout)
        self._flush_audio_queue()
        settle_ms = max(150, int(self.cfg.get("post_tts_ignore_ms", 650)))
        self.ignore_mic_until = time.time() + settle_ms / 1000.0

    def _callback(self, indata, frames, time_info, status):
        try:
            self.audio_q.put_nowait(indata.copy())
        except queue.Full:
            try:
                self.audio_q.get_nowait()
            except Exception:
                pass

    def _transcribe(self, audio) -> str:
        lang = LANG.get(self.language, LANG["pt-BR"])["whisper"]
        if not self.active:
            segments, _ = _transcribe_with_wake_hint(self.model, audio, language=lang, beam_size=3)
        else:
            segments, _ = self.model.transcribe(
                audio,
                language=lang,
                beam_size=1,
                vad_filter=True,
                condition_on_previous_text=False,
            )
        return " ".join(s.text.strip() for s in segments if s.text.strip()).strip()

    def _speak_response(self, answer: str):
        answer = str(answer or "").strip()
        if not answer:
            return
        _log("HAL: " + answer[:1000])
        try:
            vr = self.http.post(self.cfg["url"] + "/api/natural-voice-v24/synthesize", json={"text": answer}, timeout=240)
            if vr.status_code == 401:
                self._login()
                vr = self.http.post(self.cfg["url"] + "/api/natural-voice-v24/synthesize", json={"text": answer}, timeout=240)
            vr.raise_for_status()
            voice = vr.json()
            audio_url = str(voice.get("audio_url") or "")
            spoken = str((voice.get("spoken") or {}).get("spoken_text") or answer)
            if audio_url:
                _log(f"[TTS] Reproduzindo áudio neural: {audio_url}")
                ar = self.http.get(self.cfg["url"] + audio_url, timeout=120)
                ar.raise_for_status()
                outdir = DATA / "generated_audio_v24"
                outdir.mkdir(parents=True, exist_ok=True)
                wav = outdir / (Path(audio_url).name or "hall_v30.wav")
                wav.write_bytes(ar.content)
                self.speaker.play_wav(str(wav))
            else:
                _log(f"[TTS] Falando via {self.speaker.backend}: {spoken[:180]}")
                self.speaker.say(spoken)
        except Exception as exc:
            _log(f"[VOICE V30] fallback: {exc}")
            self.speaker.say(answer)

    def _turn(self, text: str):
        if not text:
            return
        _log("Você: " + text)
        if is_voice_screen_command(text):
            _log("[V30 SCREEN] Comando de tela detectado por voz.")
            payload = {"transcript": text, "session_id": self.conversation_id, "source": "windows_native_v30"}
            r = self.http.post(self.cfg["url"] + "/api/v30/voice-screen/analyze", json=payload, timeout=300)
            if r.status_code == 401:
                self._login()
                r = self.http.post(self.cfg["url"] + "/api/v30/voice-screen/analyze", json=payload, timeout=300)
            r.raise_for_status()
            data = r.json()
            answer = str(data.get("answer") or data.get("summary") or data.get("error") or "Não consegui analisar a tela.")
            self._speak_response(answer)
            return

        payload = {"message": text, "session_id": self.conversation_id, "approved": False, "run_tools": True}
        r = self.http.post(self.cfg["url"] + "/api/unified/human-conversation/converse", json=payload, timeout=300)
        if r.status_code == 401:
            self._login()
            r = self.http.post(self.cfg["url"] + "/api/unified/human-conversation/converse", json=payload, timeout=300)
        r.raise_for_status()
        data = r.json()
        self.conversation_id = data.get("session_id") or self.conversation_id
        answer = str(data.get("answer") or "")
        self._speak_response(answer)

    def run(self):
        sr = int(self.cfg.get("sample_rate", 16000))
        block_ms = int(self.cfg.get("block_ms", 100))
        block = max(320, int(sr * block_ms / 1000))
        threshold = float(self.cfg.get("vad_rms_threshold", 0.010))
        silence_blocks = max(3, int(max(2200, int(self.cfg.get("silence_ms", 2200))) / block_ms))
        min_blocks = max(2, int(self.cfg.get("min_speech_ms", 250) / block_ms))
        max_blocks = max(20, int(float(self.cfg.get("max_speech_seconds", 60)) * 1000 / block_ms))
        speech: list[Any] = []
        silence = 0
        _log(f"[READY] Microfone: {self.input_name} | threshold={threshold:.6f}")
        _log("[READY] Diga 'HAL ativar'. Para sair da conversa diga 'HAL desativar'.")
        _runtime(status="ready", microphone=self.input_name, threshold=threshold, active=self.active)
        with self.sd.InputStream(samplerate=sr, channels=1, dtype="float32", blocksize=block, callback=self._callback, device=self.input_device):
            while self.running:
                chunk = self.audio_q.get()
                self._heartbeat()
                # Nunca deixe a HAL cortar a própria voz por eco do alto-falante.
                if self.speaker.speaking.is_set():
                    if bool(self.cfg.get("native_barge_in", False)):
                        # Barge-in nativo fica desativado por padrão até haver AEC real.
                        pass
                    speech, silence = [], 0
                    continue
                if time.time() < float(getattr(self, "ignore_mic_until", 0.0)):
                    speech, silence = [], 0
                    continue
                if self.speaker.last_finished and (
                    time.time() - self.speaker.last_finished
                    < max(0.15, float(self.cfg.get("post_tts_ignore_ms", 650)) / 1000.0)
                ):
                    speech, silence = [], 0
                    continue

                current_rms = rms(self.np, chunk)
                voice = current_rms >= threshold
                if voice or speech:
                    speech.append(chunk[:, 0])
                    silence = 0 if voice else silence + 1
                if speech and (silence >= silence_blocks or len(speech) >= max_blocks):
                    if len(speech) >= min_blocks:
                        audio = self.np.concatenate(speech).astype("float32")
                        try:
                            text = self._transcribe(audio)
                        except Exception as exc:
                            _log(f"[STT] {exc}")
                            text = ""
                        if text:
                            _runtime(last_transcript=text, active=self.active, status="ready")
                            _log(f"[STT] {text}")
                            wake, remainder, matched = phrase_match(text, self.wake_phrases or LANG.get(self.language, LANG["pt-BR"])["wake"])
                            sleep, _, smatched = phrase_match(text, self.sleep_phrases or LANG.get(self.language, LANG["pt-BR"])["sleep"])
                            if not self.active:
                                if wake:
                                    _log(f"[WAKE] Reconhecido: {matched}")
                                    data = self._sync_command(text)
                                    self.active = bool(data.get("active", True))
                                    self._say_and_settle(str(data.get("reply") or LANG.get(self.language, LANG["pt-BR"])["on"]))
                                    query = str(data.get("query") or remainder or "").strip()
                                    if query:
                                        self._turn(query)
                            elif sleep:
                                _log(f"[SLEEP] Reconhecido: {smatched}")
                                data = self._sync_command(text)
                                self.active = bool(data.get("active", False))
                                self._say_and_settle(str(data.get("reply") or LANG.get(self.language, LANG["pt-BR"])["off"]))
                            else:
                                self._turn(text)
                    speech, silence = [], 0



def test_tts(interactive: bool = True) -> int:
    """Teste audível da saída de voz do companion."""
    cfg = load_config()
    print("=" * 66)
    print("HAL V30 - TESTE DE SAIDA DE VOZ")
    print("=" * 66)
    print(f"[TTS] Backend configurado: {cfg.get('tts_backend', 'windows_sapi')}")
    sp = Speaker(cfg)
    phrase = "Teste de voz da HAL. Se você está ouvindo esta frase, a saída de áudio está funcionando."
    print("[TTS] Falando agora...")
    sp.say(phrase)
    ok_wait = sp.wait_until_idle(timeout=45)
    if not ok_wait:
        print("[ERRO] O sintetizador não terminou dentro do tempo esperado.")
        return 8
    if interactive:
        answer = input("Voce ouviu a HAL? [S/n]: ").strip().lower()
        if answer in {"n", "nao", "não", "no"}:
            print("[ERRO] O software executou o TTS, mas nenhum áudio foi ouvido.")
            print("Verifique o dispositivo de SAÍDA padrão do Windows, volume/mute e Bluetooth.")
            return 9
    print("[OK] Teste de saída de voz concluído.")
    return 0



def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--configure", action="store_true")
    ap.add_argument("--doctor", action="store_true")
    ap.add_argument("--test-wake", action="store_true")
    ap.add_argument("--calibrate", action="store_true")
    ap.add_argument("--test-tts", action="store_true")
    args = ap.parse_args()
    try:
        if args.configure:
            return configure()
        if args.doctor or args.test_wake:
            return doctor(interactive=True, test_wake=bool(args.test_wake))
        if args.test_tts:
            return test_tts(interactive=True)
        if args.calibrate:
            cfg, result = calibrate_microphone(load_config(), interactive=True)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        HallNativeVoice(load_config()).run()
        return 0
    except KeyboardInterrupt:
        _runtime(status="stopped", last_error="")
        return 0
    except Exception as exc:
        tb = traceback.format_exc()
        _log(f"[ERRO FATAL] {exc}\n{tb}")
        _runtime(status="error", last_error=str(exc), traceback=tb[-5000:])
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
