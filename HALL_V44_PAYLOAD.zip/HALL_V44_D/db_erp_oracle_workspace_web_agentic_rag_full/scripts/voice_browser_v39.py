"""Loopback-only audio bridge. Browser applies its supported AEC/noise suppression."""
import base64, json, queue, secrets, subprocess, threading, time, webbrowser
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

class BrowserSpeaker:
    def __init__(self,bridge):
        self.bridge=bridge;self.lock=threading.RLock();self.epoch=0;self.process=None
        self.q=queue.Queue();self.speaking=threading.Event();self.paused=False
        self.backend='windows_sapi_browser';self.last_finished=0;self.last_error=''
        self.audio=None;self.text='';self.last_started=0
        threading.Thread(target=self._run,daemon=True).start()
    def say(self,text):
        if text:
            with self.lock:self.q.put((self.epoch,str(text)))
    def hold(self,value):
        with self.lock:self.paused=bool(value)
    def stop(self):
        with self.lock:
            self.epoch+=1;self.audio=None;self.speaking.clear();self.paused=False
            if self.process and self.process.poll() is None:self.process.terminate()
    def finished(self,ident):
        with self.lock:
            if self.audio==ident:self.audio=None;self.speaking.clear();self.last_finished=time.time()
    def state(self):
        with self.lock:return {'epoch':self.epoch,'audio':self.audio,'paused':self.paused,'answer':self.text,'tts_error':self.last_error}
    def _run(self):
        while True:
            epoch,text=self.q.get();proc=None
            ident=secrets.token_hex(12)+'.wav';out=self.bridge.audio_dir/ident
            encoded=base64.b64encode(text.encode()).decode()
            path64=base64.b64encode(str(out).encode()).decode()
            script=("$ErrorActionPreference='Stop';Add-Type -AssemblyName System.Speech;"+
                    "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"+
                    "$t=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+encoded+"'));"+
                    "$p=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+path64+"'));"+
                    "$s.SetOutputToWaveFile($p);$s.Speak($t);$s.Dispose();")
            try:
                with self.lock:
                    if epoch!=self.epoch:continue
                    self.text=text;self.last_error=''
                    proc=subprocess.Popen(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));self.process=proc
                proc.wait(timeout=180)
                with self.lock:
                    if epoch!=self.epoch:continue
                    if proc.returncode or not out.is_file():raise RuntimeError('Falha na voz Windows SAPI.')
                    self.audio=ident;self.speaking.set();self.last_started=time.time()
                # Keep only recent generated audio; not microphone recordings.
                for f in sorted(self.bridge.audio_dir.glob('*.wav'),key=lambda f:f.stat().st_mtime)[:-5]:
                    try:f.unlink()
                    except OSError:pass
            except Exception as exc:
                if proc and proc.poll() is None:proc.kill();proc.wait()
                self.last_error=str(exc)
            finally:
                with self.lock:
                    if self.process is proc:self.process=None
                if epoch!=self.epoch:out.unlink(missing_ok=True)

class Bridge:
    def __init__(self,folder,port=8769):
        self.root=Path(__file__).parent/'voice_v39_web';self.audio_dir=Path(folder)/'tts_v39';self.audio_dir.mkdir(parents=True,exist_ok=True)
        self.token=secrets.token_urlsafe(32);self.port=port;self.last_audio=0;self.last_seq=-1
        self.frames=queue.Queue(maxsize=30);self.controls=queue.Queue(maxsize=20)
        self.info={'status':'Aguardando microfone','registered':False,'active':False}
        self.settings={};self.speaker=None;self.lock=threading.RLock();self.connected=False
        bridge=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def reply(self,status,body,mime='application/json'):
                if not isinstance(body,bytes):body=json.dumps(body,ensure_ascii=False).encode()
                self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(body)))
                self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
                self.send_header('Referrer-Policy','no-referrer')
                self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; media-src 'self' blob:; worker-src 'self'; frame-ancestors 'none'")
                self.end_headers();self.wfile.write(body)
            def allowed(self,auth=True):
                origin='http://127.0.0.1:'+str(bridge.port)
                if self.headers.get('Host')!=origin.split('//')[1]:return False
                if self.headers.get('Origin') not in {None,origin}:return False
                return not auth or secrets.compare_digest(self.headers.get('Authorization',''),'Bearer '+bridge.token)
            def do_GET(self):
                path=urlsplit(self.path).path
                public={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/capture.js':'capture.js'}
                if not self.allowed(path not in public):self.reply(403,{'error':'Acesso não autorizado'});return
                if path in public:
                    file=bridge.root/public[path];mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'}[file.suffix]
                    self.reply(200,file.read_bytes(),mime)
                elif path=='/state':
                    with bridge.lock:data={**bridge.info,'settings':bridge.settings,**(bridge.speaker.state() if bridge.speaker else {})}
                    self.reply(200,data)
                elif path.startswith('/wav/') and bridge.speaker and path[5:]==bridge.speaker.state()['audio']:
                    try:self.reply(200,(bridge.audio_dir/path[5:]).read_bytes(),'audio/wav')
                    except OSError:self.reply(404,{'error':'Áudio indisponível'})
                else:self.reply(404,{'error':'Não encontrado'})
            def do_POST(self):
                if not self.allowed():self.reply(403,{'error':'Acesso não autorizado'});return
                try:
                    length=int(self.headers.get('Content-Length','0'))
                    if not 0<length<=32000:raise ValueError('Tamanho inválido')
                    raw=self.rfile.read(length)
                    if self.path=='/capture':
                        seq=int(self.headers.get('X-Audio-Sequence','-1'))
                        if len(raw)!=6400:raise ValueError('Esperados 1600 samples float32 mono / 16 kHz.')
                        with bridge.lock:
                            if not bridge.connected:raise ValueError('Microfone desligado. Inicie a captura primeiro.')
                            if seq<=bridge.last_seq:raise ValueError('Áudio fora de ordem. Reinicie o microfone.')
                            bridge.last_seq=seq;bridge.last_audio=time.monotonic()
                            try:bridge.frames.put_nowait(raw)
                            except queue.Full:raise ValueError('Processamento atrasado. Pare e reinicie o microfone.')
                    elif self.path=='/control':
                        data=json.loads(raw);op=data.get('action')
                        if op not in {'enroll','delete','standby','disconnect','start','finished','settings','playing','preferences','push_start','push_end'}:raise ValueError('Ação inválida')
                        if op=='finished':
                            if bridge.speaker:bridge.speaker.finished(data.get('id'))
                        elif op=='playing':
                            if bridge.speaker and hasattr(bridge.speaker,'playing'):bridge.speaker.playing(data.get('id'))
                        elif op=='preferences':
                            if not hasattr(bridge,'set_preferences'):raise ValueError('Ajustes não disponíveis neste cliente.')
                            bridge.set_preferences(data.get('preferences'))
                        elif op in {'push_start','push_end'}:
                            if not hasattr(bridge,'set_preferences') or not bridge.connected:raise ValueError('Ligue o microfone da V41 primeiro.')
                            bridge.controls.put_nowait(op)
                        elif op=='settings':bridge.settings=data.get('settings',{})
                        elif op=='start':
                            bridge.last_seq=-1;bridge.connected=True;bridge.last_audio=time.monotonic()
                        else:
                            if op=='disconnect':bridge.connected=False
                            bridge.controls.put_nowait(op)
                    else:self.reply(404,{'error':'Não encontrado'});return
                    self.reply(200,{'ok':True})
                except (ValueError,KeyError,queue.Full,json.JSONDecodeError) as exc:self.reply(400,{'error':str(exc)})
        self.server=ThreadingHTTPServer(('127.0.0.1',port),Handler)
        self.port=self.server.server_address[1]
    def start(self,open_browser=True):
        threading.Thread(target=self.server.serve_forever,daemon=True).start()
        if open_browser:webbrowser.open('http://127.0.0.1:'+str(self.port)+'/#'+self.token)
    def update(self,**data):
        with self.lock:self.info.update(data)
