from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CFG = ROOT / 'data' / 'enterprise_web_access_v20' / 'config.json'

def read():
    try:
        return json.loads(CFG.read_text(encoding='utf-8-sig'))
    except Exception:
        return {}

cfg=read()
mode=str(cfg.get('mode') or 'LOCAL').upper()
url=str(cfg.get('public_url') or 'http://127.0.0.1:8000').strip().rstrip('/')
secure='1' if url.lower().startswith('https://') else '0'
trust='1' if cfg.get('trust_proxy_headers') else '0'
origins=[url, 'http://127.0.0.1:8000', 'http://localhost:8000']
seen=[]
for x in origins:
    if x and x not in seen: seen.append(x)
print(f'set "HALL_WEB_MODE={mode}"')
print(f'set "HALL_PUBLIC_URL={url}"')
print(f'set "HALL_COOKIE_SECURE={secure}"')
print(f'set "HALL_TRUST_PROXY={trust}"')
print(f'set "HALL_CORS_ORIGINS={",".join(seen)}"')
