from __future__ import annotations
import json, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from fastapi.testclient import TestClient
import types
sys.modules.setdefault('oracledb', types.SimpleNamespace())
from web_app.backend import main

# Isola IAM e Voice Presence para não usar dados reais.
tmp=Path(tempfile.mkdtemp(prefix="hall_v23_http_"))
from services.identity_access import IdentityAccessService
main.STATE.identity_access=IdentityAccessService(tmp/"iam")
import services.voice_presence_v23 as vp
vp.DATA_DIR=tmp/"voice";vp.CONFIG_FILE=vp.DATA_DIR/"config.json";vp.PREFERENCES_FILE=vp.DATA_DIR/"preferences.json";vp.SESSIONS_FILE=vp.DATA_DIR/"sessions.json";vp.AUDIT_FILE=vp.DATA_DIR/"audit.jsonl"

client=TestClient(main.app, base_url="http://127.0.0.1:8000")
tests=[]
def ck(name,cond,detail=""):
    tests.append({"test":name,"ok":bool(cond),"detail":detail})
    if not cond: raise AssertionError(name+" "+detail)

r=client.post('/api/auth/bootstrap',json={'username':'admin','password':'AdminSecure#2026','display_name':'Admin','preferred_language':'pt-BR'})
ck('bootstrap admin',r.status_code==200,r.text)
r=client.get('/api/voice-presence/status');ck('status authenticated',r.status_code==200 and r.json().get('version')=='23.0',r.text)
r=client.post('/api/voice-presence/interpret',json={'transcript':'HAL ativar','source':'test'});ck('activate HTTP',r.status_code==200 and r.json().get('active') is True,r.text)
r=client.post('/api/voice-presence/interpret',json={'transcript':'qual é o status','source':'test'});ck('turn HTTP',r.status_code==200 and r.json().get('action')=='turn',r.text)
r=client.put('/api/voice-presence/preferences',json={'silence_ms':1600,'barge_in':True});ck('save prefs',r.status_code==200 and r.json()['preferences']['silence_ms']==1600,r.text)
r=client.post('/api/voice-presence/interpret',json={'transcript':'HAL desativar','source':'test'});ck('deactivate HTTP',r.status_code==200 and r.json().get('active') is False,r.text)
client.post('/api/auth/logout')
r=client.get('/api/voice-presence/status');ck('requires auth',r.status_code==401,r.text)
print(json.dumps({'ok':all(t['ok'] for t in tests),'passed':sum(t['ok'] for t in tests),'total':len(tests),'tests':tests},ensure_ascii=False,indent=2))
