from __future__ import annotations
import importlib.util
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

spec=importlib.util.spec_from_file_location("vp313", ROOT/"scripts"/"hall_voice_presence_windows_v31_3.py")
vp=importlib.util.module_from_spec(spec); spec.loader.exec_module(vp)
from services import voice_presence_v23 as svc

errors=[]
def ck(name, cond, detail=""):
    print(("[OK] " if cond else "[ERRO] ")+name+(f" :: {detail}" if detail else ""))
    if not cond: errors.append(name)

phr=vp.LANG["pt-BR"]["wake"]
for spoken in ["HAL ativar","Hall ativar","Hal ativar","AI ativar","Aí ativar","Ei ativar","AI, ativar."]:
    ok, rem, matched=vp.phrase_match(spoken,phr)
    ck(f"native reconhece {spoken!r}",ok,f"matched={matched!r} rem={rem!r}")

for spoken in ["ativar","IA generativa","AI inteligente","quero ativar","pode ativar"]:
    ok, rem, matched=vp.phrase_match(spoken,phr)
    ck(f"native NAO ativa com {spoken!r}",not ok,f"matched={matched!r}")

for spoken in ["AI ativar","Aí ativar","Ei ativar","Hal ativar"]:
    p, rem=svc._phrase_match(spoken, list(svc.LANGUAGE_PHRASES["pt-BR"]["activate"]))
    ck(f"backend reconhece alias {spoken!r}",bool(p),f"phrase={p!r} rem={rem!r}")

p, rem=svc._phrase_match("ativar", list(svc.LANGUAGE_PHRASES["pt-BR"]["activate"]))
ck("backend nao aceita ativar sozinho",not bool(p),f"phrase={p!r}")

ok, rem, _=vp.phrase_match("AI ativar veja minha tela",phr)
canon=vp.canonical_wake_text(rem,"pt-BR",phr)
ck("canonicaliza AI para HAL",canon.startswith("hall ativar"),canon)
ck("preserva comando apos wake","veja minha tela" in canon,canon)

print("\nRESULTADO:", "PASS" if not errors else "FAIL")
if errors:
    print("Falhas:", ", ".join(errors)); raise SystemExit(1)
