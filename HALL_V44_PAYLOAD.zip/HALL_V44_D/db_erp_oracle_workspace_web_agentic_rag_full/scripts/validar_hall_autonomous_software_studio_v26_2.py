from __future__ import annotations
import json, tempfile, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from services.autonomous_software_studio_v262 import AutonomousSoftwareStudioV262
from services.production_quality_gates_v262 import ProductionQualityGate

checks=[]
def ck(name,cond,detail=''):
 checks.append({'name':name,'ok':bool(cond),'detail':detail})
 if not cond: raise AssertionError(name+': '+detail)

studio=AutonomousSoftwareStudioV262(ROOT)
b=studio.brainstorm('Quero um CRM para empresa de transporte com Oracle, leads, contratos e perfis de acesso','CRM Test V262')
ck('brainstorm_ok',b.get('ok')); pid=b['project']['id']; ck('questions',len(b.get('questions',[]))>=8)
s=studio.spec(pid,{'users':'Comercial, gerente e admin','deploy':'intranet','backup':'RPO 1h / RTO 4h'})
ck('spec_ok',s.get('ok')); ck('security_baseline_in_spec','Production Security Baseline V26.2' in json.dumps(s,ensure_ascii=False))
p=studio.plan(pid); ck('plan_ok',p.get('ok')); ck('deny_by_default',p['plan']['deploy_policy']=='deny_by_default_until_all_critical_gates_pass')
q=ProductionQualityGate(ROOT); controls=q.required_security_controls(); ck('security_controls',len(controls)>=10); ck('csrf_control','csrf_on_state_changes' in controls)
print(json.dumps({'ok':True,'passed':len(checks),'total':len(checks),'checks':checks},ensure_ascii=False,indent=2))
