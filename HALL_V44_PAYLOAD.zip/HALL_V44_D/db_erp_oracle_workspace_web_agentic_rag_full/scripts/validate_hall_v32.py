from __future__ import annotations

import json
import py_compile
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGE_ROOT = ROOT.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.software_engineering_os import HallSoftwareEngineeringOS
from services.language_manager import SUPPORTED_LANGUAGES
from services.model_lifecycle import ModelLifecycleManager
from services.openclaw_runtime.app_tool_bridge import bridged_tool_ids


def check(name, ok, detail=''):
    return {'name': name, 'ok': bool(ok), 'detail': str(detail)}


def main():
    rows = []
    eng = HallSoftwareEngineeringOS(ROOT)
    preservation = eng.preservation_check()
    rows.append(check('preservation_capability_blocks', preservation.get('ok') and preservation.get('passed') == preservation.get('total'), f"{preservation.get('passed')}/{preservation.get('total')}"))

    sample = eng.assess(
        'Projetar serviço multiusuário FastAPI com Oracle 19c, 100 usuários simultâneos, auditoria, Zabbix/Grafana, backup e segurança.',
        project_name='HAL V32 Self-Test',
    )
    rows.append(check('engineering_assessment', sample.get('ok') and sample.get('requirements') and sample.get('architecture') and sample.get('security') and sample.get('technical_council'), sample.get('run_id')))
    rows.append(check('engineering_deploy_default_denied', not bool((sample.get('engineering_quality_gate') or {}).get('deploy_allowed')), 'deploy_allowed must be false for assessment-only'))

    lang_count = len(SUPPORTED_LANGUAGES)
    rows.append(check('language_catalog_70_plus', lang_count >= 70, f'{lang_count} languages'))

    router = ROOT / 'hall_transporte_agentic_pro' / 'data' / 'multi_model_router' / 'config.json'
    ml = ModelLifecycleManager(ROOT, ROOT / 'data' / 'model_lifecycle_v19', router)
    cfg = ml.config()
    rows.append(check('huggingface_model_lifecycle_enabled', bool(cfg.get('enabled', True)), cfg.get('hf_api_base')))
    rows.append(check('huggingface_auto_scanner_enabled', bool(cfg.get('auto_check_enabled', True)) and callable(getattr(ml, 'start_auto_scanner', None)), f"interval={cfg.get('check_interval_hours')}h approval={cfg.get('require_admin_approval')}"))
    rows.append(check('huggingface_admin_approval', bool(cfg.get('require_admin_approval', True)), 'model update must require admin approval'))

    bridge = set(bridged_tool_ids())
    rows.append(check('openclaw_engineering_bridge', {'software_engineering_status','software_engineering_assess','software_engineering_preservation'}.issubset(bridge), 'OpenClaw can call Engineering OS'))

    py_files = [
        ROOT / 'services/software_engineering_os/orchestrator.py',
        ROOT / 'services/software_engineering_os/requirements_engineer.py',
        ROOT / 'services/software_engineering_os/architecture_engine.py',
        ROOT / 'services/software_engineering_os/security_engineering.py',
        ROOT / 'services/software_engineering_os/quality_engineering.py',
        ROOT / 'services/software_engineering_os/reliability_engineering.py',
        ROOT / 'services/software_engineering_os/database_architect.py',
        ROOT / 'services/software_engineering_os/delivery_engineering.py',
        ROOT / 'services/software_engineering_os/technical_council.py',
        ROOT / 'services/software_engineering_os/capability_preservation.py',
        ROOT / 'services/software_factory/factory.py',
        ROOT / 'services/software_factory/release_manager.py',
        ROOT / 'web_app/backend/main.py',
    ]
    compile_errors = []
    for p in py_files:
        try:
            py_compile.compile(str(p), doraise=True)
        except Exception as exc:
            compile_errors.append(f'{p.relative_to(ROOT)}: {exc}')
    rows.append(check('python_compile', not compile_errors, '; '.join(compile_errors[:5]) or f'{len(py_files)} files'))

    node = shutil.which('node')
    if node:
        js_results = []
        for rel in ['web_app/frontend/unified_app.js', 'web_app/frontend/app.js']:
            proc = subprocess.run([node, '--check', str(ROOT / rel)], capture_output=True, text=True, timeout=30)
            js_results.append((rel, proc.returncode == 0, (proc.stderr or proc.stdout)[-800:]))
        rows.append(check('javascript_syntax', all(x[1] for x in js_results), js_results))
    else:
        rows.append({'name': 'javascript_syntax', 'ok': None, 'detail': 'node not installed; skipped'})

    root_launcher = PACKAGE_ROOT / 'INICIAR_JR_AI_HALL_V32.bat'
    generic = PACKAGE_ROOT / 'INICIAR_JR_AI_HALL.bat'
    launch_text = root_launcher.read_text(encoding='utf-8-sig', errors='ignore') if root_launcher.exists() else ''
    generic_text = generic.read_text(encoding='utf-8-sig', errors='ignore') if generic.exists() else ''
    rows.append(check('v32_direct_launcher', root_launcher.exists() and '/api/v32/status' in launch_text and 'V19.bat' not in launch_text, str(root_launcher)))
    rows.append(check('generic_launcher_points_v32', 'INICIAR_JR_AI_HALL_V32.bat' in generic_text, str(generic)))

    ok = all(r.get('ok') is not False for r in rows)
    report = {
        'ok': ok,
        'version': '32.0',
        'generated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'checks': rows,
        'preservation': preservation,
        'engineering_self_test': {
            'run_id': sample.get('run_id'),
            'next_stage': sample.get('next_stage'),
            'architecture': (sample.get('architecture') or {}).get('recommended_style'),
        },
        'notes': [
            'Hugging Face connectivity itself depends on Internet/DNS/proxy and is validated separately by VALIDAR_HUGGINGFACE_HALL_V32.bat.',
            'External integrations such as GitHub remote, Zabbix and Grafana require their own credentials/endpoints.',
        ],
    }
    out = PACKAGE_ROOT / 'VALIDACAO_HALL_V32.json'
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2, default=str), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2, default=str))
    return 0 if ok else 1


if __name__ == '__main__':
    raise SystemExit(main())
