"""Windows SAPI rendered locally; browser acknowledgments describe delivery."""
import base64
import queue
import secrets
import subprocess
import threading
import time
from voice_browser_v39 import BrowserSpeaker


class ConversationSpeaker(BrowserSpeaker):
    def __init__(self,bridge,rate=0,language='pt-BR',notify=lambda *a:None):
        self.bridge=bridge;self.lock=threading.RLock();self.epoch=0;self.process=None
        self.q=queue.Queue(maxsize=4);self.speaking=threading.Event();self.paused=False
        self.backend='windows_sapi_browser_v41';self.last_finished=0;self.last_error=''
        self.audio=None;self.text='';self.last_started=0;self.turn=None;self.rate=rate;self.language=language
        self.notify=notify;self.events=queue.Queue(maxsize=20);self.changed=threading.Condition(self.lock)
        threading.Thread(target=self._run,daemon=True).start();threading.Thread(target=self._events,daemon=True).start()

    def say(self,text,turn=None):
        if not text:return
        with self.lock:
            try:self.q.put_nowait((self.epoch,str(text),dict(turn) if turn else None))
            except queue.Full:self.last_error='Fila de voz ocupada. Aguarde ou interrompa a resposta.'

    def stop(self):
        with self.changed:
            super().stop();self.turn=None
            while True:
                try:self.q.get_nowait()
                except queue.Empty:break
            self.changed.notify_all()

    def _event(self,status):
        if self.turn:
            try:self.events.put_nowait((self.turn['session_id'],self.turn['seq'],status))
            except queue.Full:self.last_error='Confirmação da reprodução atrasada.'

    def _events(self):
        while True:
            args=self.events.get()
            try:self.notify(*args)
            except Exception:self.last_error='Não consegui confirmar a reprodução no histórico.'

    def playing(self,ident):
        with self.lock:
            if ident==self.audio and self.turn and not self.turn.get('playing'):
                self.turn['playing']=True;self._event('playing')

    def finished(self,ident):
        with self.changed:
            if ident==self.audio:
                self._event('complete');self.turn=None
                super().finished(ident);self.changed.notify_all()

    def _run(self):
        while True:
            epoch,text,turn=self.q.get();proc=None
            ident=secrets.token_hex(12)+'.wav';out=self.bridge.audio_dir/ident
            enc=lambda s:base64.b64encode(str(s).encode()).decode()
            with self.lock:rate=max(-4,min(4,int(self.rate)));language=self.language
            script=("$ErrorActionPreference='Stop';Add-Type -AssemblyName System.Speech;"
              "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
              "$t=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+enc(text)+"'));"
              "$p=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+enc(out)+"'));"
              "$l=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('"+enc(language)+"'));"
              "$v=$s.GetInstalledVoices() | Where-Object {$_.Enabled -and $_.VoiceInfo.Culture.Name -eq $l} | Select-Object -First 1;"
              "if($v){$s.SelectVoice($v.VoiceInfo.Name)};$s.Rate="+str(rate)+";"
              "$s.SetOutputToWaveFile($p);$s.Speak($t);$s.Dispose();")
            try:
                with self.changed:
                    deadline=time.monotonic()+180
                    while self.audio and epoch==self.epoch:
                        if time.monotonic()>deadline:raise RuntimeError('Reprodução não foi confirmada. Reinicie o microfone.')
                        self.changed.wait(.5)
                    if epoch!=self.epoch:continue
                    self.text=text;self.last_error=''
                    proc=subprocess.Popen(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));self.process=proc
                proc.wait(timeout=180)
                with self.lock:
                    if epoch!=self.epoch:continue
                    if proc.returncode or not out.is_file():raise RuntimeError('Falha na voz Windows SAPI.')
                    self.audio=ident;self.turn=turn;self.speaking.set();self.last_started=time.time()
                for f in sorted(self.bridge.audio_dir.glob('*.wav'),key=lambda f:f.stat().st_mtime)[:-5]:
                    try:f.unlink()
                    except OSError:pass
            except Exception as exc:
                if proc and proc.poll() is None:proc.kill();proc.wait()
                self.last_error=str(exc)
            finally:
                with self.lock:
                    if self.process is proc:self.process=None
                if epoch!=self.epoch:out.unlink(missing_ok=True)
