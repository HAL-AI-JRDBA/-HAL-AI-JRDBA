"""Read-only diagnosis of local HAL/Ollama/STT. No credentials or chat capture."""
from __future__ import annotations
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys
import sqlite3
import time
from urllib import error, parse, request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


class NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise ValueError('Redirecionamento recusado no diagnóstico local.')


def local_url(url):
    parts = parse.urlsplit(url)
    if parts.scheme != 'http' or parts.hostname not in {'localhost', '127.0.0.1', '::1'} or parts.username or parts.password:
        raise ValueError('A URL do Ollama deve apontar para este computador.')
    return url.rstrip('/')


def read_json(path, default=None):
    try:
        data = json.loads(Path(path).read_text(encoding='utf-8-sig'))
        return data if isinstance(data, dict) else (default or {})
    except (OSError, ValueError):
        return default or {}


def local_request(url, payload=None, timeout=8):
    local_url(url)
    body = json.dumps(payload).encode('utf-8') if payload is not None else None
    req = request.Request(url, data=body, headers={'Content-Type': 'application/json'})
    opener = request.build_opener(request.ProxyHandler({}), NoRedirect())
    with opener.open(req, timeout=timeout) as response:
        return response.read()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test-model', action='store_true')
    parser.add_argument('--output')
    args = parser.parse_args()
    lines = ['DIAGNÓSTICO HAL V42.5', 'Data: '+datetime.now().astimezone().isoformat(),
             'Instalação: '+str(ROOT), 'Python do diagnóstico: '+sys.executable]
    failures = []

    def record(label, fn):
        print('[CHECK] '+label, flush=True)
        try:
            value = fn()
            lines.append('[OK] '+label+': '+str(value))
            print(lines[-1], flush=True)
            return value
        except Exception as exc:
            text = str(exc)
            lines.append('[FALHA] '+label+': '+text)
            print(lines[-1], flush=True)
            failures.append(label)
            return None

    def source_check():
        main_text = (ROOT/'web_app/backend/main.py').read_text(encoding='utf-8-sig')
        index = (ROOT/'web_app/frontend/index.html').read_text(encoding='utf-8-sig')
        if 'HALL_CHAT_RECOVERY_V42_5' not in main_text or '/static/chat_recovery_v42_5.js' not in index:
            raise ValueError('A correção V42.5 ainda não está aplicada neste projeto.')
        return 'V42.5 presente no backend e na página inicial'
    record('Código instalado', source_check)
    record('Backend na porta 8000', lambda: json.loads(local_request('http://127.0.0.1:8000/api/health')).get('ok','HTTP 200'))
    record('Versão do processo ativo', lambda: json.loads(local_request('http://127.0.0.1:8000/api/v42/runtime-status')).get('version'))
    def served_check():
        expected = (ROOT/'web_app/frontend/chat_recovery_v42_5.js').read_bytes()
        served = local_request('http://127.0.0.1:8000/static/chat_recovery_v42_5.js')
        if hashlib.sha256(expected).digest() != hashlib.sha256(served).digest():
            raise ValueError('A porta 8000 está servindo outro código. Reinicie a HAL pelo iniciador V42.')
        return 'A página serve o código da correção'
    record('Interface servida', served_check)

    config = read_json(ROOT/'data/autonomy_v36/config.json', {'model': 'qwen2.5:7b', 'ollama_url': 'http://127.0.0.1:11435'})
    try:
        from services.gemma4_v42 import overlay_tools_config, prepare_payload
        config = overlay_tools_config(config, ROOT)
    except Exception as exc:
        lines.append('[FALHA] Perfil de modelo: '+str(exc));failures.append('Perfil de modelo')
    model = str(config.get('model') or 'qwen2.5:7b')
    lines.append('Modelo de conversa selecionado: '+model)
    url = record('Endereço local do Ollama', lambda: local_url(str(config.get('ollama_url') or 'http://127.0.0.1:11435')))
    if url:
        tags = record('Ollama e modelos instalados', lambda: [item.get('name') for item in json.loads(local_request(url+'/api/tags')).get('models',[])])
        def model_check():
            if ':cloud' in model.lower() or model.lower().endswith('-cloud'):
                raise ValueError('Modelo remoto selecionado; use um modelo local.')
            metadata = json.loads(local_request(url+'/api/show', {'model': model}))
            if metadata.get('remote_host') or metadata.get('remote_model'):
                raise ValueError('O modelo selecionado aponta para execução remota.')
            return model+' instalado localmente'
        installed = record('Modelo selecionado', model_check) if tags is not None else None
        if installed and args.test_model:
            def generate():
                started = time.monotonic()
                payload = {'model': model, 'messages': [{'role':'user','content':'Responda apenas OK.'}], 'stream':False,
                           'options': {'num_ctx':2048,'num_predict':12,'num_thread':int(config.get('num_thread',4)),'num_gpu':0}}
                try:
                    payload = prepare_payload(payload, ROOT)
                except NameError:
                    pass
                result = json.loads(local_request(url+'/api/chat',payload,timeout=90))
                content = str((result.get('message') or {}).get('content') or '').strip()
                if result.get('error') or not result.get('done') or not content:
                    raise ValueError(str(result.get('error') or 'O modelo não concluiu a resposta curta.'))
                return 'Resposta curta concluída em '+str(round(time.monotonic()-started,1))+' segundos'
            record('Resposta real do modelo (limite 90 segundos)', generate)

    def stt_check():
        from services.local_stt_recovery_v42_5 import status_config
        cfg = read_json(ROOT/'hall_transporte_agentic_pro/data/local_stt_fallback/config.json', {'enabled':True,'model_size':'base'})
        data = status_config(cfg)
        if not data.get('ready'):
            raise ValueError(data.get('error','STT indisponível')+(' '+str(data.get('child_error')) if data.get('child_error') else ''))
        return 'Motor e pesos encontrados; ambiente='+str(data.get('runtime'))+'; modelo='+str(data.get('model'))+'. O teste do microfone deve ser feito na página.'
    record('Transcrição local', stt_check)
    def worker_check():
        database = ROOT/'data/autonomy_v36/runtime.sqlite3'
        if not database.is_file():
            return 'Banco do agente ainda não inicializado; abra o painel Agente local.'
        connection = sqlite3.connect(database.resolve().as_uri()+'?mode=ro', uri=True, timeout=5)
        try:
            row = connection.execute("SELECT value FROM control WHERE key='paused'").fetchone()
            counts = dict(connection.execute('SELECT state,count(*) FROM tasks GROUP BY state').fetchall())
        finally:
            connection.close()
        if row and str(row[0]) == '1':
            raise ValueError('O agente está pausado. Abra Agente local V40 e clique Iniciar / continuar agente. Pedidos de conversa por texto podem funcionar mesmo com o agente pausado.')
        return 'Controle do agente habilitado; estados das missões='+json.dumps(counts)
    record('Controle do agente local', worker_check)
    for relative in ['data/voice_presence_v23/native_runtime_v41.json','data/voice_presence_v23/native_runtime_v39.json']:
        runtime = read_json(ROOT/relative)
        if runtime:
            # Deliberately omit account names, transcripts, replies and credentials.
            lines.append('Estado da voz nativa: '+json.dumps({key:runtime.get(key) for key in ['status','last_error'] if key in runtime},ensure_ascii=False))
    lines += ['', 'Resultado: '+('Falhas em '+', '.join(failures) if failures else 'Verificações concluídas sem falhas.'),
              'Se houver modelo ausente: confira o modelo selecionado e os nomes instalados no Ollama.',
              'Se a voz estiver indisponível: confira o ambiente V39/V41 e os pesos do Whisper. A instalação de voz é feita por INSTALAR_VOZ_HALL_V41.bat.',
              'Se o código servido divergir: feche a HAL, reinicie pelo V42 e recarregue com Ctrl+F5.',
              'Este relatório não contém senhas, cookies nem o histórico da conversa.']
    output = Path(args.output) if args.output else ROOT/'data/logs/DIAGNOSTICO_HALL_V42_5.txt'
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text('\n'.join(lines)+'\n',encoding='utf-8-sig')
    print('[RELATÓRIO] '+str(output),flush=True)
    return 1 if failures else 0


if __name__ == '__main__':
    raise SystemExit(main())
