from __future__ import annotations
import json, shutil, tempfile, time
from types import SimpleNamespace
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from services.reinforcement_learning_lab import ReinforcementLearningLab


def check(name, cond, detail=''):
    if not cond: raise AssertionError(f'{name}: {detail}')
    return {'test':name,'ok':True}


def main():
    tests=[]
    with tempfile.TemporaryDirectory(prefix='hall_rl_v21_') as td:
        t=Path(td); (t/'training').mkdir(); (t/'router').mkdir()
        for n in ['train_dpo.py','train_reward.py','train_grpo.py','hall_train_common.py']:
            shutil.copy2(ROOT/'training'/n,t/'training'/n)
        router=t/'router'/'config.json'; router.write_text(json.dumps({'models':{'chat':'qwen2.5:7b','sql':'sqlcoder:7b-q4_0'}}),encoding='utf-8')
        lab=ReinforcementLearningLab(t,t/'data',router)
        tests.append(check('auto_train_default_off',lab.config().get('auto_train') is False))
        cfg=lab.save_config({'auto_train':True,'min_improvement_percent':3},'admin')
        tests.append(check('auto_train_cannot_be_enabled',cfg.get('auto_train') is False))
        lab.record_experience(source='test',task_type='chat',role='chat',prompt='Explique indice Oracle',response='Indice melhora acesso seletivo.',reward=5,success=True,user_feedback=True)
        lab.record_experience(source='test',task_type='chat',role='chat',prompt='Explique indice Oracle',response='Resposta incorreta.',reward=-3,success=False,user_feedback=False)
        lab.record_experience(source='test',task_type='chat',role='chat',prompt='O que e RAG?',response='RAG recupera contexto antes de gerar resposta.',reward=4,success=True,user_feedback=True)
        st=lab.status(); tests.append(check('experience_store',st['counts']['experiences']==3))
        ds=lab.build_datasets('admin','chat',1.0)
        tests.append(check('preference_dataset_created',ds['preferences']>=1,str(ds)))
        tests.append(check('reward_dataset_created',ds['reward_records']>=3,str(ds)))
        job=lab.create_job(method='dpo',role='chat',actor='admin',dry_run=True,dataset_path=ds['paths']['dpo'])['job']
        tests.append(check('job_pending_approval',job['status']=='pending_approval'))
        try:
            lab.start_job(job['id'],'admin'); blocked=False
        except PermissionError: blocked=True
        tests.append(check('job_cannot_start_without_approval',blocked))
        lab.approve_job(job['id'],'admin',True); started=lab.start_job(job['id'],'admin')['job']
        tests.append(check('dry_run_job_started',started['status']=='running'))
        deadline=time.time()+20; final=None
        while time.time()<deadline:
            final=lab.job(job['id'])
            if final['status'] in {'completed','failed'}: break
            time.sleep(.2)
        tests.append(check('dry_run_job_completed',final and final['status']=='completed',str(final)))
        cand=lab.register_candidate(job['id'],'admin')['candidate']
        tests.append(check('dry_run_candidate_marked',cand['status']=='dry_run_candidate'))
        ev=lab.set_candidate_evaluation(cand['id'],'admin',benchmark={'improvement_percent':99},safety={'passed':True})['candidate']
        tests.append(check('dry_run_evaluation_recorded',ev['status']=='dry_run_evaluated'))
        try:
            lab.promote(cand['id'],'admin',True); blocked=False
        except ValueError: blocked=True
        tests.append(check('dry_run_never_promoted',blocked))
        tests.append(check('similarity_function',lab._similarity('oracle index performance','oracle index performance')>0.99))
        adm=lab.training_admission('dpo','chat',True); tests.append(check('dry_run_admission',adm['allowed']))
        tests.append(check('training_real_is_governed',lab.config()['require_admin_approval'] and lab.config()['require_safety_evaluation']))
        # Full real-candidate governance is tested with local mocks; no model is downloaded.
        with lab._connect() as conn:
            real_id='real-job'; out=t/'real-output'; (out/'adapter').mkdir(parents=True)
            conn.execute("INSERT INTO jobs(id,created_at,updated_at,method,role,model_source,status,approved,approved_by,dry_run,config_json,dataset_path,output_dir,log_path,pid,error,metrics_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(real_id,'now','now','dpo','chat','Qwen/Qwen2.5-7B-Instruct','completed',1,'admin',0,'{}',ds['paths']['dpo'],str(out),str(out/'log'),0,'','{}'))
        real=lab.register_candidate(real_id,'admin',candidate_model='hall-chat-rl-test')['candidate']; tests.append(check('real_candidate_adapter_ready',real['status']=='adapter_ready'))
        import services.reinforcement_learning_lab as rlm
        old_which, old_run = rlm.shutil.which, rlm.subprocess.run
        try:
            rlm.shutil.which=lambda name: '/fake/ollama' if name=='ollama' else old_which(name)
            def fake_run(cmd,*a,**k):
                if cmd[:2]==['ollama','list']: return SimpleNamespace(returncode=0,stdout='NAME\nhall-chat-rl-test latest\n',stderr='')
                if cmd[:2]==['ollama','create']: return SimpleNamespace(returncode=0,stdout='created',stderr='')
                if cmd[:2]==['ollama','run']: return SimpleNamespace(returncode=0,stdout='OK',stderr='')
                return old_run(cmd,*a,**k)
            rlm.subprocess.run=fake_run
            mat=lab.materialize_candidate(real['id'],'admin',True)['candidate']; tests.append(check('ollama_materialization_flow',mat['status']=='ready_for_evaluation'))
            # Add enough references for automatic benchmark.
            for i in range(3): lab.record_experience(source='benchmark',task_type='chat',role='chat',prompt=f'Pergunta {i}',response=f'Resposta correta {i}',reward=5,success=True)
            def fake_gen(model,prompt,timeout=180):
                if 'permiss' in prompt.lower() or 'drop table' in prompt.lower() or 'senhas' in prompt.lower() or 'desative' in prompt.lower(): return 'Não posso fazer isso sem autorização e aprovação do administrador por segurança.'
                return ('Resposta correta '+prompt.split()[-1]) if model=='hall-chat-rl-test' else 'resposta parcial'
            lab._ollama_generate=fake_gen
            auto=lab.evaluate_candidate_automatic(real['id'],'admin',3); tests.append(check('automatic_ab_benchmark',auto['benchmark']['automatic'] and auto['benchmark']['improvement_percent']>0))
            tests.append(check('automatic_safety_probe',auto['safety']['automatic'] and auto['safety']['passed']))
            promoted=lab.promote(real['id'],'admin',True); tests.append(check('governed_promotion',promoted['to']=='hall-chat-rl-test'))
            rolled=lab.rollback('chat','admin',True); tests.append(check('rl_router_rollback',rolled['to']=='qwen2.5:7b'))
        finally:
            rlm.shutil.which, rlm.subprocess.run = old_which, old_run
    result={'ok':True,'version':'V21','passed':len(tests),'total':len(tests),'tests':tests}
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
