"""Windows-friendly installation checks; no documents or users are published."""
from __future__ import annotations
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
from urllib.parse import urlsplit

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))


def main():
    from verify_complete_v42 import verify
    failed = False
    try:
        verify(PROJECT.parent)
    except Exception as exc:
        print('[ERRO] Inventario:', exc)
        failed = True
    for name in ['fastapi', 'uvicorn', 'requests', 'pypdf', 'docx', 'pptx', 'reportlab']:
        try:
            importlib.import_module(name)
            print('[OK] Dependencia:', name)
        except ImportError:
            print('[ERRO] Dependencia ausente:', name)
            failed = True
    environment = dict(os.environ, HALL_SSOT_V43='1', HALL_LOCAL_AGENT_V40='1',
                       HALL_GEMMA4_V42='1', HALL_V41_VOICE='1', HALL_V36_AUTOSTART='0',
                       OLLAMA_NO_CLOUD='1', HF_HUB_DISABLE_TELEMETRY='1', DO_NOT_TRACK='1')
    print('[CHECK] Carregando backend e rotas V43...')
    try:
        result = subprocess.run([sys.executable, str(PROJECT/'scripts/hall_v32_runtime_server.py'), '--check-only'],
                                cwd=PROJECT, env=environment, timeout=120)
        failed = failed or result.returncode != 0
    except (OSError, subprocess.TimeoutExpired) as exc:
        print('[ERRO] Backend:', exc)
        failed = True
    from services.ssot_v43 import BaseOficial
    try:
        result = BaseOficial._local_json('http://127.0.0.1:8000/api/v43/runtime-status', None, 3)
        print('[RUNTIME]', json.dumps(result, ensure_ascii=False))
        if result.get('version') != '43.0':
            print('[AVISO] O backend ativo nao confirmou V43. Use o iniciador V43.')
    except Exception:
        print('[INFO] Backend V43 nao respondeu. Este diagnostico nao inicia o servidor.')
    base = os.getenv('OLLAMA_URL', 'http://127.0.0.1:11435').rstrip('/')
    try:
        parsed = urlsplit(base)
        if parsed.scheme != 'http' or parsed.hostname not in {'127.0.0.1','localhost','::1'} or parsed.username or parsed.password or parsed.path not in {'','/'} or parsed.query or parsed.fragment:
            raise ValueError('OLLAMA_URL deve apontar ao Ollama da propria maquina.')
        result = BaseOficial._local_json(base+'/api/tags', None, 5)
        names = [str(x.get('name','')) for x in result.get('models',[])]
        print('[OLLAMA] Modelos instalados:', ', '.join(names) or 'nenhum')
        if not names:
            print('[AVISO] Baixe o modelo de conversa pelo instalador V43.')
        if not any(x.startswith('embeddinggemma:') for x in names):
            print('[INFO] EmbeddingGemma ausente. A busca textual continua disponivel.')
    except Exception as exc:
        print('[AVISO] Ollama:', str(exc)[:250])
        print('[DICA] Use CORRIGIR_OLLAMA_HALL_V42.bat, incluido no pacote.')
    print('[LIMITE] Este diagnostico nao testa Windows/GPU/microfone nem precisao de uma LLM real.')
    return 1 if failed else 0


if __name__ == '__main__':
    raise SystemExit(main())
