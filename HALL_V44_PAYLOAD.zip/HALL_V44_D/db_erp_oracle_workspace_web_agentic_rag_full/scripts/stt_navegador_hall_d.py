"""Prepare and check the browser STT route without microphone or companion login."""
import argparse
import json
import os
from pathlib import Path
import sys
import tempfile
import wave

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'hall_transporte_agentic_pro/data/local_stt_fallback'
sys.path.insert(0, str(ROOT))


def browser_config():
    path = DATA / 'config.json'
    if not path.is_file():
        return {'enabled': True, 'model_size': 'base'}
    data = json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(data, dict):
        raise ValueError('Configuracao da voz do navegador invalida: ' + str(path))
    return data


def prepare(name='base'):
    from faster_whisper import WhisperModel
    from faster_whisper.utils import download_model
    from storage_paths_v42 import whisper_cache

    cache = whisper_cache()
    try:
        location = download_model(name, cache_dir=cache, local_files_only=True)
        if not (Path(location)/'model.bin').is_file():
            raise FileNotFoundError('Pesos incompletos')
        print('Reaproveitando Faster-Whisper ' + name + ' no D:.', flush=True)
    except Exception:
        print('Baixando Faster-Whisper ' + name + ' para ' + cache, flush=True)
        location = download_model(name, cache_dir=cache)
    WhisperModel(location, device='cpu', compute_type='int8', cpu_threads=2, local_files_only=True)
    print('[OK] Faster-Whisper ' + name + ' carregou em CPU.')
    return 0


def check(full):
    from services.local_stt_recovery_v42_5 import status_config, transcribe_config

    config = browser_config()
    status = status_config(config)
    if status.get('enabled') is False:
        print('[ERRO] A transcricao local foi desativada na configuracao do HALL.')
        return 3
    if status.get('ready') is not True:
        print('[AVISO] ' + str(status.get('error', 'Falta preparar o modelo local.')))
        if status.get('child_error'):
            print('[VOZ] ' + status['child_error'])
        return 2
    print('[OK] Transcricao local pronta. Modelo: ' + str(status.get('model') or 'local'))
    if not full:
        return 0

    # Exercise the same worker and allowed audio folder as the browser endpoint.
    folder = DATA / 'audio'
    folder.mkdir(parents=True, exist_ok=True)
    fd, path = tempfile.mkstemp(suffix='.wav', prefix='teste_voz_hall_', dir=folder)
    os.close(fd)
    try:
        with wave.open(path, 'wb') as clip:
            clip.setparams((1, 2, 16000, 0, 'NONE', 'not compressed'))
            clip.writeframes(b'\0' * 32000)
        result = transcribe_config(path, 'pt', config)
        if not result.get('offline') or (not result.get('ok') and result.get('error_code') != 'no_speech'):
            raise RuntimeError(str(result.get('error') or 'O motor local nao processou o audio de teste.'))
        print('[OK] Audio de teste processado offline. O microfone sera testado no navegador.')
    finally:
        Path(path).unlink(missing_ok=True)
    return 0


def main():
    p = argparse.ArgumentParser()
    p.add_argument('action', choices=('prepare', 'prepare-small', 'status', 'check'))
    args = p.parse_args()
    if args.action in ('prepare', 'prepare-small'):
        return prepare('small' if args.action == 'prepare-small' else 'base')
    return check(args.action == 'check')


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as error:
        print('[ERRO] ' + str(error), file=sys.stderr)
        sys.exit(1)
