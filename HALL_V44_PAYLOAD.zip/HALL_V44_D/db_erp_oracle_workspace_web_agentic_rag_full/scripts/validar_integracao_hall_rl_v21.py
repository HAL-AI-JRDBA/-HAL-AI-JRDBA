from __future__ import annotations
import json, shutil, sys, tempfile, time, types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
try: import oracledb  # noqa
except Exception:
    stub=types.ModuleType('oracledb'); stub.Connection=object; stub.Cursor=object; stub.init_oracle_client=lambda **k:None; stub.connect=lambda **k:None; stub.makedsn=lambda *a,**k:'dsn'; sys.modules['oracledb']=stub
from fastapi.testclient import TestClient
from services.identity_access import IdentityAccessService
from services.reinforcement_learning_lab import ReinforcementLearningLab
from services.hall_safety import HallSafetySupervisor
import web_app.backend.main as webmain
checks=[]
def ck(name,cond,detail=''):
    checks.append({'test':name,'ok':bool(cond),'detail':detail});
    if not cond: raise AssertionError(f'{name}: {detail}')
with tempfile.TemporaryDirectory(prefix='hall-v21-http-') as td:
    t=Path(td); (t/'training').mkdir(); (t/'router').mkdir()
    for n in ['train_dpo.py','train_reward.py','train_grpo.py','hall_train_common.py']: shutil.copy2(ROOT/'training'/n,t/'training'/n)
    router=t/'router'/'config.json'; router.write_text(json.dumps({'models':{'chat':'qwen2.5:7b'}}),encoding='utf-8')
    webmain.STATE.identity_access=IdentityAccessService(t/'iam')
    webmain.STATE.reinforcement_learning_lab=ReinforcementLearningLab(t,t/'rl',router)
    webmain.STATE.safety_supervisor=HallSafetySupervisor(t)
    client=TestClient(webmain.app,base_url='http://127.0.0.1:8000')
    ck('rl_requires_login',client.get('/api/rl-lab/status').status_code==401)
    r=client.post('/api/auth/bootstrap',json={'username':'admin','password':'AdminSecure#2026','display_name':'Administrador'}); ck('bootstrap',r.status_code==200,r.text)
    r=client.get('/api/rl-lab/status'); ck('admin_status',r.status_code==200,r.text)
    r=client.put('/api/rl-lab/config',json={'changes':{'auto_train':True,'dry_run_default':True}}); ck('auto_train_forced_off',r.status_code==200 and r.json()['config']['auto_train'] is False,r.text)
    for approved,response in [(True,'Resposta útil sobre Oracle'),(False,'Resposta ruim')]:
        r=client.post('/api/rl-lab/feedback',json={'prompt':'Explique Oracle','response':response,'approved':approved,'role':'chat'}); ck('feedback_'+str(approved),r.status_code==200,r.text)
    r=client.post('/api/rl-lab/experience',json={'source':'test','task_type':'chat','role':'chat','prompt':'Outra pergunta','response':'Resposta boa','reward':4,'success':True}); ck('admin_experience',r.status_code==200,r.text)
    r=client.post('/api/rl-lab/datasets/build',json={'role':'chat','min_reward_gap':1,'import_sql_feedback':False}); ck('dataset_build',r.status_code==200 and r.json()['preferences']>=1,r.text); ds=r.json()['paths']['dpo']
    r=client.post('/api/rl-lab/jobs',json={'method':'dpo','role':'chat','dataset_path':ds,'dry_run':True,'model_source':'Qwen/Qwen2.5-7B-Instruct','config':{}}); ck('create_job',r.status_code==200,r.text); jid=r.json()['job']['id']
    ck('start_blocked_preapproval',client.post(f'/api/rl-lab/jobs/{jid}/start',json={}).status_code==400)
    r=client.post(f'/api/rl-lab/jobs/{jid}/decision',json={'approved':True,'reason':'teste'}); ck('approve_job',r.status_code==200,r.text)
    r=client.post(f'/api/rl-lab/jobs/{jid}/start',json={}); ck('start_job',r.status_code==200,r.text)
    status='running'; deadline=time.time()+20
    while time.time()<deadline:
        jobs=client.get('/api/rl-lab/jobs').json()['jobs']; status=next(x['status'] for x in jobs if x['id']==jid)
        if status in {'completed','failed'}:break
        time.sleep(.2)
    ck('job_completed',status=='completed',status)
    r=client.post(f'/api/rl-lab/jobs/{jid}/candidate',json={'candidate_model':''}); ck('register_dry_candidate',r.status_code==200 and r.json()['candidate']['status']=='dry_run_candidate',r.text); cid=r.json()['candidate']['id']
    r=client.post(f'/api/rl-lab/candidates/{cid}/evaluation',json={'benchmark':{'improvement_percent':99},'safety':{'passed':True}}); ck('dry_evaluation',r.status_code==200,r.text)
    ck('dry_promotion_blocked',client.post(f'/api/rl-lab/candidates/{cid}/promote',json={'approved':True,'reason':'test'}).status_code==400)
    # create a restricted user: feedback is allowed, admin panel is not
    r=client.post('/api/hall-iam/users',json={'username':'user1','display_name':'Usuario','password':'UserSecure#2026','is_admin':False,'active':True,'modules':['dashboard'],'erp_modules':[],'permissions':['view','chat'],'module_permissions':{},'must_change_password':False}); ck('create_nonadmin',r.status_code==200,r.text)
    user=TestClient(webmain.app,base_url='http://127.0.0.1:8000'); r=user.post('/api/auth/login',json={'username':'user1','password':'UserSecure#2026'}); ck('login_nonadmin',r.status_code==200,r.text)
    ck('nonadmin_admin_status_blocked',user.get('/api/rl-lab/status').status_code==403)
    r=user.post('/api/rl-lab/feedback',json={'prompt':'Oi','response':'Olá','approved':True,'role':'chat'}); ck('nonadmin_feedback_allowed',r.status_code==200,r.text)
out={'ok':all(x['ok'] for x in checks),'passed':sum(x['ok'] for x in checks),'total':len(checks),'tests':checks}
print(json.dumps(out,ensure_ascii=False,indent=2))
