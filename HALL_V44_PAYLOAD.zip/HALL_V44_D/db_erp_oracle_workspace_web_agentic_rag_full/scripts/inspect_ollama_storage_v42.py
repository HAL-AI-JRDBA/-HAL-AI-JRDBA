"""Read only the running Ollama's relevant settings; never dump its environment.

Optional psutil support: absence/access denial leaves the service unconfirmed.
The launcher can still start and record its own server without this dependency.
"""
from __future__ import annotations

import argparse
import json
import ntpath
import os

EPOCH_TICKS = 621355968000000000


def windows_path(value):
    if not value or not ntpath.isabs(str(value)) or not ntpath.splitdrive(str(value))[0]:
        return None
    return ntpath.normcase(ntpath.normpath(str(value)))


def inspect_process(process_id, expected_models, start_ticks, process_factory=None):
    answer = {'verified': False, 'process_id': int(process_id)}
    try:
        if process_factory is None:
            import psutil
            process_factory = psutil.Process
        process = process_factory(int(process_id))
        if process.name().casefold() not in {'ollama', 'ollama.exe'}:
            return {**answer, 'reason': 'not_ollama'}
        expected_time = (int(start_ticks) - EPOCH_TICKS) / 10_000_000
        if abs(process.create_time() - expected_time) > .001:
            return {**answer, 'reason': 'process_changed'}
        environment = {str(key).upper(): value for key, value in process.environ().items()}
        actual = environment.get('OLLAMA_MODELS')
        if windows_path(actual) != windows_path(expected_models) or windows_path(expected_models) is None:
            return {**answer, 'reason': 'different_model_directory', 'models': actual}
        if str(environment.get('OLLAMA_NO_CLOUD', '')).casefold() not in {'1', 'true', 't'}:
            return {**answer, 'reason': 'restart_for_local_mode', 'models': actual}
        if not process.is_running():
            return {**answer, 'reason': 'process_changed'}
        return {**answer, 'verified': True, 'models': actual, 'local_only': True}
    except Exception:
        return {**answer, 'reason': 'process_unreadable'}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pid', required=True, type=int)
    parser.add_argument('--models', required=True)
    parser.add_argument('--start-ticks', required=True, type=int)
    args = parser.parse_args(argv)
    if os.name != 'nt':
        result = {'verified': False, 'reason': 'windows_required'}
    else:
        result = inspect_process(args.pid, args.models, args.start_ticks)
    print(json.dumps(result, ensure_ascii=True))
    return 0 if result['verified'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
