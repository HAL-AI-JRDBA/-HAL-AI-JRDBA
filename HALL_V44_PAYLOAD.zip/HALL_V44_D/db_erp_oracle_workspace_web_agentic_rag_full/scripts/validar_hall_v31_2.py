from __future__ import annotations
from pathlib import Path
import importlib.util, sys
ROOT=Path(__file__).resolve().parents[1]
voice=ROOT/'scripts'/'hall_voice_presence_windows_v31_2.py'
svc=ROOT/'services'/'voice_presence_v23.py'
js=ROOT/'web_app'/'frontend'/'unified_app.js'
checks=[]
def ck(name,ok,detail=''):
    checks.append((name,bool(ok),detail)); print(('[OK] ' if ok else '[FAIL] ')+name+((' :: '+detail) if detail else ''))
spec=importlib.util.spec_from_file_location('hallv312',voice); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
for text in ['HAL desativar','desativar','Hall, pode desativar','Hall desligar','por favor desativar','pare de ouvir','fique em espera']:
    ok,matched=mod.active_sleep_match(text,mod.LANG['pt-BR']['sleep'],'pt-BR'); ck('sleep::'+text,ok,matched)
for text in ['nao desativar','não desativar','como desativar o Hall?','quero saber como desativar']:
    ok,matched=mod.active_sleep_match(text,mod.LANG['pt-BR']['sleep'],'pt-BR'); ck('no_false_sleep::'+text,not ok,matched)
# Wake remains strict.
ok,_,_=mod.phrase_match('ativar',mod.LANG['pt-BR']['wake']); ck('wake_requires_hall',not ok)
# Static guarantees.
txt=voice.read_text(encoding='utf-8-sig'); ck('local_deactivate_before_backend','self.active = False' in txt and '_deactivate_now' in txt)
ck('canonical_server_sync','canonical = (self.sleep_phrases' in txt)
jst=js.read_text(encoding='utf-8-sig'); ck('frontend_priority_sleep','hallPresenceDeactivatePriority' in jst and 'hallPresenceActiveSleepMatch' in jst)
svct=svc.read_text(encoding='utf-8-sig'); ck('backend_tolerant_sleep','_active_deactivate_match' in svct)
failed=[x for x in checks if not x[1]]
print(f'RESULT: {len(checks)-len(failed)}/{len(checks)} PASS')
sys.exit(1 if failed else 0)
