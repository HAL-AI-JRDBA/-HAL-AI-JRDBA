from __future__ import annotations
import json
import tempfile
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services import natural_voice_engine_v24 as nv

checks = []
def check(name, cond, detail=""):
    checks.append({"test": name, "ok": bool(cond), "detail": detail})

cfg = nv.read_config()
check("config_version", cfg.get("version") == "24.0")
status = nv.status("demo", "pt-BR")
check("status", status.get("ok") and "engines" in status)
check("browser_fallback", status.get("engines", {}).get("browser_enhanced", {}).get("available") is True)

cases = {
    "pt-BR": "Esta é uma resposta longa. " * 80,
    "en-US": "This is a long answer. " * 80,
    "es-ES": "Esta es una respuesta larga. " * 80,
    "zh-CN": "这是一个很长的回答。" * 80,
    "ja-JP": "これは長い回答です。" * 80,
}
for lang, text in cases.items():
    out = nv.prepare_spoken_text(text, lang, {"spoken_mode": "concise"})
    check(f"spoken_{lang}", bool(out.get("spoken_text")) and out.get("truncated") is True)

md = nv.prepare_spoken_text("**Resumo**\n```sql\nselect * from x;\n```\nTudo certo.", "pt-BR", {"spoken_mode": "balanced"})
check("markdown_cleanup", "```" not in md.get("spoken_text", "") and "código" in md.get("spoken_text", "").lower())

prefs = nv.save_user_preferences("demo_v24", "pt-BR", {"engine":"browser_enhanced","spoken_mode":"concise","rate":1.1,"voice_clone":False})
check("preferences", prefs.get("preferences", {}).get("engine") == "browser_enhanced")

synth = nv.synthesize("demo_v24", "pt-BR", "Olá. Este é um teste natural da HAL.")
check("synthesize_fallback", synth.get("ok") is True and synth.get("engine") in {"browser_enhanced","piper","xtts_v2"})
check("no_audio_needed_for_browser", synth.get("engine") != "browser_enhanced" or synth.get("audio_url") == "")

profile = nv._voice_profile("")
check("voice_clone_consent_metadata", "consent" in profile)

result = {"ok": all(x["ok"] for x in checks), "passed": sum(1 for x in checks if x["ok"]), "total": len(checks), "tests": checks}
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(0 if result["ok"] else 1)
