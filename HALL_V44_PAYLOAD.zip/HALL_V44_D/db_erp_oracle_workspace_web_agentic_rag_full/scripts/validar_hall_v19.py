from __future__ import annotations

import json
import tempfile
import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from services.identity_access import IdentityAccessService, PROFILE_TEMPLATES
from services.model_lifecycle import ModelLifecycleManager, _write_json
from services.enterprise_web_access import EnterpriseWebAccessManager
import services.model_lifecycle as mlmod


def check(cond: bool, name: str, tests: list[dict]):
    tests.append({"test": name, "ok": bool(cond)})
    if not cond:
        raise AssertionError(name)


def main():
    tests: list[dict] = []
    with tempfile.TemporaryDirectory(prefix="hall-v19-") as td:
        t = Path(td)

        # IAM / RBAC
        iam = IdentityAccessService(t / "iam")
        check(iam.bootstrap_needed(), "IAM primeiro acesso exige bootstrap", tests)
        admin = iam.bootstrap_admin("admin", "AdminSecure#2026", "Administrador")
        check(admin["is_admin"] is True, "Bootstrap cria administrador", tests)
        check(not iam.bootstrap_needed(), "Bootstrap fica indisponivel apos primeiro admin", tests)

        tpl = PROFILE_TEMPLATES["arrecadacao"]
        user = iam.create_user({
            "username": "arrec.user",
            "display_name": "Arrecadacao",
            "password": "ArrecSecure#2026",
            "is_admin": False,
            "active": True,
            "modules": tpl["modules"],
            "erp_modules": tpl["erp_modules"],
            "permissions": tpl["permissions"],
            "module_permissions": {m: tpl["permissions"] for m in tpl["modules"]},
            "must_change_password": True,
        }, actor="admin")
        check(iam.can_erp(user, "Arrecadação"), "Usuario Arrecadacao acessa sua area", tests)
        check(not iam.can_erp(user, "Contabilidade"), "Usuario Arrecadacao nao acessa Contabilidade", tests)
        check(iam.infer_erp_module("analise a arrecadacao das catracas") == "Arrecadação", "Deteccao ERP Arrecadacao", tests)
        check(iam.infer_erp_module("gere o balancete contabil") == "Contabilidade", "Deteccao ERP Contabilidade", tests)
        d = iam.authorize_path(user, "/api/unified/human-conversation/converse", "POST")
        check(d.allowed and d.action == "chat", "Conversa natural exige permissao chat", tests)
        d2 = iam.authorize_path(user, "/api/hall-safety/status", "GET")
        check(not d2.allowed, "Modulo nao autorizado e bloqueado no backend", tests)
        check(not iam.authorize_path(user, "/api/sql/generate", "POST").allowed, "SQL direto bloqueado para perfil sem SQL", tests)
        check(not iam.authorize_path(user, "/api/endpoint-novo-nao-catalogado", "GET").allowed, "Endpoint novo segue default deny", tests)
        check(iam.authorize_path(user, "/api/unified/turn", "POST").allowed, "Turno conversacional permitido por chat", tests)
        check(iam.authorize_path(user, "/api/history/save", "POST").allowed, "Historico de conversa permitido ao perfil de chat", tests)

        tech = iam.create_user({
            "username": "monitor.user", "display_name": "Monitoramento", "password": "MonitorSecure#2026",
            "modules": ["monitoring"], "erp_modules": [], "permissions": ["view"],
            "module_permissions": {"monitoring": ["view"]},
        }, actor="admin")
        check(iam.authorize_path(tech, "/api/monitoring/status", "GET").allowed, "Monitoramento permite leitura quando autorizado", tests)
        check(not iam.authorize_path(tech, "/api/monitoring/config", "POST").allowed, "Configuracao exige permissao configure", tests)
        tech = iam.update_user(tech["id"], {"module_permissions": {"monitoring": ["view", "configure"]}}, "admin")
        check(iam.authorize_path(tech, "/api/monitoring/config", "POST").allowed, "Configure libera configuracao do modulo", tests)

        try:
            iam.update_user(admin["id"], {"is_admin": False}, "admin")
            last_admin_blocked = False
        except ValueError:
            last_admin_blocked = True
        check(last_admin_blocked, "Ultimo administrador ativo nao pode ser removido", tests)

        logged, token = iam.authenticate("arrec.user", "ArrecSecure#2026")
        check(bool(token) and logged["must_change_password"], "Login retorna politica de troca obrigatoria", tests)
        iam.change_own_password(logged["id"], "ArrecSecure#2026", "NovaSenha#2026", "arrec.user")
        check(iam.session_user(token) is None, "Troca de senha revoga sessao anterior", tests)
        logged2, _ = iam.authenticate("arrec.user", "NovaSenha#2026")
        check(not logged2["must_change_password"], "Troca obrigatoria e concluida", tests)

        # Model Lifecycle / Hugging Face discovery (sem rede, mock controlado)
        router = t / "router.json"
        _write_json(router, {"models": {"chat": "qwen2.5:7b", "embed": "embeddinggemma:latest"}})
        mgr = ModelLifecycleManager(t, t / "model_lifecycle", router)
        mgr._search_role = lambda role, spec: [{
            "repo_id": "org/new-chat-GGUF", "last_modified": "2026-08-30T00:00:00Z",
            "downloads": 12345, "likes": 321, "pipeline_tag": "text-generation",
            "tags": ["gguf", "instruct"], "size_b": 7.0, "score": 999.0, "risk": "normal",
        }] if role == "chat" else []
        mgr._candidate_install_ref = lambda repo, quant: (f"hf.co/{repo}:Q4_K_M", "Q4_K_M")
        scan = mgr.scan(actor="admin", roles=["chat"])
        check(len(scan.get("discovered") or []) == 1, "Hugging Face cria proposta de candidato", tests)
        proposal = scan["discovered"][0]
        check(proposal["status"] == "pending", "Candidato nao e instalado automaticamente", tests)
        try:
            mgr.approve_and_install(proposal["id"], "admin", approved=False)
            explicit_approval = False
        except PermissionError:
            explicit_approval = True
        check(explicit_approval, "Instalacao exige aprovacao administrativa explicita", tests)

        # Instalação aprovada: mock de Ollama + smoke test + router + rollback metadata.
        job = {
            "id": "job-test", "proposal_id": proposal["id"], "role": "chat",
            "candidate_model": proposal["candidate_model"], "status": "queued",
            "created_at": "test", "actor": "admin",
        }
        _write_json(mgr.jobs_path, [job])
        old_which, old_run = mlmod.shutil.which, mlmod.subprocess.run
        class Proc:
            returncode = 0
            stdout = "OK"
            stderr = ""
        try:
            mlmod.shutil.which = lambda name: "ollama"
            mlmod.subprocess.run = lambda *args, **kwargs: Proc()
            mgr._smoke_test_candidate = lambda role, candidate: {"ok": True, "kind": "generate", "answer": "OK", "elapsed_s": 0.01}
            mgr._install_job("job-test")
        finally:
            mlmod.shutil.which, mlmod.subprocess.run = old_which, old_run
        cfg = mgr.router_config()
        check(cfg["models"]["chat"] == proposal["candidate_model"], "Modelo aprovado atualiza o Router", tests)
        jobs = mgr.jobs()
        check(jobs[0]["status"] == "completed" and jobs[0].get("restart_required") is True, "Atualizacao exige reinicio controlado", tests)
        check(bool(cfg.get("model_lifecycle", {}).get("chat", {}).get("previous")), "Modelo anterior fica registrado para rollback", tests)
        rb = mgr.rollback("chat", "admin", approved=True)
        check(rb["to"] == "qwen2.5:7b" and rb["restart_required"], "Rollback restaura modelo anterior", tests)

        # Integração HTTP real do FastAPI, sem abrir servidor e sem tocar dados reais.
        try:
            import oracledb  # noqa: F401
        except Exception:
            oracle_stub = types.ModuleType("oracledb")
            oracle_stub.Connection = object
            oracle_stub.Cursor = object
            oracle_stub.init_oracle_client = lambda **kwargs: None
            oracle_stub.connect = lambda **kwargs: None
            oracle_stub.makedsn = lambda *args, **kwargs: "dsn"
            sys.modules["oracledb"] = oracle_stub
        from fastapi.testclient import TestClient
        import web_app.backend.main as webmain

        http_root = t / "http"
        webmain.STATE.identity_access = IdentityAccessService(http_root / "iam")
        http_router = http_root / "router.json"
        _write_json(http_router, {"models": {"chat": "qwen2.5:7b"}})
        webmain.STATE.model_lifecycle = ModelLifecycleManager(http_root, http_root / "models", http_router)
        webmain.STATE.web_access = EnterpriseWebAccessManager(http_root, http_root / "web_access")
        client = TestClient(webmain.app, base_url="http://127.0.0.1:8000")

        r = client.get("/api/auth/status")
        check(r.status_code == 200 and r.json().get("bootstrap_required") is True, "HTTP login exige bootstrap no primeiro acesso", tests)
        r = client.post("/api/auth/bootstrap", json={"username": "admin", "password": "AdminSecure#2026", "display_name": "Administrador"})
        check(r.status_code == 200 and r.json().get("user", {}).get("is_admin") is True, "HTTP bootstrap autentica administrador", tests)
        tpl_http = PROFILE_TEMPLATES["arrecadacao"]
        r = client.post("/api/hall-iam/users", json={
            "username": "arrec.http", "display_name": "Arrecadacao HTTP", "password": "ArrecHttp#2026",
            "modules": tpl_http["modules"], "erp_modules": tpl_http["erp_modules"],
            "permissions": tpl_http["permissions"], "module_permissions": {m: tpl_http["permissions"] for m in tpl_http["modules"]},
        })
        check(r.status_code == 200, "HTTP administrador cria usuario departamental", tests)
        client.post("/api/auth/logout", json={})
        r = client.post("/api/auth/login", json={"username": "arrec.http", "password": "ArrecHttp#2026"})
        check(r.status_code == 200, "HTTP usuario departamental autentica", tests)
        check(client.get("/api/hall-safety/status").status_code == 403, "HTTP bloqueia modulo nao autorizado", tests)
        check(client.post("/api/sql/generate", json={}).status_code == 403, "HTTP bloqueia API SQL mesmo por chamada manual", tests)
        r = client.post("/api/unified/turn", json={"message": "gere o balancete contabil", "module": "auto", "approved": False, "context": {}})
        check(r.status_code == 403, "HTTP bloqueia prompt de outro modulo ERP", tests)
        r = client.get("/api/unified/modules")
        ids = {m.get("id") for m in (r.json().get("modules") or [])}
        check(r.status_code == 200 and ids == {"dashboard", "modules", "human_conversation_gateway"}, "HTTP frontend recebe somente modulos permitidos", tests)
        check(client.get("/api/endpoint-novo-nao-catalogado").status_code == 403, "HTTP endpoint novo fica fechado por padrao", tests)

    out = {"ok": all(x["ok"] for x in tests), "tests": tests, "total": len(tests), "passed": sum(1 for x in tests if x["ok"])}
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
