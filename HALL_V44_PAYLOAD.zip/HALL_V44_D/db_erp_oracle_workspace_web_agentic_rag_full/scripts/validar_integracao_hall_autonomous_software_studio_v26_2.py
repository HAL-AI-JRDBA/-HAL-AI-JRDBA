from __future__ import annotations
import json, sys, tempfile, shutil, os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
APPROOT=ROOT/'hall_transporte_agentic_pro'
for p in [str(ROOT),str(APPROOT)]:
 if p not in sys.path: sys.path.insert(0,p)
from app.services import app_factory_pro
from services.production_quality_gates_v262 import ProductionQualityGate
checks=[]
def ck(name,cond,detail=''):
 checks.append({'name':name,'ok':bool(cond),'detail':detail});
 if not cond: raise AssertionError(name+': '+detail)
r=app_factory_pro.generate_app('Crie um CRM seguro para testes V26.2','HAL V262 Gate Test','crm',False)
ck('generate_ok',r.get('ok')); path=Path(r['path']); main=(path/'app/main.py').read_text(encoding='utf-8'); html=(path/'app/templates/index.html').read_text(encoding='utf-8'); js=(path/'app/static/app.js').read_text(encoding='utf-8')
ck('no_admin123','admin123' not in (main+html+js).lower()); ck('scrypt','scrypt' in main.lower()); ck('hmac','hmac' in main.lower()); ck('csrf','csrf' in main.lower() and 'x-csrf-token' in js.lower()); ck('rate_limit','LOGIN_ATTEMPTS' in main); ck('rbac','require_role' in main); ck('security_headers','Content-Security-Policy' in main); ck('env_example',(path/'.env.example').exists()); ck('backup_script',(path/'scripts/backup.py').exists()); ck('restore_script',(path/'scripts/restore_test.py').exists()); ck('privacy',(path/'PRIVACY_READINESS.md').exists()); ck('production_gate',(path/'production_gate.py').exists()); ck('qg_ok',r.get('quality_gate',{}).get('ok'))
pg=ProductionQualityGate(ROOT).run_all(path,{}); ck('production_blocked_without_env',pg.get('deploy_allowed') is False); ck('security_gate_ok',pg['gates']['security']['ok']); ck('backup_gate_ok',pg['gates']['backup_restore']['ok']); ck('privacy_gate_ok',pg['gates']['lgpd_readiness']['ok']); ck('responsive_gate_ok',pg['gates']['responsive_accessibility']['ok'])
# With production env configured, deploy gate should be eligible.
pg2=ProductionQualityGate(ROOT).run_all(path,{'HALL_APP_SESSION_SECRET':'x'*64,'HALL_APP_ADMIN_PASSWORD':'StrongPassword!123','HALL_APP_SECURE_COOKIE':'true'}); ck('deploy_allowed_with_env',pg2.get('deploy_allowed') is True)
print(json.dumps({'ok':True,'passed':len(checks),'total':len(checks),'checks':checks,'path':str(path)},ensure_ascii=False,indent=2))
