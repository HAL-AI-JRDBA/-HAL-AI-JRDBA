from __future__ import annotations
import argparse, json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from services import natural_voice_engine_v24 as nv

p=argparse.ArgumentParser()
p.add_argument('--binary',default='')
p.add_argument('--language',default='')
p.add_argument('--model',default='')
a=p.parse_args()
cfg=nv.read_config(); ch={"piper":{}}
if a.binary: ch["piper"]["binary"]=str(Path(a.binary).resolve())
if a.language and a.model:
    ch["piper"]["models"]={a.language:str(Path(a.model).resolve())}
print(json.dumps(nv.update_config(ch),ensure_ascii=False,indent=2))
