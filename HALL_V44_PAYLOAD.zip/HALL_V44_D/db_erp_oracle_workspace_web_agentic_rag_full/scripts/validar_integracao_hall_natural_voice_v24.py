from __future__ import annotations
import json, sys, tempfile, types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from fastapi.testclient import TestClient
sys.modules.setdefault('oracledb', types.SimpleNamespace())
from services.identity_access import IdentityAccessService, PROFILE_TEMPLATES
from web_app.backend import main
import services.natural_voice_engine_v24 as nv

# Isola IAM e dados de voz.
tmp=Path(tempfile.mkdtemp(prefix='hall_v24_http_'))
main.STATE.identity_access=IdentityAccessService(tmp/'iam')
nv.DATA_DIR=tmp/'voice'; nv.OUTPUT_DIR=nv.DATA_DIR/'generated_audio'; nv.CONFIG_FILE=nv.DATA_DIR/'config.json'; nv.PREFERENCES_FILE=nv.DATA_DIR/'preferences.json'; nv.AUDIT_FILE=nv.DATA_DIR/'audit.jsonl'

client=TestClient(main.app,base_url='http://127.0.0.1:8000')
t=[]
def ck(name,cond,detail=''):
    t.append({'test':name,'ok':bool(cond),'detail':detail})
    if not cond: raise AssertionError(name+' '+detail)

r=client.post('/api/auth/bootstrap',json={'username':'admin','password':'AdminSecure#2026','display_name':'Admin','preferred_language':'pt-BR'})
ck('bootstrap admin',r.status_code==200,r.text)
r=client.get('/api/natural-voice-v24/status'); ck('status admin',r.status_code==200 and r.json().get('version')=='24.0',r.text)
r=client.put('/api/natural-voice-v24/preferences',json={'engine':'browser_enhanced','spoken_mode':'concise','rate':1.05,'voice_clone':False}); ck('save prefs',r.status_code==200 and r.json()['preferences']['rate']==1.05,r.text)
r=client.post('/api/natural-voice-v24/synthesize',json={'text':'Olá. Este é um teste da voz natural da HAL.'}); ck('synthesize fallback',r.status_code==200 and r.json().get('ok') is True and r.json().get('engine')=='browser_enhanced',r.text)
r=client.get('/api/natural-voice-v24/audio/notfound.wav'); ck('audio safe 404',r.status_code==404,r.text)
r=client.get('/api/natural-voice-v24/config'); ck('admin config',r.status_code==200,r.text)

# Usuário departamental deve poder conversar por voz, mas não administrar configuração.
tpl=PROFILE_TEMPLATES['arrecadacao']
r=client.post('/api/hall-iam/users',json={'username':'arrec.v24','display_name':'Arrecadacao','password':'ArrecVoice#2026','modules':tpl['modules'],'erp_modules':tpl['erp_modules'],'permissions':tpl['permissions'],'module_permissions':{m:tpl['permissions'] for m in tpl['modules']}})
ck('create departmental user',r.status_code==200,r.text)
client.post('/api/auth/logout',json={})
r=client.post('/api/auth/login',json={'username':'arrec.v24','password':'ArrecVoice#2026'}); ck('departmental login',r.status_code==200,r.text)
r=client.get('/api/natural-voice-v24/status'); ck('departmental can use voice',r.status_code==200,r.text)
r=client.post('/api/natural-voice-v24/synthesize',json={'text':'Teste de voz da arrecadação.'}); ck('departmental synthesize',r.status_code==200 and r.json().get('ok') is True,r.text)
r=client.get('/api/natural-voice-v24/config'); ck('departmental cannot admin voice config',r.status_code==403,r.text)
client.post('/api/auth/logout',json={})
r=client.get('/api/natural-voice-v24/status'); ck('voice requires auth',r.status_code==401,r.text)

print(json.dumps({'ok':all(x['ok'] for x in t),'passed':sum(x['ok'] for x in t),'total':len(t),'tests':t},ensure_ascii=False,indent=2))
