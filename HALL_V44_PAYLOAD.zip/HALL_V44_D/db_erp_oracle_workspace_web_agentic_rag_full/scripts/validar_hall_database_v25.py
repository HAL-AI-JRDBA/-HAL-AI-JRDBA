from __future__ import annotations
import json, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
AGENTIC=ROOT/'hall_transporte_agentic_pro'
if str(AGENTIC) not in sys.path: sys.path.insert(0,str(AGENTIC))

from app.services import universal_database_intelligence as udi
from app.services import database_access_wizard as daw
from app.services import universal_erp_connector as uec

checks={}
def ok(name, cond):
    checks[name]=bool(cond)
    if not cond: raise AssertionError(name)

# Catalog breadth
required={'oracle','sqlserver','postgresql','mysql','mariadb','sqlite','firebird','db2','mongodb','redis','elasticsearch','opensearch','cassandra','couchdb','neo4j','generic_sql','generic_rest'}
ok('catalog_all_engines', required.issubset(set(udi.ENGINE_CATALOG)))
ok('wizard_catalog_consistent', required.issubset(set(daw.DATABASE_CATALOG)))
ok('erp_catalog_consistent', required.issubset(set(uec.DATABASES)))

# Detection/version
cases=[
 ('Oracle Database 11g Enterprise Edition Release 11.2.0.4.0 - 64bit Production','oracle','11.2.0.4'),
 ('Microsoft SQL Server 2022 (RTM) - 16.0.1000.6','sqlserver','16.0.1000.6'),
 ('PostgreSQL 15.4 on x86_64','postgresql','15.4'),
 ('10.11.8-MariaDB','mariadb','10.11.8'),
 ('MySQL Community Server - GPL 8.0.36','mysql','8.0.36'),
 ('SQLite 3.45.1','sqlite','3.45.1'),
 ('MongoDB server version: 7.0.5','mongodb','7.0.5'),
 ('redis_version:7.2.4','redis','7.2.4'),
 ('Neo4j 5.18.0','neo4j','5.18.0'),
]
for banner,engine,version in cases:
    d=udi.detect_engine(banner)
    ok('detect_'+engine,d['engine']==engine)
    ok('version_'+engine,d['version'].startswith(version))

ok('canonical_sqlserver_2019', udi.canonical_version('sqlserver','SQL Server 2019')=='15.0')
ok('canonical_oracle_11g', udi.canonical_version('oracle','11g')=='11.2')

# Version feature gates
cap=udi.capability_matrix('oracle','11.2.0.4')
ok('oracle11_no_cdb', next(x for x in cap['version_features'] if x['feature']=='cdb_pdb')['supported'] is False)
cap=udi.capability_matrix('oracle','19.22')
ok('oracle19_cdb', next(x for x in cap['version_features'] if x['feature']=='cdb_pdb')['supported'] is True)
cap=udi.capability_matrix('postgresql','14')
ok('pg14_no_merge', next(x for x in cap['version_features'] if x['feature']=='merge')['supported'] is False)
cap=udi.capability_matrix('postgresql','15')
ok('pg15_merge', next(x for x in cap['version_features'] if x['feature']=='merge')['supported'] is True)
cap=udi.capability_matrix('mysql','5.7')
ok('mysql57_no_window', next(x for x in cap['version_features'] if x['feature']=='window_functions')['supported'] is False)
cap=udi.capability_matrix('mysql','8.0.36')
ok('mysql8_window', next(x for x in cap['version_features'] if x['feature']=='window_functions')['supported'] is True)

# Compatibility guard
ok('oracle11_fetch_blocked', not udi.compatibility_review('oracle','11.2.0.4','select * from t fetch first 10 rows only')['ok'])
ok('oracle12_fetch_allowed', udi.compatibility_review('oracle','12.1','select * from t fetch first 10 rows only')['ok'])
ok('pg14_merge_blocked', not udi.compatibility_review('postgresql','14','merge into a using b on (a.id=b.id) when matched then update set x=1')['ok'])
ok('pg15_merge_allowed', udi.compatibility_review('postgresql','15','merge into a using b on (a.id=b.id) when matched then update set x=1')['ok'])
ok('sqlserver2016_stringagg_blocked', not udi.compatibility_review('sqlserver','13.0','select string_agg(name,\',\') from t')['ok'])
ok('sqlserver2017_stringagg_allowed', udi.compatibility_review('sqlserver','14.0','select string_agg(name,\',\') from t')['ok'])
ok('mysql57_cte_blocked', not udi.compatibility_review('mysql','5.7','with x as (select 1 a) select * from x')['ok'])
ok('sqlite334_returning_blocked', not udi.compatibility_review('sqlite','3.34','insert into t values(1) returning *')['ok'])
ok('cross_dialect_oracle_rownum_pg_blocked', not udi.compatibility_review('postgresql','15','select * from t where rownum <= 10')['ok'])

# Diagnostic plans/version fallback
plan=udi.diagnostic_plan('oracle','11.2.0.4',['backup'])
ok('oracle11_backup_fallback', 'ROWNUM <= 20' in plan['items'][0].get('query',''))
plan=udi.diagnostic_plan('mysql','5.7',['replication'])
ok('mysql57_replication_fallback', plan['items'][0].get('query')=='SHOW SLAVE STATUS')
plan=udi.diagnostic_plan('generic_sql','',[])
ok('generic_metadata_plan', any(x.get('skill')=='metadata' for x in plan['items']))

# Natural-language routing
g=udi.guided_answer('Oracle 11.2.0.4 está lento e com locks')
ok('guided_oracle', g['engine']=='oracle' and g['version'].startswith('11.2.0.4'))
ok('guided_has_lock_plan', any(x.get('skill')=='locks' for x in g['plan']['items']))
g=udi.guided_answer('SQL Server 2019: analise performance, backup e Always On')
ok('guided_sqlserver2019', g['engine']=='sqlserver' and g['version']=='15.0')
g=udi.guided_answer('Meu banco proprietário via ODBC está lento')
ok('guided_unknown_safe', g['mode'] in {'needs_connection_or_engine','engine_version_plan'})

# Skill target/accountability
a=udi.skill_audit('oracle','19')
ok('skill_audit_oracle', all(x['score']==10 for x in a['skills'] if x['applicable']))
a=udi.skill_audit('redis','7.2')
ok('skill_audit_redis_applicable', all(x['score']==10 for x in a['skills'] if x['applicable']))
for engine in sorted(required):
    sample_versions={
        'oracle':'19','sqlserver':'16.0','postgresql':'15','mysql':'8.0.36','mariadb':'10.11',
        'sqlite':'3.45','firebird':'5.0','db2':'11.5','mongodb':'7.0','redis':'7.2',
        'elasticsearch':'8.15','opensearch':'2.15','cassandra':'5.0','couchdb':'3.3','neo4j':'5.18',
        'generic_sql':'','generic_rest':''
    }
    audit=udi.skill_audit(engine,sample_versions.get(engine,''))
    ok('10of10_applicable_'+engine, all(x['score']==10 for x in audit['skills'] if x['applicable']))

# Safety/status
s=udi.status()
ok('readonly_default', s['policy']['read_only_default'] is True)
ok('detect_before_generate', s['policy']['detect_before_generate'] is True)
ok('version_guard_before_execute', s['policy']['version_guard_before_execute'] is True)
ok('writes_need_approval', s['policy']['write_requires_human_approval'] is True)
ok('credentials_not_returned', s['policy']['credentials_never_returned'] is True)

print(json.dumps({'ok':all(checks.values()),'passed':sum(checks.values()),'total':len(checks),'checks':checks},ensure_ascii=False,indent=2))
