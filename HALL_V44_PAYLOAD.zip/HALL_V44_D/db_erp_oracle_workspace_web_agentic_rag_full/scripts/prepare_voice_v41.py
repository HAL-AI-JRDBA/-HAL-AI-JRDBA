"""Explicit installation step, allowed to download the configured open model."""
import json
from pathlib import Path
from storage_paths_v42 import whisper_cache

if __name__=='__main__':
    from faster_whisper import WhisperModel
    config=Path(__file__).resolve().parents[1]/'data/voice_presence_v23/native_client.json'
    data=json.loads(config.read_text(encoding='utf-8-sig')) if config.exists() else {}
    model=WhisperModel(data.get('stt_model','small'),device='cpu',compute_type='int8',cpu_threads=2,download_root=whisper_cache())
    print('Modelo de reconhecimento de fala preparado para uso local.')
