from __future__ import annotations
import json,sys,tempfile,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
sys.modules.setdefault('oracledb',types.SimpleNamespace())
from fastapi.testclient import TestClient
from web_app.backend import main
from services.identity_access import IdentityAccessService
import services.voice_presence_v23 as vp

tmp=Path(tempfile.mkdtemp(prefix="hall_v241_http_"))
main.STATE.identity_access=IdentityAccessService(tmp/'iam')
vp.DATA_DIR=tmp/'voice';vp.CONFIG_FILE=vp.DATA_DIR/'config.json';vp.PREFERENCES_FILE=vp.DATA_DIR/'preferences.json';vp.SESSIONS_FILE=vp.DATA_DIR/'sessions.json';vp.AUDIT_FILE=vp.DATA_DIR/'audit.jsonl'
c=TestClient(main.app,base_url='http://127.0.0.1:8000')
t=[]
def ck(n,cond,d=''):
 t.append({'test':n,'ok':bool(cond),'detail':d})
 if not cond:raise AssertionError(n+' '+d)
r=c.post('/api/auth/bootstrap',json={'username':'admin','password':'AdminSecure#2026','display_name':'Admin','preferred_language':'pt-BR'});ck('bootstrap',r.status_code==200,r.text)
r=c.post('/api/voice-presence/native-heartbeat',json={'active':False,'source':'test'});ck('heartbeat endpoint',r.status_code==200 and r.json().get('native_online') is True,r.text)
r=c.get('/api/voice-presence/status');ck('status reports native online',r.status_code==200 and r.json().get('native_companion',{}).get('online') is True,r.text)
r=c.post('/api/voice-presence/interpret',json={'transcript':'HAL ativar','source':'windows_native_v24_1'});ck('voice activate endpoint',r.status_code==200 and r.json().get('active') is True,r.text)
r=c.post('/api/voice-presence/native-heartbeat',json={'active':True,'source':'test'});ck('heartbeat active',r.status_code==200 and r.json().get('native_active') is True,r.text)
r=c.post('/api/voice-presence/interpret',json={'transcript':'HAL desativar','source':'windows_native_v24_1'});ck('voice deactivate endpoint',r.status_code==200 and r.json().get('active') is False,r.text)
c.post('/api/auth/logout')
r=c.post('/api/voice-presence/native-heartbeat',json={'active':False});ck('heartbeat requires auth',r.status_code==401,r.text)
print(json.dumps({'ok':all(x['ok'] for x in t),'passed':sum(x['ok'] for x in t),'total':len(t),'tests':t},ensure_ascii=False,indent=2))
