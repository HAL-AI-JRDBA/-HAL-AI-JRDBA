from __future__ import annotations

import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
IAM_DIR = ROOT / "data" / "identity_access_v19"
DB = IAM_DIR / "identity.sqlite"


def main() -> int:
    print("=" * 64)
    print("HAL V19.1 - RECUPERACAO DO ADMINISTRADOR INICIAL")
    print("=" * 64)
    print()
    if not DB.exists():
        print("[OK] Banco IAM ainda nao existe. Nao ha nada para recuperar.")
        print("Inicie a HAL V19.1 e crie o administrador pela tela.")
        return 0

    try:
        conn = sqlite3.connect(DB)
        conn.row_factory = sqlite3.Row
        rows = conn.execute("SELECT id,username,display_name,is_admin,active FROM users ORDER BY created_at").fetchall()
        conn.close()
    except Exception as exc:
        print(f"[ERRO] Nao foi possivel ler o banco IAM: {exc}")
        return 2

    if not rows:
        print("[OK] Banco IAM existe, mas nao possui usuarios.")
        return 0

    print(f"Usuarios encontrados: {len(rows)}")
    for row in rows:
        print(f" - {row['username']} | admin={bool(row['is_admin'])} | ativo={bool(row['active'])}")
    print()

    if len(rows) > 1:
        print("[BLOQUEADO] Ha mais de um usuario cadastrado.")
        print("Por seguranca, este utilitario nao apaga uma base IAM em uso.")
        return 3
    row = rows[0]
    if not bool(row["is_admin"]):
        print("[BLOQUEADO] O unico usuario nao e administrador.")
        print("A recuperacao automatica foi recusada para preservar os dados.")
        return 4

    print("Este utilitario e destinado somente ao PRIMEIRO ACESSO que falhou.")
    print("Ele fara backup do IAM atual e permitira criar o administrador novamente.")
    confirm = input("Digite RESETAR para continuar: ").strip()
    if confirm != "RESETAR":
        print("Operacao cancelada.")
        return 1

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = ROOT / "data" / f"identity_access_v19_backup_{stamp}"
    shutil.copytree(IAM_DIR, backup)
    for name in ("identity.sqlite", "identity.sqlite-wal", "identity.sqlite-shm", "audit.jsonl"):
        p = IAM_DIR / name
        if p.exists():
            p.unlink()
    print(f"[OK] Backup criado em: {backup}")
    print("[OK] Bootstrap liberado novamente.")
    print("Inicie a HAL e crie o administrador na tela de primeiro acesso.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
