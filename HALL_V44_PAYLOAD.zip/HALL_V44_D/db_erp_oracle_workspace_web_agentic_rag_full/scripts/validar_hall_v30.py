from __future__ import annotations
import json, platform, py_compile, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
AGENTIC=ROOT/'hall_transporte_agentic_pro'
if str(AGENTIC) not in sys.path: sys.path.insert(0,str(AGENTIC))

checks=[]
def check(name, ok, detail=''):
    checks.append({'name':name,'ok':bool(ok),'detail':str(detail)})

for rel in [
    'services/conversation_intelligence_v29.py',
    'services/screen_assist_v29.py',
    'services/voice_screen_assist_v30.py',
    'services/conversation_grounding_v30.py',
    'web_app/backend/main.py',
    'hall_transporte_agentic_pro/app/services/human_conversation_gateway.py',
    'scripts/hall_voice_presence_windows_v30.py',
]:
    try:
        py_compile.compile(str(ROOT/rel),doraise=True)
        check('python_compile:'+rel,True)
    except Exception as exc: check('python_compile:'+rel,False,exc)

try:
    from services import language_manager
    catalog=language_manager.language_catalog()
    check('languages_70_plus',len(catalog)>=70,f'{len(catalog)} languages')
except Exception as exc: check('languages',False,exc)

try:
    from services import voice_screen_assist_v30 as vs
    st=vs.status(); cfg=st.get('config') or {}
    check('voice_screen_status',st.get('ok') is True,st.get('name'))
    check('voice_screen_explicit_command',cfg.get('capture_only_on_explicit_command') is True,cfg.get('capture_only_on_explicit_command'))
    check('voice_screen_ephemeral',cfg.get('retain_captures') is False,cfg.get('retain_captures'))
    check('voice_screen_command_pt',vs.matches_voice_command('HAL, veja minha tela e me diga o que está errado').get('matched') is True)
    check('voice_screen_normal_question_not_capture',vs.matches_voice_command('Qual é a capital da França?').get('matched') is False)
except Exception as exc: check('voice_screen',False,exc)

try:
    from services import conversation_grounding_v30 as g
    bad=g.analyze_candidate('Pode me explicar o erro ORA-01653?','Claro! Quer que eu conte uma piada para descontrair?',{'intent':'database','topic_signature':'database'},[])
    good=g.analyze_candidate('Conte uma piada sobre DBA','Claro! Aqui vai uma piada de DBA.',{'intent':'knowledge','topic_signature':'general_chat'},[])
    check('grounding_blocks_random_joke',bad.get('should_rewrite') is True,bad.get('reasons'))
    check('grounding_allows_requested_joke',good.get('should_rewrite') is False,good.get('reasons'))
except Exception as exc: check('grounding',False,exc)

try:
    # Force the agentic package to win over root app.py.
    for key in [str(AGENTIC), str(ROOT)]:
        if key in sys.path: sys.path.remove(key)
    sys.path.insert(0,str(ROOT))
    sys.path.insert(0,str(AGENTIC))
    from app.services import human_conversation_gateway as h
    cases={
        'ora_database':('Pode me explicar o erro ORA-01653?','database'),
        'oracle_recommendation':('Qual índice você recomenda para essa query Oracle?','database'),
        'general_history':('Explique a Revolução Francesa','knowledge'),
        'child_education':('Explique equação de primeiro grau para meu filho','education'),
    }
    for name,(q,expected) in cases.items():
        got=h.classify_message(q,{'turns':[]}).get('intent')
        check('intent_'+name,got==expected,f'{got} expected {expected}')
except Exception as exc: check('intent_classifier',False,exc)

try:
    js=(ROOT/'web_app/frontend/unified_app.js').read_text(encoding='utf-8-sig')
    check('frontend_voice_screen_command','/api/v30/voice-screen/analyze' in js and 'hallPresenceHandleScreenCommand' in js)
    check('frontend_longer_turn_wait','Math.max(2200' in js and '3000' in js)
    if subprocess.run(['node','--check',str(ROOT/'web_app/frontend/unified_app.js')],capture_output=True,text=True).returncode==0:
        check('javascript_syntax',True)
    else:
        check('javascript_syntax',False,'node --check failed')
except FileNotFoundError:
    check('javascript_syntax',True,'node unavailable in target validator; source markers verified')
except Exception as exc: check('frontend',False,exc)

try:
    native=(ROOT/'scripts/hall_voice_presence_windows_v30.py').read_text(encoding='utf-8-sig')
    check('native_companion_voice_screen','/api/v30/voice-screen/analyze' in native and 'is_voice_screen_command' in native)
    check('native_companion_waits_end','max(2200' in native)
except Exception as exc: check('native_companion',False,exc)

report={
  'product':'JR-AI / HAL V30 Voice-First Conversation + Screen Assist',
  'version':'30.0',
  'ok':all(c['ok'] for c in checks),
  'checks':checks,
  'notes':[
    'Voice screen capture uses native Windows desktop capture when an explicit spoken screen command is detected.',
    'A local Ollama vision-capable model is still required to interpret pixels; capture alone does not invent visual content.',
    'Continuous voice keeps the same conversation session so HAL can ask a follow-up question and listen to the answer.',
    'Intent Grounding V30 blocks off-topic joke/humor drift unless the user actually requested it.',
    'Full FastAPI startup remains dependent on the target Windows environment and installed database drivers.'
  ]
}
(ROOT.parent/'VALIDACAO_HALL_V30.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(0 if report['ok'] else 1)
