"""Run offline STT in HAL's existing voice environment, without a shell."""
from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from services.local_stt_recovery_v42_5 import status_config, transcribe_config


def main():
    request = json.load(sys.stdin)
    config = request.get('config') or {}
    if len(sys.argv) != 2 or sys.argv[1] not in {'status', 'transcribe'}:
        raise ValueError('Operação de voz inválida.')
    if sys.argv[1] == 'status':
        data = status_config(config, use_child=False)
    else:
        audio = Path(request['path']).resolve()
        allowed = ROOT/'hall_transporte_agentic_pro/data/local_stt_fallback/audio'
        if not audio.is_relative_to(allowed.resolve()):
            raise ValueError('Áudio fora da pasta de captura da HAL.')
        data = transcribe_config(audio, str(request.get('language') or 'pt'), config, use_child=False)
    print(json.dumps(data, ensure_ascii=True))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(json.dumps({'ok': False, 'ready': False, 'text': '', 'error': str(error)}))
        sys.exit(1)
