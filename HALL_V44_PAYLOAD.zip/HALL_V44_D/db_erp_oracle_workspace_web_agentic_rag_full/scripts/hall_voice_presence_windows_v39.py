"""V39: WebRTC capture + local speaker matching + interruptible conversation."""
import queue, threading, time
from voice_identity_v39 import VoiceIdentity,TurnBuffer
from voice_browser_v39 import Bridge,BrowserSpeaker
from voice_turns_v38 import VoiceTurns
import hall_voice_presence_windows_v38 as previous
base=previous.base
base.RUNTIME=base.DATA/'native_runtime_v39.json';base.LOGFILE=base.DATA/'native_voice_v39.log'

class HallVoice(previous.HallNativeVoice):
    def __init__(self,cfg):
        import numpy as np,requests,keyring,webrtcvad
        from faster_whisper import WhisperModel
        self.np=np;self.requests=requests;self.keyring=keyring;self.cfg=cfg
        self.voice_source='windows_native_v39';self.http=requests.Session();self.active=False;self.language='pt-BR';self.running=True
        self.wake_phrases=[];self.sleep_phrases=[];self.last_heartbeat=0;self.conversation_id=''
        self.input_name='Navegador WebRTC V39';self.input_device=None
        self.bridge=Bridge(base.DATA);self.speaker=BrowserSpeaker(self.bridge);self.bridge.speaker=self.speaker
        self.turns=VoiceTurns(self._request_turn,self.speaker,self._cancel_turn)
        self.model=WhisperModel(cfg.get('stt_model','small'),device='cpu',compute_type='int8',cpu_threads=2)
        self._login();self.active=False
        self.identity=VoiceIdentity(base.DATA/'voice_profiles_v39',str(cfg.get('username') or ''))
        self.vad=webrtcvad.Vad(2);self.noise=.002
        self.state_lock=threading.RLock();self.generation=0;self.accepted_uid=-1;self.capture_uid=0
        self.buffer=TurnBuffer(cfg.get('conversation_pause_v39_ms',1400));self.enrolling=False;self.enrollment_busy=False;self.enroll_frames=[]
        self.prefix_q=queue.Queue(maxsize=1);self.utterance_q=queue.Queue(maxsize=2)
        self.bridge.update(registered=self.identity.vector is not None,status='Ligue o microfone e cadastre sua voz.')
        threading.Thread(target=self._prefix_worker,daemon=True).start()
        threading.Thread(target=self._utterance_worker,daemon=True).start()
    def _refresh(self,status=None,**extra):
        data={'active':self.active,'registered':self.identity.vector is not None,**extra}
        if status:data['status']=status
        self.bridge.update(**data)
    def _standby(self):
        with self.state_lock:
            self.generation+=1;self.active=False;self.turns.deactivate();self.enrolling=False;self.enrollment_busy=False
            self.enroll_frames=[]
            try:
                while True:self.bridge.frames.get_nowait()
            except queue.Empty:pass
            self.buffer=TurnBuffer(self.cfg.get('conversation_pause_v39_ms',1400));self.accepted_uid=-1
            self._refresh('Em espera. Diga HAL ativar.')
    def _owner(self,uid,generation):
        with self.state_lock:
            if generation!=self.generation or uid<self.accepted_uid or self.enrolling:return False
            if uid>self.accepted_uid:
                self.accepted_uid=uid
                if self.active:self.turns.interrupt()
            return True
    def _prefix_worker(self):
        while self.running:
            uid,generation,frames=self.prefix_q.get()
            try:
                ok,score=self.identity.match(self.np.concatenate(frames))
                with self.state_lock:
                    if generation!=self.generation or uid!=self.capture_uid:continue
                    if ok:
                        self._owner(uid,generation);self._refresh('Estou ouvindo você.',voice_match=round(score,3))
                    else:
                        self.speaker.hold(False);self._refresh('Voz não confirmada; aguardando.',voice_match=round(score,3))
            except Exception as exc:self._refresh(error='Identificação de voz: '+str(exc));self.speaker.hold(False)
    def _transcribe_checked(self,audio):
        lang=base.LANG.get(self.language,base.LANG['pt-BR'])['whisper']
        segments,info=self.model.transcribe(audio,language=lang,beam_size=1,vad_filter=True,condition_on_previous_text=False)
        good=[]
        for segment in segments:
            if float(getattr(segment,'no_speech_prob',0))>.65:continue
            if float(getattr(segment,'avg_logprob',0))<-1.0:continue
            if float(getattr(segment,'compression_ratio',1))>2.4:continue
            good.append(segment.text.strip())
        return ' '.join(good).strip()
    def _utterance_worker(self):
        while self.running:
            kind,uid,generation,frames,voiced=self.utterance_q.get()
            try:
                if kind=='enroll':
                    clips=[self.np.concatenate(x) if x else self.np.array([],dtype='float32') for x in voiced]
                    with self.state_lock:
                        if generation!=self.generation:continue
                    self.identity.enroll(clips,valid=lambda:generation==self.generation)
                    with self.state_lock:
                        if generation!=self.generation:continue
                        self.enrolling=False;self.enrollment_busy=False
                        self._refresh('Voz cadastrada. Diga HAL ativar.',error='')
                    continue
                ok,score=self.identity.match(self.np.concatenate(voiced))
                if not ok:
                    with self.state_lock:
                        if generation==self.generation and uid==self.capture_uid:
                            self.speaker.hold(False);self._refresh('Voz não confirmada; conversa paralela ignorada.',voice_match=round(score,3))
                    continue
                with self.state_lock:
                    if generation!=self.generation:continue
                self._owner(uid,generation)
                text=self._transcribe_checked(self.np.concatenate(frames))
                with self.state_lock:
                    if generation!=self.generation:continue
                    lang=base.LANG.get(self.language,base.LANG['pt-BR'])
                    sleep,_,_=base.phrase_match(text,self.sleep_phrases or lang['sleep'])
                    if sleep:
                        self._standby();self._refresh(transcript=text,error='');continue
                    if uid!=self.accepted_uid:continue
                    self.speaker.hold(False)
                    if not text:
                        if self.active:self.speaker.say('Não consegui ouvir essa parte. Pode repetir o último trecho?')
                        self._refresh('Trecho pouco claro.');continue
                    self._handle_text(text)
                    self._refresh('Conversa ativa.' if self.active else 'Em espera. Diga HAL ativar.',transcript=text,error='')
            except Exception as exc:
                with self.state_lock:
                    if generation==self.generation:
                        self.enrolling=False;self.enrollment_busy=False;self.speaker.hold(False);self._refresh(error=str(exc),status='Não consegui processar esse trecho.')
    def _queue_latest(self,q,item):
        try:q.put_nowait(item)
        except queue.Full:
            try:q.get_nowait()
            except queue.Empty:pass
            q.put_nowait(item)
    def _control(self,action):
        if action in {'standby','disconnect','delete','enroll'}:
            self._standby()
        if action=='delete':self.identity.delete();self._refresh('Cadastro apagado.')
        elif action=='disconnect':self.bridge.connected=False;self._refresh('Microfone desligado.')
        elif action=='enroll':
            if not self.bridge.connected:self._refresh(error='Ligue o microfone antes de cadastrar.');return
            self.enrolling=True;self.enroll_frames=[];self._refresh('Gravando cadastro: fale sozinho por 18 segundos.',error='')
    def _frame(self,frame):
        np=self.np
        if not np.all(np.isfinite(frame)):return
        pcm=(np.clip(frame,-1,1)*32767).astype('<i2').tobytes()
        speech=self.vad.is_speech(pcm,16000)
        level=float(np.sqrt(np.mean(frame*frame)))
        if not speech:self.noise=.98*self.noise+.02*level
        speech=speech and level>=max(.003,min(.018,self.noise*2))
        if self.enrollment_busy:return
        if self.enrolling:
            self.enroll_frames.append((frame,speech))
            count=len(self.enroll_frames)
            if count%50==0:self._refresh('Cadastro: '+str(max(0,18-count//50))+' segundos restantes.')
            if count==900:
                clips=[[f for f,v in self.enroll_frames[i:i+300] if v] for i in [0,300,600]]
                self.enroll_frames=[];self.enrolling=False;self.enrollment_busy=True
                self._queue_latest(self.utterance_q,('enroll',0,self.generation,[],clips))
                self._refresh('Analisando o cadastro de voz…')
            return
        if self.identity.vector is None:return
        for event,uid,data in self.buffer.push(frame,speech):
            if event=='start':
                self.capture_uid=uid
                if self.active:self.speaker.hold(True)
            elif event=='prefix':self._queue_latest(self.prefix_q,(uid,self.generation,data))
            elif event=='reject':self.speaker.hold(False)
            elif event=='end':self._queue_latest(self.utterance_q,('turn',uid,self.generation,*data))
    def run(self):
        self.bridge.start()
        def heartbeat():
            while self.running:
                self._heartbeat();time.sleep(5)
        threading.Thread(target=heartbeat,daemon=True).start()
        while self.running:
            try:
                while True:self._control(self.bridge.controls.get_nowait())
            except queue.Empty:pass
            if self.bridge.connected and time.monotonic()-self.bridge.last_audio>3:
                self._standby();self.bridge.connected=False;self._refresh('Captura interrompida. Ligue o microfone novamente.')
            try:raw=self.bridge.frames.get(timeout=.1)
            except queue.Empty:continue
            if not self.bridge.connected:continue
            audio=self.np.frombuffer(raw,dtype='<f4')
            for i in range(0,1600,320):self._frame(audio[i:i+320])

def main():
    client=None
    try:client=HallVoice(base.load_config());client.run()
    except KeyboardInterrupt:return 0
    except Exception as exc:base._log('[V39] '+str(exc));base._runtime(status='error',last_error=str(exc));return 2
    finally:
        if client:client.running=False;client.speaker.stop();client.bridge.server.shutdown();client.bridge.server.server_close()
    return 0
if __name__=='__main__':raise SystemExit(main())
