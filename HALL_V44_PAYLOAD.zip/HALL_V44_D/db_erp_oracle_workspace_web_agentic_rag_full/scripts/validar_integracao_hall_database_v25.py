from __future__ import annotations
import json, sys, tempfile, types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
try:
 import oracledb  # noqa
except Exception:
 stub=types.ModuleType('oracledb'); stub.Connection=object; stub.Cursor=object
 stub.init_oracle_client=lambda **kwargs: None; stub.connect=lambda **kwargs: None; stub.makedsn=lambda *a,**k:'dsn'
 sys.modules['oracledb']=stub
from fastapi.testclient import TestClient
from services.identity_access import IdentityAccessService
import web_app.backend.main as webmain

checks=[]
def ck(name,cond,detail=''):
 checks.append({'test':name,'ok':bool(cond),'detail':detail})
 if not cond: raise AssertionError(f'{name}: {detail}')

with tempfile.TemporaryDirectory(prefix='hall-v25-db-http-') as td:
 webmain.STATE.identity_access=IdentityAccessService(Path(td)/'iam')
 client=TestClient(webmain.app,base_url='http://127.0.0.1:8000')
 ck('requires_login',client.get('/api/unified/database-intelligence/status').status_code==401)
 r=client.post('/api/auth/bootstrap',json={'username':'admin','password':'AdminSecure#2026','display_name':'Administrador'})
 ck('bootstrap',r.status_code==200,r.text)
 r=client.get('/api/unified/database-intelligence/status')
 ck('status',r.status_code==200 and r.json().get('name')=='HAL Universal Database Intelligence V25',r.text)
 ck('coverage',len(r.json().get('coverage',{}).get('sql',[]))>=8 and len(r.json().get('coverage',{}).get('nosql',[]))>=7,r.text)
 r=client.post('/api/unified/database-intelligence/detect',json={'banner':'Oracle Database 11g Enterprise Edition Release 11.2.0.4.0 - 64bit Production','hint':''})
 ck('detect_oracle_http',r.status_code==200 and r.json().get('engine')=='oracle' and r.json().get('version','').startswith('11.2.0.4'),r.text)
 r=client.post('/api/unified/database-intelligence/capabilities',json={'database_type':'postgresql','version':'15','edition':''})
 ck('capabilities_http',r.status_code==200 and any(x.get('feature')=='merge' and x.get('supported') for x in r.json().get('version_features',[])),r.text)
 r=client.post('/api/unified/database-intelligence/compatibility',json={'database_type':'oracle','version':'11.2.0.4','statement':'select * from t fetch first 10 rows only'})
 ck('version_guard_http',r.status_code==200 and r.json().get('ok') is False and r.json().get('findings'),r.text)
 r=client.post('/api/unified/database-intelligence/diagnostic-plan',json={'database_type':'sqlserver','version':'15.0','scopes':['sessions','locks','top_sql','backup','ha']})
 ck('diagnostic_http',r.status_code==200 and len(r.json().get('items',[]))>=5,r.text)
 r=client.post('/api/unified/database-intelligence/guided',json={'message':'Redis 7.2 está lento, analise clientes, slowlog, memória e replicação','connection_id':'','execute_probe':False})
 ck('guided_http',r.status_code==200 and r.json().get('engine')=='redis',r.text)
 r=client.get('/api/unified/database-intelligence/skill-audit',params={'database_type':'oracle','version':'19'})
 ck('skill_audit_http',r.status_code==200 and all(x.get('score')==10 for x in r.json().get('skills',[]) if x.get('applicable')),r.text)

out={'ok':all(x['ok'] for x in checks),'passed':sum(x['ok'] for x in checks),'total':len(checks),'tests':checks}
print(json.dumps(out,ensure_ascii=False,indent=2))
