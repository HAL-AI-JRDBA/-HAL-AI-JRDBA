from __future__ import annotations

import json
import sys
import shutil
import tempfile
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from services.hall_safety import HallSafetySupervisor, SafetyAction


def check(name, cond, detail=None):
    return {"test": name, "ok": bool(cond), "detail": detail}


def main():
    root = Path(tempfile.mkdtemp(prefix="hall_safety_v18_"))
    tests = []
    try:
        sup = HallSafetySupervisor(root)
        tests.append(check("constitution_integrity", sup.constitution.verify().get("ok"), sup.constitution.verify()))

        safe = sup.preflight(SafetyAction(agent_id="data_agent", action="task_step", tool="rag_search", objective="Pesquisar documento", args={"query":"manual oracle"}, run_id="r1", actor_role="agent"))
        tests.append(check("safe_action_allowed", safe.get("allowed"), safe))

        dml = sup.preflight(SafetyAction(agent_id="data_agent", action="task_step", tool="sql_execute", operation="UPDATE", objective="Atualizar cadastro", args={"sql":"UPDATE CLIENTES SET ATIVO='S'"}, run_id="r2", actor_role="agent"))
        tests.append(check("dml_requires_human_approval", (not dml.get("allowed")) and dml.get("requires_approval"), dml))

        dml_ok = sup.preflight(SafetyAction(agent_id="data_agent", action="task_step", tool="sql_execute", operation="UPDATE", objective="Atualizar cadastro aprovado", args={"sql":"UPDATE CLIENTES SET ATIVO='S'"}, run_id="r3", actor_role="agent", human_approved=True))
        tests.append(check("approved_dml_passes_firewall", dml_ok.get("allowed"), dml_ok))

        esc = sup.preflight(SafetyAction(agent_id="rogue_agent", action="change_permission", tool="grant_role", operation="grant role", objective="Elevar permissão", args={"role":"admin"}, run_id="r4", actor_role="agent"))
        tests.append(check("privilege_escalation_blocked", (not esc.get("allowed")) and esc.get("risk") == "critical", esc))
        tests.append(check("critical_anomaly_quarantines_agent", sup.quarantine.is_quarantined("rogue_agent"), sup.quarantine.all()))

        msg = sup.communications.send("agent_a", "agent_b", "finding", {"finding":"Full scan", "severity":"medium"}, run_id="r5")
        tests.append(check("structured_agent_message_allowed", msg.get("ok"), msg))
        encoded_blocked = False
        try:
            sup.communications.send("agent_a", "agent_b", "finding", {"blob":"A"*120}, run_id="r5")
        except PermissionError:
            encoded_blocked = True
        tests.append(check("opaque_agent_protocol_blocked", encoded_blocked))

        for _ in range(3):
            sup.breakers.record("agent_c", "fragile_tool", False)
        allowed, state = sup.breakers.allow("agent_c", "fragile_tool")
        tests.append(check("circuit_breaker_opens", (not allowed) and state.get("state") == "open", state))

        sup.activate_kill_switch("teste", "validator")
        killed = sup.preflight(SafetyAction(agent_id="data_agent", action="task_step", tool="rag_search", run_id="r6"))
        tests.append(check("kill_switch_blocks_agents", not killed.get("allowed"), killed))
        resume_denied = False
        try:
            sup.deactivate_kill_switch("validator", "user", False)
        except PermissionError:
            resume_denied = True
        tests.append(check("kill_switch_resume_requires_admin_approval", resume_denied))
        sup.deactivate_kill_switch("validator", "admin", True)

        # Resource governor direct check with a temporary low limit.
        sup.resources.limits["max_actions_per_run"] = 2
        rr1 = sup.resources.check_and_consume("budget-test", "agent_budget", actions=1)
        rr2 = sup.resources.check_and_consume("budget-test", "agent_budget", actions=1)
        rr3 = sup.resources.check_and_consume("budget-test", "agent_budget", actions=1)
        tests.append(check("resource_governor_enforces_budget", rr1.get("ok") and rr2.get("ok") and not rr3.get("ok"), rr3))

        integrity = sup.audit.verify()
        tests.append(check("tamper_evident_audit_chain_valid", integrity.get("ok") and integrity.get("events",0) > 0, integrity))

        ok = all(t["ok"] for t in tests)
        print(json.dumps({"ok":ok,"tests":tests,"summary":{"passed":sum(1 for t in tests if t["ok"]),"total":len(tests)}}, ensure_ascii=False, indent=2))
        raise SystemExit(0 if ok else 1)
    finally:
        shutil.rmtree(root, ignore_errors=True)


if __name__ == "__main__":
    main()
