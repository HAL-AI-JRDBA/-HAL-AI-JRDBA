from __future__ import annotations
import json, sys, tempfile, shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from services.enterprise_web_access import EnterpriseWebAccessManager

results=[]
def check(name, ok, detail=''):
    results.append({'test':name,'ok':bool(ok),'detail':detail})
    if not ok: raise AssertionError(f'{name}: {detail}')

tmp=Path(tempfile.mkdtemp(prefix='hall_v20_'))
try:
    fake_root=tmp/'project'; fake_root.mkdir(parents=True)
    mgr=EnterpriseWebAccessManager(fake_root,fake_root/'data'/'web')
    c=mgr.config(); check('default_local',c['mode']=='LOCAL')
    check('default_loopback',c['public_url']=='http://127.0.0.1:8000')
    c=mgr.save_config({'mode':'INTRANET','public_url':'https://hall.empresa.local','tls_mode':'internal','network_whitelist_enabled':True,'allowed_networks':['10.0.0.0/8','192.168.0.0/16'],'trust_proxy_headers':True},'test')
    check('intranet_mode',c['mode']=='INTRANET')
    check('secure_cookie',c['cookie_secure'] is True)
    check('hostname_added','hall.empresa.local' in c['allowed_hosts'])
    text=mgr.generate_caddyfile(); check('caddy_reverse_proxy','reverse_proxy 127.0.0.1:8000' in text)
    check('caddy_tls_internal','tls internal' in text)
    try:
        mgr.save_config({'mode':'INTERNET','public_url':'http://hall.example.com','tls_mode':'off'},'test')
        check('internet_requires_https',False,'deveria falhar')
    except ValueError:
        check('internet_requires_https',True)
    c=mgr.save_config({'mode':'INTERNET','public_url':'https://hall.example.com','tls_mode':'automatic','network_whitelist_enabled':False,'trust_proxy_headers':True},'test')
    check('internet_https',c['cookie_secure'] and c['mode']=='INTERNET')
    text=mgr.generate_caddyfile(); check('caddy_auto_https','hall.example.com {' in text and 'tls internal' not in text)
finally:
    shutil.rmtree(tmp,ignore_errors=True)

print(json.dumps({'ok':all(x['ok'] for x in results),'passed':sum(x['ok'] for x in results),'total':len(results),'tests':results},ensure_ascii=False,indent=2))
