from __future__ import annotations
import json, sys, tempfile, types
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

try:
    import oracledb  # noqa
except Exception:
    stub=types.ModuleType('oracledb'); stub.Connection=object; stub.Cursor=object
    stub.init_oracle_client=lambda **kwargs: None; stub.connect=lambda **kwargs: None; stub.makedsn=lambda *a,**k:'dsn'
    sys.modules['oracledb']=stub

from fastapi.testclient import TestClient
from services.identity_access import IdentityAccessService
from services.model_lifecycle import ModelLifecycleManager, _write_json
from services.enterprise_web_access import EnterpriseWebAccessManager
import web_app.backend.main as webmain

checks=[]
def ck(name,cond,detail=''):
    checks.append({'test':name,'ok':bool(cond),'detail':detail})
    if not cond: raise AssertionError(f'{name}: {detail}')

with tempfile.TemporaryDirectory(prefix='hall-v20-http-') as td:
    t=Path(td)
    webmain.STATE.identity_access=IdentityAccessService(t/'iam')
    router=t/'router.json'; _write_json(router,{'models':{'chat':'qwen2.5:7b'}})
    webmain.STATE.model_lifecycle=ModelLifecycleManager(t,t/'models',router)
    webmain.STATE.web_access=EnterpriseWebAccessManager(t,t/'web')
    client=TestClient(webmain.app,base_url='http://127.0.0.1:8000')

    r=client.get('/api/health')
    ck('health_public',r.status_code==200)
    ck('security_header_nosniff',r.headers.get('x-content-type-options')=='nosniff')
    ck('request_id_header',bool(r.headers.get('x-request-id')))
    ck('web_access_requires_login',client.get('/api/web-access/status').status_code==401)

    r=client.post('/api/auth/bootstrap',json={'username':'admin','password':'AdminSecure#2026','display_name':'Administrador'})
    ck('bootstrap_admin',r.status_code==200,r.text)
    r=client.get('/api/web-access/status')
    ck('admin_web_access_status',r.status_code==200,r.text)
    ck('default_local_status',r.json().get('config',{}).get('mode')=='LOCAL')

    r=client.put('/api/web-access/config',json={'changes':{
        'mode':'INTRANET','public_url':'https://hall.empresa.local','tls_mode':'internal',
        'network_whitelist_enabled':False,'allowed_networks':['10.0.0.0/8','127.0.0.0/8'],
        'trust_proxy_headers':True,'trusted_proxies':['127.0.0.1/32'],
    }})
    ck('save_intranet_config',r.status_code==200,r.text)
    ck('restart_required',r.json().get('restart_required') is True)
    r=client.post('/api/web-access/generate-caddy',json={})
    ck('generate_caddy_endpoint',r.status_code==200 and 'reverse_proxy 127.0.0.1:8000' in r.json().get('caddyfile',''))
    ck('caddy_tls_internal','tls internal' in r.json().get('caddyfile',''))

    # reset local so secure cookie / host policies do not affect remaining tests
    webmain.STATE.web_access.save_config({'mode':'LOCAL','public_url':'http://127.0.0.1:8000','tls_mode':'off','network_whitelist_enabled':False,'trust_proxy_headers':False,'hsts_enabled':False},'test')

    # Host allowlist should reject an unconfigured hostname.
    bad=client.get('/api/health',headers={'Host':'evil.example'})
    ck('host_allowlist',bad.status_code==421,bad.text)

    # Model lifecycle V20 exposes scheduler metadata.
    r=client.get('/api/model-lifecycle/status')
    ck('model_lifecycle_admin',r.status_code==200,r.text)
    body=r.json(); ck('model_scanner_metadata',all(k in body for k in ('scanner_running','last_scan_at','next_scan_at','hugging_face_status')))

out={'ok':all(x['ok'] for x in checks),'passed':sum(x['ok'] for x in checks),'total':len(checks),'tests':checks}
print(json.dumps(out,ensure_ascii=False,indent=2))
