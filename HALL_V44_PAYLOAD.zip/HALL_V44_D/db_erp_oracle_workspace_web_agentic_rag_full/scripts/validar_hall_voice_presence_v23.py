from __future__ import annotations
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))

# Isola os dados de runtime da validação.
import services.voice_presence_v23 as vp

tmp = Path(tempfile.mkdtemp(prefix="hall_v23_test_"))
vp.DATA_DIR = tmp
vp.CONFIG_FILE = tmp / "config.json"
vp.PREFERENCES_FILE = tmp / "preferences.json"
vp.SESSIONS_FILE = tmp / "sessions.json"
vp.AUDIT_FILE = tmp / "audit.jsonl"

tests=[]
def check(name, cond, detail=""):
    tests.append({"test":name,"ok":bool(cond),"detail":detail})
    if not cond: raise AssertionError(name+": "+detail)

for lang, activation, deactivation in [
    ("pt-BR","HAL ativar","HAL desativar"),
    ("en-US","HAL activate","HAL deactivate"),
    ("es-ES","HAL activar","HAL desactivar"),
    ("zh-CN","HAL 启动","HAL 停用"),
    ("ja-JP","HAL 起動","HAL 停止"),
]:
    u="user_"+lang.lower().replace('-','_')
    r=vp.interpret(u, "conversa aleatória antes de ativar", lang)
    check(lang+" ignores dormant speech", r["action"]=="ignore" and not r["active"])
    r=vp.interpret(u, activation, lang)
    check(lang+" activates", r["action"]=="activate" and r["active"])
    r=vp.interpret(u, "uma pergunta normal", lang)
    check(lang+" continuous turn", r["action"]=="turn" and r["active"])
    r=vp.interpret(u, deactivation, lang)
    check(lang+" deactivates", r["action"]=="deactivate" and not r["active"])

r=vp.interpret("combo","HAL ativar qual é o status do Oracle?","pt-BR")
check("activation plus question", r["action"]=="activate_and_turn" and "status" in r["query"])

prefs=vp.save_user_preferences("combo","pt-BR",{"silence_ms":1800,"barge_in":False,"speak_answers":False})["preferences"]
check("preferences persist", prefs["silence_ms"]==1800 and prefs["barge_in"] is False and prefs["speak_answers"] is False)
check("privacy no sleeping transcript audit", "conversa aleatória antes de ativar" not in (vp.AUDIT_FILE.read_text(encoding="utf-8") if vp.AUDIT_FILE.exists() else ""))
check("status reports V23", vp.status("combo","pt-BR")["version"]=="23.0")
check("five languages", len(vp.LANGUAGE_PHRASES)==5)

# Verificações estruturais da integração Web/Windows.
html=(ROOT/'web_app/frontend/index.html').read_text(encoding='utf-8')
js=(ROOT/'web_app/frontend/unified_app.js').read_text(encoding='utf-8')
css=(ROOT/'web_app/frontend/unified_styles.css').read_text(encoding='utf-8')
main=(ROOT/'web_app/backend/main.py').read_text(encoding='utf-8')
iam=(ROOT/'services/identity_access.py').read_text(encoding='utf-8')
native=(ROOT/'scripts/hall_voice_presence_windows_v23.py').read_text(encoding='utf-8')
check('frontend presence pill', 'id="hallPresencePill"' in html)
check('frontend settings panel', 'id="hallPresenceSettings"' in html and 'hallPresenceAutoArm' in html)
check('frontend auto bootstrap', 'hallPresenceBootstrap().catch' in js and 'setTimeout(hallPresenceArm,500)' in js)
check('sleeping speech stays client-side', "if(!wake.match){return;}" in js)
check('barge-in mic monitor', 'echoCancellation:true' in js and 'hallPresence.bargeFrames' in js)
check('frontend cache busting current', ('unified_app.js?v=hall_v23' in html or 'unified_app.js?v=hall_v24' in html or 'unified_app.js?v=hall_v25' in html or 'unified_app.js?v=hall_v26' in html) and ('unified_styles.css?v=hall_v23' in html or 'unified_styles.css?v=hall_v24' in html or 'unified_styles.css?v=hall_v25' in html or 'unified_styles.css?v=hall_v26' in html))
check('backend endpoints', '/api/voice-presence/status' in main and '/api/voice-presence/interpret' in main)
check('RBAC maps voice to conversation', '("/api/voice-presence", "human_conversation_gateway", "chat")' in iam)
check('native credential manager', 'keyring.set_password' in native and 'Windows Credential Manager' in native)
check('native local STT', 'faster_whisper' in native and 'sounddevice' in native)

print(json.dumps({"ok":all(x["ok"] for x in tests),"passed":sum(x["ok"] for x in tests),"total":len(tests),"tests":tests},ensure_ascii=False,indent=2))
