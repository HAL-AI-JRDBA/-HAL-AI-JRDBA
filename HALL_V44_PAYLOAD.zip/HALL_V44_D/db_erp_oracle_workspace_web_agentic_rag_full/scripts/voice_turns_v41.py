from voice_turns_v38 import VoiceTurns


class ConversationalTurns(VoiceTurns):
    def _worker(self):
        while True:
            with self.changed:
                while self.pending is None:self.changed.wait()
                sid,seq,text=self.pending;self.pending=None
            try:data=self.request(sid,seq,text)
            except Exception as exc:data={'answer':'Não consegui acessar a HAL. Verifique a conexão local.','error':str(exc)}
            with self.lock:
                if self.active and self.seq==seq and not data.get('discarded'):
                    self.speaker.say(str(data.get('answer') or ''),turn={'session_id':sid,'seq':seq})
