# JR Avatar / Omnichannel — HAL

Esta versão adiciona as 8 fases para uma experiência de assistente visual no estilo futurista, com identidade própria da JR-AI.  
O avatar foi chamado de **HAL**, sem copiar nome, voz, aparência ou identidade visual de personagens de filmes.

## Fases implementadas

### Fase 1 — Avatar JR-AI na tela principal
O HAL aparece diretamente no Dashboard, com campo de pergunta, microfone, resposta por voz/texto e animação visual.

### Fase 2 — PWA mobile
Foram adicionados:
- `manifest.webmanifest`
- `sw.js`
- ícone SVG
- meta tags mobile

Assim a aplicação pode ser instalada como app web em tablets, iPad, Android, iOS e desktop.

### Fase 3 — Acesso remoto seguro
A aba traz orientações para acesso via:
- VPN
- HTTPS com proxy reverso
- Zero Trust corporativo
- autenticação obrigatória

A recomendação é não expor a porta 8000 diretamente na internet sem segurança.

### Fase 4 — WebSocket
Endpoint adicionado:

```text
/ws/jr-avatar
```

Permite conversa em tempo real entre o avatar e o backend.

### Fase 5 — Telegram Bridge
Endpoint local configurável:

```text
POST /api/jr-avatar/channels/telegram/webhook
```

A IA continua local. O Telegram é apenas canal opcional de entrada/saída.

### Fase 6 — WhatsApp Bridge opcional
Endpoints configuráveis:

```text
GET  /api/jr-avatar/whatsapp/webhook
POST /api/jr-avatar/whatsapp/webhook
```

A IA continua local. O WhatsApp é canal externo opcional e depende da infraestrutura/plataforma do cliente.

### Fase 7 — Central de notificações e permissões
Foram adicionados:
- notificações
- permissões por papel
- canais permitidos por papel
- bloqueio de ações sensíveis
- auditoria

### Fase 8 — Integração com OpenClaw Teams e aprovação humana
O HAL pode rotear solicitações para:
- OpenClaw Teams
- Agent Evaluation
- JR-Evolve Lab
- Runtime Local CPU/GPU
- DBA
- SQL
- Zabbix/Grafana
- Power BI
- Dev Studio
- RAG
- Apresentações

Ações destrutivas ou sensíveis exigem aprovação humana.

## Comportamento principal

O usuário pode perguntar direto na página inicial:

```text
HAL, o ERP está lento. Verifique Oracle, locks, Zabbix/Grafana e diga o que priorizar.
```

O HAL:
1. entende a intenção;
2. escolhe o módulo correto;
3. mostra o destino;
4. pode abrir a aba adequada;
5. preenche campos compatíveis;
6. sugere a próxima ação;
7. exige aprovação se houver risco.

## Endpoints adicionados

```text
GET  /api/jr-avatar/status
GET  /api/jr-avatar/config
POST /api/jr-avatar/config
GET  /api/jr-avatar/permissions
POST /api/jr-avatar/permissions
POST /api/jr-avatar/turn
POST /api/jr-avatar/route
GET  /api/jr-avatar/sessions
GET  /api/jr-avatar/sessions/{filename}
POST /api/jr-avatar/notification
GET  /api/jr-avatar/notifications
POST /api/jr-avatar/pwa/generate
GET  /api/jr-avatar/remote-access-notes
GET  /api/jr-avatar/channel-status
POST /api/jr-avatar/channels/{channel}/webhook
GET  /api/jr-avatar/telegram/webhook
GET  /api/jr-avatar/whatsapp/webhook
POST /api/jr-avatar/whatsapp/webhook
GET  /api/jr-avatar/messages
GET  /api/jr-avatar/audit
WS   /ws/jr-avatar
```

## Importante

A JR-AI continua:
- local;
- open-source;
- sem OpenAI;
- sem Anthropic;
- com Ollama local;
- com opção CPU/GPU;
- com canais externos opcionais e governados.
