# DB ERP Local Studio V3.3 GenAI

Aplicação local em **Streamlit + Ollama + Oracle** para:
- gerar e revisar Views Oracle
- analisar metadados de schemas ERP multi-módulo
- sugerir joins compostos
- validar SQL no Oracle
- comparar versões de Views
- executar análises operacionais, financeiras, preditivas e antifraude em datasets Oracle ou arquivos

## Correções desta versão

- corrigido `StreamlitDuplicateElementId` com `key` únicos para widgets repetidos
- separação do contexto de módulo da aba de **schema/view** e da aba de **análises**, evitando mistura de prompts
- indexação de PDFs e documentos em **lotes** no Ollama para reduzir timeout
- mensagens de erro mais claras para timeout de embedding
- adicionados parâmetros de ambiente:
  - `EMBEDDING_BATCH_SIZE`
  - `EMBEDDING_TIMEOUT`
  - `EMBEDDING_KEEP_ALIVE`
- corrigido o `default_oracle_lib_dir` para `C:\oracle\provider\bin`
- instalador continua bloqueando Python **free-threaded** e interrompe se a instalação falhar

## Recursos mantidos

- modelo gerador local
- modelo revisor/corretor local
- histórico `V_1`, `V_2`, `V_3`...
- botão **Comparar versões**
- botão **Validar no Oracle**
- botão **Gerar View final**
- sugestão automática de joins com foco em chaves compostas ERP
- detecção de tabelas mestre x movimento e famílias operacionais
- análises heurísticas para anomalias, consumo, fraude, controller e parecer executivo

## Módulos ERP contemplados

- Abastecimento
- Ativo
- Bilheteria
- Contabilidade
- Contas a Pagar
- Contas a Receber
- Bancos / Tesouraria
- Despachante
- Estoque
- Escrita Fiscal
- Fretamento
- Turismo
- Frota
- Manutenção
- Plantão
- RH
- Arrecadação
- Escala
- Tráfego
- Compras
- Comercial
- Operação
- Administrativo
- e modo genérico para módulos não mapeados

## Modelos sugeridos no Ollama

```powershell
ollama pull qwen2.5-coder:14b
ollama pull deepseek-coder-v2:16b
ollama pull embeddinggemma
```


## Versão Agentic RAG adicionada

Esta entrega inclui uma nova camada de **Agentic RAG** mantendo as funcionalidades existentes.

Principais inclusões:

- planner para decompor perguntas complexas em subperguntas;
- recuperação iterativa com reescrita de consulta quando a evidência é fraca;
- evidence grader para medir cobertura, confiança e lacunas;
- Graph RAG local simples por entidades e relações de coocorrência;
- reflection/check final para reduzir alucinação;
- trace local em `data/agentic_rag/traces.jsonl`;
- novo modo `Agentic RAG` na aba RAG;
- novos scripts `install_agentic.bat` e `run_agentic_web.bat`.

Para detalhes, consulte `README_AGENTIC_RAG.md`.

## Instalação

1. Use **Python padrão** (com GIL), preferencialmente:
   - Python 3.12 x64 normal
   - Python 3.13 x64 normal
2. Rode `install_local.bat`
3. Rode `run_local.bat`

## Como saber se o seu Python está errado

```powershell
python -VV
```

Se aparecer algo como **`free-threading build`**, você está usando a variante errada para este projeto.

## Parâmetros úteis

```text
EMBEDDING_BATCH_SIZE=12
EMBEDDING_TIMEOUT=600
EMBEDDING_KEEP_ALIVE=15m
```

## Observações

- As análises preditivas e antifraude continuam sendo **heurísticas locais**.
- Quanto melhor estiverem os nomes das colunas, relacionamentos e filtros SQL, melhor será a inferência.
- Em bases Oracle grandes, prefira trazer datasets analíticos menores e mais direcionados.


## Integração ChartDB

Esta versão inclui uma aba **ERD / ChartDB** para exportar o schema atual em **DDL Oracle** ou **DBML** e abrir o ChartDB local sem Docker. Consulte `README_CHARTDB.md`.

## Atualização: Módulo DBA / Monitoramento Oracle remoto

Foi adicionada uma expansão do módulo DBA com coletas somente leitura para Health Snapshot, backups RMAN/Data Pump, SQL ativo, top SQL por carga, conexões, locks, tablespaces, FRA, archivelog, jobs, alert log e backlog de demandas priorizadas.

A aplicação Web pode rodar em servidor separado do Oracle. Consulte:

- `README_DBA_MONITORING.md`
- `scripts/create_monitor_user_oracle.sql`
