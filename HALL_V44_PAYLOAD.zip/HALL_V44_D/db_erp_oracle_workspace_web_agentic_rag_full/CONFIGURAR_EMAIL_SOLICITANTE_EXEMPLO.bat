@echo off
chcp 65001 >nul
echo Configure as variaveis abaixo com seu SMTP real.
echo.
echo setx SMTP_HOST "smtp.seudominio.com"
echo setx SMTP_PORT "587"
echo setx SMTP_USER "usuario@seudominio.com"
echo setx SMTP_PASSWORD "sua_senha_ou_app_password"
echo setx SMTP_FROM "hall@seudominio.com"
echo.
echo Depois feche e abra o terminal novamente.
pause
