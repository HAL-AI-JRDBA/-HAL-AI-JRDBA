@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================================
echo JR-AI / HAL V23 - ALWAYS-ON NATURAL VOICE
echo ============================================================
echo.

if exist "web_app\backend\main.py" (
    set "HALL_PROJECT=%CD%"
) else if exist "db_erp_oracle_workspace_web_agentic_rag_full\web_app\backend\main.py" (
    set "HALL_PROJECT=%CD%\db_erp_oracle_workspace_web_agentic_rag_full"
) else (
    echo [ERRO] Projeto HAL nao encontrado.
    echo Esperado: C:\AI_HALL\db_erp_oracle_workspace_web_agentic_rag_full
    pause
    exit /b 1
)

cd /d "%HALL_PROJECT%"
if not exist ".venv_web\Scripts\python.exe" (
    echo [ERRO] Ambiente virtual .venv_web nao encontrado.
    echo Execute primeiro: install_web.bat
    pause
    exit /b 1
)
call ".venv_web\Scripts\activate.bat"

if exist "scripts\corrigir_utf8_bom_v18_2.py" python "scripts\corrigir_utf8_bom_v18_2.py" >nul 2>nul
if exist "scripts\hall_model_env_v19.py" for /f "usebackq delims=" %%L in (`python "scripts\hall_model_env_v19.py"`) do %%L
if exist "scripts\hall_web_access_env_v20.py" for /f "usebackq delims=" %%L in (`python "scripts\hall_web_access_env_v20.py"`) do %%L

if "%OLLAMA_URL%"=="" set "OLLAMA_URL=http://127.0.0.1:11434"
if "%HALL_OLLAMA_MODEL%"=="" set "HALL_OLLAMA_MODEL=qwen2.5:7b"
if "%OLLAMA_MODEL%"=="" set "OLLAMA_MODEL=%HALL_OLLAMA_MODEL%"
if "%HALL_DIALOG_MODEL%"=="" set "HALL_DIALOG_MODEL=%HALL_OLLAMA_MODEL%"
set "HALL_WEB_SUMMARY_MODEL=%HALL_DIALOG_MODEL%"
set "HALL_BOOT_MODE=V23_ALWAYS_ON_NATURAL_VOICE"
set "HALL_DIALOG_TIMEOUT=120"
set "HALL_SQL_TIMEOUT=120"
set "HALL_FAST_CODE_TIMEOUT=120"
set "HALL_CODE_TIMEOUT=180"
set "HALL_DEEP_CODE_TIMEOUT=240"
set "HALL_VISION_TIMEOUT=180"
set "HALL_CHAT_KEEP_ALIVE=15m"
set "HALL_SPECIALIST_KEEP_ALIVE=2m"

if not defined HALL_MODELS_VALIDATED_THIS_BOOT (
    set "HALL_MODELS_VALIDATED_THIS_BOOT=1"
    if exist "HALL_VALIDAR_MODELOS_V15_UMA_VEZ.bat" call "HALL_VALIDAR_MODELOS_V15_UMA_VEZ.bat"
)

if exist "check_web_deps.py" (
    echo [AUTO] Verificando dependencias Python...
    python "check_web_deps.py"
    if errorlevel 1 (
        echo [ERRO] Dependencias incompletas. Execute install_web.bat
        pause
        exit /b 1
    )
)

echo.
echo [IAM] Login/RBAC corporativo: ATIVO
echo [MODEL] Hugging Face Model Lifecycle: ATIVO - aprovacao admin obrigatoria
echo [SAFE] Safety Supervisor: ATIVO
echo [RAG] Enterprise RAG V2: ATIVO
echo [RL] Reinforcement Learning Lab: ATIVO - sandbox + aprovacao admin
echo [LANG] Idiomas: Portugues / English / Espanol / Mandarin / Japanese
echo [VOICE] HAL Voice Presence V23: ATIVO - diga "HAL ativar"
echo [WEB] Modo: %HALL_WEB_MODE%
echo [WEB] URL corporativa: %HALL_PUBLIC_URL%
echo [WEB] Backend interno: http://127.0.0.1:8000

set "HALL_BROWSER_URL=%HALL_PUBLIC_URL%"
if /I not "%HALL_WEB_MODE%"=="LOCAL" (
    if exist "INICIAR_HALL_WEB_GATEWAY_V20.bat" (
        call "INICIAR_HALL_WEB_GATEWAY_V20.bat"
        if errorlevel 1 set "HALL_BROWSER_URL=http://127.0.0.1:8000"
    ) else set "HALL_BROWSER_URL=http://127.0.0.1:8000"
)
if "%HALL_BROWSER_URL%"=="" set "HALL_BROWSER_URL=http://127.0.0.1:8000"

echo.
echo [START] HAL backend em 127.0.0.1:8000
start "" "%HALL_BROWSER_URL%"
python -m uvicorn web_app.backend.main:app --host 127.0.0.1 --port 8000 --proxy-headers --forwarded-allow-ips="127.0.0.1,::1"

echo.
echo [INFO] HAL V23 encerrado.
pause
endlocal
