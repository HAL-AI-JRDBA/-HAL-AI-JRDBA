# JR-AI — Voz Própria / Perfil de Voz

Esta versão adiciona uma aba completa para cadastrar e usar uma voz própria dentro da JR-AI.

## O que foi implementado

- Nova aba **Voz Própria**
- Gravação de voz pelo navegador usando microfone
- Upload de amostras de áudio gravadas fora da aplicação
- Lista guiada de frases de treinamento
- Consentimento explícito obrigatório
- Perfil de voz local com:
  - nome do dono da voz
  - sotaque paulistano
  - tom desejado
  - estilo de fala
  - calibração de pausas
  - tolerância a ruído
  - assinatura local simples de locutor
- Identificação de locutor preparada
- Integração com:
  - HAL / JR Avatar
  - JR Voz
  - JR Ao Vivo
  - OpenClaw Runtime
  - Chat JR-AI
- Configuração de motores locais:
  - Browser fallback
  - Piper
  - Coqui XTTS
  - OpenVoice
  - F5-TTS
  - comando local personalizado
- Ajuste para o HAL não interromper a fala do usuário
- Resposta com tom educado, claro, objetivo, humilde e agradável

## Importante

Este ZIP **não contém a voz real do usuário**, porque o áudio da conversa não é disponibilizado para o projeto.

Para usar a sua voz, execute a JR-AI, abra a aba **Voz Própria** e grave as amostras pelo navegador.

## Fluxo recomendado

1. Abra a aba **Voz Própria**
2. Marque o consentimento
3. Clique em **Criar/salvar perfil**
4. Clique em **Carregar frases**
5. Grave pelo menos 3 frases para teste inicial
6. Clique em **Enviar amostra** depois de cada gravação
7. Clique em **Calibrar perfil**
8. Clique em **Definir como padrão**
9. Teste no Dashboard com o HAL

## Quantidade de áudio recomendada

- Teste mínimo: 3 amostras
- Teste razoável: 8 a 20 amostras
- Qualidade melhor: 30 minutos ou mais, usando motor local adequado

## Voz realmente clonada

Para voz realmente parecida com a sua, instale e configure um motor local de TTS/clonagem.

Exemplo de comando local customizado:

```text
python local_tts.py --text "{text}" --speaker "{speaker_wav}" --out "{output_wav}"
```

A aba permite configurar esse comando em:

```text
Motor de voz local: Comando local personalizado
Comando local TTS opcional
```

## Segurança

- Não clone voz de terceiros sem autorização
- O consentimento é obrigatório
- O perfil pode ser apagado
- A voz fica local no projeto
- Em produção, proteger a pasta `data/jr_voice_profile`
- Evitar expor amostras de voz em backups públicos ou repositórios Git

## Endpoints adicionados

```text
GET    /api/jr-voice-profile/status
GET    /api/jr-voice-profile/config
POST   /api/jr-voice-profile/config
GET    /api/jr-voice-profile/phrases
GET    /api/jr-voice-profile/profiles
POST   /api/jr-voice-profile/profiles
GET    /api/jr-voice-profile/profiles/{profile_id}
DELETE /api/jr-voice-profile/profiles/{profile_id}
POST   /api/jr-voice-profile/default
POST   /api/jr-voice-profile/upload-sample/{profile_id}
POST   /api/jr-voice-profile/calibrate/{profile_id}
POST   /api/jr-voice-profile/identify
POST   /api/jr-voice-profile/synthesize
GET    /api/jr-voice-profile/avatar-integration
GET    /api/jr-voice-profile/audit
```

## Observação sobre qualidade

O navegador sozinho não consegue clonar sua voz real. Ele apenas usa a melhor voz pt-BR disponível.

A clonagem real depende de motor local instalado, como Piper treinado, Coqui XTTS, OpenVoice ou F5-TTS, respeitando licenças e recursos de CPU/GPU.
