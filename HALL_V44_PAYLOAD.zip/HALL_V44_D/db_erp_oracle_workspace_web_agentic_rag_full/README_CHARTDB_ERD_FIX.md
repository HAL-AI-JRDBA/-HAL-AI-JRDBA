# Correção ERD / ChartDB

Esta versão adiciona um **ERD Local** dentro da própria aplicação. Ele não depende do ChartDB nem de Docker.

## Como usar

1. Abra `run_web.bat`.
2. Vá em **Mapa ERP / Metadados**.
3. Informe owner/módulo e clique em **Analisar schema**.
4. Vá em **ERD / ChartDB**.
5. Clique em **Gerar ERD Local**.

## Usando ChartDB externo

O ChartDB continua opcional. Para usar o iframe:

1. Execute `install_chartdb_local.bat` na primeira vez.
2. Depois execute `run_chartdb_local.bat`.
3. No app, vá em **ERD / ChartDB** e clique em **Verificar ChartDB**.
4. Se o iframe ficar em branco, clique em **Abrir em nova aba**.

## Exportação

A aba também continua gerando:

- DBML para importar no ChartDB.
- DDL Oracle para revisão técnica.
