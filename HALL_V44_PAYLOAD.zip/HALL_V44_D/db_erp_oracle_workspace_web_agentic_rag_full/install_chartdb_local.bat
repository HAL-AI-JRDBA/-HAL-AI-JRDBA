
@echo off
setlocal
set CHARTDB_DIR=%USERPROFILE%\chartdb

where git >nul 2>nul
if errorlevel 1 (
  echo Git nao encontrado no PATH.
  echo Instale o Git e tente novamente.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo npm nao encontrado no PATH.
  echo Instale o Node.js 18+ e tente novamente.
  pause
  exit /b 1
)

if not exist "%CHARTDB_DIR%" (
  echo Clonando ChartDB em %CHARTDB_DIR% ...
  git clone https://github.com/chartdb/chartdb "%CHARTDB_DIR%"
  if errorlevel 1 (
    echo Falha ao clonar o ChartDB.
    pause
    exit /b 1
  )
)

cd /d "%CHARTDB_DIR%"
echo Instalando dependencias do ChartDB...
call npm install
if errorlevel 1 (
  echo Falha no npm install.
  pause
  exit /b 1
)

echo Iniciando ChartDB em modo local...
call npm run dev -- --host 127.0.0.1 --port 5173
endlocal
