# HAL V27 — Evolution Engine / Governed Self-Improvement

## Objetivo
Adicionar autoaperfeicoamento continuo e governado ao JR-AI/HAL sem remover as capacidades existentes da V26.2.

## Niveis
- **E1 Experience**: memoria de experiencias, falhas, causas-raiz e acoes corretivas.
- **E2 Optimization**: experimentos para prompt, agentes, roteador e ferramentas; comparacao por metricas.
- **E3 Engineering**: evolucao de codigo/datasets/fine-tuning em sandbox e promocao com aprovacao.
- **E4 Research**: ciclo hipotese -> experimento -> benchmark -> avaliacao -> candidato.
- **E5 Total RSI (Experimental)**: opcao futura, bloqueada por padrao.

## Seguranca do E5
Para habilitar E5 sao exigidas simultaneamente:
1. Variavel de ambiente `HALL_ALLOW_TOTAL_RSI=1` antes de iniciar o backend.
2. Usuario administrador autenticado.
3. Confirmacao literal `HABILITAR RSI TOTAL EXPERIMENTAL`.

A ausencia do gate de ambiente desativa E5 inclusive se o arquivo de configuracao tiver sido alterado manualmente.

## API
- `GET /api/evolution/status`
- `GET|PUT /api/evolution/config`
- `GET|POST /api/evolution/experiences`
- `GET|POST /api/evolution/experiments`
- `POST /api/evolution/experiments/{id}/decision`
- `POST /api/evolution/rollback`
- `POST /api/evolution/rsi-total/activate`
- `POST /api/evolution/rsi-total/disable`
- `GET /api/evolution/audit`

## Dados locais
Persistidos em `data/evolution_v27/`. Nenhum servico de nuvem e necessario para o Evolution Engine.
