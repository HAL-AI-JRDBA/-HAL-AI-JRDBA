# Correção do microfone — no-speech

## Como iniciar

Execute:

```bat
INICIAR_JR_AI_HALL_MICROFONE_CORRIGIDO.bat
```

ou o inicializador principal já existente.

## Teste

1. Abra `http://127.0.0.1:8000`.
2. Clique em `Ouvir`.
3. Espere aparecer `Ouvindo... pode falar naturalmente`.
4. Fale próximo ao microfone.

Se aparecer `Não ouvi nada ainda...`, continue falando. O HAL vai tentar ouvir novamente automaticamente.

## Se ainda falhar

Verifique:

```text
Chrome ou Edge
Permissão do microfone no cadeado da barra de endereço
Microfone correto no Windows
Volume de entrada
Nenhum outro programa bloqueando o microfone
```
