@echo off
chcp 65001 >nul
echo Instalando modelos recomendados para GPU via Ollama...
ollama pull qwen2.5:14b
ollama pull qwen2.5-coder:14b
ollama pull llama3.1:8b
ollama pull llava:7b
ollama pull mxbai-embed-large
echo Concluido. Para GPU 24GB+, avalie modelos maiores conforme VRAM.
pause
