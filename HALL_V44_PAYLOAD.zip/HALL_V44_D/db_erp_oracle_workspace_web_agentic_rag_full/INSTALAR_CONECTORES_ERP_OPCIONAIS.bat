@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo Instalando conectores opcionais para ERP, bancos, arquivos e Browser/RPA...
python -m pip install --upgrade pip
python -m pip install requests httpx pandas openpyxl lxml pymongo redis elasticsearch playwright selenium
python -m playwright install chromium
echo.
echo Drivers corporativos opcionais podem exigir instaladores do fornecedor:
echo Oracle Client / ODBC SQL Server / IBM DB2 / Firebird / etc.
echo.
pause
endlocal
