# HAL Business Teams — Guia de Uso

Esta camada adiciona o conceito de **time de agentes empresariais**, parecido com uma empresa trabalhando junto com o usuário.

## Times disponíveis

```text
Atendimento
Vendas / SDR
Conteúdo
Financeiro / Contábil
Operações
Dados / BI
Automação
Jarvis Executivo Pessoal
Personalizado
```

## Agentes disponíveis

```text
CEO Agent / Orquestrador
Agente de Governança
Agente de Atendimento
Agente SDR / Vendas
Agente de Conteúdo
Agente Financeiro / Contábil
Agente de Operações
Agente de Dados / BI
Agente de Automação
Jarvis Executivo Pessoal
```

## Canais preparados

```text
Web Chat
WhatsApp via Evolution API / WAHA / Meta Cloud API
Telegram Bot API
Discord Bot
E-mail IMAP/SMTP
iMessage via bridge macOS
Desktop Local
Power BI
Zabbix
Grafana
```

## Como usar

No Console Unificado, escreva por exemplo:

```text
HAL, crie um time de atendimento no WhatsApp para minha empresa de logística.

HAL, monte um time de vendas SDR para atacado B2B.

HAL, crie um time financeiro para priorizar contas a receber no SQL Server.

HAL, crie um time de dados e BI para analisar vendas do varejo no MongoDB.

HAL, crie um Jarvis Executivo para me dar briefing diário de indicadores.
```

O HAL detecta o objetivo, escolhe template, segmento, banco e canais, monta os agentes, cria workflow e coloca ações sensíveis na fila de aprovação humana.

## Aprovação humana

Ações sensíveis, como enviar mensagem para cliente, escrever em ERP/banco, alterar arquivo, abrir canal externo ou executar desktop, exigem aprovação.

## Arquivos locais

```text
data/business_teams/teams.json
data/business_teams/approvals.json
data/business_teams/audit.jsonl
```

## Observação

Os conectores de WhatsApp, Telegram, Discord e E-mail estão preparados como adaptadores. Para usar em produção, é necessário configurar tokens/credenciais do canal escolhido.


## HAL SaaS Builder / White Label Studio

Adicionada camada para criar apps/sites com IA, white-label, domínio próprio, projetos por cliente, preview local, código-fonte inicial, Dockerfile, deploy plan, versionamento, rollback e planos de assinatura.


## HAL Agent Runtime Enterprise

Adicionada camada de runtime para tarefas longas, fila persistente, checkpoints, pausa/retomada/cancelamento, agentes paralelos, sandbox, testes, scorecard, métricas, observabilidade, segurança enterprise e Model Advisor para modelos open-source por hardware.


## HAL Human Voice Assistant 24x7

Adicionada camada para avatar futurístico, conversa natural pt-BR, sotaque paulista/neutro, voz própria autorizada, assistente pessoal 24x7, funcionário especialista por área, política de turn-taking, barge-in e resposta humanizada integrada ao roteamento do HAL.


## HAL Real-Time Voice Engine

Adicionada camada de voz em tempo real com escuta contínua, detecção de silêncio final, barge-in, transcrição parcial/final, TTS mais lento e audível, avatar com estados, roteamento automático para ferramentas e adaptadores para faster-whisper, whisper.cpp, Piper, Coqui XTTS, F5-TTS e OpenVoice.


## HAL Open AI Access Center

Adicionada camada para democratizar IA local: escolha CPU/GPU, catálogo de modelos open-source/open-weight, plano Ollama, marketplace de funcionários digitais, modo empresa pequena/profissional/enterprise local, acesso externo seguro, ROI, backup, atualização e rollback.


## HAL OpenClaw Enterprise Layers

Adicionadas 6 camadas: Channel Gateway, n8n Workflow Center, Browser Automation, Cron Enterprise, Sandbox Enterprise e Agent Framework Bridge. Essas camadas conectam o HAL a canais externos, workflows n8n, navegador controlado, agendamentos, sandbox Docker e frameworks como CrewAI, LangGraph, AutoGen, MCP e OpenClaw.


## HAL Visual Mission Control

Adicionado painel visual futurístico estilo escritório digital de agentes, com salas por área, avatares, missões, aprovações, notas do dia, produtividade, modo operação e modo apresentação para clientes.


## HAL Universal ERP & Application Connector

Adicionada camada universal para conectar ERP, bancos relacionais/NoSQL, APIs, arquivos, n8n, browser/RPA e sistemas individuais, incluindo venda de passagens, bilhetagem e vale-transporte, com consulta somente leitura por padrão e aprovação humana para ações sensíveis.
