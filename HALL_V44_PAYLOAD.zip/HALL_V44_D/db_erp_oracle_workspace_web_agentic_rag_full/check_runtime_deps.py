from __future__ import annotations

REQUIRED = [
    ('streamlit', 'streamlit'),
    ('requests', 'requests'),
    ('oracledb', 'oracledb'),
    ('pypdf', 'pypdf'),
    ('numpy', 'numpy'),
    ('pandas', 'pandas'),
    ('openpyxl', 'openpyxl'),
    ('faker', 'faker'),
]

OPTIONAL = [
    ('chromadb', 'chromadb'),
]


def main() -> int:
    failed: list[str] = []
    optional_missing: list[str] = []
    for module_name, package_name in REQUIRED:
        try:
            __import__(module_name)
        except Exception:
            failed.append(package_name)

    for module_name, package_name in OPTIONAL:
        try:
            __import__(module_name)
        except Exception:
            optional_missing.append(package_name)

    if failed:
        print('[ERRO] Dependencias ausentes ou quebradas:')
        for item in failed:
            print(f' - {item}')
        print('')
        print('Corrija o ambiente e rode novamente o install_local.bat.')
        return 1

    print('[OK] Dependencias essenciais importadas com sucesso.')
    if optional_missing:
        print('[AVISO] Dependencias opcionais ausentes; o app seguirá com fallback local:')
        for item in optional_missing:
            print(f' - {item}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
