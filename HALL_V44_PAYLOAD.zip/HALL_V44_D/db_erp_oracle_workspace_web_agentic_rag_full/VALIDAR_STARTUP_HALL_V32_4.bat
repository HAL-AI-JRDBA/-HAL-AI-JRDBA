@echo off
call "%~dp0..\VALIDAR_STARTUP_HALL_V32_4.bat"
exit /b %ERRORLEVEL%
