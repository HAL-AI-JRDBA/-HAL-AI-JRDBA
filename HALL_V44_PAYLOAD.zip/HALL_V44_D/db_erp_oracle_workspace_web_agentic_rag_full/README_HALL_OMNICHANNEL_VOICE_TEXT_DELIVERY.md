# HAL Omnichannel Voice/Text Delivery

Esta versão adiciona ao projeto a camada para entregar as respostas do HAL em WhatsApp e Telegram, em texto e voz.

## Objetivo

Quando o usuário pedir, ou quando a configuração de autoentrega estiver ativada, o HAL pode preparar e/ou enviar a resposta para:

```text
WhatsApp
Telegram
Teams — texto preparado
E-mail — texto/voz preparado
```

O foco principal desta entrega é:

```text
WhatsApp em texto
WhatsApp em voz
Telegram em texto
Telegram em voz
```

## Como funciona

Fluxo:

```text
1. Usuário pergunta ao HAL.
2. HAL entende e gera a resposta.
3. Se a pergunta mencionar WhatsApp, Telegram, voz ou texto, a camada Omnichannel é acionada.
4. Ela prepara a resposta textual.
5. Ela prepara o roteiro de voz.
6. Se houver TTS local configurado, tenta gerar arquivo de áudio.
7. Verifica destinatário.
8. Verifica credenciais do canal.
9. Verifica aprovação humana/política.
10. Envia ou deixa preparado para envio.
```

## Exemplos de pedido

```text
HAL, responda isso e mande no WhatsApp em voz e texto.
HAL, envie a resposta para o Telegram do time de TI.
HAL, mande esse resumo para o financeiro no WhatsApp.
HAL, depois da reunião envie a ata em texto e áudio no Telegram.
```

## Canais

### WhatsApp

Para envio real por WhatsApp, configurar:

```text
WHATSAPP_TOKEN
WHATSAPP_PHONE_NUMBER_ID
```

Também pode usar:

```text
HALL_WHATSAPP_TOKEN
HALL_WHATSAPP_PHONE_NUMBER_ID
```

Observação: voz no WhatsApp exige upload de mídia ou URL pública do áudio. Esta camada prepara o áudio/roteiro e deixa o sender/desktop companion executar o envio final quando necessário.

### Telegram

Para envio real por Telegram, configurar:

```text
TELEGRAM_BOT_TOKEN
```

Também pode usar:

```text
HALL_TELEGRAM_BOT_TOKEN
```

Para Telegram, é necessário informar `chat_id`, grupo/canal autorizado ou contato.

## Contatos

A tela permite cadastrar destinos:

```text
Nome
Canal
Destinatário
Setor
Enviar texto
Enviar voz
Ativo/inativo
```

Exemplos:

```text
Financeiro WhatsApp: +5511999999999
TI Telegram: 123456789
Grupo Operações Telegram: -100123456789
```

## Voz

A camada gera:

```text
Roteiro de voz natural
Manifesto de voz
Arquivo WAV quando pyttsx3 estiver disponível
```

Para uma voz mais humana/paulista, em produção recomenda-se conectar o TTS preferido do cliente ou o módulo de voz já previsto no HAL.

## Segurança

```text
Envio externo exige aprovação por padrão.
Sem destinatário, o HAL pergunta ou deixa como pendente.
Sem credencial, o HAL prepara a entrega e informa o que falta.
Todas as entregas são auditadas.
Ações sensíveis continuam exigindo aprovação humana.
```

## Configurações principais

```json
{
  "auto_deliver_when_channel_requested": true,
  "auto_deliver_all_answers": false,
  "require_approval_for_external_send": true,
  "send_text": true,
  "send_voice": true
}
```

Se `auto_deliver_all_answers` for ativado, toda resposta do HAL passa pela camada de entrega. Use com cuidado em produção.

## Integrações

Esta camada se conecta a:

```text
Human Conversation Gateway
Meeting Intelligence Gateway
Enterprise Integration & Team Intelligence
Database Access Wizard
Reliable Web Answer
Universal ERP Connector
```


## E-mail ao Solicitante

Adicionado envio/preparo de e-mail ao solicitante dentro do HAL Omnichannel Voice/Text Delivery, com corpo em texto, áudio anexado quando disponível, assunto automático, SMTP por variáveis de ambiente e aprovação humana antes de envio externo.


## HAL Dialogue Brain V2

Substituída a conversa natural por uma versão anti-papagaio, com memória de sessão, resposta contextual, fallback para Ollama/modelo local, perguntas de esclarecimento reais e correção do comportamento repetitivo em mensagens curtas ou ambíguas.


## HAL Auto Ollama Setup

Adicionada inicialização automática do Ollama/modelo local. O sistema verifica instalação, tenta instalar via winget quando necessário, inicia o serviço, configura OLLAMA_MODEL/HALL_DIALOG_MODEL/OLLAMA_URL na sessão, baixa `qwen2.5:7b` se faltar e continua em fallback se houver falha.


## HAL Executive Financial Intelligence

Adicionada camada executiva financeira para gestores e diretoria, com indicadores fundamentalistas, EBITDA, DRE, fluxo de caixa, margens, liquidez, endividamento, rentabilidade, inadimplência, capital de giro, score de saúde financeira, fontes reais ERP/bancos/Power BI/DRE e regra de não inventar números.
