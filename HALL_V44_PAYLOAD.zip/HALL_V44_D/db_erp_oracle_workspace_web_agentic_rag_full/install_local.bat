@echo off
setlocal
cd /d %~dp0

set "PY_CMD="
where py >nul 2>nul
if %errorlevel%==0 set "PY_CMD=py"
if not defined PY_CMD (
  where python >nul 2>nul
  if %errorlevel%==0 set "PY_CMD=python"
)

if not defined PY_CMD (
  echo [ERRO] Python nao encontrado no PATH.
  echo Instale Python 3.12 ou 3.13 padrao ^(com GIL^), marque "Add Python to PATH" e tente novamente.
  pause
  exit /b 1
)

echo.
echo Verificando o interpretador Python selecionado...
%PY_CMD% check_python_env.py
if errorlevel 1 (
  echo.
  echo Instalacao abortada por incompatibilidade do interpretador.
  pause
  exit /b 1
)

if not exist .venv (
  echo.
  echo Criando ambiente virtual...
  %PY_CMD% -m venv .venv
  if errorlevel 1 (
    echo [ERRO] Falha ao criar o ambiente virtual.
    pause
    exit /b 1
  )
)

call .venv\Scripts\activate.bat
if errorlevel 1 (
  echo [ERRO] Falha ao ativar o ambiente virtual.
  pause
  exit /b 1
)

echo.
echo Atualizando ferramentas base do pip...
python -m pip install --upgrade pip setuptools wheel
if errorlevel 1 (
  echo [ERRO] Falha ao atualizar pip/setuptools/wheel.
  pause
  exit /b 1
)

echo.
echo Instalando dependencias do projeto...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo [ERRO] A instalacao das dependencias falhou.
  echo Revise a mensagem acima. Se aparecer "free-threaded build", use Python 3.12/3.13 padrao.
  pause
  exit /b 1
)

echo.
echo Verificando imports essenciais...
python check_runtime_deps.py
if errorlevel 1 (
  echo.
  echo [ERRO] A instalacao terminou incompleta ou com pacotes quebrados.
  pause
  exit /b 1
)

echo.
echo Instalacao concluida com sucesso.
echo Para executar: run_local.bat
pause
exit /b 0
