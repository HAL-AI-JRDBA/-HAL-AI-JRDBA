# Apresentações IA / Deck Studio

Módulo local e open-source para gerar apresentações PowerPoint (`.pptx`) a partir de briefing, logo, módulos ERP, exemplos por aba, prompts, resultados e insights.

## Recursos

- Nova aba: **Apresentações IA**.
- Geração de `.pptx` com `python-pptx`.
- Upload de logo local.
- Slides por aba da solução.
- Slides por módulos ERP completos de transporte:
  - Contas a Pagar
  - Contas a Receber
  - Financeiro / Controller
  - Bancos / Tesouraria
  - Bilheteria
  - Arrecadação
  - Escala
  - Frequência
  - Contabilidade
  - Folha de Pagamento
  - Jurídico
  - Abastecimento
  - Frota / Manutenção
  - Estoque / Compras
- Casos práticos: diesel, frota parada e saúde financeira.
- Salvamento em `data/presentations`.
- Integração ao OpenClaw Runtime pela skill `presentation_generate`.

## Endpoints

```text
GET  /api/presentation/status
GET  /api/presentation/templates
GET  /api/presentation/files
POST /api/presentation/upload-logo
POST /api/presentation/generate
GET  /api/presentation/download/{filename}
```

## Skill OpenClaw

```text
presentation_generate
```

Exemplo de solicitação:

```text
Gere uma apresentação PowerPoint para clientes de transporte explicando a plataforma IA ERP Oracle.
Use o logo anexado.
Inclua um slide para cada aba.
Para cada aba, coloque: o que faz, prompt, resultado, insight e benefício.
Inclua Contas a Pagar, Contas a Receber, Financeiro/Controller, Bancos, Bilheteria, Arrecadação, Escala, Frequência, Contabilidade, Folha e Jurídico.
```

## Segurança

O módulo não executa comandos Oracle, DML, DDL ou shell. Ele apenas gera arquivos locais `.pptx` como artefato.
