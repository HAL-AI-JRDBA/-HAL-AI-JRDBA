# Fábrica de Software IA Governada

Esta camada adiciona ao projeto uma **AI Software Factory local/open-source**, inspirada no modelo em que a IA gera grande parte do código e o humano vira o gargalo de revisão/aprovação.

## Objetivo

Permitir que a IA proponha melhorias no próprio projeto com governança:

1. Indexa o codebase.
2. Identifica arquivos candidatos.
3. Cria plano técnico.
4. Gera artefatos em laboratório.
5. Gera patch/diff revisável.
6. Gera testes/checklists.
7. Executa validações estáticas.
8. Faz code review automático.
9. Faz security review automático.
10. Coloca na fila de aprovação humana.
11. Aplica somente se aprovado.
12. Cria backup antes de aplicar.
13. Permite rollback.

## Arquivos adicionados

```text
services/software_factory/
  __init__.py
  factory.py
  codebase_indexer.py
  software_architect_agent.py
  coding_agent.py
  test_generator_agent.py
  test_runner.py
  code_reviewer_agent.py
  security_reviewer_agent.py
  diff_builder.py
  approval_queue.py
  release_manager.py
  rollback_manager.py
```

## Interface

Nova aba:

```text
Fábrica de Software IA
```

Nela é possível:

- criar proposta de melhoria;
- revisar plano técnico;
- ver arquivos candidatos;
- ver diff/patch;
- aprovar ou rejeitar;
- simular aplicação;
- aplicar proposta aprovada;
- executar rollback por backup;
- enviar pedido para o workflow multiagente.

## Endpoints

```text
GET  /api/software-factory/status
GET  /api/software-factory/codebase/index
GET  /api/software-factory/audit
GET  /api/software-factory/proposals
GET  /api/software-factory/proposals/{proposal_id}
POST /api/software-factory/propose
POST /api/software-factory/proposals/decision
POST /api/software-factory/proposals/apply
POST /api/software-factory/rollback
POST /api/software-factory/static-checks
```

## Workflow multiagente

Novo workflow:

```text
Fábrica de Software IA
```

Agentes adicionados:

- Arquiteto de Software IA;
- Coding Agent;
- QA/Test Engineer;
- Code Reviewer IA;
- Security Reviewer IA;
- Release Manager IA.

## Segurança

Por padrão:

- não altera produção automaticamente;
- não executa shell;
- não gera DML/DDL automático;
- não aceita path traversal;
- exige aprovação humana;
- cria backup antes da aplicação real;
- permite rollback.

## Uso recomendado

Exemplo de pedido:

```text
Adicione um coletor read-only de queries com maior consumo de CPU no módulo DBA Monitoring, com endpoint, card na interface e revisão de segurança.
```

Fluxo recomendado:

1. Clicar em **Gerar proposta**.
2. Revisar o diff.
3. Conferir code review e security review.
4. Clicar em **Simular aplicação**.
5. Clicar em **Aprovar**.
6. Clicar em **Aplicar aprovada** apenas quando estiver seguro.
7. Guardar o caminho de backup para rollback.
