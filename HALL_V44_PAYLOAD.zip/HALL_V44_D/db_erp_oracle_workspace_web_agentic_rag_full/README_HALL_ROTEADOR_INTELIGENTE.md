# HAL — Roteador Inteligente de Ferramentas

Esta versão troca a identidade visível do assistente para **HAL** e adiciona um roteador central para escolher automaticamente a ferramenta correta dentro da JR-AI.

## Objetivo

O usuário não precisa saber qual aba usar. Ele fala ou digita livremente:

```text
HAL, o ERP está lento. Verifique Oracle, Zabbix/Grafana e diga o que priorizar.
```

O HAL decide:

```text
Ferramenta: OpenClaw Teams
Aba: OpenClaw Teams
Campos: prompt da equipe preenchido automaticamente
Ação sugerida: Planejar diagnóstico
Aprovação: exigida se houver risco
```

## O que foi implementado

- Serviço `services/hall_tool_router.py`
- Roteamento automático por intenção
- Pontuação por ferramenta
- Detecção de ambiguidade
- Pergunta de esclarecimento quando duas ferramentas estiverem próximas
- Preenchimento automático de campos da aba escolhida
- Indicação de botão/ação sugerida
- Proteção para ações sensíveis
- Fallback para Pesquisa Web Confiável
- Troca da identidade visível para **HAL**
- Integração com JR Avatar / Omnichannel
- Integração com Chat JR-AI
- Integração com OpenClaw Runtime
- Integração com Voz Própria

## Ferramentas que o HAL pode escolher

```text
Chat JR-AI
Pesquisa Web Confiável
RAG / Documentos
SQL Copilot
DBA Oracle
Monitoramento Zabbix/Grafana
Power BI
Dev Studio
Apresentações IA
Agent Evaluation
JR-Evolve Lab
Runtime Local CPU/GPU
OpenClaw Teams
Voz Própria / Perfil de Voz
HAL / Omnichannel
Segurança / Aprovação Humana
```

## Exemplos

```text
"HAL, gere uma SQL de contas a receber vencidas"
→ SQL Copilot

"HAL, o ERP está lento"
→ OpenClaw Teams

"HAL, consulte os alertas do Zabbix"
→ Monitoramento

"HAL, configure para rodar em GPU"
→ Runtime Local CPU/GPU

"HAL, quero cadastrar minha voz"
→ Voz Própria

"HAL, crie um sistema em Python"
→ Dev Studio

"HAL, pesquise a documentação oficial atual do Oracle"
→ Pesquisa Web Confiável

"HAL, apague uma tabela em produção"
→ Segurança / Aprovação Humana
```

## Endpoints adicionados

```text
GET  /api/hall-router/status
GET  /api/hall-router/tools
GET  /api/hall-router/config
POST /api/hall-router/config
POST /api/hall-router/route
POST /api/hall-router/answer
GET  /api/hall-router/audit
```

## Como usar

1. Abra o Dashboard.
2. Digite ou fale no campo do HAL.
3. O HAL escolhe a ferramenta correta.
4. Ele abre a aba e preenche os campos.
5. Se estiver ambíguo, ele pergunta antes de seguir.
6. Se for sensível, ele pede aprovação humana.

## Segurança

O HAL não deve executar ações destrutivas automaticamente.

Pedidos envolvendo:

```text
DROP
TRUNCATE
DELETE
ALTER em produção
deploy
matar sessão
refresh crítico
```

são direcionados para Segurança/Aprovação Humana.
