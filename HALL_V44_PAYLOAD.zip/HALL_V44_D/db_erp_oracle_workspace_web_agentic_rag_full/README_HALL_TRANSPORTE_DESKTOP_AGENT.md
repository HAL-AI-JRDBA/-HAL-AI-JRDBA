# HAL Transporte — Assistente funcional estilo ALFRED

Esta versão corrige a arquitetura para ficar muito mais próxima do que é demonstrado em assistentes estilo "filmes".

## Ponto principal

Somente uma aplicação web não consegue controlar todo o computador por segurança do navegador.

Por isso foi adicionado:

```text
HAL Desktop Agent
```

Ele roda localmente no Windows em:

```text
http://127.0.0.1:8765
```

E permite ao HAL, com aprovação humana:

```text
Capturar tela do desktop
Capturar câmera
Abrir URLs e pesquisas
Criar pasta
Digitar texto na janela ativa
Executar atalhos de teclado
Clicar em coordenadas
Planejar comandos voltados ao ERP de transporte
```

## Como executar

1. Execute:

```bat
install_web.bat
```

2. Instale bibliotecas opcionais do Desktop Agent:

```bat
desktop_agent\INSTALAR_DESKTOP_AGENT.bat
```

3. Inicie o Desktop Agent:

```bat
desktop_agent\INICIAR_DESKTOP_AGENT.bat
```

4. Em outro terminal, inicie a JR-AI:

```bat
INICIAR_JR_AI_HALL.bat
```

5. Abra a aba:

```text
HAL Filme
```

## Para empresas de transporte

O HAL foi ajustado para comandos como:

```text
HAL, veja minha tela e analise o dashboard de arrecadação.

HAL, capture a tela do Zabbix e diga o que afeta a bilheteria.

HAL, consulte o último mês da base de dados.

HAL, abra o módulo de monitoramento e priorize alertas da garagem.

HAL, crie uma pasta para relatórios de operação.

HAL, digite uma resposta para o cliente explicando o atraso da linha.

HAL, analise viagens, arrecadação, escala e frota e gere um plano de ação.
```

## Segurança

Ações de controle do computador exigem checkbox de aprovação.

O HAL não executa ações destrutivas como:

```text
DROP
TRUNCATE
DELETE produção
Enviar e-mail sem revisão
Alterar ERP sem aprovação
```

## Visão computacional

Há dois caminhos:

1. Browser capture — captura tela/câmera pelo navegador.
2. Desktop Agent — captura tela/câmera pelo agente local.

Para análise visual detalhada, use Ollama Vision:

```bat
voice_engines\CONFIGURAR_OLLAMA_VISION.bat
```

Depois marque na aba HAL Filme:

```text
Usar Ollama Vision local
Modelo: llava:latest
```

## Observação honesta

Agora a arquitetura está correta: web app + agente local de desktop + visão + voz + memória + automação.

A qualidade final ainda depende de configurar motores locais:
- STT: faster-whisper ou whisper.cpp
- TTS: Coqui XTTS, OpenVoice, F5-TTS ou Piper
- Vision: LLaVA ou outro modelo multimodal via Ollama
