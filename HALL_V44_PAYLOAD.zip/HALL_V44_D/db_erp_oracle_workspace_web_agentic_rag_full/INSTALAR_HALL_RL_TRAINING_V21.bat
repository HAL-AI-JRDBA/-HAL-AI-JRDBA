@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
set "PROJETO=db_erp_oracle_workspace_web_agentic_rag_full"
if not exist "%PROJETO%\.venv_web\Scripts\python.exe" (
  echo [ERRO] Ambiente .venv_web nao encontrado. Execute install_web.bat primeiro.
  pause
  exit /b 1
)
call "%PROJETO%\.venv_web\Scripts\activate.bat"
echo ============================================================
echo HAL V21 - INSTALACAO OPCIONAL DO AMBIENTE DE TREINO
echo ============================================================
echo.
echo AVISO: PyTorch/Transformers/TRL sao grandes e NAO sao necessarios
echo para usar a HAL normalmente nem para dry-run do RL Lab.
echo.
set /p CONF=Digite INSTALAR para continuar: 
if /I not "%CONF%"=="INSTALAR" exit /b 0
python -m pip install --upgrade pip
python -m pip install -r "%PROJETO%\requirements_training_v21.txt"
if errorlevel 1 (
  echo [ERRO] Falha na instalacao das dependencias de treinamento.
  pause
  exit /b 1
)
echo [OK] Ambiente de treinamento V21 instalado.
pause
endlocal
