# HAL Conversational Runtime V3 — Conversa Primeiro

Esta versão corrige o problema em que o HAL parecia um “papagaio” ou um roteador de abas.

## Mudança principal

O modo automático agora funciona assim:

```text
Usuário pergunta
HAL responde naturalmente
Se precisar de ferramenta, ele usa por trás
Ele não joga o usuário para outra tela
Ele não exige botão para continuar
Ele mantém o contexto da conversa
Ele pode fazer perguntas de esclarecimento coerentes
```

## Antes

```text
Usuário: ação prática
HAL: Entendi. Me conta um pouco mais...
Usuário: eu quero que transforme isso numa ação prática
HAL: Entendi. Me conta um pouco mais...
```

## Agora

```text
Usuário: ação prática

HAL:
Pode ser sim — mas eu preciso saber qual assunto você quer transformar em ação prática.
Qual é o tema ou objetivo da ação?

Usuário:
eu quero que transforme isso numa ação prática

HAL:
Sim, pode. Só falta você me dizer o tema dessa ação.
É uma ação comercial, financeira, de banco de dados, reunião, estudo, atendimento ou automação?
```

## O que foi alterado

```text
Modo automático não abre painel técnico sozinho
Checkbox de painel vem desligado por padrão
Conversa usa memória de sessão
Resposta repetida é bloqueada
Ferramentas são usadas em segundo plano
Retorno técnico não substitui a resposta humana
Realtime voice também usa conversa natural
Unified turn em automático força Conversational Runtime V3
```

## Estilo desejado

O HAL deve ser uma IA declarada, mas com presença natural:

```text
Calmo
Seguro
Objetivo
Educado
Inteligente
Sem soar robótico
Sem responder como formulário
Sem forçar módulo ou aba
Sem inventar dado
```

A inspiração é uma presença serena e observadora como assistentes clássicos de ficção científica, mas sem fingir ser humano físico.

## Regras

```text
Responder o que foi perguntado.
Quando faltar contexto, perguntar somente o que falta.
Não repetir a mesma pergunta genérica.
Não abrir painel se o usuário só quer conversar.
Não obrigar o usuário a apertar botão para continuar.
Manter ferramentas nos bastidores.
Mostrar detalhes técnicos apenas como apoio.
```

## Ollama

O Auto Ollama continua funcionando. Se o modelo local responder, o HAL usa o modelo para deixar a conversa mais natural. Se falhar, usa fallback contextual.


## HAL Executive Financial Intelligence

Adicionada camada executiva financeira para gestores e diretoria, com indicadores fundamentalistas, EBITDA, DRE, fluxo de caixa, margens, liquidez, endividamento, rentabilidade, inadimplência, capital de giro, score de saúde financeira, fontes reais ERP/bancos/Power BI/DRE e regra de não inventar números.


## HAL Skills & Multi-Agent Center

Adicionada camada local-first para Skills em Markdown, hub local estilo ClawHub, agentes especializados, delegação de tarefas, sessions_spawn, colaboração multiagente, briefing de geração de imagens, execução governada e auditoria.


## HAL Microphone No-Speech Fix

Corrigido o erro `Erro no microfone: no-speech`: agora o HAL não trata silêncio inicial como falha fatal, testa permissão de microfone, tenta ouvir novamente automaticamente, aumenta o tempo de silêncio antes de enviar e mantém fallback por texto.


## HAL Live Dialogue Engine V4

Corrigida a rota principal para conversa natural real: o HAL responde primeiro, usa ferramentas em segundo plano, não abre painel técnico sozinho, mantém sessão, usa o modelo local com contexto das ferramentas e deixa de se comportar como roteador/papagaio.
