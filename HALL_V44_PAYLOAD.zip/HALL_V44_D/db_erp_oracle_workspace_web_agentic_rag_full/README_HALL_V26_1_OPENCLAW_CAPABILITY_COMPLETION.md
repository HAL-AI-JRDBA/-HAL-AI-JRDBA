# HAL V26.1 — OpenClaw Capability Completion

A V26.1 fecha as principais lacunas funcionais identificadas ao comparar a HAL V26
com o material **OpenClaw na Prática: Skills, Ferramentas e Agentes de IA**.

## 1. Browser Automation real

`hall_transporte_agentic_pro/app/services/browser_automation.py` agora mantém uma
sessão Chromium real via Playwright e executa navegação, leitura de DOM, clique,
preenchimento, teclado, seleção, screenshots e downloads governados.

Ações sensíveis continuam dependentes de aprovação humana. A política possui
allowlist/blocklist, perfis isolados e auditoria. Este componente **não oferece shell
do host nem controle irrestrito do Windows**.

## 2. Dynamic Planner & Replanner

`services/openclaw_runtime/dynamic_planner.py` usa um LLM Ollama local para decompor
objetivos em skills existentes. O resultado passa por validação determinística:

- somente IDs de skills do catálogo;
- somente skills permitidas ao agente;
- sem criação de comandos de shell;
- sem bypass de aprovação;
- fallback para regras locais se o modelo estiver indisponível;
- replanejamento limitado quando uma etapa falha.

## 3. Declarative Skills Runtime

Skills customizadas podem declarar um workflow com etapas:

- `tool`: chama ferramenta/skill já registrada;
- `template`: compõe conteúdo a partir do contexto;
- `condition`: decisão simples no workflow;
- `script`: Python **somente em Docker sandbox**, sem rede, com limites de CPU/RAM,
  `cap-drop ALL` e `no-new-privileges`.

Uma Skill Markdown pode conter um bloco:

```text
```hall-workflow
[{"type":"tool","tool":"notify_log","args":{"message":"{{question}}"}}]
```
```

## 4. Continuous Vision

`services/continuous_vision_v261.py` implementa captura contínua por OpenCV com:

- buffer temporal pequeno em memória;
- retenção desligada por padrão;
- detecção simples de movimento;
- análise de até 4 frames pelo modelo de visão local no Ollama;
- nenhuma nuvem externa;
- início da câmera condicionado a aprovação humana.

## 5. Memória persistente e comunicação A2A

- `agent_memory_v261.py`: memória persistente por escopo `agent`, `team`, `project`,
  `domain` e `global`.
- `agent_bus_v261.py`: mensagens persistentes entre agentes com sessão e correlation ID.

## 6. Execução autônoma contínua

`autonomous_supervisor_v261.py` executa schedules, triggers e fila em background.
Em HA, um lock/heartbeat em storage compartilhado faz leader election para evitar
que duas instâncias executem o mesmo ciclo em paralelo.

## 7. Conectores

O Connector Hub suporta log local, webhook, SMTP, Telegram Bot API e webhooks de
Slack, Teams e Discord. Secrets devem ser fornecidos por variáveis de ambiente.

## 8. HA / VPS

`deployment/v26_1_ha/` inclui:

- duas instâncias HAL;
- Caddy reverse proxy;
- health checks `/api/health`;
- failover de processo;
- Ollama;
- volume de dados compartilhado no perfil single-host;
- template para multi-VPS.

Para multi-host, a infraestrutura precisa fornecer storage persistente
compartilhado/replicado. A HAL não finge resolver replicação física sozinha.

## 9. Segurança Windows

A V26.1 mantém deliberadamente bloqueado o acesso irrestrito ao Windows:

- `unrestricted_windows_access = false`;
- shell/hotkeys administrativas bloqueadas;
- scripts customizados nunca rodam diretamente no host;
- ações Desktop continuam com aprovação e escopo de filesystem;
- Browser é isolado da automação Desktop.

## Instalação

```text
C:\AI_HALL\INSTALAR_HALL_OPENCLAW_COMPLETION_V26_1.bat
C:\AI_HALL\VALIDAR_HALL_V26_1.bat
C:\AI_HALL\INICIAR_JR_AI_HALL_V26_1.bat
```
