# HAL V26.2 — Autonomous Software Studio

## BSPA
Brainstorm → Spec → Plan → Build → Audit.

## Production Security Baseline
Apps gerados não possuem usuário/senha padrão. O bootstrap usa variáveis de ambiente e persiste apenas hash scrypt. Sessões são assinadas, mudanças exigem CSRF, login possui rate limit, rotas usam RBAC e respostas incluem security headers.

## Production Quality Gates
- Functional Quality Gate
- Security Gate
- Backup + Restore Drill
- LGPD / Privacy Readiness (não é certificação jurídica)
- Responsive / Accessibility Gate
- Deploy Readiness
- Human Approval

Deploy é deny-by-default enquanto qualquer gate crítico estiver pendente.

## Windows
Acesso irrestrito ao Windows continua bloqueado. O Studio não adiciona shell host, PowerShell arbitrário ou escalada de privilégio.
