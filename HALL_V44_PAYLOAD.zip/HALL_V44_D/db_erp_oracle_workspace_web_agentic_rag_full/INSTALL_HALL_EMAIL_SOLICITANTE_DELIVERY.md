# Configurar envio de e-mail ao solicitante

Execute o projeto:

```bat
INICIAR_JR_AI_HALL_EMAIL_SOLICITANTE.bat
```

ou:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Acesse:

```text
http://127.0.0.1:8000
```

## Configurar SMTP

No Windows, exemplo:

```bat
setx SMTP_HOST "smtp.seudominio.com"
setx SMTP_PORT "587"
setx SMTP_USER "usuario@seudominio.com"
setx SMTP_PASSWORD "sua_senha_ou_app_password"
setx SMTP_FROM "hall@seudominio.com"
```

Depois feche e abra o terminal novamente.

## Observação

Gmail, Outlook e serviços corporativos podem exigir senha de aplicativo, OAuth ou liberação de SMTP.
