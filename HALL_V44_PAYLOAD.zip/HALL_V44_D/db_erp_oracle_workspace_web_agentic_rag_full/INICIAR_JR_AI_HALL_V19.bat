@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================================
echo JR-AI / HAL V19 - ENTERPRISE IAM ^& MODEL LIFECYCLE
echo ============================================================
echo.

rem Funciona na raiz C:\AI_HALL ou dentro da pasta do projeto.
if exist "web_app\backend\main.py" (
    set "HALL_PROJECT=%CD%"
) else if exist "db_erp_oracle_workspace_web_agentic_rag_full\web_app\backend\main.py" (
    set "HALL_PROJECT=%CD%\db_erp_oracle_workspace_web_agentic_rag_full"
) else (
    echo [ERRO] Projeto HAL nao encontrado.
    echo Estrutura esperada: C:\AI_HALL\db_erp_oracle_workspace_web_agentic_rag_full
    pause
    exit /b 1
)

cd /d "%HALL_PROJECT%"

if not exist ".venv_web\Scripts\python.exe" (
    echo.
    echo [ERRO] Ambiente virtual .venv_web nao encontrado.
    echo Execute primeiro: install_web.bat
    pause
    exit /b 1
)
call ".venv_web\Scripts\activate.bat"

rem Corrige BOM herdado antes de ler JSON/configuracoes.
if exist "scripts\corrigir_utf8_bom_v18_2.py" python "scripts\corrigir_utf8_bom_v18_2.py" >nul 2>nul

rem Carrega os modelos atualmente aprovados no Router V19.
if exist "scripts\hall_model_env_v19.py" (
    for /f "usebackq delims=" %%L in (`python "scripts\hall_model_env_v19.py"`) do %%L
)

if "%OLLAMA_URL%"=="" set "OLLAMA_URL=http://127.0.0.1:11434"
if "%HALL_OLLAMA_MODEL%"=="" set "HALL_OLLAMA_MODEL=qwen2.5:7b"
if "%OLLAMA_MODEL%"=="" set "OLLAMA_MODEL=%HALL_OLLAMA_MODEL%"
if "%HALL_DIALOG_MODEL%"=="" set "HALL_DIALOG_MODEL=%HALL_OLLAMA_MODEL%"
set "HALL_WEB_SUMMARY_MODEL=%HALL_DIALOG_MODEL%"
set "HALL_BOOT_MODE=V19_ENTERPRISE_IAM"
set "HALL_DIALOG_TIMEOUT=120"
set "HALL_SQL_TIMEOUT=120"
set "HALL_FAST_CODE_TIMEOUT=120"
set "HALL_CODE_TIMEOUT=180"
set "HALL_DEEP_CODE_TIMEOUT=240"
set "HALL_VISION_TIMEOUT=180"
set "HALL_CHAT_KEEP_ALIVE=15m"
set "HALL_SPECIALIST_KEEP_ALIVE=2m"

if not defined HALL_MODELS_VALIDATED_THIS_BOOT (
    set "HALL_MODELS_VALIDATED_THIS_BOOT=1"
    if exist "HALL_VALIDAR_MODELOS_V15_UMA_VEZ.bat" call "HALL_VALIDAR_MODELOS_V15_UMA_VEZ.bat"
)

if exist "check_web_deps.py" (
    echo [AUTO] Verificando dependencias Python...
    python "check_web_deps.py"
    if errorlevel 1 (
        echo [ERRO] Dependencias incompletas. Execute install_web.bat
        pause
        exit /b 1
    )
)

echo.
echo [IAM] Login e controle de acesso: ATIVO
echo [IAM] RBAC por modulo/ERP e permissao: ATIVO
echo [IAM] Troca obrigatoria de senha e auditoria: ATIVO
echo [MODEL] Hugging Face Model Lifecycle: ATIVO
echo [MODEL] Atualizacoes somente com aprovacao do administrador
echo [MODEL] Smoke test + rollback + reinicio controlado: ATIVO
echo [SAFE] HAL Safety Supervisor V18: ATIVO
echo [RAG] Enterprise RAG V2: ATIVO
echo.
echo [START] http://127.0.0.1:8000

start "" "http://127.0.0.1:8000"
python -m uvicorn web_app.backend.main:app --host 127.0.0.1 --port 8000

echo.
echo [INFO] HAL V19 encerrado.
pause
endlocal
