from __future__ import annotations

import platform
import sys
import sysconfig
from textwrap import dedent


def main() -> int:
    version = sys.version_info
    py_gil_disabled = sysconfig.get_config_var('Py_GIL_DISABLED')
    supports_free_threading = bool(py_gil_disabled == 1)
    version_text = sys.version.replace('\n', ' ')

    print('=== Diagnostico do Python ===')
    print(f'Executavel : {sys.executable}')
    print(f'Versao     : {platform.python_version()}')
    print(f'Detalhe    : {version_text}')
    print(f'Py_GIL_DISABLED = {py_gil_disabled!r}')
    status = 'SIM' if supports_free_threading else 'NAO'
    print(f'Suporta free-threading build: {status}')
    print('')

    if supports_free_threading:
        print(dedent(
            '''\
            [ERRO] Este instalador detectou um Python free-threaded (sem GIL).

            Esta stack ainda nao esta homologada para builds free-threaded.
            Em especial, ambientes Python 3.13 free-threaded costumam falhar ao instalar
            dependencias nativas como cffi/cryptography.

            Use um Python PADRAO (com GIL), de preferencia:
              - Python 3.12 x64 normal
              - Python 3.13 x64 normal

            Como confirmar no Windows:
              1. Rode: python -VV
              2. Se aparecer "free-threading build", esta usando a variante errada.
              3. Instale a versao padrao em python.org e execute novamente o install_local.bat.
            '''
        ))
        return 2

    if version < (3, 11):
        print('[ERRO] Python 3.11 ou superior e obrigatorio.')
        return 3

    print('[OK] Interpretador compativel com o instalador.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
