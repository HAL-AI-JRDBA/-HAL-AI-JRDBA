# Instalação — HAL Dialogue Brain V2

Execute:

```bat
INICIAR_JR_AI_HALL_DIALOGUE_BRAIN_V2.bat
```

ou:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Acesse:

```text
http://127.0.0.1:8000
```

## Recomendado para respostas mais naturais

Instale e rode Ollama com um modelo local:

```bat
ollama pull qwen2.5:7b
setx OLLAMA_MODEL "qwen2.5:7b"
setx HALL_DIALOG_MODEL "qwen2.5:7b"
```

Sem Ollama, o HAL ainda usa o novo fallback contextual e não deve repetir a mesma frase mecânica.
