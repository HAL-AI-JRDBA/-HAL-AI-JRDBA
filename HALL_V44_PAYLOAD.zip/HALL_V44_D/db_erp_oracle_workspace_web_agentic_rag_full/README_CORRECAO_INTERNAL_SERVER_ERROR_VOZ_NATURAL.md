# Correção — Internal Server Error na aba Voz Natural

Esta versão corrige o erro apresentado no front-end:

```text
Erro no turno natural: Internal Server Error
```

## Causa provável

O backend da aba Voz Natural usava uma biblioteca de áudio (`audioop`) que pode não existir em versões novas do Python, especialmente Python 3.13+.  
Quando o endpoint `/api/hall-natural-voice/turn` tentava importar/processar o módulo, o backend podia retornar 500.

## Correções aplicadas

- Removida dependência obrigatória de `audioop`
- Adicionado fallback Python puro para cálculo RMS/VAD
- Endpoint `/api/hall-natural-voice/turn` agora retorna erro controlado, não 500 bruto
- Endpoint de status/TTS/STT também protegido
- Mantido fallback para voz do navegador
- Mantido roteamento automático do HAL

## Como validar

1. Execute `install_web.bat`
2. Execute `INICIAR_JR_AI_HALL.bat`
3. Abra a aba **Voz Natural**
4. Digite algo como:

```text
último mês da base de dados
```

5. Clique em **Enviar texto**

A resposta não deve mais aparecer como `Internal Server Error`.
