# HAL V35 - Quality Lab local

O Quality Lab adiciona avaliação reproduzível ao pacote V34. Não baixa modelos, não usa APIs pagas e não altera o roteador de produção.

## Uso

1. Inicie a HAL e entre como administrador.
2. Revise `data/quality_lab_v35/cases.json`. Os dois casos inclusos são **exemplos didáticos**; substitua por perguntas e fontes próprias, sem dados pessoais. Para cada caso, informe `id`, `question`, `domain`, `critical`, `relevant_sources`, `reference_answer`, `required_terms`, `forbidden_terms`, `min_recall`, `should_abstain` e `context` conforme aplicável.
3. Chame `POST /api/v35/quality/run` com `{"models":["qwen2.5:7b","outro-modelo:tag"],"k":5}`. A HAL consulta somente Ollama em loopback, com temperatura zero. O primeiro modelo é a base.
4. Consulte `GET /api/v35/quality/runs` para comparar os relatórios armazenados localmente. `GET /api/v35/quality/cases` exibe os casos.

Para avaliar a recuperação real do RAG, envie os resultados de cada modelo em `POST /api/v35/quality/evaluate-outputs`:

```json
{
  "models": ["base", "candidate"],
  "outputs": {
    "base": {"oracle_01653_exemplo": {"answer": "Verifique o tablespace", "hits": [{"source_id": "manual_oracle_01653"}], "latency_ms": 1200}, "sem_fonte_exemplo": {"answer": "Não há evidências suficientes", "hits": []}},
    "candidate": {"oracle_01653_exemplo": {"answer": "Verifique o tablespace", "hits": [{"source_id": "manual_oracle_01653"}]}, "sem_fonte_exemplo": {"answer": "Não há evidências suficientes", "hits": []}}
  }
}
```

O conector do RAG deve fornecer IDs de fonte estáveis e os trechos recuperados. A rota `run` mede as respostas sobre contexto rotulado no arquivo; ela **não executa o recuperador da HAL**. A rota `evaluate-outputs` mede Precision@K e Recall@K dos resultados fornecidos pelo recuperador.

`required_terms`, sobreposição com resposta de referência e detecção de abstenção são indicadores aproximados. Uma resposta pode passar nessas checagens e estar errada. Casos críticos exigem revisão humana; `promotion_approved` permanece sempre falso. O laboratório não treina nem promove modelos automaticamente.

Os relatórios são gravados em `data/quality_lab_v35/runs/`. Restrinja acesso a essa pasta quando usar respostas corporativas; as rotas exigem administrador.
