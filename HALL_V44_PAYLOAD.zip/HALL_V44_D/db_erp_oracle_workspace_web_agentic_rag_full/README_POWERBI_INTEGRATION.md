# Integração Power BI — JR-AI

Esta versão adiciona uma aba **Power BI** para conectar a JR-AI ao ecossistema Microsoft Power BI.

## Recursos adicionados

- Nova aba **Power BI**
- Configuração de Tenant ID, Client ID, Client Secret, Workspace ID, Report ID e Dataset ID
- Teste de autenticação via service principal
- Listagem de workspaces
- Listagem de relatórios
- Listagem de datasets
- Solicitação de refresh de dataset
- Geração de embed token
- Campo para abrir/embutir relatório Power BI por Embed URL
- Geração de scripts Power Query M para consumir endpoints da JR-AI:
  - Zabbix Problems
  - Zabbix Hosts
  - Prometheus Metrics da JR-AI
  - Health da JR-AI
- Geração de plano de modelo Power BI recomendado
- Integração com Chat JR-AI, JR Voz e OpenClaw Runtime

## Endpoints

```text
GET  /api/powerbi/status
GET  /api/powerbi/config
POST /api/powerbi/config
GET  /api/powerbi/test
GET  /api/powerbi/workspaces
GET  /api/powerbi/reports
GET  /api/powerbi/datasets
POST /api/powerbi/refresh-dataset
POST /api/powerbi/embed-token
GET  /api/powerbi/power-query-scripts
GET  /api/powerbi/model-plan
GET  /api/powerbi/artifacts
GET  /api/powerbi/artifacts/{filename}
```

## Como usar

1. Abra a aba **Power BI**.
2. Informe Tenant ID, Client ID e Client Secret da aplicação registrada no Microsoft Entra ID.
3. Informe Workspace ID, Report ID e Dataset ID se desejar operar em um workspace específico.
4. Clique em **Salvar configuração**.
5. Clique em **Testar conexão**.
6. Use **Gerar scripts Power Query M** para criar arquivos `.m` que podem ser usados no Power BI Desktop.
7. Use **Refresh dataset** para solicitar atualização de dados no Power BI Service.

## Observação

Para uso empresarial, o administrador do Power BI precisa permitir service principals e conceder permissão ao workspace.
