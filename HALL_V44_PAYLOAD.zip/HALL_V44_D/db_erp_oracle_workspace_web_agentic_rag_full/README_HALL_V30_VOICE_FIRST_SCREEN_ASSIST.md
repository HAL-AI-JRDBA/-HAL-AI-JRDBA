# HAL V30 — Voice-First Conversation + Screen Assist

## Voice conversation
HAL V30 keeps one conversation session across spoken turns. The user can ask a question, HAL can answer or ask a follow-up, and listening resumes after TTS.

Turn-taking was made more conservative: the browser waits at least 2.2 seconds after the last recognized speech fragment, and up to 3.0 seconds when the utterance appears unfinished. The native Windows companion also uses a minimum 2.2-second silence window.

## Spoken screen capture
While HAL is active, say for example:

- `HAL, veja minha tela`
- `HAL, capture minha tela e me diga como resolver`
- `HAL, analise esse erro na tela`

The Windows companion or browser voice-presence path calls the V30 voice-screen endpoint. The backend captures the virtual desktop of the same Windows machine where HAL is running, sends the frame to the local V29 Screen Assist/Ollama vision engine, speaks the result, and continues listening.

Screen capture requires an explicit screen-related phrase every time. Captures are deleted after analysis by default. No clicks or keystrokes are executed automatically from visual analysis.

## Intent Grounding V30
The current user question is treated as authoritative. Candidate answers are rejected and regenerated when they drift into an unrelated domain or introduce unsolicited jokes/humor. The classifier was also tightened so generic terms such as `explique` or `recomenda` no longer force unrelated domains; `ORA-nnnnn` codes are explicitly classified as Oracle/database questions.

## Vision model
A local Ollama vision-capable model is required for actual pixel interpretation. Existing V29 vision setup remains compatible.
