# HAL Voice Safety V10 — Voz Segura, Sem Tela Presa

Esta versão corrige a piora causada pelo modo "gravação primeiro".

## Problema visto no print

A tela ficava em:

```text
Gravando... 1s restantes
Aguardando pedido...
```

e a pergunta não aparecia.

Isso acontecia porque o modo gravado escondia a pergunta até a transcrição. Se o STT local não estivesse pronto ou demorasse, a experiência parecia travada.

## Correção V10

Agora o HAL só usa gravação local se o STT local estiver realmente pronto.

Fluxo novo:

```text
1. Verifica /api/unified/stt/status
2. Se STT local estiver pronto: pode gravar e transcrever
3. Se STT local não estiver pronto: usa voz do navegador
4. Se o navegador não captar: mostra mensagem clara e volta para Pronto
5. Nunca fica preso aguardando pedido
```

## Correções específicas

```text
Modo recorded_first deixou de ser padrão cego
Uso de gravação local agora depende de STT pronto
Contador fecha a gravação também quando chega a zero
Watchdog preservado
Botão Responder agora preservado
Mensagem clara quando STT não está instalado
Campo de texto continua disponível
```

## Como forçar modos manualmente

No console do navegador:

```javascript
localStorage.setItem('hallVoiceCaptureMode','browser_first')
```

ou:

```javascript
localStorage.setItem('hallVoiceCaptureMode','recorded_first')
```

Para voltar ao automático seguro:

```javascript
localStorage.removeItem('hallVoiceCaptureMode')
```

## Recomendação

Execute:

```bat
HALL_AUTO_STT.bat
```

para instalar `faster-whisper` e `av`. Depois a gravação local fica disponível.


## HAL Software Builder & Anti-Parrot V11

Corrigido o caso “Eu quero um software para controlar minhas finanças pessoais”. Agora o HAL reconhece como `software_builder`, responde com arquitetura Python/Web/SQLite, não pede “ponto central” e consegue gerar scaffold local de app de finanças pessoais.


## HAL App Factory Pro V12

Adicionada fábrica de sistemas completos estilo Lovable/Zheus local: login, páginas, CRUD, filtros, cálculos, estado vazio, settings, cobrança falhou, teto de custo de IA, preview, GitHub manifest, deploy Docker/local, templates, white-label e quality gate.


## HAL Enterprise Productization V13

Adicionada camada de produto comercial robusto: saúde da plataforma, testes automáticos de roteamento, 60 Skills, 45 templates, 20 integrações configuráveis, deploy assistido, GitHub manifest, Quality Gate global, Agent Fleet Manager 24/7, Knowledge/RAG Center e white-label com planos, custo de IA e alerta de cobrança.
