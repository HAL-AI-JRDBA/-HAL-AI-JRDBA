# Instalação — HAL Conversa Natural sem Botões

Execute normalmente:

```bat
INICIAR_JR_AI_HALL_CONVERSA_NATURAL.bat
```

ou:

```bat
INICIAR_JR_AI_CONSOLE_UNIFICADO.bat
```

Acesse:

```text
http://127.0.0.1:8000
```

Deixe o seletor em:

```text
Automático — HAL escolhe
```

Agora o envio principal passa pela camada de conversa natural.
