@echo off
chcp 65001 >nul
echo Configurando modelos especializados do HAL V15...

setx OLLAMA_URL "http://127.0.0.1:11434"
setx OLLAMA_MODEL "qwen2.5:7b"

setx HALL_MODEL_CHAT "qwen2.5:7b"
setx HALL_MODEL_DIALOG "qwen2.5:7b"
setx HALL_DIALOG_MODEL "qwen2.5:7b"

setx HALL_MODEL_CODE "qwen2.5-coder:14b"
setx HALL_MODEL_FAST_CODE "qwen2.5-coder:7b"
setx HALL_MODEL_DEEP_CODE "deepseek-coder-v2:16b"
setx HALL_MODEL_SQL "sqlcoder:7b-q4_0"
setx HALL_MODEL_EMBED "embeddinggemma:latest"
setx HALL_EMBEDDING_MODEL "embeddinggemma:latest"
setx HALL_MODEL_VISION "llava:latest"
setx HALL_MODEL_FAST "phi3:mini"

echo.
echo [OK] Variaveis configuradas.
echo Feche e abra o terminal novamente para o Windows recarregar as variaveis.
pause
