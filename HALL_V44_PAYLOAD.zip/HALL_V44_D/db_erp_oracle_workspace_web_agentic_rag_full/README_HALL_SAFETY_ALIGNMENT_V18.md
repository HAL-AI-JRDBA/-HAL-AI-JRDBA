JR-AI / HAL V18 - SAFETY, ALIGNMENT & AGENT GOVERNANCE
==========================================================

PASTA PADRAO
C:\AI_HALL

INICIALIZAR
C:\AI_HALL\INICIAR_JR_AI_HALL_V18.bat

NOVAS CAMADAS DE SEGURANCA
- HAL Safety Supervisor independente
- HAL Constitution com verificação de integridade SHA-256
- Permission Firewall para impedir escalada de privilégio e operações sensíveis sem aprovação
- Structured Agent Protocol: mensagens agente-a-agente somente em JSON/tipos conhecidos
- Agent Communication Audit
- Decision Journal / Explainability de alto nível (sem expor raciocínio interno bruto)
- Anomaly Detection para loops, escalada de privilégio, tentativa de alterar segurança e payload opaco
- Circuit Breaker por agente/ferramenta
- Resource Governor para passos, ações, tempo e orçamento estimado de tokens
- Agent Quarantine
- Emergency Kill Switch
- Auditoria encadeada por hash para detectar adulteração

VALIDAR
C:\AI_HALL\VALIDAR_HALL_SAFETY_V18.bat

PARADA DE EMERGENCIA
C:\AI_HALL\EMERGENCY_KILL_SWITCH_HALL_V18.bat
A ativação bloqueia novas execuções agentic no preflight.

REATIVAR
C:\AI_HALL\REATIVAR_HALL_V18_APOS_KILL_SWITCH.bat
Exige digitar APROVAR.

IMPORTANTE
O Kill Switch da camada HAL bloqueia novas ações dos agentes. Ele não substitui o encerramento
do processo/servidor pelo sistema operacional em um incidente de host.
