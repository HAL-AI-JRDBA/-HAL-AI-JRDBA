@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"

if exist "db_erp_oracle_workspace_web_agentic_rag_full\scripts\validar_hall_v19.py" (
  cd /d "db_erp_oracle_workspace_web_agentic_rag_full"
) else if not exist "scripts\validar_hall_v19.py" (
  echo [ERRO] Validador V19 nao encontrado.
  pause
  exit /b 1
)

if exist ".venv_web\Scripts\activate.bat" call ".venv_web\Scripts\activate.bat"
if exist "scripts\corrigir_utf8_bom_v18_2.py" python "scripts\corrigir_utf8_bom_v18_2.py" >nul 2>nul

echo ============================================================
echo HAL V19 - VALIDACAO INTEGRADA IAM ^& MODEL LIFECYCLE
echo ============================================================
python "scripts\validar_hall_v19.py"
if errorlevel 1 (
  echo.
  echo [ERRO] A validacao V19 encontrou falhas.
  pause
  exit /b 1
)
echo.
echo [OK] Validacao HAL V19 concluida.
pause
endlocal
