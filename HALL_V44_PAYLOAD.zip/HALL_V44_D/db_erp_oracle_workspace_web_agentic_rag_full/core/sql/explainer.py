from __future__ import annotations

from ..llm.router import LLMRouter


class SQLExplainer:
    def __init__(self, llm_router: LLMRouter):
        self.llm_router = llm_router

    def explain(self, sql: str) -> str:
        system_prompt = "Você é um especialista Oracle e explica SQL em português claro e técnico."
        user_prompt = f"""
Explique a SQL abaixo em português:
1. Objetivo
2. Tabelas e joins
3. Filtros
4. Agregações
5. Riscos/performance
6. Sugestão de melhoria

SQL:
{sql}
""".strip()
        return self.llm_router.ask_chat(system_prompt, user_prompt)
