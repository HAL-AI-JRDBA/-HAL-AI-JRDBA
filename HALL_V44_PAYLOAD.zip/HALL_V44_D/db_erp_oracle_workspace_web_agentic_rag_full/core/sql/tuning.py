from __future__ import annotations

from ..llm.router import LLMRouter


class SQLTuningAdvisor:
    def __init__(self, llm_router: LLMRouter):
        self.llm_router = llm_router

    def analyze(self, sql: str, plan_text: str = "") -> str:
        system_prompt = "Você é um especialista Oracle em performance e tuning."
        user_prompt = f"""
Analise a consulta abaixo.
Forneça:
- diagnóstico provável
- gargalos prováveis
- índices possíveis
- melhorias de escrita
- cuidados com estatísticas/cardinalidade
- próximos testes recomendados

SQL:
{sql}

Plano/observações:
{plan_text or 'não informado'}
""".strip()
        return self.llm_router.ask_chat(system_prompt, user_prompt)
