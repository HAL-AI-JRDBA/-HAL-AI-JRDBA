from __future__ import annotations

import re
from dataclasses import dataclass, field


FORBIDDEN_KEYWORDS = {
    "INSERT", "UPDATE", "DELETE", "MERGE", "ALTER", "DROP", "TRUNCATE",
    "GRANT", "REVOKE", "CREATE", "BEGIN", "DECLARE", "EXECUTE", "CALL",
    "DBMS_", "UTL_", "COMMIT", "ROLLBACK",
}


@dataclass
class ValidationResult:
    ok: bool
    reasons: list[str] = field(default_factory=list)


class SQLValidator:
    def __init__(self, allowed_schemas: list[str] | None = None):
        self.allowed_schemas = [s.upper() for s in (allowed_schemas or []) if s]

    def validate_read_only(self, sql: str) -> ValidationResult:
        normalized = (sql or "").strip().upper()

        if not normalized:
            return ValidationResult(False, ["SQL vazio."])

        if ";" in normalized.rstrip(";"):
            return ValidationResult(False, ["Múltiplas instruções não são permitidas."])

        if not (normalized.startswith("SELECT") or normalized.startswith("WITH")):
            return ValidationResult(False, ["Somente SELECT ou WITH são permitidos."])

        reasons = []
        for keyword in FORBIDDEN_KEYWORDS:
            if re.search(rf"\b{re.escape(keyword)}\b", normalized):
                reasons.append(f"Palavra proibida detectada: {keyword}")

        if self.allowed_schemas:
            for owner in self._extract_schema_owners(normalized):
                if owner not in self.allowed_schemas:
                    reasons.append(f"Schema fora da allowlist: {owner}")

        return ValidationResult(not reasons, reasons)

    def _extract_schema_owners(self, normalized_sql: str) -> list[str]:
        """Extract owners only from table references in FROM/JOIN clauses.

        This intentionally ignores generic ``alias.column`` occurrences in the
        SELECT list, predicates, GROUP BY, ORDER BY, etc. Previous versions used
        a loose `, OWNER.TABLE` regex that incorrectly treated aliases like
        `e.CODIGO` or `i.DESCRICAO` as schema-qualified object names.
        """
        owners: list[str] = []

        # 1) Direct schema-qualified references after FROM / JOIN.
        for owner, table in re.findall(
            r'\b(?:FROM|JOIN)\s+([A-Z0-9_"$#]+)\.([A-Z0-9_"$#]+)',
            normalized_sql,
        ):
            owner = owner.replace('"', '')
            table = table.replace('"', '')
            if owner and table:
                owners.append(owner)

        # 2) Comma-separated tables only inside the FROM clause body.
        from_match = re.search(
            r'\bFROM\b(?P<body>.*?)(?=\bWHERE\b|\bGROUP\b|\bORDER\b|\bHAVING\b|\bFETCH\b|\bUNION\b|$)',
            normalized_sql,
            re.DOTALL,
        )
        if from_match:
            body = from_match.group('body')
            for _sep, owner, table in re.findall(r'(^|,)\s*([A-Z0-9_"$#]+)\.([A-Z0-9_"$#]+)', body):
                owner = owner.replace('"', '')
                table = table.replace('"', '')
                if owner and table:
                    owners.append(owner)

        seen: list[str] = []
        for owner in owners:
            if owner not in seen:
                seen.append(owner)
        return seen

    def ensure_fetch_limit(self, sql: str, max_rows: int = 500) -> str:
        normalized = sql.strip().rstrip(";")
        upper = normalized.upper()
        if " FETCH FIRST " in upper or " ROWNUM " in upper:
            return normalized
        return f"SELECT * FROM ({normalized}) WHERE ROWNUM <= {int(max_rows)}"
