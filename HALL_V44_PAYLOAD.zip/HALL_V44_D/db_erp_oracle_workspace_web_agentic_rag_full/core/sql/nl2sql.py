from __future__ import annotations

import re
from typing import Any, Dict, List

from ..catalog.extractor import CatalogExtractor
from ..llm.router import LLMRouter
from services.schema_ground_truth import build_schema_grounding_context


SYSTEM_PROMPT = """Você é um especialista Oracle focado em gerar SQL correto, seguro e legível.
Regras obrigatórias:
1. Gere APENAS Oracle SQL.
2. Gere SOMENTE consultas de leitura (SELECT ou WITH).
3. Nunca gere INSERT, UPDATE, DELETE, MERGE, DDL, PL/SQL ou DBMS_*.
4. Prefira nomes totalmente qualificados OWNER.TABELA quando houver owner.
5. Use aliases legíveis.
6. USE prioritariamente as tabelas, colunas, PKs e joins do contexto estruturado do schema.
7. Não invente tabelas, colunas ou joins fora do contexto fornecido.
8. Se precisar escolher entre múltiplos joins, prefira os marcados como FK ou GROUND_TRUTH.
9. Nunca use coluna de código/ID como valor financeiro; valor financeiro deve vir de coluna real de valor/custo/saldo/preço.
10. Se não houver coluna real para saldo, custo médio, família ou almoxarifado no contexto, gere uma SQL diagnóstica simples para listar colunas candidatas em vez de inventar.
11. Retorne a resposta no formato:
```sql
<SQL>
```
"""


class NL2SQLService:
    def __init__(self, llm_router: LLMRouter):
        self.llm_router = llm_router

    def generate_sql(
        self,
        question: str,
        catalog: List[Dict[str, Any]],
        schema: str = "",
        schema_package: Dict[str, Any] | None = None,
        selected_tables: List[str] | None = None,
        intent_context: str = "",
        column_hints_text: str = "",
        learning_examples_text: str = "",
    ) -> str:
        schema_hint = f"Schema principal: {schema}\n" if schema else ""
        catalog_context = CatalogExtractor.summarize_for_prompt(catalog, max_objects=12)
        schema_context = ''
        if schema_package:
            schema_context = build_schema_grounding_context(
                schema_package=schema_package,
                selected_tables=selected_tables or schema_package.get('candidate_tables', []),
                max_tables=3,
                max_joins=4,
            )

        compact_question = (question or '').strip()[:700]
        compact_schema = (schema_context or 'Nenhum contexto estruturado adicional.')[:2200]
        compact_catalog = catalog_context[:900]
        compact_intent = (intent_context or "")[:700]
        user_prompt = f"""
{schema_hint}
Pergunta do usuário:
{compact_question}

Contexto de intenção/regra de negócio:
{compact_intent or "Nenhum contexto adicional de intenção."}

Contexto estruturado do schema:
{compact_schema}

Dicas de colunas reais por tabela:
{(column_hints_text or "Sem dicas extras de colunas.")[:1400]}

Exemplos anteriores aprovados / memória da IA:
{(learning_examples_text or "Sem exemplos prévios aprovados.")[:900]}

Catálogo resumido:
{compact_catalog}

IMPORTANTE:
- use somente colunas reais do schema fornecido
- se a pergunta pedir descrição, material, item, saldo, data, custo ou conta, escolha a coluna real mais aderente da tabela envolvida
- não use nomes genéricos como DESCRICAO se a tabela real tiver DESCRICAOMAT, DESCRICAOGRE, NOMECONTA ou outra coluna específica
- para análises gerenciais, não some colunas de código como CODIGOMATINT, CODIGOLOCAL, CODIGOGRE, CODCONTACTB, CODIGOEMPRESA ou CODIGOFL para representar valor; use somente colunas reais de valor, custo, saldo ou quantidade
- para perguntas de Controller/Saúde financeira-contábil no módulo Contabilidade, priorize CTBSALDO + CTBCONTA; não use CTBLANCA_APURPISCOFINS, PIS/COFINS, ECF, SPED, LALUR ou tabelas auxiliares salvo pedido explícito de imposto/fiscal
- se o período do usuário vier como data e a tabela tiver PERIODOSALDO, converta para YYYYMM; nunca aplique TO_DATE em CODIGOEMPRESA, CODIGOFL, CODCONTACTB ou outro código/ID
- para estoque parado/baixo giro, use data de movimento real; para ruptura, use saldo/estoque mínimo reais; para valor imobilizado, use quantidade/saldo x custo/preço médio quando essas colunas existirem

Retorne apenas a SQL em bloco markdown sql. Seja objetivo e use o menor número correto de tabelas e joins.
""".strip()

        raw = self.llm_router.ask_sql(SYSTEM_PROMPT, user_prompt)
        return self.extract_sql(raw)


    @staticmethod
    def extract_sql(text: str) -> str:
        block = re.search(r"```sql\s*(.*?)```", text, re.IGNORECASE | re.DOTALL)
        if block:
            return block.group(1).strip()
        return text.strip().strip("`")
