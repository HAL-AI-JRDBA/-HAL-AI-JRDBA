from __future__ import annotations

import pandas as pd

from ..oracle_client import OracleClient
from .validator import SQLValidator, ValidationResult


class SQLExecutor:
    def __init__(self, oracle_client: OracleClient, validator: SQLValidator, max_rows: int = 500):
        self.oracle_client = oracle_client
        self.validator = validator
        self.max_rows = max_rows

    def run_safe_select(self, sql: str) -> tuple[ValidationResult, pd.DataFrame]:
        validation = self.validator.validate_read_only(sql)
        if not validation.ok:
            return validation, pd.DataFrame()

        final_sql = self.validator.ensure_fetch_limit(sql, self.max_rows)
        df = self.oracle_client.query(final_sql, max_rows=self.max_rows)
        return validation, df
