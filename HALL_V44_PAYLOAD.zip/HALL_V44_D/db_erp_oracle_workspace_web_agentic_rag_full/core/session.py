from __future__ import annotations

import uuid
import streamlit as st


def init_session_state() -> None:
    defaults = {
        "session_id": str(uuid.uuid4())[:8],
        "chat_history": [],
        "oracle_connected": False,
        "catalog_cache": None,
        "last_sql": "",
        "last_sql_result": None,
        "last_rag_answer": "",
        "config_overrides": {},
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def skey(name: str) -> str:
    session_id = st.session_state.get("session_id", "default")
    return f"{name}_{session_id}"
