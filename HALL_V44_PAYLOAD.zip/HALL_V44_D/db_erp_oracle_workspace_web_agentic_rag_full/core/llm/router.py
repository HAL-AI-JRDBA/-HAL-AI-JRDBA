from __future__ import annotations

import hashlib
import math
import re
from collections import Counter
from typing import Dict, List

from .ollama_client import OllamaClient


class OpenAICompatibleClient:
    def __init__(self, base_url: str, api_key: str, timeout_seconds: int = 180):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def chat(self, model: str, messages: list[dict], temperature: float = 0.1, max_tokens: int = 1500) -> str:
        import requests

        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        response = requests.post(
            f"{self.base_url}/chat/completions",
            headers=self._headers(),
            json=payload,
            timeout=self.timeout_seconds,
        )
        response.raise_for_status()
        data = response.json()
        return data["choices"][0]["message"]["content"]


class HashEmbeddingBackend:
    def __init__(self, dimensions: int = 384):
        self.dimensions = dimensions

    def embed(self, texts: list[str]) -> list[list[float]]:
        vectors: list[list[float]] = []
        for text in texts:
            vec = [0.0] * self.dimensions
            tokens = re.findall(r"\w+", (text or "").lower())
            counts = Counter(tokens)
            for token, count in counts.items():
                idx = int(hashlib.md5(token.encode("utf-8")).hexdigest(), 16) % self.dimensions
                vec[idx] += float(count)
            norm = math.sqrt(sum(v * v for v in vec)) or 1.0
            vectors.append([v / norm for v in vec])
        return vectors


class SentenceTransformerBackend:
    def __init__(self, model_name: str):
        from sentence_transformers import SentenceTransformer

        self.model = SentenceTransformer(model_name)

    def embed(self, texts: list[str]) -> list[list[float]]:
        vectors = self.model.encode(texts, normalize_embeddings=True)
        return [list(map(float, row)) for row in vectors]


class LLMRouter:
    def __init__(self, config: Dict):
        llm_cfg = config.get("llm", {})
        backend = llm_cfg.get("backend", "ollama")
        self.temperature = float(llm_cfg.get("temperature", 0.1))
        self.max_tokens = int(llm_cfg.get("max_tokens", 1500))

        if backend == "openai_compatible":
            self.chat_backend = OpenAICompatibleClient(
                base_url=llm_cfg.get("openai_compatible_base_url", "http://localhost:8000/v1"),
                api_key=llm_cfg.get("openai_compatible_api_key", "local"),
                timeout_seconds=int(llm_cfg.get("timeout_seconds", 180)),
            )
        else:
            self.chat_backend = OllamaClient(
                base_url=llm_cfg.get("base_url", "http://127.0.0.1:11435"),
                timeout_seconds=int(llm_cfg.get("timeout_seconds", 180)),
            )

        emb_backend = llm_cfg.get("embedding_backend", "ollama")
        emb_model = llm_cfg.get("embedding_model", "all-minilm")

        if emb_backend == "sentence_transformers":
            try:
                self.embedding_backend = SentenceTransformerBackend(emb_model)
            except Exception:
                self.embedding_backend = HashEmbeddingBackend()
        elif emb_backend == "ollama":
            if isinstance(self.chat_backend, OllamaClient):
                self.embedding_backend = self.chat_backend
            else:
                self.embedding_backend = HashEmbeddingBackend()
        else:
            self.embedding_backend = HashEmbeddingBackend()

        self.sql_model = llm_cfg.get("sql_model", "qwen3:8b")
        self.chat_model = llm_cfg.get("chat_model", "qwen3:8b")
        self.embedding_model = emb_model

    def ask_sql(self, system_prompt: str, user_prompt: str) -> str:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]
        return self.chat_backend.chat(self.sql_model, messages, self.temperature, self.max_tokens)

    def ask_chat(self, system_prompt: str, user_prompt: str) -> str:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]
        return self.chat_backend.chat(self.chat_model, messages, self.temperature, self.max_tokens)

    def embed(self, texts: list[str]) -> list[list[float]]:
        if hasattr(self.embedding_backend, "embed"):
            if isinstance(self.embedding_backend, OllamaClient):
                return self.embedding_backend.embed(self.embedding_model, texts)
            return self.embedding_backend.embed(texts)
        raise RuntimeError("Nenhum backend de embedding configurado.")
