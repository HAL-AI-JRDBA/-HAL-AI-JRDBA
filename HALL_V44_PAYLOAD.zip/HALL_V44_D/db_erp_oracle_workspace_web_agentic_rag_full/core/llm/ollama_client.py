from __future__ import annotations

import json
from typing import Any, Dict, List
import time
from pathlib import Path

import requests
from services.gemma4_v42 import is_gemma4, prepare_payload, final_answer, guard_local_model
from services import ssot_context_v43 as official
SSOT_ROOT = Path(__file__).resolve().parents[2]


class OllamaClient:
    def __init__(self, base_url: str, timeout_seconds: int = 180):
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds

    def _extract_error(self, response: requests.Response) -> str:
        try:
            data = response.json()
            if isinstance(data, dict):
                return data.get('error') or data.get('message') or json.dumps(data, ensure_ascii=False)
        except Exception:
            pass
        text = (response.text or '').strip()
        return text[:1000] if text else f'HTTP {response.status_code}'

    def healthcheck(self) -> bool:
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=10)
            return response.ok
        except Exception:
            return False

    def generate(self, model: str, prompt: str, temperature: float = 0.1, max_tokens: int = 1500) -> str:
        guard_local_model(model, self.base_url)
        prepared,ssot_pack=official.augment_current(SSOT_ROOT,[{'role':'user','content':prompt}],byte_budget=2400)
        local_options={}
        if ssot_pack.get('scope'):
            prompt='\n\n'.join(x['role'].upper()+':\n'+x['content'] for x in prepared)
        if ssot_pack.get('sources'):
            official.ensure_local_inference(self.base_url,model)
            local_options={'proxies':{'http':'','https':'','all':''},'allow_redirects':False}
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": True,
            "options": {
                "temperature": temperature,
                "num_predict": max_tokens,
            },
        }
        started = time.time()
        payload = prepare_payload(payload)
        try:
            with requests.post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=(30, None),
                stream=True,
                **local_options,
            ) as response:
                if ssot_pack.get('sources') and not 200<=response.status_code<300:
                    raise RuntimeError('Ollama local recusou a geração SSOT.')
                if not response.ok:
                    raise RuntimeError(f"Ollama /api/generate falhou (HTTP {response.status_code}): {self._extract_error(response)}")
                parts: list[str] = []
                saw_done = False
                for raw_line in response.iter_lines(decode_unicode=True):
                    if not raw_line:
                        continue
                    try:
                        data = json.loads(raw_line)
                    except Exception:
                        continue
                    if isinstance(data, dict) and data.get('error'):
                        raise RuntimeError(str(data.get('error')))
                    if isinstance(data, dict):
                        piece = data.get('response', '') or ''
                        if piece:
                            parts.append(piece)
                        if data.get('done'):
                            saw_done = True
                            break
                result = final_answer(model, ''.join(parts))
                if not result and not saw_done:
                    raise RuntimeError(f"Ollama não retornou conteúdo após {int(time.time()-started)}s")
                official.validate_current(SSOT_ROOT,ssot_pack,result)
                return result
        except requests.ReadTimeout as exc:
            raise RuntimeError(f"Timeout lendo resposta do Ollama após {self.timeout_seconds}s: {exc}") from exc

    def chat(self, model: str, messages: List[Dict[str, str]], temperature: float = 0.1, max_tokens: int = 1500) -> str:
        if is_gemma4(model):
            guard_local_model(model, self.base_url)
            messages,ssot_pack=official.augment_current(SSOT_ROOT,messages,byte_budget=2400)
            local_options={}
            if ssot_pack.get('sources'):
                official.ensure_local_inference(self.base_url,model)
                local_options={'proxies':{'http':'','https':'','all':''},'allow_redirects':False}
            payload = prepare_payload({'model': model, 'messages': messages, 'stream': True,
                        'options': {'temperature': temperature, 'num_predict': max_tokens}})
            with requests.post(f'{self.base_url}/api/chat', json=payload,
                               timeout=(30, self.timeout_seconds), stream=True, **local_options) as response:
                if ssot_pack.get('sources') and not 200<=response.status_code<300:
                    raise RuntimeError('Ollama local recusou a geração SSOT.')
                if not response.ok:
                    raise RuntimeError('Ollama /api/chat falhou: ' + self._extract_error(response))
                content = ''; done = False
                for line in response.iter_lines(decode_unicode=True):
                    if not line:
                        continue
                    data = json.loads(line)
                    if data.get('error'):
                        raise RuntimeError(str(data['error']))
                    content += str((data.get('message') or {}).get('content') or '')
                    if len(content) > 50000:
                        raise RuntimeError('Resposta Gemma 4 excede o limite.')
                    if data.get('done'):
                        done = True; break
                answer = final_answer(model, content)
                if not done or not answer:
                    raise RuntimeError('Ollama não concluiu a resposta Gemma 4.')
                official.validate_current(SSOT_ROOT,ssot_pack,answer)
                return answer
        prompt_parts = []
        for message in messages:
            role = message.get("role", "user").upper()
            content = message.get("content", "")
            prompt_parts.append(f"{role}:\n{content}\n")
        prompt_parts.append("ASSISTANT:\n")
        prompt = "\n".join(prompt_parts)
        return self.generate(model=model, prompt=prompt, temperature=temperature, max_tokens=max_tokens)

    def embed(self, model: str, texts: list[str]) -> list[list[float]]:
        results: list[list[float]] = []
        for text in texts:
            payload_new = {"model": model, "input": text}
            try:
                response = requests.post(
                    f"{self.base_url}/api/embed",
                    json=payload_new,
                    timeout=self.timeout_seconds,
                )
                if response.ok:
                    data = response.json()
                    vector = data.get("embeddings", [[]])[0]
                    if vector:
                        results.append(vector)
                        continue
            except Exception:
                pass

            payload_old = {"model": model, "prompt": text}
            response = requests.post(
                f"{self.base_url}/api/embeddings",
                json=payload_old,
                timeout=self.timeout_seconds,
            )
            if not response.ok:
                raise RuntimeError(f"Ollama embeddings falhou (HTTP {response.status_code}): {self._extract_error(response)}")
            data = response.json()
            results.append(data.get("embedding", []))
        return results
