from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pandas as pd

try:
    import oracledb
except Exception:  # pragma: no cover
    oracledb = None


logger = logging.getLogger(__name__)


class OracleClient:
    _thick_initialized = False

    def __init__(self, config: Dict[str, Any]):
        if oracledb is None:
            raise RuntimeError("python-oracledb não está instalado.")
        self.config = config
        self.oracle_cfg = config.get("oracle", {})

    def init_thick_mode_if_needed(self) -> None:
        mode = self.oracle_cfg.get("mode", "thin").lower()
        lib_dir = self.oracle_cfg.get("thick_client_lib_dir")
        if mode == "thick" and lib_dir and not OracleClient._thick_initialized:
            try:
                oracledb.init_oracle_client(lib_dir=lib_dir)
                OracleClient._thick_initialized = True
                logger.info("Oracle Thick mode inicializado com sucesso: %s", lib_dir)
            except Exception as exc:
                logger.warning("Falha ao iniciar Thick mode: %s", exc)

    def connect(self):
        self.init_thick_mode_if_needed()
        dsn = oracledb.makedsn(
            self.oracle_cfg.get("host", ""),
            int(self.oracle_cfg.get("port", 1521)),
            service_name=self.oracle_cfg.get("service_name", ""),
        )
        conn = oracledb.connect(
            user=self.oracle_cfg.get("username", ""),
            password=self.oracle_cfg.get("password", ""),
            dsn=dsn,
        )
        return conn

    def test_connection(self) -> tuple[bool, str]:
        try:
            with self.connect() as conn:
                with conn.cursor() as cur:
                    cur.execute("select 'OK' from dual")
                    row = cur.fetchone()
            return True, str(row[0])
        except Exception as exc:
            return False, str(exc)

    def query(self, sql: str, binds: Optional[dict] = None, max_rows: int = 500) -> pd.DataFrame:
        binds = binds or {}
        with self.connect() as conn:
            with conn.cursor() as cur:
                cur.arraysize = min(max_rows, 1000)
                cur.execute(sql, binds)
                columns = [d[0] for d in cur.description] if cur.description else []
                rows = cur.fetchmany(numRows=max_rows)
                return pd.DataFrame(rows, columns=columns)

    def scalar(self, sql: str, binds: Optional[dict] = None) -> Any:
        binds = binds or {}
        with self.connect() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, binds)
                row = cur.fetchone()
                return row[0] if row else None

    def fetch_schema_objects(self, owner: Optional[str] = None) -> pd.DataFrame:
        owner = owner or self.oracle_cfg.get("default_schema", "").upper()
        sql = """
        select owner, object_name, object_type, status
          from all_objects
         where (:owner is null or owner = :owner)
           and object_type in ('TABLE', 'VIEW')
         order by owner, object_name
        """
        return self.query(sql, {"owner": owner or None}, max_rows=5000)

    def fetch_columns(self, owner: Optional[str] = None) -> pd.DataFrame:
        owner = owner or self.oracle_cfg.get("default_schema", "").upper()
        sql = """
        select owner, table_name, column_id, column_name, data_type, data_length, nullable
          from all_tab_columns
         where (:owner is null or owner = :owner)
         order by owner, table_name, column_id
        """
        return self.query(sql, {"owner": owner or None}, max_rows=20000)

    def fetch_comments(self, owner: Optional[str] = None) -> pd.DataFrame:
        owner = owner or self.oracle_cfg.get("default_schema", "").upper()
        sql = """
        select owner, table_name, comments
          from all_tab_comments
         where (:owner is null or owner = :owner)
         order by owner, table_name
        """
        return self.query(sql, {"owner": owner or None}, max_rows=5000)

    def fetch_constraints(self, owner: Optional[str] = None) -> pd.DataFrame:
        owner = owner or self.oracle_cfg.get("default_schema", "").upper()
        sql = """
        select c.owner,
               c.table_name,
               c.constraint_name,
               c.constraint_type,
               cc.column_name,
               c.r_owner,
               c.r_constraint_name
          from all_constraints c
          join all_cons_columns cc
            on cc.owner = c.owner
           and cc.constraint_name = c.constraint_name
         where (:owner is null or c.owner = :owner)
           and c.constraint_type in ('P', 'R', 'U')
         order by c.owner, c.table_name, c.constraint_name, cc.position
        """
        return self.query(sql, {"owner": owner or None}, max_rows=20000)

    def fetch_indexes(self, owner: Optional[str] = None) -> pd.DataFrame:
        owner = owner or self.oracle_cfg.get("default_schema", "").upper()
        sql = """
        select i.owner, i.table_name, i.index_name, i.uniqueness, ic.column_name, ic.column_position
          from all_indexes i
          join all_ind_columns ic
            on ic.index_owner = i.owner
           and ic.index_name = i.index_name
         where (:owner is null or i.owner = :owner)
         order by i.owner, i.table_name, i.index_name, ic.column_position
        """
        return self.query(sql, {"owner": owner or None}, max_rows=20000)
