from __future__ import annotations

from collections import defaultdict
from typing import Any, Dict, List

from ..oracle_client import OracleClient


class CatalogExtractor:
    def __init__(self, oracle_client: OracleClient):
        self.oracle_client = oracle_client

    def build_catalog(self, owner: str) -> List[Dict[str, Any]]:
        objects_df = self.oracle_client.fetch_schema_objects(owner)
        columns_df = self.oracle_client.fetch_columns(owner)
        comments_df = self.oracle_client.fetch_comments(owner)
        constraints_df = self.oracle_client.fetch_constraints(owner)
        indexes_df = self.oracle_client.fetch_indexes(owner)

        comments_map = {
            (row["OWNER"], row["TABLE_NAME"]): row.get("COMMENTS")
            for _, row in comments_df.iterrows()
        }

        columns_map = defaultdict(list)
        for _, row in columns_df.iterrows():
            columns_map[(row["OWNER"], row["TABLE_NAME"])].append(
                {
                    "name": row["COLUMN_NAME"],
                    "data_type": row["DATA_TYPE"],
                    "length": int(row["DATA_LENGTH"]) if row.get("DATA_LENGTH") is not None else None,
                    "nullable": row["NULLABLE"],
                }
            )

        constraints_map = defaultdict(list)
        for _, row in constraints_df.iterrows():
            constraints_map[(row["OWNER"], row["TABLE_NAME"])].append(
                {
                    "constraint_name": row["CONSTRAINT_NAME"],
                    "constraint_type": row["CONSTRAINT_TYPE"],
                    "column_name": row["COLUMN_NAME"],
                    "r_owner": row.get("R_OWNER"),
                    "r_constraint_name": row.get("R_CONSTRAINT_NAME"),
                }
            )

        indexes_map = defaultdict(list)
        for _, row in indexes_df.iterrows():
            indexes_map[(row["OWNER"], row["TABLE_NAME"])].append(
                {
                    "index_name": row["INDEX_NAME"],
                    "uniqueness": row["UNIQUENESS"],
                    "column_name": row["COLUMN_NAME"],
                    "column_position": int(row["COLUMN_POSITION"]) if row.get("COLUMN_POSITION") is not None else None,
                }
            )

        catalog: List[Dict[str, Any]] = []
        for _, row in objects_df.iterrows():
            owner = row["OWNER"]
            table_name = row["OBJECT_NAME"]
            key = (owner, table_name)

            business_terms = self._infer_business_terms(table_name, columns_map[key], comments_map.get(key))
            doc = {
                "owner": owner,
                "object_name": table_name,
                "object_type": row["OBJECT_TYPE"],
                "status": row["STATUS"],
                "description": comments_map.get(key) or "",
                "columns": columns_map[key],
                "constraints": constraints_map[key],
                "indexes": indexes_map[key],
                "business_terms": business_terms,
            }
            catalog.append(doc)
        return catalog

    def _infer_business_terms(self, table_name: str, columns: list[dict], comment: str | None) -> list[str]:
        terms = set()
        raw = f"{table_name} {' '.join(c['name'] for c in columns)} {comment or ''}".upper()

        mappings = {
            "MANUTENCAO": ["MAN", "OS", "VEIC", "OFICINA", "PECA"],
            "ESTOQUE": ["EST", "ITEM", "PROD", "ALMOX", "MOVTO"],
            "FATURAMENTO": ["FAT", "NF", "NOTA", "TITULO", "REC"],
            "FINANCEIRO": ["FIN", "PAG", "REC", "BANCO", "CAIXA"],
            "FROTA": ["VEIC", "FROTA", "CARRO", "PLACA", "GARAGEM"],
            "BILHETAGEM": ["BILH", "CARTAO", "PASSAGEM", "TARIFA", "ARREC"],
            "AUDITORIA": ["AUD", "LOG", "HIST", "TRACE"],
        }
        for label, keywords in mappings.items():
            if any(k in raw for k in keywords):
                terms.add(label)
        return sorted(terms)



    @staticmethod
    def from_schema_package(schema_package: Dict[str, Any]) -> List[Dict[str, Any]]:
        grouped = schema_package.get("grouped_columns") or {}
        candidate_rows = schema_package.get("candidate_tables") or []
        owner = str(schema_package.get("owner") or "").upper()

        candidate_map = {}
        for row in candidate_rows:
            if not isinstance(row, dict):
                continue
            name = str(row.get("table_name") or row.get("OBJECT_NAME") or "").upper()
            if name:
                candidate_map[name] = row

        catalog: List[Dict[str, Any]] = []
        seen: set[str] = set()
        ordered_names = list(candidate_map.keys()) or list(grouped.keys())

        for name in ordered_names:
            if not name or name in seen:
                continue
            seen.add(name)
            cols = grouped.get(name, [])
            columns = []
            for c in cols:
                if isinstance(c, dict):
                    columns.append({
                        "name": c.get("COLUMN_NAME") or c.get("name") or "",
                        "data_type": c.get("DATA_TYPE") or c.get("data_type") or "",
                        "length": c.get("DATA_LENGTH") or c.get("length"),
                        "nullable": c.get("NULLABLE") or c.get("nullable"),
                    })
            row = candidate_map.get(name, {})
            catalog.append({
                "owner": owner or str(row.get("owner") or "").upper(),
                "object_name": name,
                "object_type": row.get("object_type") or row.get("OBJECT_TYPE") or "TABLE",
                "status": row.get("status") or row.get("STATUS") or "VALID",
                "description": row.get("description") or row.get("description_text") or "",
                "columns": columns,
                "constraints": row.get("constraints") or [],
                "indexes": row.get("indexes") or [],
                "business_terms": row.get("business_terms") or [],
            })

        return catalog

    @staticmethod
    def summarize_for_prompt(catalog: List[Dict[str, Any]], max_objects: int = 20) -> str:
        parts = []
        for obj in catalog[:max_objects]:
            cols = ", ".join(c["name"] for c in obj.get("columns", [])[:20])
            parts.append(
                f"- {obj['owner']}.{obj['object_name']} ({obj['object_type']}): "
                f"{obj.get('description','') or 'sem descrição'} | colunas: {cols}"
            )
        return "\n".join(parts)
