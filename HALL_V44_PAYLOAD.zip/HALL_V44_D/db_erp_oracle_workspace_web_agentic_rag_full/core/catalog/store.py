from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List


class CatalogStore:
    def __init__(self, catalog_dir: str):
        self.catalog_dir = Path(catalog_dir)
        self.catalog_dir.mkdir(parents=True, exist_ok=True)

    def path_for_schema(self, schema: str) -> Path:
        return self.catalog_dir / f"{schema.lower()}_catalog.json"

    def save(self, schema: str, catalog: List[Dict[str, Any]]) -> Path:
        path = self.path_for_schema(schema)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(catalog, f, ensure_ascii=False, indent=2)
        return path

    def load(self, schema: str) -> List[Dict[str, Any]]:
        path = self.path_for_schema(schema)
        if not path.exists():
            return []
        with open(path, "r", encoding="utf-8-sig") as f:
            return json.load(f)

    def list_catalogs(self) -> list[str]:
        return [p.name for p in self.catalog_dir.glob("*_catalog.json")]
