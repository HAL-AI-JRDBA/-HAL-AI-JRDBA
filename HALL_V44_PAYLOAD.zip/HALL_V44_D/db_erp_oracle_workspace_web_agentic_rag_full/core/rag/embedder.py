from __future__ import annotations

from ..llm.router import LLMRouter


class Embedder:
    def __init__(self, llm_router: LLMRouter):
        self.llm_router = llm_router

    def embed(self, texts: list[str]) -> list[list[float]]:
        return self.llm_router.embed(texts)
