from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

from ..utils import cosine_similarity


class SimpleVectorStore:
    def __init__(self, base_dir: str, collection_name: str):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.path = self.base_dir / f"{collection_name}.json"
        self.records: list[dict] = []
        if self.path.exists():
            with open(self.path, "r", encoding="utf-8-sig") as f:
                self.records = json.load(f)

    def add(self, records: list[dict]) -> None:
        if not records:
            return
        existing = {rec.get("id"): rec for rec in self.records if rec.get("id")}
        for rec in records:
            rec_id = rec.get("id")
            if rec_id:
                existing[rec_id] = rec
            else:
                self.records.append(rec)
        self.records = list(existing.values()) + [rec for rec in self.records if not rec.get("id")]
        # remove duplicates preserving newest version by id
        seen = {}
        for rec in self.records:
            rid = rec.get("id")
            if rid:
                seen[rid] = rec
        unnamed = [rec for rec in self.records if not rec.get("id")]
        self.records = list(seen.values()) + unnamed
        self._save()

    def _save(self) -> None:
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self.records, f, ensure_ascii=False)

    def query(self, query_vector: list[float], top_k: int = 5) -> list[dict]:
        scored = []
        for rec in self.records:
            score = cosine_similarity(query_vector, rec.get("embedding", []))
            scored.append((score, rec))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [{**rec, "score": score} for score, rec in scored[:top_k]]

    def list_documents(self) -> list[str]:
        return sorted(set(rec.get("source", "") for rec in self.records))


class ChromaVectorStore:
    def __init__(self, base_dir: str, collection_name: str):
        import chromadb

        self.client = chromadb.PersistentClient(path=base_dir)
        self.collection = self.client.get_or_create_collection(collection_name)

    def add(self, records: list[dict]) -> None:
        if not records:
            return
        payload = {
            "ids": [r["id"] for r in records],
            "documents": [r["text"] for r in records],
            "embeddings": [r["embedding"] for r in records],
            "metadatas": [r["metadata"] for r in records],
        }
        try:
            self.collection.upsert(**payload)
        except Exception:
            self.collection.add(**payload)

    def query(self, query_vector: list[float], top_k: int = 5) -> list[dict]:
        result = self.collection.query(query_embeddings=[query_vector], n_results=top_k)
        docs = result.get("documents", [[]])[0]
        metas = result.get("metadatas", [[]])[0]
        distances = result.get("distances", [[]])[0]
        ids = result.get("ids", [[]])[0]
        rows = []
        for doc_id, doc, meta, dist in zip(ids, docs, metas, distances):
            rows.append(
                {
                    "id": doc_id,
                    "text": doc,
                    "metadata": meta,
                    "score": 1 - float(dist) if dist is not None else 0.0,
                    "source": meta.get("source", ""),
                }
            )
        return rows

    def list_documents(self) -> list[str]:
        data = self.collection.get(include=["metadatas"])
        metas = data.get("metadatas", [])
        return sorted(set(meta.get("source", "") for meta in metas if meta))


def create_vectorstore(base_dir: str, collection_name: str):
    try:
        return ChromaVectorStore(base_dir=base_dir, collection_name=collection_name)
    except Exception:
        return SimpleVectorStore(base_dir=base_dir, collection_name=collection_name)
