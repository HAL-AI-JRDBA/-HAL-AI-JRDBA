from __future__ import annotations

from pathlib import Path
from typing import Dict

import pandas as pd
from pypdf import PdfReader


def load_text_from_file(path: str | Path) -> str:
    path = Path(path)
    suffix = path.suffix.lower()

    if suffix == ".pdf":
        reader = PdfReader(str(path))
        texts = []
        for page in reader.pages:
            texts.append(page.extract_text() or "")
        return "\n".join(texts)

    if suffix in {".txt", ".md", ".sql", ".log", ".py"}:
        return path.read_text(encoding="utf-8", errors="ignore")

    if suffix == ".csv":
        df = pd.read_csv(path)
        return df.to_csv(index=False)

    if suffix in {".xlsx", ".xlsm"}:
        xls = pd.ExcelFile(path)
        texts = []
        for sheet in xls.sheet_names:
            df = pd.read_excel(path, sheet_name=sheet)
            texts.append(f"### PLANILHA: {sheet}\n{df.head(500).to_csv(index=False)}")
        return "\n\n".join(texts)

    raise ValueError(f"Tipo de arquivo não suportado: {suffix}")


def chunk_text(text: str, chunk_size: int = 900, chunk_overlap: int = 120) -> list[str]:
    text = (text or "").strip()
    if not text:
        return []

    tokens = text.split()
    if len(tokens) <= chunk_size:
        return [text]

    chunks = []
    start = 0
    while start < len(tokens):
        end = min(len(tokens), start + chunk_size)
        chunk = " ".join(tokens[start:end]).strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(tokens):
            break
        start = max(0, end - chunk_overlap)
    return chunks
