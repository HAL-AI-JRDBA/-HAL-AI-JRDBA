from __future__ import annotations

from pathlib import Path
from typing import Dict, List

from ..llm.router import LLMRouter
from ..utils import sha256_file
from .embedder import Embedder
from .loader import chunk_text, load_text_from_file
from .vectorstore import create_vectorstore


class RAGPipeline:
    def __init__(self, config: dict, llm_router: LLMRouter):
        rag_cfg = config.get("rag", {})
        app_cfg = config.get("app", {})
        self.chunk_size = int(rag_cfg.get("chunk_size", 900))
        self.chunk_overlap = int(rag_cfg.get("chunk_overlap", 120))
        self.top_k = int(rag_cfg.get("top_k", 5))
        self.collection_name = rag_cfg.get("collection_name", "oracle_local_docs")
        self.vector_dir = app_cfg.get("vector_dir", "data/vectors")
        self.vectorstore = create_vectorstore(self.vector_dir, self.collection_name)
        self.embedder = Embedder(llm_router)
        self.llm_router = llm_router

    def index_file(self, path: str | Path) -> dict:
        path = Path(path)
        file_hash = sha256_file(path)
        text = load_text_from_file(path)
        chunks = chunk_text(text, self.chunk_size, self.chunk_overlap)
        if not chunks:
            return {"file": path.name, "chunks": 0, "hash": file_hash, "warning": "arquivo sem texto extraível"}
        embeddings = self.embedder.embed(chunks)

        records = []
        for idx, (chunk, vector) in enumerate(zip(chunks, embeddings)):
            record_id = f"{file_hash}_{idx}"
            records.append(
                {
                    "id": record_id,
                    "text": chunk,
                    "embedding": vector,
                    "metadata": {
                        "source": path.name,
                        "path": str(path),
                        "chunk_index": idx,
                        "hash": file_hash,
                    },
                    "source": path.name,
                }
            )
        self.vectorstore.add(records)
        return {"file": path.name, "chunks": len(records), "hash": file_hash}

    def ask(self, question: str) -> tuple[str, list[dict]]:
        query_vector = self.embedder.embed([question])[0]
        hits = self.vectorstore.query(query_vector, top_k=self.top_k)
        context = "\n\n".join(
            f"[Fonte: {h.get('source','desconhecida')} | chunk {h.get('metadata',{}).get('chunk_index','?')}]\n{h.get('text','')}"
            for h in hits
        )
        system_prompt = "Você responde com base no contexto recuperado. Seja técnico, claro e cite as fontes no final."
        user_prompt = f"""
Pergunta:
{question}

Contexto recuperado:
{context}

Responda em português. Se o contexto for insuficiente, diga isso claramente.
""".strip()
        answer = self.llm_router.ask_chat(system_prompt, user_prompt)
        return answer, hits
