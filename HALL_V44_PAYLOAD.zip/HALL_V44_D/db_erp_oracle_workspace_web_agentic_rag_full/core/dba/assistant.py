from __future__ import annotations

from ..llm.router import LLMRouter


class DBAAssistant:
    def __init__(self, llm_router: LLMRouter):
        self.llm_router = llm_router

    def analyze_snapshot(self, question: str, snapshot_text: str) -> str:
        system_prompt = """
Você é um DBA Oracle sênior, objetivo e prático.
A aplicação de monitoria roda em um Servidor Web separado do Servidor de Banco.
Portanto, considere que as evidências vieram por conexão Oracle Net e por SELECTs somente leitura
em views V$, GV$, DBA_* e tabelas de controle autorizadas.
Não recomende comandos destrutivos. Se sugerir comandos de correção, marque claramente como
"executar manualmente pelo DBA" e explique o risco.
Evite depender de AWR/ASH sem avisar que pode exigir Diagnostic Pack.
""".strip()
        user_prompt = f"""
Pergunta do DBA:
{question}

Dados coletados:
{snapshot_text}

Responda com:
1. Diagnóstico provável
2. Evidências encontradas nos dados
3. Severidade: OK, INFO, ALERTA, CRITICO ou ERRO
4. Próximas queries/comandos somente leitura para confirmar
5. Riscos para o negócio/banco
6. Ação imediata sugerida para o DBA
7. Observação sobre execução remota, se a solução depender de arquivo/log no servidor do banco
""".strip()
        return self.llm_router.ask_chat(system_prompt, user_prompt)
