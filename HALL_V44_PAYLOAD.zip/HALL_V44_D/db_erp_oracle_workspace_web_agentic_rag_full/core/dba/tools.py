from __future__ import annotations

import re
from typing import Callable

import pandas as pd

from ..oracle_client import OracleClient


class DBATools:
    """Coletas Oracle DBA somente leitura.

    Todas as rotinas abaixo executam apenas SELECT em views dinâmicas/dicionário.
    A aplicação pode rodar em um servidor WEB separado: a coleta é feita pela conexão
    Oracle Net configurada no sistema, não por comandos locais no servidor do banco.
    """

    def __init__(self, oracle_client: OracleClient):
        self.oracle_client = oracle_client

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _q(self, sql: str, binds: dict | None = None, max_rows: int = 500) -> pd.DataFrame:
        return self.oracle_client.query(sql, binds or {}, max_rows=max_rows)

    def _safe_df(self, name: str, fn: Callable[[], pd.DataFrame]) -> pd.DataFrame:
        """Executa uma coleta sem derrubar snapshots compostos.

        Útil para Health Snapshot, onde algumas views podem não estar liberadas para
        o usuário de monitoramento. O retorno deixa claro qual coleta falhou.
        """
        try:
            return fn()
        except Exception as exc:  # pragma: no cover - depende de privilégios Oracle
            return pd.DataFrame([{
                "COLETA": name,
                "STATUS": "ERRO",
                "DETALHE": str(exc)[:1000],
            }])

    @staticmethod
    def _safe_object_name(value: str, default: str = "MON_BACKUP_EXECUCAO") -> str:
        name = (value or default).strip().upper()
        if not re.match(r"^[A-Z][A-Z0-9_$#]*(\.[A-Z][A-Z0-9_$#]*)?$", name):
            return default
        return name

    # ------------------------------------------------------------------
    # Disponibilidade / saúde geral
    # ------------------------------------------------------------------
    def database_status(self) -> pd.DataFrame:
        sql = """
        select i.inst_id,
               d.name as database_name,
               i.instance_name,
               i.host_name,
               i.version,
               i.status as instance_status,
               i.database_status,
               i.startup_time,
               d.open_mode,
               d.log_mode,
               d.database_role,
               d.force_logging
          from gv$instance i
          cross join v$database d
         order by i.inst_id
        """
        return self._q(sql, max_rows=20)

    def resource_limits(self) -> pd.DataFrame:
        sql = """
        with rl as (
            select resource_name,
                   current_utilization,
                   max_utilization,
                   limit_value,
                   case when regexp_like(limit_value, '^[0-9]+$') then to_number(limit_value) end as limit_num
              from v$resource_limit
             where resource_name in ('sessions', 'processes', 'transactions')
        )
        select resource_name,
               current_utilization,
               max_utilization,
               limit_value,
               case when limit_num > 0 then round(current_utilization / limit_num * 100, 2) end as pct_current_limit,
               case when limit_num > 0 then round(max_utilization / limit_num * 100, 2) end as pct_max_limit
          from rl
         order by resource_name
        """
        return self._q(sql, max_rows=50)

    def health_snapshot(self) -> pd.DataFrame:
        """Resumo executivo com severidade para painel de monitoria."""
        checks: list[dict] = []

        def add(item: str, severity: str, value: str | int | float | None = None, detail: str = "") -> None:
            checks.append({
                "ITEM": item,
                "SEVERIDADE": severity,
                "VALOR": value,
                "DETALHE": detail,
            })

        # Banco/instância
        try:
            df = self.database_status()
            if df.empty:
                add("Banco/instância", "CRITICO", 0, "Nenhuma instância retornada.")
            else:
                bad = df[(df.get("INSTANCE_STATUS") != "OPEN") | (~df.get("OPEN_MODE", "").astype(str).str.contains("READ", na=False))]
                add("Banco/instância", "OK" if bad.empty else "CRITICO", len(df), "Instâncias coletadas via conexão remota Oracle Net.")
        except Exception as exc:
            add("Banco/instância", "CRITICO", None, str(exc)[:500])

        # Sessions/processes
        try:
            rl = self.resource_limits()
            alert_rows = []
            for _, r in rl.iterrows():
                pct = r.get("PCT_CURRENT_LIMIT")
                if pd.notna(pct) and float(pct) >= 90:
                    alert_rows.append(f"{r.get('RESOURCE_NAME')}={pct}%")
            add("Sessions/processes", "CRITICO" if alert_rows else "OK", ", ".join(alert_rows) or "normal", "Uso atual contra LIMIT_VALUE.")
        except Exception as exc:
            add("Sessions/processes", "ERRO", None, str(exc)[:500])

        # Tablespaces
        try:
            ts = self.tablespaces()
            high = ts[pd.to_numeric(ts.get("PCT_USED_MAX"), errors="coerce") >= 90]
            warn = ts[pd.to_numeric(ts.get("PCT_USED_MAX"), errors="coerce") >= 80]
            add("Tablespaces", "CRITICO" if not high.empty else ("ALERTA" if not warn.empty else "OK"), len(high), "Crítico >=90%, alerta >=80% do limite com autoextend.")
        except Exception as exc:
            add("Tablespaces", "ERRO", None, str(exc)[:500])

        # FRA
        try:
            fra = self.fra_usage()
            if fra.empty:
                add("FRA", "INFO", 0, "V$RECOVERY_FILE_DEST sem dados ou FRA não configurada.")
            else:
                pct = float(fra.iloc[0].get("PCT_USED", 0) or 0)
                add("FRA", "CRITICO" if pct >= 90 else ("ALERTA" if pct >= 80 else "OK"), pct, "Uso da Flash Recovery Area.")
        except Exception as exc:
            add("FRA", "ERRO", None, str(exc)[:500])

        # Backup RMAN
        try:
            bkp = self.rman_backup_summary()
            if bkp.empty:
                add("Backup RMAN", "ALERTA", 0, "Nenhum backup COMPLETED encontrado em V$RMAN_BACKUP_JOB_DETAILS.")
            else:
                max_age = pd.to_numeric(bkp.get("IDADE_HORAS"), errors="coerce").max()
                add("Backup RMAN", "CRITICO" if pd.notna(max_age) and float(max_age) > 48 else "OK", round(float(max_age), 2) if pd.notna(max_age) else None, "Maior idade, em horas, entre tipos de backup concluídos.")
        except Exception as exc:
            add("Backup RMAN", "ERRO", None, str(exc)[:500])

        # Locks
        try:
            locks = self.blocking_sessions()
            long_locks = locks[pd.to_numeric(locks.get("SECONDS_IN_WAIT"), errors="coerce") >= 300]
            add("Locks bloqueadores", "CRITICO" if not long_locks.empty else "OK", len(long_locks), "Bloqueios >= 5 minutos.")
        except Exception as exc:
            add("Locks bloqueadores", "ERRO", None, str(exc)[:500])

        # Jobs
        try:
            failed = self.scheduler_failed_jobs(hours=24)
            add("Scheduler jobs com erro", "CRITICO" if not failed.empty else "OK", len(failed), "Falhas nas últimas 24 horas.")
        except Exception as exc:
            add("Scheduler jobs com erro", "ERRO", None, str(exc)[:500])

        # Alert log
        try:
            alerts = self.alert_log_errors(hours=24)
            add("Alert log", "ALERTA" if not alerts.empty else "OK", len(alerts), "ORA-/TNS-/erros nas últimas 24 horas.")
        except Exception as exc:
            add("Alert log", "ERRO", None, str(exc)[:500])

        return pd.DataFrame(checks)

    # ------------------------------------------------------------------
    # Sessões, conexões, carga e SQL
    # ------------------------------------------------------------------
    def active_sessions(self) -> pd.DataFrame:
        sql = """
        select s.inst_id,
               s.sid,
               s.serial#,
               s.username,
               s.status,
               s.state,
               s.event,
               s.wait_class,
               s.seconds_in_wait,
               s.sql_id,
               s.machine,
               s.program,
               s.module,
               s.action,
               s.logon_time
          from gv$session s
         where s.type = 'USER'
         order by case when s.status = 'ACTIVE' then 0 else 1 end,
                  s.seconds_in_wait desc,
                  s.username,
                  s.machine
        """
        return self._q(sql, max_rows=500)

    def session_summary(self) -> pd.DataFrame:
        sql = """
        select inst_id,
               nvl(username, '(sem usuario)') as username,
               nvl(machine, '(sem maquina)') as machine,
               nvl(program, '(sem programa)') as program,
               status,
               count(*) as qtd_sessoes
          from gv$session
         where type = 'USER'
         group by inst_id, nvl(username, '(sem usuario)'), nvl(machine, '(sem maquina)'), nvl(program, '(sem programa)'), status
         order by qtd_sessoes desc, username, machine
        """
        return self._q(sql, max_rows=500)

    def active_sql(self) -> pd.DataFrame:
        sql = """
        select s.inst_id,
               s.sid,
               s.serial#,
               s.username,
               s.machine,
               s.program,
               s.module,
               s.status,
               s.event,
               s.wait_class,
               s.seconds_in_wait,
               s.sql_id,
               q.executions,
               round(q.elapsed_time / 1000000, 2) as elapsed_seconds_total,
               round(q.cpu_time / 1000000, 2) as cpu_seconds_total,
               q.buffer_gets,
               q.disk_reads,
               q.rows_processed,
               substr(q.sql_text, 1, 1200) as sql_text
          from gv$session s
          left join gv$sql q
            on q.inst_id = s.inst_id
           and q.sql_id = s.sql_id
           and q.child_number = s.sql_child_number
         where s.type = 'USER'
           and s.status = 'ACTIVE'
         order by nvl(q.elapsed_time, 0) desc, s.seconds_in_wait desc
        """
        return self._q(sql, max_rows=200)

    def top_sql(self) -> pd.DataFrame:
        sql = """
        select *
          from (
                select sql_id,
                       parsing_schema_name,
                       executions,
                       round(elapsed_time / 1000000, 2) as elapsed_seconds_total,
                       round(cpu_time / 1000000, 2) as cpu_seconds_total,
                       buffer_gets,
                       disk_reads,
                       rows_processed,
                       round(case when executions > 0 then elapsed_time / executions / 1000000 end, 4) as elapsed_seconds_avg,
                       round(case when executions > 0 then cpu_time / executions / 1000000 end, 4) as cpu_seconds_avg,
                       substr(sql_text,1,1200) sql_text
                  from v$sql
                 where sql_text is not null
                 order by elapsed_time desc
               )
         where rownum <= 50
        """
        return self._q(sql, max_rows=50)

    def top_sql_by_cpu(self) -> pd.DataFrame:
        sql = """
        select *
          from (
                select sql_id,
                       parsing_schema_name,
                       executions,
                       round(cpu_time / 1000000, 2) as cpu_seconds_total,
                       round(elapsed_time / 1000000, 2) as elapsed_seconds_total,
                       buffer_gets,
                       disk_reads,
                       rows_processed,
                       substr(sql_text,1,1200) sql_text
                  from v$sql
                 where sql_text is not null
                 order by cpu_time desc
               )
         where rownum <= 50
        """
        return self._q(sql, max_rows=50)

    def top_sql_by_io(self) -> pd.DataFrame:
        sql = """
        select *
          from (
                select sql_id,
                       parsing_schema_name,
                       executions,
                       disk_reads,
                       buffer_gets,
                       round(elapsed_time / 1000000, 2) as elapsed_seconds_total,
                       round(cpu_time / 1000000, 2) as cpu_seconds_total,
                       substr(sql_text,1,1200) sql_text
                  from v$sql
                 where sql_text is not null
                 order by disk_reads desc
               )
         where rownum <= 50
        """
        return self._q(sql, max_rows=50)

    def long_operations(self) -> pd.DataFrame:
        sql = """
        select inst_id,
               sid,
               serial#,
               username,
               opname,
               target,
               sofar,
               totalwork,
               units,
               round(sofar / nullif(totalwork, 0) * 100, 2) as pct_done,
               elapsed_seconds,
               time_remaining,
               sql_id,
               start_time,
               last_update_time
          from gv$session_longops
         where totalwork > 0
           and sofar <> totalwork
         order by elapsed_seconds desc
        """
        return self._q(sql, max_rows=200)

    def wait_events(self) -> pd.DataFrame:
        sql = """
        select inst_id,
               wait_class,
               event,
               count(*) as qtd_sessoes,
               max(seconds_in_wait) as maior_espera_segundos
          from gv$session
         where type = 'USER'
           and status = 'ACTIVE'
           and wait_class is not null
         group by inst_id, wait_class, event
         order by qtd_sessoes desc, maior_espera_segundos desc
        """
        return self._q(sql, max_rows=200)

    # ------------------------------------------------------------------
    # Locks
    # ------------------------------------------------------------------
    def locks(self) -> pd.DataFrame:
        sql = """
        select s.inst_id,
               s.sid,
               s.serial#,
               s.username,
               l.type,
               l.id1,
               l.id2,
               l.lmode,
               l.request,
               l.block,
               s.event,
               s.seconds_in_wait,
               s.sql_id,
               s.machine,
               s.program
          from gv$lock l
          join gv$session s
            on s.inst_id = l.inst_id
           and s.sid = l.sid
         order by s.username, l.block desc, l.type
        """
        return self._q(sql, max_rows=500)

    def blocking_sessions(self) -> pd.DataFrame:
        sql = """
        select w.inst_id,
               w.sid as sid_bloqueado,
               w.serial# as serial_bloqueado,
               w.username as usuario_bloqueado,
               w.machine as maquina_bloqueada,
               w.program as programa_bloqueado,
               w.event,
               w.seconds_in_wait,
               b.inst_id as inst_id_bloqueador,
               b.sid as sid_bloqueador,
               b.serial# as serial_bloqueador,
               b.username as usuario_bloqueador,
               b.machine as maquina_bloqueadora,
               b.program as programa_bloqueador,
               w.sql_id as sql_id_bloqueado,
               b.sql_id as sql_id_bloqueador
          from gv$session w
          join gv$session b
            on b.inst_id = w.blocking_instance
           and b.sid = w.blocking_session
         where w.blocking_session is not null
         order by w.seconds_in_wait desc
        """
        return self._q(sql, max_rows=300)

    def locked_objects(self) -> pd.DataFrame:
        sql = """
        select lo.inst_id,
               s.sid,
               s.serial#,
               s.username,
               s.machine,
               s.program,
               o.owner,
               o.object_name,
               o.object_type,
               lo.locked_mode
          from gv$locked_object lo
          join dba_objects o
            on o.object_id = lo.object_id
          join gv$session s
            on s.inst_id = lo.inst_id
           and s.sid = lo.session_id
         order by lo.inst_id, s.sid, o.owner, o.object_name
        """
        return self._q(sql, max_rows=300)

    # ------------------------------------------------------------------
    # Espaço / archive / FRA
    # ------------------------------------------------------------------
    def tablespaces(self) -> pd.DataFrame:
        sql = """
        with df as (
            select tablespace_name,
                   sum(bytes) as total_bytes,
                   sum(case when autoextensible = 'YES' then maxbytes else bytes end) as max_bytes
              from dba_data_files
             group by tablespace_name
        ), fs as (
            select tablespace_name, sum(bytes) as free_bytes
              from dba_free_space
             group by tablespace_name
        )
        select df.tablespace_name,
               round(df.total_bytes / 1024 / 1024, 2) as total_mb,
               round(nvl(fs.free_bytes, 0) / 1024 / 1024, 2) as free_mb,
               round((df.total_bytes - nvl(fs.free_bytes, 0)) / 1024 / 1024, 2) as used_mb,
               round((df.total_bytes - nvl(fs.free_bytes, 0)) / nullif(df.total_bytes, 0) * 100, 2) as pct_used_allocated,
               round(df.max_bytes / 1024 / 1024, 2) as max_mb,
               round((df.total_bytes - nvl(fs.free_bytes, 0)) / nullif(df.max_bytes, 0) * 100, 2) as pct_used_max
          from df
          left join fs on fs.tablespace_name = df.tablespace_name
         order by pct_used_max desc nulls last, used_mb desc
        """
        return self._q(sql, max_rows=200)

    def temp_usage(self) -> pd.DataFrame:
        sql = """
        with tf as (
            select tablespace_name, sum(bytes) total_bytes
              from dba_temp_files
             group by tablespace_name
        ), th as (
            select tablespace_name, sum(bytes_used) used_bytes, sum(bytes_free) free_bytes
              from v$temp_space_header
             group by tablespace_name
        )
        select tf.tablespace_name,
               round(tf.total_bytes / 1024 / 1024, 2) as total_mb,
               round(nvl(th.used_bytes, 0) / 1024 / 1024, 2) as used_mb,
               round(nvl(th.free_bytes, 0) / 1024 / 1024, 2) as free_mb,
               round(nvl(th.used_bytes, 0) / nullif(tf.total_bytes, 0) * 100, 2) as pct_used
          from tf
          left join th on th.tablespace_name = tf.tablespace_name
         order by pct_used desc nulls last
        """
        return self._q(sql, max_rows=100)

    def fra_usage(self) -> pd.DataFrame:
        sql = """
        select name,
               round(space_limit / 1024 / 1024, 2) as space_limit_mb,
               round(space_used / 1024 / 1024, 2) as space_used_mb,
               round(space_reclaimable / 1024 / 1024, 2) as space_reclaimable_mb,
               number_of_files,
               round(space_used / nullif(space_limit, 0) * 100, 2) as pct_used
          from v$recovery_file_dest
        """
        return self._q(sql, max_rows=20)

    def archive_log_generation(self, days: int = 2) -> pd.DataFrame:
        days = max(1, min(int(days or 2), 30))
        sql = """
        select trunc(first_time, 'HH24') as hora,
               thread#,
               count(*) as qtd_archives,
               round(sum(blocks * block_size) / 1024 / 1024, 2) as mb_gerados
          from v$archived_log
         where first_time >= sysdate - :days
         group by trunc(first_time, 'HH24'), thread#
         order by hora desc, thread#
        """
        return self._q(sql, {"days": days}, max_rows=500)

    # ------------------------------------------------------------------
    # Backup / Data Pump
    # ------------------------------------------------------------------
    def rman_backup_jobs(self, days: int = 7) -> pd.DataFrame:
        days = max(1, min(int(days or 7), 90))
        sql = """
        select session_key,
               input_type,
               status,
               start_time,
               end_time,
               elapsed_seconds,
               input_bytes_display,
               output_bytes_display,
               output_device_type,
               compression_ratio
          from v$rman_backup_job_details
         where start_time >= sysdate - :days
         order by start_time desc
        """
        return self._q(sql, {"days": days}, max_rows=500)

    def rman_backup_summary(self) -> pd.DataFrame:
        sql = """
        select input_type,
               max(end_time) as ultimo_backup_sucesso,
               round((sysdate - max(end_time)) * 24, 2) as idade_horas
          from v$rman_backup_job_details
         where status = 'COMPLETED'
         group by input_type
         order by idade_horas desc
        """
        return self._q(sql, max_rows=50)

    def datapump_jobs(self) -> pd.DataFrame:
        sql = """
        select owner_name,
               job_name,
               operation,
               job_mode,
               state,
               degree,
               attached_sessions
          from dba_datapump_jobs
         order by owner_name, job_name
        """
        return self._q(sql, max_rows=100)

    def backup_control_history(self, table_name: str = "MON_BACKUP_EXECUCAO") -> pd.DataFrame:
        table = self._safe_object_name(table_name, "MON_BACKUP_EXECUCAO")
        sql = f"""
        select *
          from (
                select *
                  from {table}
                 order by data_inicio desc
               )
         where rownum <= 200
        """
        return self._q(sql, max_rows=200)

    # ------------------------------------------------------------------
    # Jobs / alertas / objetos
    # ------------------------------------------------------------------
    def scheduler_running_jobs(self) -> pd.DataFrame:
        sql = """
        select owner,
               job_name,
               session_id,
               running_instance,
               elapsed_time,
               cpu_used
          from dba_scheduler_running_jobs
         order by owner, job_name
        """
        return self._q(sql, max_rows=300)

    def scheduler_failed_jobs(self, hours: int = 24) -> pd.DataFrame:
        hours = max(1, min(int(hours or 24), 720))
        sql = """
        select *
          from (
                select owner,
                       job_name,
                       status,
                       actual_start_date,
                       run_duration,
                       error# as error_number,
                       substr(additional_info, 1, 1000) as additional_info
                  from dba_scheduler_job_run_details
                 where log_date >= systimestamp - numtodsinterval(:hours, 'HOUR')
                   and status <> 'SUCCEEDED'
                 order by actual_start_date desc nulls last
               )
         where rownum <= 300
        """
        return self._q(sql, {"hours": hours}, max_rows=300)

    def alert_log_errors(self, hours: int = 24) -> pd.DataFrame:
        hours = max(1, min(int(hours or 24), 720))
        sql = """
        select *
          from (
                select originating_timestamp,
                       component_id,
                       host_id,
                       message_type,
                       message_level,
                       substr(message_text, 1, 1200) as message_text
                  from v$diag_alert_ext
                 where originating_timestamp >= systimestamp - numtodsinterval(:hours, 'HOUR')
                   and regexp_like(message_text, 'ORA-|TNS-|erro|error|fatal|incident', 'i')
                 order by originating_timestamp desc
               )
         where rownum <= 300
        """
        return self._q(sql, {"hours": hours}, max_rows=300)

    def invalid_objects(self) -> pd.DataFrame:
        sql = """
        select owner,
               object_name,
               object_type,
               status,
               last_ddl_time
          from all_objects
         where status <> 'VALID'
         order by owner, object_type, object_name
        """
        return self._q(sql, max_rows=1000)

    def unusable_indexes(self) -> pd.DataFrame:
        sql = """
        select owner,
               index_name,
               table_owner,
               table_name,
               status,
               partitioned,
               visibility,
               last_analyzed
          from dba_indexes
         where status <> 'VALID'
         order by owner, table_name, index_name
        """
        return self._q(sql, max_rows=1000)

    def parameters(self, search_term: str = "") -> pd.DataFrame:
        sql = """
        select name,
               value,
               isdefault,
               issys_modifiable,
               description
          from v$parameter
         where :term is null or upper(name) like '%' || upper(:term) || '%'
         order by name
        """
        return self._q(sql, {"term": search_term or None}, max_rows=300)

    # ------------------------------------------------------------------
    # Governança: demandas priorizadas
    # ------------------------------------------------------------------
    def monitoring_backlog(self) -> pd.DataFrame:
        rows = [
            ("P0", "Banco/listener indisponível", "Testar conexão Oracle Net, instância, open_mode e status", "Impacto total"),
            ("P0", "Backup RMAN/Data Pump com erro ou atrasado", "V$RMAN_BACKUP_JOB_DETAILS e MON_BACKUP_EXECUCAO", "Risco de perda de dados"),
            ("P0", "Tablespace/FRA/disco próximo do limite", "DBA_DATA_FILES, DBA_FREE_SPACE, V$RECOVERY_FILE_DEST", "Risco de parada"),
            ("P0", "Archivelog/FRA travando banco", "V$RECOVERY_FILE_DEST e V$ARCHIVED_LOG", "Banco pode parar por falta de espaço"),
            ("P1", "Locks bloqueadores", "GV$SESSION, GV$LOCKED_OBJECT", "Afeta operação e integrações"),
            ("P1", "Sessions/processes perto do limite", "V$RESOURCE_LIMIT e GV$SESSION", "Risco de ORA-00020/ORA-12518"),
            ("P1", "Queries com maior carga", "GV$SESSION, GV$SQL, GV$SESSION_LONGOPS", "Impacto de performance"),
            ("P1", "Jobs críticos com erro ou presos", "DBA_SCHEDULER_*", "Paralisa rotinas de negócio"),
            ("P2", "Objetos inválidos e índices unusable", "ALL_OBJECTS, DBA_INDEXES", "Risco funcional/performance"),
            ("P2", "Alert log com ORA/TNS/incidents", "V$DIAG_ALERT_EXT", "Diagnóstico preventivo"),
            ("P3", "Tendência de crescimento", "Histórico próprio de coletas", "Capacidade e planejamento"),
        ]
        return pd.DataFrame(rows, columns=["PRIORIDADE", "DEMANDA", "COMO_MONITORAR", "MOTIVO"])

    def remote_webserver_notes(self) -> pd.DataFrame:
        rows = [
            ("Arquitetura", "A aplicação roda no Servidor Web e conecta no Oracle por HOST/PORT/SERVICE_NAME."),
            ("Sem comandos locais", "Coletas DBA não dependem de lsnrctl, shell, PowerShell ou acesso ao filesystem do servidor do banco."),
            ("Usuário recomendado", "Criar usuário de monitoramento somente leitura com CREATE SESSION e grants SELECT nas views necessárias."),
            ("Backups Data Pump", "Para monitorar arquivos/logs do servidor do banco, grave status em tabela MON_BACKUP_EXECUCAO ou exponha via rotina controlada."),
            ("Segurança", "Não usar SYS/SYSTEM na aplicação web; restringir IP do Servidor Web no firewall/listener quando possível."),
        ]
        return pd.DataFrame(rows, columns=["ITEM", "ORIENTACAO"])

    # ------------------------------------------------------------------
    # Dispatcher compatível com a UI/API antigas
    # ------------------------------------------------------------------
    def collect(self, option: str, search_term: str = "") -> pd.DataFrame:
        key = (option or "").strip().lower()
        key = key.replace("ç", "c").replace("õ", "o").replace("ã", "a").replace("á", "a").replace("â", "a").replace("é", "e").replace("ê", "e").replace("í", "i").replace("ó", "o").replace("ô", "o").replace("ú", "u")
        aliases = {
            "health": self.health_snapshot,
            "health_snapshot": self.health_snapshot,
            "status": self.database_status,
            "database_status": self.database_status,
            "sessions": self.active_sessions,
            "sessoes ativas": self.active_sessions,
            "active_sessions": self.active_sessions,
            "session_summary": self.session_summary,
            "conexoes": self.session_summary,
            "connections": self.session_summary,
            "resource_limits": self.resource_limits,
            "limits": self.resource_limits,
            "locks": self.locks,
            "blocking_sessions": self.blocking_sessions,
            "bloqueios": self.blocking_sessions,
            "locked_objects": self.locked_objects,
            "active_sql": self.active_sql,
            "sql_ativo": self.active_sql,
            "top_sql": self.top_sql,
            "top sql": self.top_sql,
            "top_sql_cpu": self.top_sql_by_cpu,
            "top_sql_io": self.top_sql_by_io,
            "longops": self.long_operations,
            "long_operations": self.long_operations,
            "wait_events": self.wait_events,
            "tablespaces": self.tablespaces,
            "temp_usage": self.temp_usage,
            "fra": self.fra_usage,
            "fra_usage": self.fra_usage,
            "archive_generation": self.archive_log_generation,
            "archivelog": self.archive_log_generation,
            "rman_backups": self.rman_backup_jobs,
            "rman_backup_jobs": self.rman_backup_jobs,
            "backup_summary": self.rman_backup_summary,
            "rman_backup_summary": self.rman_backup_summary,
            "backup_control": lambda: self.backup_control_history(search_term or "MON_BACKUP_EXECUCAO"),
            "datapump": self.datapump_jobs,
            "datapump_jobs": self.datapump_jobs,
            "scheduler_running": self.scheduler_running_jobs,
            "scheduler_failed": self.scheduler_failed_jobs,
            "failed_jobs": self.scheduler_failed_jobs,
            "alert_log": self.alert_log_errors,
            "invalid_objects": self.invalid_objects,
            "objetos invalidos": self.invalid_objects,
            "unusable_indexes": self.unusable_indexes,
            "parametros": lambda: self.parameters(search_term),
            "parameters": lambda: self.parameters(search_term),
            "monitoring_backlog": self.monitoring_backlog,
            "demandas": self.monitoring_backlog,
            "remote_notes": self.remote_webserver_notes,
        }
        fn = aliases.get(key)
        if fn is None:
            # Mantém comportamento anterior: opção desconhecida cai em Data Pump Jobs.
            return self.datapump_jobs()
        return fn()
