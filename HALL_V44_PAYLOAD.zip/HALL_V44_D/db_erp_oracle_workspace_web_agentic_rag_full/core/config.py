from __future__ import annotations

import copy
from pathlib import Path
from typing import Any, Dict

import yaml


ROOT_DIR = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG_PATH = ROOT_DIR / "config" / "default_config.yaml"


def deep_update(base: Dict[str, Any], updates: Dict[str, Any]) -> Dict[str, Any]:
    merged = copy.deepcopy(base)
    for key, value in updates.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = deep_update(merged[key], value)
        else:
            merged[key] = value
    return merged


def load_config(custom_path: str | None = None) -> Dict[str, Any]:
    with open(DEFAULT_CONFIG_PATH, "r", encoding="utf-8-sig") as f:
        config = yaml.safe_load(f) or {}
    if custom_path:
        path = Path(custom_path)
        if path.exists():
            with open(path, "r", encoding="utf-8-sig") as f:
                overrides = yaml.safe_load(f) or {}
            config = deep_update(config, overrides)
    return config


def ensure_dirs(config: Dict[str, Any]) -> None:
    app_cfg = config.get("app", {})
    for key in ("upload_dir", "catalog_dir", "vector_dir", "cache_dir", "log_dir"):
        path = ROOT_DIR / app_cfg.get(key, f"data/{key}")
        path.mkdir(parents=True, exist_ok=True)
