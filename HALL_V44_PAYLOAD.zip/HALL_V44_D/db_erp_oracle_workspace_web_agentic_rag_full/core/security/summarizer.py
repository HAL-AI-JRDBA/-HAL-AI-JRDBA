from __future__ import annotations

from ..llm.router import LLMRouter


class SecuritySummarizer:
    def __init__(self, llm_router: LLMRouter):
        self.llm_router = llm_router

    def summarize(self, csv_preview: str) -> str:
        system_prompt = "Você é um analista de segurança e auditoria Oracle."
        user_prompt = f"""
A seguir há um extrato de eventos classificados.
Gere um resumo executivo contendo:
- principais suspeitas
- possíveis padrões por usuário/máquina/ferramenta
- eventos que merecem atenção imediata
- recomendações operacionais

Dados:
{csv_preview}
""".strip()
        return self.llm_router.ask_chat(system_prompt, user_prompt)
