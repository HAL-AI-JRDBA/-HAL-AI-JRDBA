from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

import numpy as np
import pandas as pd


@dataclass
class SecurityConfig:
    work_start_hour: int = 7
    work_end_hour: int = 20
    suspicious_row_factor: float = 5.0
    suspicious_object_diversity: int = 5
    ddl_weight: int = 35
    off_hours_weight: int = 20
    volume_weight: int = 30
    tool_weight: int = 20


class AnomalyScorer:
    def __init__(self, config: dict):
        sec = config.get("security", {})
        self.cfg = SecurityConfig(
            work_start_hour=int(sec.get("work_start_hour", 7)),
            work_end_hour=int(sec.get("work_end_hour", 20)),
            suspicious_row_factor=float(sec.get("suspicious_row_factor", 5.0)),
            suspicious_object_diversity=int(sec.get("suspicious_object_diversity", 5)),
            ddl_weight=int(sec.get("ddl_weight", 35)),
            off_hours_weight=int(sec.get("off_hours_weight", 20)),
            volume_weight=int(sec.get("volume_weight", 30)),
            tool_weight=int(sec.get("tool_weight", 20)),
        )

    def score_dataframe(
        self,
        df: pd.DataFrame,
        user_col: str,
        ts_col: str,
        op_col: str,
        object_col: str,
        rows_col: str | None = None,
        tool_col: str | None = None,
    ) -> pd.DataFrame:
        if df.empty:
            return df

        work_start = self.cfg.work_start_hour
        work_end = self.cfg.work_end_hour

        data = df.copy()
        data[ts_col] = pd.to_datetime(data[ts_col], errors="coerce")
        data["_hour"] = data[ts_col].dt.hour.fillna(-1)
        data["_off_hours"] = ~data["_hour"].between(work_start, work_end)
        data["_is_ddl"] = data[op_col].astype(str).str.upper().isin(["DDL", "ALTER", "DROP", "TRUNCATE", "CREATE"])
        data["_score"] = 0

        data.loc[data["_off_hours"], "_score"] += self.cfg.off_hours_weight
        data.loc[data["_is_ddl"], "_score"] += self.cfg.ddl_weight

        if rows_col and rows_col in data.columns:
            rows_numeric = pd.to_numeric(data[rows_col], errors="coerce").fillna(0)
            med_by_user = rows_numeric.groupby(data[user_col]).transform(lambda s: float(s.median()) if len(s) else 0.0)
            data["_volume_flag"] = rows_numeric > (med_by_user * self.cfg.suspicious_row_factor).clip(lower=1)
            data.loc[data["_volume_flag"], "_score"] += self.cfg.volume_weight
        else:
            data["_volume_flag"] = False

        if tool_col and tool_col in data.columns:
            tool_text = data[tool_col].astype(str).str.upper()
            suspicious_tools = tool_text.str.contains("TOAD|SQL DEVELOPER|PL/SQL|SQLPLUS|PYTHON|EXCEL|DBeaver".upper(), regex=True)
            data.loc[suspicious_tools, "_score"] += self.cfg.tool_weight
            data["_suspicious_tool"] = suspicious_tools
        else:
            data["_suspicious_tool"] = False

        obj_div = data.groupby(user_col)[object_col].transform("nunique")
        data["_object_diversity_flag"] = obj_div >= self.cfg.suspicious_object_diversity
        data.loc[data["_object_diversity_flag"], "_score"] += 10

        data["classification"] = np.select(
            [
                data["_score"] >= 60,
                data["_score"] >= 30,
            ],
            [
                "MALICIOSA",
                "SUSPEITA",
            ],
            default="NORMAL",
        )
        return data.sort_values("_score", ascending=False)
