from __future__ import annotations

import random
from datetime import datetime, timedelta
from typing import Any, Dict, List

import pandas as pd
from faker import Faker


class SyntheticDataGenerator:
    def __init__(self, locale: str = "pt_BR"):
        self.fake = Faker(locale)

    def generate_from_columns(self, columns: list[dict], rows: int = 100) -> pd.DataFrame:
        records = []
        for _ in range(rows):
            row = {}
            for col in columns:
                name = col["name"]
                dtype = (col.get("data_type") or "").upper()
                row[name] = self._generate_value(name, dtype)
            records.append(row)
        return pd.DataFrame(records)

    def _generate_value(self, name: str, dtype: str):
        upper_name = name.upper()

        if "CPF" in upper_name:
            return self.fake.cpf()
        if "CNPJ" in upper_name:
            return self.fake.cnpj()
        if "EMAIL" in upper_name:
            return self.fake.email()
        if "NOME" in upper_name:
            return self.fake.name()
        if "ENDERECO" in upper_name or "END" in upper_name:
            return self.fake.address().replace("\n", ", ")
        if "TELEFONE" in upper_name or "FONE" in upper_name:
            return self.fake.phone_number()
        if "PLACA" in upper_name:
            return f"{random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ')}{random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ')}{random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ')}{random.randint(0,9)}{random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ')}{random.randint(10,99)}"
        if "DATA" in upper_name or dtype in {"DATE", "TIMESTAMP"}:
            start = datetime.now() - timedelta(days=365)
            return start + timedelta(days=random.randint(0, 365), seconds=random.randint(0, 86400))
        if dtype in {"NUMBER", "FLOAT", "BINARY_FLOAT", "BINARY_DOUBLE"}:
            return round(random.uniform(1, 10000), 2)
        if dtype.startswith("VARCHAR") or dtype.startswith("CHAR") or dtype in {"CLOB", "NVARCHAR2", "VARCHAR2"}:
            return self.fake.word()
        return self.fake.word()

    @staticmethod
    def dataframe_to_insert_sql(df: pd.DataFrame, table_name: str) -> str:
        lines = []
        for _, row in df.iterrows():
            cols = []
            vals = []
            for col, value in row.items():
                cols.append(col)
                if pd.isna(value):
                    vals.append("NULL")
                elif hasattr(value, "strftime"):
                    vals.append(f"TO_DATE('{value.strftime('%Y-%m-%d %H:%M:%S')}', 'YYYY-MM-DD HH24:MI:SS')")
                elif isinstance(value, (int, float)):
                    vals.append(str(value))
                else:
                    safe = str(value).replace("'", "''")
                    vals.append(f"'{safe}'")
            lines.append(f"INSERT INTO {table_name} ({', '.join(cols)}) VALUES ({', '.join(vals)});")
        return "\n".join(lines)
