# Monitoramento Zabbix + Grafana — JR-AI

Esta versão adiciona uma aba **Monitoramento** para integrar a JR-AI ao Zabbix e Grafana.

## O que foi adicionado

- Nova aba: **Monitoramento**
- Configuração de Zabbix API JSON-RPC
- Teste de conexão com Zabbix
- Consulta de hosts via `host.get`
- Consulta de problemas abertos via `problem.get`
- Configuração de Grafana URL + Service Account Token
- Teste de conexão com Grafana
- Listagem de datasources do Grafana
- Geração de dashboard JSON
- Importação automática de dashboard no Grafana
- Iframe para abrir Grafana dentro da JR-AI
- Endpoint Prometheus da JR-AI:
  - `/api/monitoring/prometheus-metrics`

## Endpoints

```text
GET  /api/monitoring/status
GET  /api/monitoring/config
POST /api/monitoring/config
GET  /api/monitoring/zabbix/test
GET  /api/monitoring/zabbix/hosts
GET  /api/monitoring/zabbix/problems
GET  /api/monitoring/grafana/test
GET  /api/monitoring/grafana/datasources
GET  /api/monitoring/grafana/dashboard-json
POST /api/monitoring/grafana/import-dashboard
GET  /api/monitoring/prometheus-metrics
```

## Como usar

1. Abra a aba **Monitoramento**.
2. Informe a URL do Zabbix:
   ```text
   http://SEU_ZABBIX/zabbix/api_jsonrpc.php
   ```
3. Informe usuário/senha ou API Token.
4. Clique em **Salvar configuração**.
5. Clique em **Testar Zabbix**, **Hosts** ou **Problemas**.
6. Informe a URL do Grafana:
   ```text
   http://SEU_GRAFANA:3000
   ```
7. Informe um Service Account Token do Grafana.
8. Clique em **Gerar Dashboard JSON** ou **Importar Dashboard**.

## Prometheus

Configure o Prometheus para raspar:

```text
http://IP_DA_JR_AI:8000/api/monitoring/prometheus-metrics
```

Depois adicione Prometheus como datasource no Grafana.

## Observação

Para visualizar métricas do Zabbix diretamente no Grafana, instale/configure um datasource/plugin do Zabbix no Grafana ou use Prometheus como camada intermediária. A JR-AI já consulta o Zabbix pela API e traz os problemas/hosts para análise, chat e insights.
