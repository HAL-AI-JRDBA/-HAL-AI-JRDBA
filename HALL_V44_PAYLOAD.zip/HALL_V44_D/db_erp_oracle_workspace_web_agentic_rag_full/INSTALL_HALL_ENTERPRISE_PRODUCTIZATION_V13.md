# Instalação — HAL Enterprise Productization V13

Execute:

```bat
INICIAR_JR_AI_HALL_ENTERPRISE_PRODUCTIZATION_V13.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Teste rápido

No chat, digite:

```text
Adicione AIHub, Zheus, Asimov, 50 skills, 40 templates, deploy real, fleet de agentes, RAG e white-label.
```

O HAL deve escolher:

```text
intent: enterprise_productization
tool: enterprise_productization_v13
```

## Endpoints úteis

```text
/api/unified/enterprise-v13/status
/api/unified/enterprise-v13/health
/api/unified/enterprise-v13/quality-gate
/api/unified/enterprise-v13/router-tests
/api/unified/enterprise-v13/skills?seed=true
/api/unified/enterprise-v13/templates
/api/unified/enterprise-v13/integrations
/api/unified/enterprise-v13/fleet
/api/unified/enterprise-v13/white-label
```

## Credenciais opcionais

Configure variáveis de ambiente conforme o conector:

```text
GITHUB_TOKEN
GITHUB_OWNER
VERCEL_TOKEN
SUPABASE_URL
SUPABASE_SERVICE_KEY
STRIPE_SECRET_KEY
WHATSAPP_TOKEN
TELEGRAM_BOT_TOKEN
GOOGLE_APPLICATION_CREDENTIALS
N8N_BASE_URL
N8N_API_KEY
```

Sem credenciais, o HAL gera plano, manifest e validação local; não executa publicação externa.
