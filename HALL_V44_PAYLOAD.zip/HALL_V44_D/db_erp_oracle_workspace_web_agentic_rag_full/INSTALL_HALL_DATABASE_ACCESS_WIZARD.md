# Instalação opcional — drivers SQL/NoSQL

A camada Database Access Wizard já foi adicionada. Para executar consultas reais, instale os drivers conforme o banco do cliente.

## SQL

```bash
pip install oracledb pyodbc pymssql psycopg pymysql mariadb firebird-driver ibm_db
```

## NoSQL

```bash
pip install pymongo redis elasticsearch cassandra-driver requests
```

## Observação

Alguns bancos exigem client/driver do fornecedor, como Oracle Client, ODBC SQL Server, IBM DB2 Client ou Firebird Client.
