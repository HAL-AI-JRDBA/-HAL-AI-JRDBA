# Ground Truth de Schema ERP

Esta versão passa a usar o arquivo `data/ground_truth/Tabelas_Colunas_Relacionamentos.txt` como camada canônica para:

- reforçar descoberta de módulos e prefixos (`ABA`, `ACD`, `CTB`, etc.)
- completar PKs e FKs quando o Oracle não trouxer tudo no filtro inicial
- priorizar tabelas candidatas por termos de negócio
- expandir tabelas relacionadas por vizinhança de FK
- montar joins `GROUND_TRUTH` antes do LLM gerar a SQL
- reduzir alucinação no NL2SQL usando `schema_package` + joins/blueprints reais

Arquivos adicionados:
- `services/schema_ground_truth.py`
- `data/ground_truth/Tabelas_Colunas_Relacionamentos.txt`
- `data/ground_truth/ground_truth_schema.json`

## Fluxo recomendado
1. Conecte ao Oracle.
2. Vá em **Mapa ERP / Metadados** e rode **Analisar schema**.
3. Confira as tabelas candidatas e refine se necessário.
4. Só depois use a aba de geração de SQL / View Studio.

## Observação
Se você atualizar o TXT canônico, apague `ground_truth_schema.json` para forçar nova regeneração do índice local.
