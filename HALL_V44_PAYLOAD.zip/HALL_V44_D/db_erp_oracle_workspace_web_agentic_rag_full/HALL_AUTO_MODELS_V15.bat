@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion

echo.
echo ============================================================
echo HAL MULTI-MODEL ROUTER V15 - CHECK DE MODELOS OLLAMA
echo ============================================================
echo.

if "%OLLAMA_URL%"=="" set "OLLAMA_URL=http://127.0.0.1:11434"

if "%HALL_MODEL_CHAT%"=="" set "HALL_MODEL_CHAT=qwen2.5:7b"
if "%HALL_MODEL_DIALOG%"=="" set "HALL_MODEL_DIALOG=%HALL_MODEL_CHAT%"
if "%HALL_MODEL_CODE%"=="" set "HALL_MODEL_CODE=qwen2.5-coder:14b"
if "%HALL_MODEL_FAST_CODE%"=="" set "HALL_MODEL_FAST_CODE=qwen2.5-coder:7b"
if "%HALL_MODEL_DEEP_CODE%"=="" set "HALL_MODEL_DEEP_CODE=deepseek-coder-v2:16b"
if "%HALL_MODEL_SQL%"=="" set "HALL_MODEL_SQL=sqlcoder:7b-q4_0"
if "%HALL_MODEL_EMBED%"=="" set "HALL_MODEL_EMBED=embeddinggemma:latest"
if "%HALL_MODEL_VISION%"=="" set "HALL_MODEL_VISION=llava:latest"
if "%HALL_MODEL_FAST%"=="" set "HALL_MODEL_FAST=phi3:mini"

echo Ollama URL: %OLLAMA_URL%
echo.
echo Modelos esperados:
echo [CHAT]      %HALL_MODEL_CHAT%
echo [DIALOG]    %HALL_MODEL_DIALOG%
echo [CODE]      %HALL_MODEL_CODE%
echo [FAST CODE] %HALL_MODEL_FAST_CODE%
echo [DEEP CODE] %HALL_MODEL_DEEP_CODE%
echo [SQL]       %HALL_MODEL_SQL%
echo [EMBED]     %HALL_MODEL_EMBED%
echo [VISION]    %HALL_MODEL_VISION%
echo [FAST]      %HALL_MODEL_FAST%
echo.

where ollama >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Ollama nao encontrado no PATH.
  echo Instale o Ollama ou ajuste o PATH.
  goto end_ok
)

echo [AUTO] Verificando servico Ollama...
ollama list >nul 2>nul
if errorlevel 1 (
  echo [AUTO] Tentando iniciar Ollama...
  start "" /min ollama serve
  timeout /t 4 /nobreak >nul
)

ollama list >nul 2>nul
if errorlevel 1 (
  echo [AVISO] Ollama ainda nao respondeu. O HAL abrira, mas modelos nao foram validados.
  goto end_ok
)

echo [OK] Ollama respondendo.
echo.

call :checkModel "CHAT" "%HALL_MODEL_CHAT%"
call :checkModel "DIALOG" "%HALL_MODEL_DIALOG%"
call :checkModel "CODE" "%HALL_MODEL_CODE%"
call :checkModel "FAST CODE" "%HALL_MODEL_FAST_CODE%"
call :checkModel "DEEP CODE" "%HALL_MODEL_DEEP_CODE%"
call :checkModel "SQL" "%HALL_MODEL_SQL%"
call :checkModel "EMBED" "%HALL_MODEL_EMBED%"
call :checkModel "VISION" "%HALL_MODEL_VISION%"
call :checkModel "FAST" "%HALL_MODEL_FAST%"

echo.
echo [AUTO] Teste rapido dos modelos principais...
call :quickRun "CHAT" "%HALL_MODEL_CHAT%" "Responda apenas: CHAT OK"
call :quickRun "CODE" "%HALL_MODEL_CODE%" "Responda apenas: CODE OK"
call :quickRun "SQL" "%HALL_MODEL_SQL%" "Crie um SELECT simples para listar clientes ativos. Responda curto."
call :quickEmbed "%HALL_MODEL_EMBED%"
call :quickRun "VISION" "%HALL_MODEL_VISION%" "Responda apenas: VISION OK"

echo.
echo [OK] Verificacao Multi-Model V15 concluida.
goto end_ok

:checkModel
set "LABEL=%~1"
set "MODEL=%~2"
ollama list | findstr /I /C:"%MODEL%" >nul
if errorlevel 1 (
  echo [FALTANDO] %LABEL%: %MODEL%
  if /I "%HALL_AUTO_PULL_MODELS%"=="1" (
    echo [AUTO] Baixando %MODEL%...
    ollama pull "%MODEL%"
  ) else (
    echo          Para baixar: ollama pull %MODEL%
  )
) else (
  echo [OK] %LABEL%: %MODEL%
)
exit /b 0

:quickRun
set "LABEL=%~1"
set "MODEL=%~2"
set "PROMPT=%~3"
ollama run "%MODEL%" "%PROMPT%" >nul 2>nul
if errorlevel 1 (
  echo [AVISO] Teste %LABEL% falhou ou demorou: %MODEL%
) else (
  echo [OK] Teste %LABEL%: %MODEL%
)
exit /b 0

:quickEmbed
set "MODEL=%~1"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$body=@{model='%MODEL%';input='teste embedding'}|ConvertTo-Json; try {$r=Invoke-RestMethod -Uri '%OLLAMA_URL%/api/embed' -Method Post -ContentType 'application/json' -Body $body -TimeoutSec 15; if($r.embeddings -or $r.embedding){exit 0}else{exit 2}} catch {exit 1}" >nul 2>nul
if errorlevel 1 (
  echo [AVISO] Teste EMBED falhou: %MODEL%
) else (
  echo [OK] Teste EMBED: %MODEL%
)
exit /b 0

:end_ok
endlocal
exit /b 0
