# Instalação — HAL Conversation Repair V8

Execute:

```bat
INICIAR_JR_AI_HALL_REPAIR_V8.bat
```

ou:

```bat
INICIAR_JR_AI_HALL_TOPIC_SWITCH_V7.bat
```

Depois acesse:

```text
http://127.0.0.1:8000
```

## Teste recomendado

Digite:

```text
acredito que você não está me ouvindo
```

A resposta não deve falar sobre Skills, agentes, ClawHub ou imagem.

Depois digite:

```text
você não entendeu, não era isso
```

O HAL deve abandonar a interpretação anterior e pedir a pergunta principal.

## Teste para garantir que Skills ainda funciona

Digite:

```text
crie uma imagem com agentes colaborando
```

Nesse caso, aí sim ele pode usar o Skills/Multi-Agent Center.
