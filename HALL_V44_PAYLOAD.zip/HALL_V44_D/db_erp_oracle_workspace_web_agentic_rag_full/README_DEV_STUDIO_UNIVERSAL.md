# Dev Studio Universal — JR-AI

Esta versão adiciona uma nova aba **Dev Studio Universal**, transformando a JR-AI em uma plataforma para planejar e gerar sistemas em múltiplas linguagens.

## O que faz

- Planeja arquitetura de sistemas.
- Gera estrutura de projeto em ZIP.
- Suporta aplicações web, APIs, scripts, console e templates genéricos.
- Integra com Chat JR-AI, JR Voz Global e OpenClaw Runtime.
- Permite criar sistemas em Python, Java, C++, C#, JavaScript, TypeScript, PHP e stacks customizadas.

## Linguagens/stacks prontas

- Python CLI
- Python FastAPI
- Python Flask
- Node.js Express
- React + Vite
- Java Maven
- Java Spring Boot
- C++ CMake
- C# .NET Console
- PHP simples
- Template genérico para outras linguagens

## Endpoints

```text
GET  /api/dev-studio/status
GET  /api/dev-studio/profiles
POST /api/dev-studio/plan
POST /api/dev-studio/generate
GET  /api/dev-studio/projects
GET  /api/dev-studio/download/{filename}
```

## Exemplo de prompt no Chat JR-AI

```text
Crie um projeto web em Python FastAPI para controlar ordens de serviço da frota, com cadastro, consulta por garagem, dashboard e exportação Excel. Gerar projeto em ZIP.
```

## Observação

O Dev Studio gera uma base inicial segura e organizada. Para sistemas complexos, use a Fábrica de Software IA para evoluir o projeto com patch, revisão, testes e aprovação.
