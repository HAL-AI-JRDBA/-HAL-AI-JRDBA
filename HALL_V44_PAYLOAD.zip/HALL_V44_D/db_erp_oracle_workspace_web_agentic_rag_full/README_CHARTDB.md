
# Integração do ChartDB no DB ERP Local Studio V3.3 GenAI

Esta integração usa o ChartDB como editor visual **separado** do Streamlit.
O app atual continua responsável por:
- descobrir schema e tabelas relevantes no Oracle
- inferir joins
- filtrar tabelas para o módulo
- exportar o resultado em **DDL Oracle** ou **DBML**

O ChartDB entra como camada visual para montar o diagrama ER.

## Instalação sem Docker (Windows)

Pré-requisitos:
- Node.js 18+ no PATH
- npm no PATH
- Git no PATH

Passos:
1. Clone o repositório do ChartDB
2. Rode `npm install`
3. Rode `npm run dev`
4. Ajuste a URL na aba **ERD / ChartDB** do app (ex.: `http://localhost:5173`)

## Fluxo recomendado

1. Abra a aba **Mapa ERP / Metadados**
2. Rode **Analisar schema**
3. Selecione as tabelas principais
4. Vá para **ERD / ChartDB**
5. Gere **DBML** ou **DDL Oracle**
6. Importe o conteúdo no ChartDB

## Quando usar cada formato

- **DBML**: melhor para importação rápida e visualização imediata
- **DDL Oracle**: melhor para revisão técnica, auditoria e validação manual

## Observação

A importação JSON do ChartDB é voltada a diagramas exportados pelo próprio ChartDB.
Para integração simples e estável, este projeto exporta **DBML** e **DDL**.
