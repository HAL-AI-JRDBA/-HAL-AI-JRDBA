# Instalação — HAL Voice STT Fallback V5

Execute:

```bat
INICIAR_JR_AI_HALL_VOICE_STT_V5.bat
```

ou o inicializador principal.

O sistema vai tentar instalar automaticamente:

```bat
pip install faster-whisper
pip install av
```

## Teste

1. Abra `http://127.0.0.1:8000`.
2. Clique em `Conversar`.
3. Aguarde `Ouvindo...`.
4. Fale.
5. Se aparecer `Não captei pelo navegador`, aguarde `Gravando voz...` e fale novamente.

## Status

Para verificar o STT local, acesse no navegador:

```text
http://127.0.0.1:8000/api/unified/stt/status
```

ou no Agentic Pro:

```text
http://127.0.0.1:8000/api/stt/status
```
