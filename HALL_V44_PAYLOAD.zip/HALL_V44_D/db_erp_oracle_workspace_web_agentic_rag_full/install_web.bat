@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo JR-AI HAL - INSTALACAO WEB
echo ============================================================
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo [ERRO] Python Launcher py nao encontrado.
  echo Instale Python 3.11 ou superior x64 e tente novamente.
  pause
  exit /b 1
)

if not exist ".venv_web\Scripts\python.exe" (
  echo Criando ambiente virtual .venv_web...
  py -3 -m venv ".venv_web"
  if errorlevel 1 (
    echo [ERRO] Falha ao criar o ambiente virtual.
    pause
    exit /b 1
  )
)

call ".venv_web\Scripts\activate.bat"

echo Atualizando pip...
python -m pip install --upgrade pip setuptools wheel
if errorlevel 1 (
  echo [ERRO] Falha ao atualizar pip.
  pause
  exit /b 1
)

if exist "requirements_web.txt" (
  echo Instalando requirements_web.txt...
  pip install -r "requirements_web.txt"
) else if exist "requirements.txt" (
  echo Instalando requirements.txt...
  pip install -r "requirements.txt"
) else (
  echo [AVISO] Nenhum arquivo de requirements encontrado.
)

if errorlevel 1 (
  echo [ERRO] Falha ao instalar dependencias.
  pause
  exit /b 1
)

echo.
echo Validando dependencias web...
if exist "check_web_deps.py" (
  python "check_web_deps.py"
  if errorlevel 1 (
    echo [ERRO] Falha na validacao das dependencias web.
    pause
    exit /b 1
  )
)

echo.
echo [OK] Instalacao concluida.
echo Para Qdrant/PGVector/Enterprise RAG execute tambem: INSTALAR_HALL_ENTERPRISE_RAG_V17.bat
echo Execute a plataforma pela raiz com: INICIAR_JR_AI_HALL_V17.bat
pause
endlocal
