@echo off
call "%~dp0..\VALIDAR_HUGGINGFACE_HALL_V32.bat"
