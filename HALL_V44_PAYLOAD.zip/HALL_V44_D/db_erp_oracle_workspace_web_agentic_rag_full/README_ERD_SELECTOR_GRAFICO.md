# ERD / ChartDB com seleção gráfica de tabelas

Esta versão acrescenta uma seleção visual de tabelas dentro da aba **ERD / ChartDB**.

## Fluxo recomendado

1. Abra o sistema com `run_web.bat`.
2. Vá em **Mapa ERP / Metadados**.
3. Informe o owner/schema, módulo, prefixos e clique em **Analisar schema**.
4. Vá em **ERD / ChartDB**.
5. Use o painel **Selecionar tabelas do ERD** para:
   - filtrar por nome de tabela, coluna, papel ou prefixo;
   - selecionar todas as tabelas filtradas;
   - selecionar Top N;
   - incluir tabelas relacionadas pelas sugestões de relacionamento;
   - limpar ou aplicar a seleção.
6. Clique em **Gerar ERD Local**, **Gerar DBML** ou **Gerar DDL**.

## O que muda

- O usuário não precisa digitar nomes de tabelas manualmente.
- As tabelas aparecem com checkbox, papel, família, quantidade de colunas, PK visível e amostra de colunas.
- A seleção feita no ERD fica sincronizada com o contexto usado pelo SQL Copilot/Codex.
- O DBML e o DDL agora respeitam a seleção visual.
- O ERD Local mostra somente as tabelas escolhidas e os relacionamentos entre elas.

## Observação

O ChartDB externo continua opcional. Mesmo sem o ChartDB rodando em `http://127.0.0.1:5173`, o **ERD Local** funciona dentro da própria ferramenta.
