# Chat JR-AI

Nova aba de chat no formato conversacional, integrada ao JR-AI Voz Global.

## Recursos

- Aba **Chat JR-AI**.
- Histórico de conversas na barra lateral direita.
- Botão **+** com opções: nova conversa, anexar arquivo, usar módulo atual, enviar para SQL, DBA, Insights e Apresentações.
- Campo de prompt com modo **Estendido**.
- Botão de microfone para ditar pergunta em pt-BR.
- Botão de envio com seta para cima.
- Resposta por texto e voz usando o perfil pt-BR brasileiro/sudeste configurado no JR.
- Backend persistente em `data/chat_jr_ai/conversations`.

## Endpoints

- `GET /api/chat/status`
- `GET /api/chat/conversations`
- `POST /api/chat/conversations`
- `GET /api/chat/conversations/{conversation_id}`
- `DELETE /api/chat/conversations/{conversation_id}`
- `POST /api/chat/ask`
- `POST /api/chat/upload`

## Como rodar

```bat
install_web.bat
run_web_chat_jr_ai.bat
```

Também funciona com:

```bat
run_web_jr_global.bat
```

Abra a aba **Chat JR-AI** e use texto ou microfone.
