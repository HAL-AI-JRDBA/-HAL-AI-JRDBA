@echo off
title JR-AI Pull Modelos Locais
echo Baixando modelos recomendados localmente...
ollama pull qwen2.5:7b
ollama pull qwen2.5-coder:7b
ollama pull nomic-embed-text
echo.
echo Modelos instalados/listados:
ollama list
pause
