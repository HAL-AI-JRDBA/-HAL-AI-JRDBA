@echo off
title JR-AI Ollama GPU
echo ============================================================
echo JR-AI - Ollama Local GPU
echo Requer GPU compativel e drivers instalados
echo ============================================================
set OLLAMA_CONTEXT_LENGTH=64000
set OLLAMA_NO_GPU=
echo OLLAMA_CONTEXT_LENGTH=%OLLAMA_CONTEXT_LENGTH%
ollama serve
pause
