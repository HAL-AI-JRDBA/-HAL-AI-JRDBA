@echo off
echo Exemplo para instalar JR-AI como Windows Service usando NSSM.
echo Baixe o NSSM e ajuste os caminhos antes de executar como Administrador.
set JR_DIR=C:\JR-AI
nssm install JR-AI "%JR_DIR%\.venv\Scripts\python.exe" "-m uvicorn web_app.backend.main:app --host 0.0.0.0 --port 8000"
nssm set JR-AI AppDirectory "%JR_DIR%"
nssm set JR-AI Start SERVICE_AUTO_START
nssm start JR-AI
pause
