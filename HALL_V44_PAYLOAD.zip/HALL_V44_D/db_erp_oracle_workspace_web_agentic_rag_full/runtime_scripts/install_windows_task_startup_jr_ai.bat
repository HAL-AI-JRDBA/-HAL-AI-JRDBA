@echo off
title JR-AI Agendar inicializacao
echo Este script cria uma tarefa agendada simples para iniciar a JR-AI no logon.
echo Ajuste o caminho abaixo se necessario.
set JR_DIR=%~dp0..
schtasks /Create /TN "JR-AI Local Runtime" /TR ""%JR_DIR%\run_web_dev_studio.bat"" /SC ONLOGON /RL LIMITED /F
echo Tarefa criada. Verifique no Agendador de Tarefas do Windows.
pause
