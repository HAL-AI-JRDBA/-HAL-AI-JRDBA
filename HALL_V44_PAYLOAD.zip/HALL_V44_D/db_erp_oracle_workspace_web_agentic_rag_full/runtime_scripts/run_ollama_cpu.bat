@echo off
title JR-AI Ollama CPU
echo ============================================================
echo JR-AI - Ollama Local CPU
echo Plataforma Gen-AI Open Source para ERP, Oracle, Agentes e Automacao
echo ============================================================
set OLLAMA_NO_GPU=1
set OLLAMA_CONTEXT_LENGTH=8192
echo OLLAMA_NO_GPU=%OLLAMA_NO_GPU%
echo OLLAMA_CONTEXT_LENGTH=%OLLAMA_CONTEXT_LENGTH%
ollama serve
pause
