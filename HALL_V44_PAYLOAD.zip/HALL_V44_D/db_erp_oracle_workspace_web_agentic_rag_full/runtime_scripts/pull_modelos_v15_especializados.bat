@echo off
chcp 65001 >nul
echo Baixando modelos especializados do HAL V15...

ollama pull qwen2.5:7b
ollama pull qwen2.5-coder:14b
ollama pull qwen2.5-coder:7b
ollama pull deepseek-coder-v2:16b
ollama pull sqlcoder:7b-q4_0
ollama pull embeddinggemma:latest
ollama pull llava:latest
ollama pull phi3:mini

echo.
echo [OK] Downloads solicitados.
pause
