@echo off
title JR-AI Ollama Auto
echo ============================================================
echo JR-AI - Ollama Local Auto CPU/GPU
echo ============================================================
set OLLAMA_CONTEXT_LENGTH=8192
echo OLLAMA_CONTEXT_LENGTH=%OLLAMA_CONTEXT_LENGTH%
ollama serve
pause
