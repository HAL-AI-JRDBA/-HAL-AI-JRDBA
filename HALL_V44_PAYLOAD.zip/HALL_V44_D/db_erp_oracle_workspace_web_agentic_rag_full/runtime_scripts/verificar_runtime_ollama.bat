@echo off
title JR-AI Verificar Runtime Ollama
echo ============================================================
echo Verificando Ollama, modelos carregados e GPU
echo ============================================================
echo.
echo [1] ollama --version
ollama --version
echo.
echo [2] ollama list
ollama list
echo.
echo [3] ollama ps
ollama ps
echo.
echo [4] nvidia-smi, se existir
nvidia-smi
pause
