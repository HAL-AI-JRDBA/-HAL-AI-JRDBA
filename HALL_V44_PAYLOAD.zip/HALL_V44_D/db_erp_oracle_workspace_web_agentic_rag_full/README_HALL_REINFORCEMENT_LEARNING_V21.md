# HAL V21 — Reinforcement Learning Lab

A V21 separa **aprendizado em produção** de **treinamento de pesos**.

## Produção

A HAL continua aprendendo por `PolicyBandit`, memória, feedback e rewards sem alterar pesos. O chat agora permite `Útil` e `Melhorar`, gravando sinais no Experience Store.

## RL Lab

Pipeline governado:

`Experience Store -> Dataset -> Job pendente -> Aprovação Admin -> Sandbox -> DPO/Reward/GRPO -> Adapter -> Ollama Candidate -> Benchmark A/B -> Safety -> Aprovação Admin -> Router -> Restart -> Rollback`

### Garantias

- `auto_train=false` é imposto pelo código.
- Job não executa sem aprovação administrativa.
- Treino real é bloqueado sem GPU por padrão.
- Dry-run não altera pesos e nunca pode ser promovido.
- Candidato real precisa existir no Ollama antes da promoção.
- Benchmark e Safety automáticos são exigidos por padrão.
- O Router é salvo antes da troca e há rollback.

### Métodos

- **DPO**: preference pairs `prompt/chosen/rejected`.
- **Reward Model**: pares derivados de respostas com rewards distintos.
- **GRPO**: prompts + reward function local de referência; destinado a ambientes de treino com GPU.

### Dependências opcionais

`requirements_training_v21.txt`.

Essas dependências não são instaladas no boot e não são necessárias para inferência normal.
