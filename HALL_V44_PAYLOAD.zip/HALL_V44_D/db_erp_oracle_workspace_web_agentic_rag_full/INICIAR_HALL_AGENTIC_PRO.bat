@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if exist "HALL_AUTO_MODELS_V15.bat" call "HALL_AUTO_MODELS_V15.bat"

echo ============================================================
echo INICIAR HAL TRANSPORTE AGENTIC PRO
echo ============================================================
echo.

if not exist "hall_transporte_agentic_pro\INICIAR_HALL_AGENTIC_PRO.bat" (
  echo [ERRO] Pasta hall_transporte_agentic_pro nao encontrada.
  pause
  exit /b 1
)

cd /d "hall_transporte_agentic_pro"
call "INICIAR_HALL_AGENTIC_PRO.bat"

endlocal
