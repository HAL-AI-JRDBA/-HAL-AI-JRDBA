# HAL Cyber Defense & Ransomware Shield V14

Esta versão adiciona uma camada defensiva para proteger empresas contra invasões, phishing, malware e ransomware.

## Importante

Nenhuma IA consegue prometer proteção absoluta contra invasões ou criptografia de arquivos. O papel do HAL Cyber Defense é reduzir risco, detectar sinais cedo, orquestrar resposta e integrar ferramentas de segurança já existentes.

Ações reais como isolar computador, bloquear usuário, mexer em firewall, EDR, SIEM ou e-mail corporativo exigem credenciais, permissões administrativas e aprovação humana.

## O que foi adicionado

```text
Triagem de e-mails e anexos suspeitos
Detecção de anexos executáveis/scripts
Detecção de documentos com macro
Detecção de dupla extensão, como boleto.pdf.exe
Canary files em pastas críticas
Baseline de arquivos
Scan defensivo de pastas monitoradas
Detecção de extensões típicas de ransomware
Detecção de alteração em massa
Verificação de backup
Postura de segurança
Plano anti-ransomware em camadas
Playbook de incidente
Alertas locais
Catálogo de integrações EDR/SIEM/monitoramento
```

## Integrações previstas

```text
Microsoft Defender
Windows Event Log
Sysmon
Wazuh
Elastic
Splunk
SentinelOne
CrowdStrike
VirusTotal
Zabbix
Grafana
Gateway de e-mail
```

## Endpoints principais

```text
/api/unified/cyber-defense/status
/api/unified/cyber-defense/config
/api/unified/cyber-defense/integrations
/api/unified/cyber-defense/email/analyze
/api/unified/cyber-defense/canaries
/api/unified/cyber-defense/baseline
/api/unified/cyber-defense/scan
/api/unified/cyber-defense/backup-readiness
/api/unified/cyber-defense/posture
/api/unified/cyber-defense/ransomware-guard-plan
/api/unified/cyber-defense/incident-playbook
/api/unified/cyber-defense/alerts
```

## Como funciona

### 1. E-mail

O HAL analisa assunto, remetente, corpo e anexos. Ele marca risco quando encontra:

```text
anexo .exe, .scr, .js, .vbs, .ps1
documento com macro .docm, .xlsm, .pptm
arquivo compactado suspeito
dupla extensão como nota_fiscal.pdf.exe
linguagem de urgência, boleto, senha, bloqueio, PIX ou clique aqui
```

### 2. Arquivos

O HAL pode monitorar pastas informadas pelo usuário, criar arquivos canário e fazer baseline. Depois, ao vasculhar novamente, detecta:

```text
arquivos renomeados
arquivos com extensões de ransomware
mudança em massa
notas de resgate
alta entropia em arquivos inesperados
```

### 3. Backup

O HAL verifica se existem caminhos de backup configurados e recomenda:

```text
backup offline ou imutável
teste de restauração
credencial separada para backup
não manter único backup montado na mesma rede
```

### 4. Resposta a incidente

O playbook orienta:

```text
isolar máquinas suspeitas
bloquear credenciais comprometidas
interromper compartilhamentos afetados
coletar logs
verificar backup antes de restaurar
corrigir causa raiz antes de reconectar
```

## Limites de segurança

Esta camada é defensiva. Ela não executa anexos, não cria malware, não ensina invasão e não realiza ações destrutivas automaticamente.


## HAL Multi-Model Router V15

Adicionada camada de roteamento automático de modelos Ollama: `qwen2.5:7b` para conversa, `qwen2.5-coder:14b` para software, `qwen2.5-coder:7b` para código rápido, `deepseek-coder-v2:16b` para programação complexa, `sqlcoder:7b-q4_0` para SQL, `embeddinggemma:latest` para RAG/embeddings, `llava:latest` para visão e `phi3:mini` para respostas rápidas. O boot agora verifica todos os modelos especializados.
