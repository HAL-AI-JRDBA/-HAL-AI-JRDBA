# HAL V26 — Enterprise AI Governance & Shadow AI Defense

A V26 transforma a HAL em um **Enterprise AI Control Plane**: produtividade e governança de IA na mesma plataforma.

## Arquitetura

```text
Usuário / Telemetria corporativa
        |
        v
HAL AI Governance V26
  |-- AI Inventory
  |-- Prompt Firewall / DLP
  |-- Data Classification
  |-- Risk Engine
  |-- Policy Engine
  |-- Approval Workflow
  |-- Incident Response
  |-- Audit Trail
  |-- Vendor Assessment
  |-- Risk Intelligence
        |
        +--> HAL local / Ollama (dados sensíveis)
        +--> Serviço externo aprovado (somente conforme política)
```

## Shadow AI Discovery

A HAL recebe eventos por push de proxy/SWG, DNS, firewall, EDR/endpoint, navegador corporativo, CASB/SSE ou SIEM. O evento pode conter:

- usuário e departamento;
- dispositivo;
- URL/domínio/aplicação;
- conta pessoal/corporativa;
- ação: acesso, prompt, upload;
- classificação de dado conhecida.

A HAL identifica a aplicação, consulta o registry, calcula risco, decide permitir/controlar/aprovar/bloquear e pode abrir incidente automaticamente.

## Prompt Firewall e DLP

Detectores locais incluem CPF, CNPJ, e-mail, telefone, cartão válido por Luhn, Bearer token, chaves AWS, chaves privadas, secrets/senhas e connection strings com credencial. O audit persiste apenas tipos/fingerprints/hash, nunca o segredo bruto.

## Política de dados

- Público
- Interno
- Confidencial
- Restrito

Padrão: confidencial/restrito fica `local_only`; dado restrito em aplicação externa é bloqueado; confidencial em aplicação externa exige aprovação.

## Enterprise AI Gateway

`POST /api/ai-governance/gateway/evaluate`

Retorna `route`:

- `hall_local`
- `approved_external`
- `approval_queue`
- `blocked`

## Inventários

`/api/ai-governance/registry/{kind}`

Kinds:

- `applications`
- `providers`
- `models`
- `use_cases`
- `policies`
- `connectors`
- `risk_intel`

## AI Vendor Assessment

`GET /api/ai-governance/providers/{provider_id}/assessment`

Avalia status, security review, DPA/localidade, retenção, política de treinamento, auditoria e residência de dados. O resultado é um score e grade.

## Risk Intelligence / Roadmap

Novas práticas, ferramentas e riscos de Shadow AI podem ser registrados em `risk_intel`, com severidade, fonte e ação de roadmap. Isso permite transformar inteligência externa/SOC em revisão de política.

## Pesquisa Web

A Pesquisa Web Confiável agora passa pelo guard da V26. Conteúdo confidencial/restrito não é enviado silenciosamente à Internet: o HAL bloqueia ou exige aprovação e recomenda RAG/modelo local.

## Segurança e RBAC

A API `/api/ai-governance/*` é administrativa. IAM V19 aplica default deny e regra explícita `ai_governance/admin`.

## Limitação intencional

A V26 não instala um sniffer oculto e não afirma enxergar tráfego que não recebe. Para descoberta real na empresa, conecte sua camada de rede/endpoint e envie a telemetria para a HAL.
