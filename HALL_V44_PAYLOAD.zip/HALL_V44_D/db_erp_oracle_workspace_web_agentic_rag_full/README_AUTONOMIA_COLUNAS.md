# Autonomia + Reconhecimento de Colunas Reais

Esta versão adiciona quatro camadas para reduzir alucinação de tabelas/colunas e permitir evolução mais automática do assistente:

## 1. Ground Truth Canônico
- Arquivo em `data/ground_truth/Tabelas_Colunas_Relacionamentos.txt`
- Parser em `services/schema_ground_truth.py`
- Usado para reforçar módulos, PKs, FKs, colunas e caminhos de join.

## 2. Inteligência de Colunas
- Serviço: `services/column_intelligence.py`
- Gera dicas de colunas reais por tabela antes da geração de SQL.
- Faz reparo automático de `alias.coluna` inválidos quando existe coluna real equivalente.
- Ex.: `descricao` -> `DESCRICAOMAT` quando o contexto indicar material/item.

## 3. Auto-Review / Auto-Repair
- O endpoint `/api/sql/generate` agora:
  - detecta intenção
  - monta hints de colunas
  - consulta exemplos aprovados do learning store
  - gera SQL
  - repara colunas inválidas
  - valida no Oracle
  - tenta nova geração usando o erro Oracle, se necessário

## 4. Memória de Aprendizado
- Serviço: `services/self_improvement.py`
- Arquivo: `data/learning/sql_learning.json`
- Registra queries aprovadas, tabelas usadas e correções de colunas.
- A execução bem-sucedida alimenta o learning store.
- A próxima geração passa a usar exemplos aprovados semelhantes.

## Como alimentar a IA
1. Carregue o arquivo canônico em `data/ground_truth/Tabelas_Colunas_Relacionamentos.txt` ou use a aba **Módulos**.
2. Analise o schema por módulo em **Mapa ERP / Metadados**.
3. Selecione as tabelas candidatas adequadas.
4. Gere a SQL.
5. Execute a SQL.
6. Execuções válidas alimentam a memória automaticamente.

## Onde copiar o arquivo canônico
- `data/ground_truth/Tabelas_Colunas_Relacionamentos.txt`

## Observação
A autonomia implementada aqui é de **aprendizado operacional e correção automática de SQL**, não de autoedição do próprio código-fonte sem controle humano.
