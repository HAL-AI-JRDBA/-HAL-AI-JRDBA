# HAL — Voz do Aprigio integrada

Esta versão inclui a amostra de voz enviada como perfil padrão do HAL.

## Perfil criado

```text
profile_id: voice_aprigio_hall
display_name: Voz do Aprigio para HAL
locale: pt-BR
accent: paulistano
status: voice_reference_uploaded
```

## Arquivos incluídos

```text
data/jr_voice_profile/samples/voice_aprigio_hall/sample_uploaded_20260729_201852.ogg
data/jr_voice_profile/samples/voice_aprigio_hall/sample_uploaded_20260729_201852.wav
```

## Importante

A amostra enviada foi incluída como referência de voz.  
Com uma única amostra, a JR-AI já fica preparada para usar essa voz como referência nos motores locais de TTS/clonagem.

Para a voz ficar realmente parecida e estável, abra a aba **Voz Própria** e grave mais frases.

Recomendação:

```text
Teste inicial: 3 amostras
Bom primeiro resultado: 8 a 20 amostras
Melhor qualidade: 30 minutos ou mais de áudio limpo
```

## Configuração aplicada

```text
silence_ms: 5000
do_not_interrupt: true
confirm_when_unclear: true
noise_tolerance: medium_high
voice_engine: browser_fallback
```

O `browser_fallback` evita travamento quando ainda não há motor local instalado.  
Para clonagem real, configure Coqui XTTS, OpenVoice, F5-TTS ou Piper treinado na aba Voz Própria.
