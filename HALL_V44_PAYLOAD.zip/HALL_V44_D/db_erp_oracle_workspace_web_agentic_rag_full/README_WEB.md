# DB ERP Local Studio V3.3 GenAI Web

Versão web direta do projeto, sem Streamlit, usando:
- FastAPI no backend
- HTML/CSS/JavaScript no frontend
- reutilização dos módulos Python já existentes do projeto

## Instalação
1. Rode `install_web.bat`
2. Depois rode `run_web.bat`
3. Abra `http://127.0.0.1:8010`

## O que esta versão já usa do projeto atual
- `services/oracle_client.py`
- `services/schema_ground_truth.py`
- `services/chartdb_integration.py`
- `services/prompt_builder.py`
- `core/sql/nl2sql.py`
- `core/llm/router.py`

## Abas disponíveis
- Dashboard
- Conexão
- Mapa ERP / Metadados
- SQL Copilot
- View Studio
- ERD / ChartDB

## Observações
- O ChartDB local continua podendo rodar em `http://localhost:5173`
- O backend web roda em `http://127.0.0.1:8010`
- Esta versão foi preparada para reduzir a dependência do Streamlit, mas mantém o núcleo Oracle/LLM existente.
