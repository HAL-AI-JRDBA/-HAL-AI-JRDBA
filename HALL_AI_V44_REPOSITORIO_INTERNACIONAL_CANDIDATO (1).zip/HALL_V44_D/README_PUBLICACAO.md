# HALL-AI V44 — Open Source Candidate

Developed by AJDS Informatica LTDA, Brazil.

HALL-AI is a local-first AI application for enterprise workflows, with Ollama, RAG, database tools and voice capabilities.

**Status:** Source package assembled from supplied V44 installation and verified hash-compatible voice/transcription updates. No Windows run-time testing or security audit has been performed here. Some optional features may require further configuration.

## Windows setup

The V44 distribution targets `D:\AI_HALL\HALL_V44_D`. Copy the contents of `HALL_V44_D` to that location, read `00_LEIA_PRIMEIRO.txt`, and run `01_INSTALAR_HALL_D.bat` from a trusted Windows environment. Other drive roots may require script edits.

The supplied scripts may download Python tooling, Ollama and speech models. Review them before executing.

## Important

Never commit actual `.env` credentials, customer databases, SQL exports, runtime caches or private files. This is source code, not trained Ollama model weights. Oracle Lab material is supplied separately and should be used only in a test environment.

## Voice patches

Voice patch files were layered in the following order, after checking SHA256 manifests: `HALL_V44_CORRECAO_TRANSCRICAO_D`, then `HALL_V44_AJUSTE_VOZ_D`.

## License

Intended project licensing: Apache-2.0. Third-party code, models and assets remain subject to their respective licenses. Before legal distribution, confirm ownership and compatibility of bundled components.

## Links

GitHub organization: https://github.com/HAL-AI-JRDBA

Hugging Face demo: https://huggingface.co/spaces/HAL-AI-JRDBA/README
