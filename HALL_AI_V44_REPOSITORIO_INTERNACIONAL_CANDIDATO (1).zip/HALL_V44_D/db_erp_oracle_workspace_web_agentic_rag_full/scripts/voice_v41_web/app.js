'use strict';
const $=id=>document.getElementById(id);
const token=location.hash.slice(1);history.replaceState(null,'',location.pathname);
let stream=null,ctx=null,node=null,seq=0,backlog=0,chain=Promise.resolve(),capturing=false;
let audio=new Audio(),audioId=null,epoch=-1,paused=false,requestId=0,objectURL=null;
let sendGeneration=0;
let pushing=false,preferencesLoaded=false;
async function api(path,body,extra={}){
  const opts={headers:{Authorization:'Bearer '+token,...extra}};
  if(body!==undefined){opts.method='POST';opts.body=body instanceof ArrayBuffer?body:JSON.stringify(body);}
  const response=await fetch(path,opts);
  if(!response.ok){let data={};try{data=await response.json();}catch(_){}throw Error(data.error||'Falha na conexão local: '+response.status);}
  return response;
}
const control=(action,extra={})=>api('/control',{action,...extra});
function clearAudio(){requestId++;audio.pause();audio.removeAttribute('src');audio.load();audioId=null;if(objectURL){URL.revokeObjectURL(objectURL);objectURL=null;}}
async function stopCapture(){
  capturing=false;sendGeneration++;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;
  if(ctx){await ctx.close();ctx=null;}node=null;
  clearAudio();$('start').disabled=false;$('stop').disabled=true;$('enroll').disabled=true;
  pushing=false;$('push').disabled=true;$('push').textContent='Segure para falar agora';
  try{await control('disconnect');}catch(_){}
}
async function startCapture(){
  $('error').textContent='';$('start').disabled=true;
  try{
    stream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});
    ctx=new AudioContext({sampleRate:16000});await ctx.resume();
    if(ctx.sampleRate!==16000)throw Error('Este navegador não ofereceu áudio de 16 kHz. Use Edge ou Chrome atualizado.');
    const track=stream.getAudioTracks()[0];
    try{await track.applyConstraints({echoCancellation:{exact:'all'}});}catch(_){}
    const settings=track.getSettings();
    await control('settings',{settings:{echoCancellation:settings.echoCancellation===true||typeof settings.echoCancellation==='string',noiseSuppression:settings.noiseSuppression===true,autoGainControl:settings.autoGainControl===true,sampleRate:settings.sampleRate}});
    await control('start');await ctx.audioWorklet.addModule('/capture.js');
    const input=ctx.createMediaStreamSource(stream);node=new AudioWorkletNode(ctx,'hall-capture');input.connect(node);node.connect(ctx.destination);
    seq=0;backlog=0;chain=Promise.resolve();capturing=true;const generation=++sendGeneration;
    node.port.onmessage=e=>{
      if(!capturing||generation!==sendGeneration)return;
      const packet=e.data,current=++seq;backlog++;
      if(backlog>8){$('error').textContent='Áudio atrasado. Reinicie o microfone.';stopCapture();return;}
      chain=chain.then(async()=>{
        if(generation!==sendGeneration)return;
        await api('/capture',packet,{'X-Audio-Sequence':String(current)});
      }).catch(error=>{if(generation===sendGeneration){$('error').textContent=error.message;stopCapture();}}).finally(()=>{if(generation===sendGeneration)backlog--;});
    };
    $('stop').disabled=false;$('enroll').disabled=false;
  }catch(error){await stopCapture();$('error').textContent=error.message;}
}
async function poll(){
  try{
    const state=await(await api('/state')).json();
    $('status').textContent=state.status||'Em espera';$('mode').textContent=state.active?'Conversa ativa':'Aguardando “HAL ativar”';
    $('profile').textContent=state.registered?'Sua voz está cadastrada.':'Cadastre sua voz antes de conversar.';
    $('environment').textContent=state.environment||'Aguardando fala';
    $('push').disabled=!capturing||!state.registered||state.enrolling||state.enrollment_busy;
    if(!preferencesLoaded&&state.preferences){$('pause').value=String(state.preferences.pause_ms);$('rate').value=String(state.preferences.tts_rate);preferencesLoaded=true;showPreferences();}
    $('heard').textContent=state.transcript||'—';$('answer').textContent=state.answer||'—';
    if(state.error||state.tts_error)$('error').textContent=state.error||state.tts_error;
    const settings=state.settings||{};
    $('processing').textContent='Eco: '+(settings.echoCancellation?'ativado pelo navegador':'não confirmado — use fones')+' · Ruído: '+(settings.noiseSuppression?'redução ativada':'não confirmada');
    if(state.epoch!==epoch){epoch=state.epoch;clearAudio();}
    paused=Boolean(state.paused);
    if(!state.audio&&audioId)clearAudio();
    if(state.audio&&state.audio!==audioId){
      clearAudio();audioId=state.audio;const id=audioId,version=++requestId;
      const blob=await(await api('/wav/'+encodeURIComponent(id))).blob();
      if(version!==requestId)return;
      objectURL=URL.createObjectURL(blob);audio.src=objectURL;
      audio.onplaying=()=>{control('playing',{id}).catch(()=>{});};
      audio.onended=()=>{control('finished',{id}).catch(()=>{});};
      if(!paused&&capturing)await audio.play();
    }else if(audioId){
      if(paused||!capturing)audio.pause();
      else if(audio.paused&&!audio.ended)await audio.play();
    }
  }catch(error){$('error').textContent=error.message;clearAudio();}
  finally{setTimeout(poll,150);}
}
$('start').onclick=startCapture;$('stop').onclick=stopCapture;
$('standby').onclick=()=>{clearAudio();control('standby').catch(e=>$('error').textContent=e.message);};
$('enroll').onclick=()=>{clearAudio();$('error').textContent='';control('enroll').catch(e=>$('error').textContent=e.message);};
$('delete').onclick=()=>{clearAudio();control('delete').catch(e=>$('error').textContent=e.message);};
function showPreferences(){$('pauseValue').textContent=(Number($('pause').value)/1000).toFixed(1)+' s';$('rateValue').textContent=$('rate').value==='0'?'Normal':Number($('rate').value)<0?'Mais devagar ('+$('rate').value+')':'Mais rápido ('+$('rate').value+')';}
$('pause').oninput=showPreferences;$('rate').oninput=showPreferences;
$('savePreferences').onclick=async()=>{try{await control('preferences',{preferences:{pause_ms:Number($('pause').value),tts_rate:Number($('rate').value)}});$('saved').textContent='Ajustes enviados.';}catch(e){$('error').textContent=e.message;}};
async function pushStart(){if(pushing||$('push').disabled)return;pushing=true;$('push').textContent='Ouvindo… solte ao terminar';clearAudio();try{await control('push_start');}catch(e){pushing=false;$('error').textContent=e.message;}}
async function pushEnd(){if(!pushing)return;pushing=false;$('push').textContent='Segure para falar agora';try{await control('push_end');}catch(e){$('error').textContent=e.message;}}
$('push').onpointerdown=e=>{e.preventDefault();$('push').setPointerCapture(e.pointerId);pushStart();};
$('push').onpointerup=pushEnd;$('push').onpointercancel=pushEnd;
$('push').onkeydown=e=>{if([' ','Enter'].includes(e.key)){e.preventDefault();if(!e.repeat)pushStart();}};
$('push').onkeyup=e=>{if([' ','Enter'].includes(e.key)){e.preventDefault();pushEnd();}};
window.addEventListener('blur',pushEnd);
window.addEventListener('pagehide',()=>{if(stream)stream.getTracks().forEach(t=>t.stop());clearAudio();});
if(token)poll();else{$('start').disabled=true;$('error').textContent='Abra esta janela pelo INICIAR_JR_AI_HALL_V41.bat.';}
