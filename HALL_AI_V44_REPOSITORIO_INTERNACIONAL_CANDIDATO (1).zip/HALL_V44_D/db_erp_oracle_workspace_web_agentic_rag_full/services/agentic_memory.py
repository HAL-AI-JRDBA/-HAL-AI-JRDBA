from __future__ import annotations

import json
from pathlib import Path
from typing import Any
import uuid
import time


class AgenticRAGMemory:
    """Append-only local trace store for agentic RAG runs."""

    def __init__(self, path: str | Path = 'data/agentic_rag/traces.jsonl') -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def save_trace(self, payload: dict[str, Any]) -> str:
        trace_id = payload.get('trace_id') or str(uuid.uuid4())
        row = {'trace_id': trace_id, 'ts': time.time(), **payload}
        with self.path.open('a', encoding='utf-8') as fh:
            fh.write(json.dumps(row, ensure_ascii=False, default=str) + '\n')
        return trace_id

    def recent(self, limit: int = 20) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        rows: list[dict[str, Any]] = []
        for line in self.path.read_text(encoding='utf-8', errors='ignore').splitlines()[-limit:]:
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
        return rows
