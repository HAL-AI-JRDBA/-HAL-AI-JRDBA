"""HAL V36: persistent, evidence-backed local agent. No arbitrary host shell."""
from __future__ import annotations
from contextlib import contextmanager
import hashlib
import hmac
import json
import os
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from typing import Any


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


class AgentEngine:
    def __init__(self, root: Path, tools, planner=None):
        self.root = Path(root)
        self.data = self.root / 'data' / 'autonomy_v36'
        self.data.mkdir(parents=True, exist_ok=True)
        self.db_path = self.data / 'runtime.sqlite3'
        self.tools = tools
        self.planner = planner or tools.plan
        self.stop_event = threading.Event()
        self.thread = None
        self.last_error = ''
        self.worker_id = uuid.uuid4().hex
        self._init_db()

    @contextmanager
    def db(self):
        c = sqlite3.connect(self.db_path, timeout=20, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute('PRAGMA busy_timeout=20000')
        try:
            yield c
        except BaseException:
            c.rollback()
            raise
        finally:
            c.close()

    def _init_db(self):
        with self.db() as c:
            c.execute('PRAGMA journal_mode=WAL')
            c.executescript('''
            CREATE TABLE IF NOT EXISTS tasks (
              id TEXT PRIMARY KEY, owner TEXT NOT NULL, objective TEXT NOT NULL,
              state TEXT NOT NULL, created REAL NOT NULL, updated REAL NOT NULL,
              payload TEXT NOT NULL, summary TEXT NOT NULL DEFAULT '',
              event_key TEXT UNIQUE, lease TEXT, lease_until REAL,
              step_count INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS steps (
              id TEXT PRIMARY KEY, task_id TEXT NOT NULL, tool TEXT NOT NULL,
              args TEXT NOT NULL, args_hash TEXT NOT NULL, state TEXT NOT NULL,
              result TEXT, created REAL NOT NULL, approval_by TEXT,
              approval_until REAL, attempts INTEGER NOT NULL DEFAULT 0);
            CREATE TABLE IF NOT EXISTS schedules (
              id TEXT PRIMARY KEY, owner TEXT NOT NULL, objective TEXT NOT NULL,
              payload TEXT NOT NULL, interval_s INTEGER NOT NULL,
              next_run REAL NOT NULL, enabled INTEGER NOT NULL DEFAULT 1);
            CREATE TABLE IF NOT EXISTS audit (
              seq INTEGER PRIMARY KEY AUTOINCREMENT, created REAL NOT NULL,
              event TEXT NOT NULL, task_id TEXT, detail TEXT NOT NULL,
              previous_hash TEXT NOT NULL, hash TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS control (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            INSERT OR IGNORE INTO control VALUES ('paused', '0');
            ''')

    def audit(self, c, event, task_id='', detail=None):
        last = c.execute('SELECT hash FROM audit ORDER BY seq DESC LIMIT 1').fetchone()
        previous = last['hash'] if last else 'GENESIS'
        stamp = time.time()
        body = {'created': stamp, 'event': event, 'task_id': task_id,
                'detail': detail or {}, 'previous_hash': previous}
        c.execute('INSERT INTO audit(created,event,task_id,detail,previous_hash,hash) VALUES(?,?,?,?,?,?)',
                  (stamp, event, task_id, canonical(body['detail']), previous, digest(body)))

    def create(self, owner, objective, payload=None, event_key=None):
        objective = str(objective).strip()
        if not owner or not objective or len(objective) > 12000:
            raise ValueError('Usuário e objetivo (até 12000 caracteres) obrigatórios.')
        payload = dict(payload or {})
        from .ssot_context_v43 import pin_scope
        payload['_ssot_v43_scope']=pin_scope(self.root,owner)
        if len(canonical(payload)) > 300000:
            raise ValueError('Payload muito grande.')
        allowed = payload.get('allowed_tools', list(self.tools.catalog()))
        if not isinstance(allowed, list) or not allowed or not set(allowed) <= set(self.tools.catalog()):
            raise ValueError('Ferramentas não reconhecidas.')
        payload['allowed_tools'] = allowed
        payload['max_steps'] = max(1, min(int(payload.get('max_steps', 12)), 30))
        if 'plan' in payload:
            plan=payload['plan']
            if not isinstance(plan,list) or not 1<=len(plan)<=payload['max_steps']:
                raise ValueError('Plano deve ter de uma até max_steps etapas.')
            for action in plan:
                if not isinstance(action,dict) or action.get('tool') not in allowed or not isinstance(action.get('args',{}),dict):
                    raise ValueError('Plano explícito contém ferramenta/argumentos inválidos.')
        tid, now = 'task_' + uuid.uuid4().hex, time.time()
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            if event_key:
                existing = c.execute('SELECT id FROM tasks WHERE event_key=?', (event_key,)).fetchone()
                if existing:
                    c.commit()
                    return self.get(existing['id'])
            c.execute('INSERT INTO tasks(id,owner,objective,state,created,updated,payload,event_key) VALUES(?,?,?,?,?,?,?,?)',
                      (tid, owner, objective, 'queued', now, now, canonical(payload), event_key))
            self.audit(c, 'task_created', tid, {'owner': owner, 'source': payload.get('source', 'console')})
            c.commit()
        return self.get(tid)

    def get(self, tid):
        with self.db() as c:
            row = c.execute('SELECT * FROM tasks WHERE id=?', (tid,)).fetchone()
            if not row:
                raise KeyError('Tarefa não encontrada.')
            result = dict(row)
            result['payload'] = json.loads(result['payload'])
            result['steps'] = []
            for step in c.execute('SELECT * FROM steps WHERE task_id=? ORDER BY created,id', (tid,)):
                item = dict(step)
                item['args'] = json.loads(item['args'])
                item['result'] = json.loads(item['result']) if item['result'] else None
                result['steps'].append(item)
            result['goal_validation'] = 'human_review_required'
            return result

    def list(self, owner=None, limit=100):
        with self.db() as c:
            if owner:
                rows = c.execute('SELECT id FROM tasks WHERE owner=? ORDER BY created DESC LIMIT ?', (owner, min(limit, 200))).fetchall()
            else:
                rows = c.execute('SELECT id FROM tasks ORDER BY created DESC LIMIT ?', (min(limit, 200),)).fetchall()
        return [self.get(r['id']) for r in rows]

    def status(self):
        with self.db() as c:
            counts = {r['state']: r['n'] for r in c.execute('SELECT state,count(*) n FROM tasks GROUP BY state')}
            paused = c.execute("SELECT value FROM control WHERE key='paused'").fetchone()['value'] == '1'
        return {'ok': True, 'version': '36.1', 'worker_running': bool(self.thread and self.thread.is_alive()),
                'paused': paused, 'counts': counts, 'last_error': self.last_error,
                'inference': 'local_ollama', 'capabilities': self.tools.readiness(),
                'goal_validation': 'human_review_required'}

    def set_paused(self, paused, actor):
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            c.execute("UPDATE control SET value=? WHERE key='paused'", ('1' if paused else '0',))
            self.audit(c, 'worker_paused' if paused else 'worker_resumed', detail={'actor': actor})
            c.commit()

    def cancel(self, tid, actor):
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            c.execute("UPDATE tasks SET state='cancelled',updated=? WHERE id=? AND state NOT IN ('completed','cancelled')", (time.time(), tid))
            c.execute("UPDATE steps SET state='cancelled' WHERE task_id=? AND state IN ('ready','awaiting_approval')", (tid,))
            self.audit(c, 'task_cancelled', tid, {'actor': actor, 'running_tool': 'may_finish_before_timeout'})
            c.commit()
        return self.get(tid)

    def approve(self, tid, sid, actor, expected_hash):
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            task = c.execute('SELECT state FROM tasks WHERE id=?', (tid,)).fetchone()
            step = c.execute('SELECT * FROM steps WHERE id=? AND task_id=?', (sid, tid)).fetchone()
            if not task or task['state'] != 'awaiting_approval' or not step or step['state'] != 'awaiting_approval':
                raise ValueError('Etapa não está aguardando aprovação.')
            if not hmac.compare_digest(str(expected_hash), step['args_hash']):
                raise ValueError('Plano mudou: atualize e revise a etapa.')
            c.execute("UPDATE steps SET state='ready',approval_by=?,approval_until=? WHERE id=?", (actor, time.time()+900, sid))
            c.execute("UPDATE tasks SET state='queued',updated=? WHERE id=?", (time.time(), tid))
            self.audit(c, 'step_approved', tid, {'actor': actor, 'step_id': sid, 'args_hash': expected_hash})
            c.commit()
        return self.get(tid)

    def retry(self, tid, actor):
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            task = c.execute('SELECT state FROM tasks WHERE id=?', (tid,)).fetchone()
            if not task or task['state'] not in ('failed', 'interrupted'):
                raise ValueError('Somente tarefas falhadas/interrompidas podem ser retomadas.')
            rows = c.execute("SELECT * FROM steps WHERE task_id=? AND state IN ('failed','interrupted')", (tid,)).fetchall()
            waiting = False
            for row in rows:
                if row['attempts'] >= 3:
                    raise ValueError('Limite de três tentativas alcançado; crie uma nova missão após diagnóstico.')
                risk = self.tools.requires_approval(row['tool'], json.loads(row['args']))
                waiting = waiting or risk
                c.execute('UPDATE steps SET state=?,approval_by=NULL,approval_until=NULL WHERE id=?',
                          ('awaiting_approval' if risk else 'ready', row['id']))
            c.execute('UPDATE tasks SET state=?,lease=NULL,lease_until=NULL,updated=? WHERE id=?',
                      ('awaiting_approval' if waiting else 'queued', time.time(), tid))
            self.audit(c, 'task_retry', tid, {'actor': actor, 'external_effects': 'review_before_repeat'})
            c.commit()
        return self.get(tid)

    def schedule(self, owner, objective, interval_s=3600, payload=None, first_run=None):
        interval_s = int(interval_s)
        if not 60 <= interval_s <= 31536000:
            raise ValueError('Intervalo entre 60 segundos e um ano.')
        # Validate without creating a task.
        if not str(objective).strip() or not owner:
            raise ValueError('Objetivo e usuário obrigatórios.')
        payload = dict(payload or {})
        from .ssot_context_v43 import pin_scope
        payload['_ssot_v43_scope']=pin_scope(self.root,owner)
        payload['max_steps']=max(1,min(int(payload.get('max_steps',12)),30))
        if len(canonical(payload))>300000 or len(str(objective))>12000:
            raise ValueError('Objetivo/contexto excede limite.')
        if 'plan' in payload and (not isinstance(payload['plan'],list) or not 1<=len(payload['plan'])<=payload['max_steps']):
            raise ValueError('Plano explícito inválido.')
        if not payload.get('allowed_tools',list(self.tools.catalog())) or not set(payload.get('allowed_tools',self.tools.catalog())) <= set(self.tools.catalog()):
            raise ValueError('Ferramenta desconhecida.')
        sid = 'schedule_' + uuid.uuid4().hex
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            c.execute('INSERT INTO schedules(id,owner,objective,payload,interval_s,next_run) VALUES(?,?,?,?,?,?)',
                      (sid, owner, objective, canonical(payload), interval_s, first_run if first_run is not None else time.time()))
            self.audit(c, 'schedule_created', detail={'actor': owner, 'schedule_id': sid})
            c.commit()
        return {'id': sid}

    def schedules(self):
        with self.db() as c:
            return [dict(r) for r in c.execute('SELECT * FROM schedules ORDER BY next_run')]

    def disable_schedule(self, sid, actor):
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            c.execute('UPDATE schedules SET enabled=0 WHERE id=?', (sid,))
            self.audit(c, 'schedule_disabled', detail={'actor': actor, 'schedule_id': sid})
            c.commit()

    def enqueue_due(self):
        now = time.time()
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            rows = c.execute('SELECT * FROM schedules WHERE enabled=1 AND next_run<=?', (now,)).fetchall()
            for row in rows:
                slot = row['next_run']
                event_key = row['id'] + ':' + str(slot)
                payload = json.loads(row['payload'])
                payload['source'] = 'schedule'
                payload.setdefault('allowed_tools', list(self.tools.catalog()))
                payload.setdefault('max_steps', 12)
                c.execute('INSERT OR IGNORE INTO tasks(id,owner,objective,state,created,updated,payload,event_key) VALUES(?,?,?,?,?,?,?,?)',
                          ('task_'+uuid.uuid4().hex, row['owner'], row['objective'], 'queued', now, now, canonical(payload), event_key))
                # Coalesce missed intervals: no flood after shutdown.
                c.execute('UPDATE schedules SET next_run=? WHERE id=?', (now+row['interval_s'], row['id']))
                self.audit(c, 'schedule_enqueued', detail={'schedule_id': row['id'], 'slot': slot})
            c.commit()

    def _claim(self):
        now = time.time()
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute("SELECT value FROM control WHERE key='paused'").fetchone()['value'] == '1':
                c.commit()
                return None
            # Unknown outcome after a crash is never silently retried.
            stale = c.execute("SELECT id FROM tasks WHERE state='running' AND lease_until<?", (now,)).fetchall()
            for row in stale:
                c.execute("UPDATE tasks SET state='interrupted',lease=NULL,lease_until=NULL WHERE id=?", (row['id'],))
                c.execute("UPDATE steps SET state='interrupted' WHERE task_id=? AND state='running'", (row['id'],))
                self.audit(c, 'lease_expired', row['id'])
            # Single active inference/tool globally, including multiple backend processes.
            if c.execute("SELECT 1 FROM tasks WHERE lease IS NOT NULL AND lease_until>=?", (now,)).fetchone():
                c.commit()
                return None
            row = c.execute("SELECT id FROM tasks WHERE state='queued' ORDER BY created LIMIT 1").fetchone()
            if row:
                c.execute("UPDATE tasks SET state='running',lease=?,lease_until=?,updated=? WHERE id=?", (self.worker_id, now+30, now, row['id']))
            c.commit()
        return row['id'] if row else None

    def _heartbeat(self, tid, done):
        while not done.wait(5):
            with self.db() as c:
                c.execute("UPDATE tasks SET lease_until=? WHERE id=? AND lease=? AND state IN ('running','cancelled')", (time.time()+30, tid, self.worker_id))

    def _state(self, tid, state, summary=''):
        with self.db() as c:
            c.execute('BEGIN IMMEDIATE')
            c.execute("UPDATE tasks SET state=?,summary=?,updated=?,lease=NULL,lease_until=NULL WHERE id=? AND state='running' AND lease=?",
                      (state, summary[:16000], time.time(), tid, self.worker_id))
            self.audit(c, 'task_'+state, tid, {'summary': summary[:2000]})
            c.commit()

    def _execution_current(self, c, task, step):
        """Recheck a planned action inside the execution transaction."""
        return True

    def tick(self):
        self.enqueue_due()
        tid = self._claim()
        if not tid:
            return False
        done = threading.Event()
        heartbeat = threading.Thread(target=self._heartbeat, args=(tid, done), daemon=True)
        heartbeat.start()
        try:
            task = self.get(tid)
            from .ssot_context_v43 import assert_task_context
            assert_task_context(self.root,task)
            step = next((s for s in task['steps'] if s['state'] == 'ready'), None)
            if not step:
                explicit=task['payload'].get('plan')
                if explicit and task['step_count']>=len(explicit):
                    action={'finish':True,'summary':'Plano explícito executado; revise os resultados e o objetivo.'}
                elif task['step_count'] >= task['payload'].get('max_steps', 12):
                    self._state(tid, 'needs_review', 'Limite de etapas alcançado; revise os resultados.')
                    return True
                elif explicit:
                    action=explicit[task['step_count']]
                else:
                    from .ssot_context_v43 import actor_scope
                    with actor_scope(self.root,task['owner'],task['payload'].get('_ssot_v43_scope',{}),task['objective']):
                        action = self.planner(task)
                if action.get('finish') is True:
                    verified = [s for s in task['steps'] if s['state'] == 'verified' and (s['result'] or {}).get('evidence')]
                    if not verified:
                        raise ValueError('Conclusão recusada: nenhuma ferramenta produziu evidência.')
                    self._state(tid, 'completed', str(action.get('summary') or 'Etapas executadas e verificadas.'))
                    return True
                tool, args = str(action.get('tool', '')), action.get('args', {})
                if tool not in task['payload']['allowed_tools'] or not isinstance(args, dict):
                    raise ValueError('Plano pediu ferramenta não autorizada ou argumentos inválidos.')
                self.tools.validate(tool, args, task)
                ah = digest({'tool': tool, 'args': args})
                if not explicit and any(s['state']=='verified' and s['args_hash']==ah for s in task['steps']):
                    self._state(tid, 'needs_review', 'O planejador repetiu uma ação já verificada; repetição bloqueada.')
                    return True
                sid = 'step_'+uuid.uuid4().hex
                risk = self.tools.requires_approval(tool, args)
                with self.db() as c:
                    c.execute('BEGIN IMMEDIATE')
                    current = c.execute('SELECT state FROM tasks WHERE id=?', (tid,)).fetchone()
                    if current['state'] != 'running':
                        c.commit()
                        return True
                    c.execute('INSERT INTO steps(id,task_id,tool,args,args_hash,state,created) VALUES(?,?,?,?,?,?,?)',
                              (sid, tid, tool, canonical(args), ah, 'awaiting_approval' if risk else 'ready', time.time()))
                    c.execute('UPDATE tasks SET step_count=step_count+1 WHERE id=?', (tid,))
                    self.audit(c, 'step_planned', tid, {'step_id': sid, 'tool': tool, 'args_hash': ah})
                    c.commit()
                if risk:
                    self._state(tid, 'awaiting_approval', 'Revise a ferramenta e os argumentos antes de executar.')
                    return True
                step = next(s for s in self.get(tid)['steps'] if s['id'] == sid)
            risk = self.tools.requires_approval(step['tool'], step['args'])
            if risk and (not step['approval_by'] or (step['approval_until'] or 0) < time.time()):
                with self.db() as c:
                    c.execute("UPDATE steps SET state='awaiting_approval',approval_by=NULL WHERE id=?", (step['id'],))
                self._state(tid, 'awaiting_approval', 'Aprovação expirada; revise novamente.')
                return True
            with self.db() as c:
                c.execute('BEGIN IMMEDIATE')
                current = c.execute('SELECT state FROM tasks WHERE id=?', (tid,)).fetchone()
                paused = c.execute("SELECT value FROM control WHERE key='paused'").fetchone()['value']=='1'
                if current['state'] != 'running' or paused:
                    c.commit()
                    if paused:
                        self._state(tid, 'queued', 'Pausado antes da execução da ferramenta.')
                    return True
                if not self._execution_current(c, task, step):
                    c.commit()
                    return True
                c.execute("UPDATE steps SET state='running',attempts=attempts+1 WHERE id=?", (step['id'],))
                self.audit(c, 'step_started', tid, {'step_id': step['id'], 'tool': step['tool']})
                c.commit()
            try:
                result = self.tools.execute(step['tool'], step['args'], task)
                if not isinstance(result, dict) or result.get('ok') is not True or result.get('simulated') or not result.get('evidence'):
                    raise ValueError('Ferramenta não apresentou resultado verificável: ' + canonical(result)[:1800])
                if not self.tools.verify(step['tool'], result, task):
                    raise ValueError('Verificação independente da ferramenta falhou.')
                state = 'verified'
            except Exception as exc:
                result = {'ok': False, 'error': str(exc)[:2000], 'evidence': []}
                state = 'failed'
            with self.db() as c:
                c.execute('BEGIN IMMEDIATE')
                c.execute('UPDATE steps SET state=?,result=?,approval_until=NULL WHERE id=?', (state, canonical(result), step['id']))
                self.audit(c, 'step_'+state, tid, {'step_id': step['id'], 'tool': step['tool'], 'result_hash': digest(result)})
                c.commit()
            self._state(tid, 'queued' if state == 'verified' else 'failed', '' if state == 'verified' else result['error'])
            return True
        except Exception as exc:
            self.last_error = str(exc)[:2000]
            self._state(tid, 'failed', self.last_error)
            return True
        finally:
            done.set()
            heartbeat.join(timeout=1)
            with self.db() as c:
                c.execute("UPDATE tasks SET lease=NULL,lease_until=NULL WHERE id=? AND lease=?", (tid, self.worker_id))

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._loop, daemon=True, name='hall-v36-worker')
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=2)

    def _loop(self):
        while not self.stop_event.is_set():
            try:
                did_work = self.tick()
                if hasattr(self, "channels"):
                    with self.db() as c:
                        paused = c.execute("SELECT value FROM control WHERE key='paused'").fetchone()["value"] == "1"
                    if not paused:
                        self.channels.poll()
                        self.channels.deliver()
            except Exception as exc:
                self.last_error = str(exc)[:2000]
                did_work = False
            self.stop_event.wait(1 if did_work else 5)

    def verify_audit(self):
        previous = 'GENESIS'
        with self.db() as c:
            rows = c.execute('SELECT * FROM audit ORDER BY seq').fetchall()
        for row in rows:
            body = {'created': row['created'], 'event': row['event'], 'task_id': row['task_id'],
                    'detail': json.loads(row['detail']), 'previous_hash': row['previous_hash']}
            if row['previous_hash'] != previous or digest(body) != row['hash']:
                return {'ok': False, 'invalid_seq': row['seq']}
            previous = row['hash']
        return {'ok': True, 'events': len(rows), 'last_hash': previous,
                'limitation': 'Detecta alteração da cadeia; não substitui armazenamento externo imutável.'}
