from __future__ import annotations

BRAND_NAME = 'JR-AI'
BRAND_TAGLINE = 'Plataforma Gen-AI Open Source para ERP, Oracle, Agentes e Automação'
BRAND_FULL_NAME = 'JR-AI — Plataforma Gen-AI Open Source para ERP, Oracle, Agentes e Automação'

def as_dict() -> dict[str, str]:
    return {
        "brand_name": BRAND_NAME,
        "brand_tagline": BRAND_TAGLINE,
        "brand_full_name": BRAND_FULL_NAME,
    }
