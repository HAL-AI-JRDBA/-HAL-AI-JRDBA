from __future__ import annotations

from dataclasses import asdict, dataclass, field
import json
import re
from pathlib import Path
from typing import Any

from services.advanced_rag import AdvancedRAG, choose_retrieval_mode, guard_hits, rerank_hits
from services.document_graph import SimpleDocumentGraph
from services.evidence_grader import EvidenceGrade, grade_evidence, rewrite_query, support_score_for_answer, tokenize
from services.agentic_memory import AgenticRAGMemory
from services.vector_store import LocalVectorStore


@dataclass
class AgenticRAGConfig:
    max_subquestions: int = 5
    max_iterations: int = 2
    top_k_per_step: int = 8
    enable_reflection: bool = True
    enable_graph_context: bool = True
    enable_memory_trace: bool = True
    use_llm_planner: bool = False
    min_coverage: float = 0.34


@dataclass
class AgenticPlanStep:
    step_id: int
    question: str
    objective: str = 'buscar evidência'
    preferred_mode: str = 'auto'
    status: str = 'pending'

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class AgenticStepResult:
    step_id: int
    original_query: str
    attempts: list[dict[str, Any]] = field(default_factory=list)
    final_query: str = ''
    mode: str = 'auto'
    grade: dict[str, Any] = field(default_factory=dict)
    hits: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


COMPLEX_TRIGGERS = [
    'compare', 'comparar', 'relacione', 'relacionar', 'agrup', 'calcule', 'calcular', 'risco', 'baixo giro',
    'estoque parado', 'aumento', 'diferença', 'diferenca', 'por almoxarifado', 'por família', 'por familia',
    'quais tabelas', 'quais colunas', 'gerar sql', 'view', 'indicador', 'kpi', 'fraude', 'anomalia',
]


class AgenticRAGOrchestrator:
    """Agentic RAG loop: plan -> retrieve -> grade -> rewrite -> synthesize -> reflect.

    This class wraps the existing AdvancedRAG and LocalVectorStore without removing
    any previous functionality. The planner/retriever is deterministic by default,
    so it also works offline with local Ollama unavailable.
    """

    def __init__(
        self,
        vector_store: LocalVectorStore,
        llm_router: Any | None = None,
        config: AgenticRAGConfig | None = None,
        memory: AgenticRAGMemory | None = None,
    ) -> None:
        self.vector_store = vector_store
        self.llm_router = llm_router
        self.config = config or AgenticRAGConfig()
        self.advanced = AdvancedRAG(vector_store, llm_router)
        self.memory = memory or AgenticRAGMemory(Path('data/agentic_rag/traces.jsonl'))

    def _is_complex(self, question: str) -> bool:
        q = (question or '').lower()
        return len(tokenize(q)) >= 9 or any(t in q for t in COMPLEX_TRIGGERS)

    def _heuristic_plan(self, question: str) -> list[AgenticPlanStep]:
        q = (question or '').strip()
        if not q:
            return []
        if not self._is_complex(q):
            return [AgenticPlanStep(1, q, 'Responder diretamente com evidências locais', 'auto')]

        parts: list[str] = []
        # Split only on strong separators first to avoid destroying ERP terms.
        for piece in re.split(r'[;\n]+', q):
            piece = piece.strip(' .')
            if len(piece) >= 18:
                parts.append(piece)
        if len(parts) <= 1:
            # For composite prompts, create explicit analytical subgoals.
            lowered = q.lower()
            if any(t in lowered for t in ['tabela', 'coluna', 'schema', 'sql', 'view']):
                parts.extend([
                    f'Quais tabelas, colunas e relacionamentos são relevantes para: {q}',
                    f'Quais regras de negócio e filtros precisam ser respeitados para: {q}',
                ])
            if any(t in lowered for t in ['baixo giro', 'estoque parado', 'ruptura', 'custo médio', 'custo medio']):
                parts.extend([
                    'Como identificar materiais com baixo giro ou estoque parado nos documentos indexados?',
                    'Como identificar risco de ruptura, saldo mínimo, consumo médio e aumento de custo médio?',
                    'Como agrupar o resultado por almoxarifado, família de material e valor financeiro?',
                ])
            if any(t in lowered for t in ['compare', 'comparar', 'diferença', 'diferenca']):
                parts.append(f'Quais evidências permitem comparar os itens pedidos em: {q}')
            if not parts:
                # Split on connective words only for long questions.
                parts = [p.strip(' .') for p in re.split(r'\b(?:e também|também| alem disso | além disso | e | ou )\b', q, flags=re.IGNORECASE) if len(p.strip()) > 16]
        # Always include original as final synthesis target if it is not duplicated.
        if q not in parts:
            parts.append(q)
        deduped: list[str] = []
        for part in parts:
            if part and part not in deduped:
                deduped.append(part)
        steps = []
        for idx, part in enumerate(deduped[: self.config.max_subquestions], start=1):
            steps.append(AgenticPlanStep(idx, part, 'Recuperar evidência para subpergunta', 'auto'))
        return steps

    def _llm_plan(self, question: str) -> list[AgenticPlanStep]:
        if not self.llm_router or not self.config.use_llm_planner:
            return self._heuristic_plan(question)
        system = (
            'Você é um planejador de RAG agentico. Decomponha a pergunta em no máximo 5 subperguntas objetivas. '
            'Responda somente JSON válido no formato {"steps":[{"question":"...","objective":"...","preferred_mode":"auto|hybrid|vectorless|traditional"}]}.'
        )
        user = f'Pergunta original:\n{question}'
        try:
            raw = self.llm_router.ask_chat(system, user)
            match = re.search(r'\{.*\}', raw, flags=re.DOTALL)
            data = json.loads(match.group(0) if match else raw)
            rows = data.get('steps') or []
            steps = []
            for idx, row in enumerate(rows[: self.config.max_subquestions], start=1):
                sq = str(row.get('question') or '').strip()
                if sq:
                    steps.append(AgenticPlanStep(idx, sq, str(row.get('objective') or 'buscar evidência'), str(row.get('preferred_mode') or 'auto')))
            return steps or self._heuristic_plan(question)
        except Exception:
            return self._heuristic_plan(question)

    def plan(self, question: str) -> list[dict[str, Any]]:
        return [s.to_dict() for s in self._llm_plan(question)]

    def _embed_query(self, query: str) -> list[float] | None:
        if self.llm_router is None:
            return None
        try:
            return self.llm_router.embed([query])[0]
        except Exception:
            return None

    def _retrieve_once(self, query: str, mode: str, top_k: int) -> tuple[str, list[dict[str, Any]], dict[str, Any]]:
        decision = choose_retrieval_mode(query, self.vector_store, requested_mode=mode or 'auto')
        q_emb = self._embed_query(query) if decision.mode in {'traditional', 'hybrid'} else None
        if decision.mode == 'traditional':
            hits = self.advanced.traditional_retrieve(query, q_emb, top_k=top_k)
        elif decision.mode == 'vectorless':
            hits = self.advanced.vectorless_retrieve(query, top_k=top_k)
        else:
            hits = self.advanced.hybrid_retrieve(query, q_emb, top_k=top_k)
        return decision.mode, hits, decision.to_dict()

    def retrieve_step(self, step: AgenticPlanStep) -> AgenticStepResult:
        query = step.question
        result = AgenticStepResult(step_id=step.step_id, original_query=step.question, final_query=query)
        hints: list[str] = []
        last_grade: EvidenceGrade | None = None
        for attempt in range(1, max(1, self.config.max_iterations) + 1):
            mode, hits, decision_dict = self._retrieve_once(query, step.preferred_mode, self.config.top_k_per_step)
            grade = grade_evidence(step.question, hits, min_coverage=self.config.min_coverage)
            result.attempts.append({
                'attempt': attempt,
                'query': query,
                'mode': mode,
                'router': decision_dict,
                'grade': grade.to_dict(),
                'hit_count': len(hits),
                'top_sources': sorted({str(h.get('source') or '') for h in hits[:5] if h.get('source')}),
            })
            result.mode = mode
            result.hits = hits
            result.grade = grade.to_dict()
            result.final_query = query
            last_grade = grade
            if not grade.should_retry or attempt >= self.config.max_iterations:
                break
            hints = [str(h.get('title') or h.get('source') or '') for h in hits[:5]]
            query = rewrite_query(step.question, grade, attempt=attempt, hints=hints)
        return result

    def _build_evidence_text(self, steps: list[AgenticStepResult], max_chars_per_hit: int = 1400) -> str:
        blocks: list[str] = []
        seen: set[str] = set()
        for step in steps:
            for hit in step.hits[:5]:
                key = str(hit.get('chunk_id') or hit.get('node_id') or f"{hit.get('source')}:{len(seen)}")
                if key in seen:
                    continue
                seen.add(key)
                title = hit.get('title') or hit.get('source') or 'bloco'
                blocks.append(
                    f"[Step {step.step_id} | Fonte: {hit.get('source','desconhecida')} | Bloco: {title} | modo: {hit.get('mode','?')} | score: {hit.get('rerank_score', hit.get('score', 0.0))}]\n"
                    f"{str(hit.get('text') or '')[:max_chars_per_hit]}"
                )
        return '\n\n'.join(blocks)

    def _synthesize_without_llm(self, question: str, steps: list[AgenticStepResult], graph_context: dict[str, Any]) -> str:
        lines = [
            'Resposta baseada nas evidências recuperadas localmente.',
            '',
            f'Pergunta: {question}',
            '',
            'Principais evidências:',
        ]
        seen = set()
        count = 0
        for step in steps:
            for hit in step.hits[:3]:
                key = str(hit.get('chunk_id') or hit.get('node_id') or hit.get('text')[:60])
                if key in seen:
                    continue
                seen.add(key)
                count += 1
                source = hit.get('source') or 'desconhecida'
                snippet = re.sub(r'\s+', ' ', str(hit.get('text') or '')).strip()[:360]
                lines.append(f'{count}. {snippet} [fonte: {source}]')
                if count >= 8:
                    break
            if count >= 8:
                break
        if graph_context.get('entities'):
            entities = ', '.join(e['id'] for e in graph_context.get('entities', [])[:8])
            lines.extend(['', f'Entidades relacionadas pelo Graph RAG local: {entities}.'])
        weak = [s for s in steps if (s.grade or {}).get('confidence') == 'low']
        if weak:
            lines.extend(['', 'Observação: algumas subperguntas tiveram evidência fraca; valide os documentos ou indexe mais fontes antes de tomar decisão operacional.'])
        return '\n'.join(lines)

    def synthesize(self, question: str, plan: list[dict[str, Any]], steps: list[AgenticStepResult], graph_context: dict[str, Any]) -> str:
        evidence_text = self._build_evidence_text(steps)
        if not self.llm_router:
            return self._synthesize_without_llm(question, steps, graph_context)
        system = (
            'Você é um assistente técnico de Oracle ERP e RAG agentico. Responda somente com base nas evidências. '
            'Não invente tabelas, colunas, regras, datas ou conclusões. Quando faltar evidência, diga explicitamente. '
            'Cite a fonte/bloco entre colchetes nos parágrafos importantes.'
        )
        user = (
            f'Pergunta original:\n{question}\n\n'
            f'Plano executado:\n{json.dumps(plan, ensure_ascii=False, indent=2)}\n\n'
            f'Notas do Graph RAG local:\n{json.dumps(graph_context, ensure_ascii=False, indent=2)}\n\n'
            f'Evidências recuperadas:\n{evidence_text}\n\n'
            'Produza uma resposta em português, técnica, objetiva e aterrada. '
            'Inclua uma seção "O que foi encontrado" e outra "Lacunas / próximos passos" quando necessário.'
        )
        try:
            return self.llm_router.ask_chat(system, user)
        except Exception:
            return self._synthesize_without_llm(question, steps, graph_context)

    def reflect(self, question: str, answer: str, steps: list[AgenticStepResult]) -> dict[str, Any]:
        evidence_text = self._build_evidence_text(steps, max_chars_per_hit=900)
        support = support_score_for_answer(answer, evidence_text)
        if not self.config.enable_reflection:
            return {'enabled': False, 'support': support, 'final_decision': 'not_checked'}
        weak_steps = [s.step_id for s in steps if (s.grade or {}).get('confidence') == 'low']
        base = {
            'enabled': True,
            'support': support,
            'weak_steps': weak_steps,
            'final_decision': 'approved' if support.get('risk') in {'low', 'unknown'} and not weak_steps else 'approved_with_caution',
            'notes': [],
        }
        if weak_steps:
            base['notes'].append(f'Subperguntas com evidência fraca: {weak_steps}.')
        if support.get('risk') == 'high':
            base['notes'].append('A resposta contém muitos termos que não aparecem nas evidências recuperadas; revisar antes de usar em produção.')
        if not self.llm_router:
            return base
        try:
            system = 'Revise a resposta contra as evidências. Responda JSON curto com approved:boolean, risks:list, missing:list.'
            user = f'Pergunta:\n{question}\n\nResposta:\n{answer[:5000]}\n\nEvidências:\n{evidence_text[:9000]}'
            raw = self.llm_router.ask_chat(system, user)
            match = re.search(r'\{.*\}', raw, flags=re.DOTALL)
            if match:
                base['llm_review'] = json.loads(match.group(0))
        except Exception:
            pass
        return base

    def run(self, question: str, top_k: int = 8) -> dict[str, Any]:
        self.config.top_k_per_step = max(3, min(int(top_k or self.config.top_k_per_step), 16))
        plan_steps = self._llm_plan(question)
        plan = [s.to_dict() for s in plan_steps]
        step_results: list[AgenticStepResult] = []
        for step in plan_steps:
            step_results.append(self.retrieve_step(step))

        all_hits: list[dict[str, Any]] = []
        seen: set[str] = set()
        for step in step_results:
            for hit in step.hits:
                key = str(hit.get('chunk_id') or hit.get('node_id') or f"{hit.get('source')}:{hit.get('text','')[:60]}")
                if key not in seen:
                    seen.add(key)
                    all_hits.append(hit)

        # Final rerank against original question to keep backward-compatible evidence list.
        final_hits = rerank_hits(question, all_hits, top_k=max(8, top_k)) if all_hits else []
        graph_context = {}
        if self.config.enable_graph_context:
            graph_context = SimpleDocumentGraph.from_hits(final_hits).query_context(question)
        answer = self.synthesize(question, plan, step_results, graph_context)
        reflection = self.reflect(question, answer, step_results)
        guard = guard_hits(question, final_hits).to_dict()
        grades = [s.grade for s in step_results]
        if any(g.get('confidence') == 'high' for g in grades):
            guard['confidence'] = 'high'
            guard['ok'] = True
        elif any(g.get('confidence') == 'medium' for g in grades):
            guard['confidence'] = 'medium'
            guard['ok'] = True
        elif grades:
            guard['confidence'] = 'low'
            guard['ok'] = False
            guard['reason'] = 'As buscas agentic não encontraram evidência suficiente.'

        result = {
            'mode': 'agentic',
            'router': {'mode': 'agentic', 'reason': 'Planner agentic com decomposição, reconsulta e reflexão.', 'steps': len(plan)},
            'routing': {'mode': 'agentic', 'reason': 'Planner agentic com decomposição, reconsulta e reflexão.', 'steps': len(plan)},
            'guard': guard,
            'answer': answer,
            'plan': plan,
            'steps': [s.to_dict() for s in step_results],
            'graph_context': graph_context,
            'reflection': reflection,
            'hits': final_hits,
            'evidence': final_hits,
        }
        if self.config.enable_memory_trace:
            try:
                result['trace_id'] = self.memory.save_trace({
                    'question': question,
                    'plan': plan,
                    'steps': [s.to_dict() for s in step_results],
                    'guard': guard,
                    'reflection': reflection,
                })
            except Exception as exc:
                result['trace_error'] = str(exc)
        return result
