from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import time
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


def _now_text() -> str:
    return time.strftime('%Y-%m-%d %H:%M:%S')


def _safe_read_json(path: Path, default: Any) -> Any:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding='utf-8-sig'))
    except Exception:
        pass
    return default


def _safe_write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def _parse_json(value: Any, default: Any) -> Any:
    if value is None:
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(str(value))
    except Exception:
        return default


def _norm_error(text: str) -> str:
    text = str(text or '').strip()
    ora = re.search(r'\b(ORA-\d{5})\b', text.upper())
    if ora:
        return ora.group(1)
    dpy = re.search(r'\b(DPY-\d{4,5})\b', text.upper())
    if dpy:
        return dpy.group(1)
    if 'SQL gerada foi bloqueada' in text:
        return 'SQL_BLOCKED_BY_VALIDATOR'
    if 'timeout' in text.lower():
        return 'TIMEOUT'
    if not text:
        return 'NO_DETAIL'
    return re.sub(r'\s+', ' ', text[:90].upper())


def _proposal_id(kind: str, title: str, evidence_key: str = '') -> str:
    raw = f'{kind}|{title}|{evidence_key}'.encode('utf-8', errors='ignore')
    return hashlib.sha1(raw).hexdigest()[:12]


@dataclass
class ImprovementProposal:
    id: str
    title: str
    kind: str
    priority: str
    risk: str
    status: str = 'pending'
    created_at: str = field(default_factory=_now_text)
    updated_at: str = field(default_factory=_now_text)
    evidence: list[str] = field(default_factory=list)
    recommended_actions: list[str] = field(default_factory=list)
    acceptance_criteria: list[str] = field(default_factory=list)
    lab_files: list[str] = field(default_factory=list)
    approval_note: str = ''


class AutonomyManager:
    """Governed self-improvement layer for the local Oracle/ERP assistant.

    It never edits production code, never executes DML/DDL and never runs shell commands.
    The manager learns from feedback/traces and writes proposals/rules under data/autonomy*.
    """

    def __init__(
        self,
        root_dir: str | Path,
        feedback_db: str | Path,
        learning_path: str | Path,
        policy_path: str | Path,
        trace_dir: str | Path,
        agent_audit_path: str | Path,
    ):
        self.root_dir = Path(root_dir)
        self.feedback_db = Path(feedback_db)
        self.learning_path = Path(learning_path)
        self.policy_path = Path(policy_path)
        self.trace_dir = Path(trace_dir)
        self.agent_audit_path = Path(agent_audit_path)
        self.data_dir = self.root_dir / 'data' / 'autonomy'
        self.lab_dir = self.root_dir / 'data' / 'autonomy_lab'
        self.state_path = self.data_dir / 'autonomy_state.json'
        self.proposals_path = self.data_dir / 'proposals.json'
        self.rules_path = self.data_dir / 'learned_rules.json'
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.lab_dir.mkdir(parents=True, exist_ok=True)

    def status(self) -> dict[str, Any]:
        proposals = self._load_proposals()
        rules = _safe_read_json(self.rules_path, {'rules': []})
        state = _safe_read_json(self.state_path, {})
        feedback = self._load_feedback(limit=200)
        ok_count = sum(1 for r in feedback if r.get('oracle_ok'))
        return {
            'enabled': True,
            'mode': 'governed_autonomy',
            'safety': {
                'production_code_auto_edit': False,
                'shell': False,
                'dml': False,
                'ddl': False,
                'auto_apply_without_human': False,
                'lab_patch_generation': True,
            },
            'feedback_rows_recent': len(feedback),
            'recent_success_rate': round(ok_count / len(feedback), 3) if feedback else None,
            'proposals': {
                'total': len(proposals),
                'pending': sum(1 for p in proposals if p.get('status') == 'pending'),
                'approved': sum(1 for p in proposals if p.get('status') == 'approved'),
                'rejected': sum(1 for p in proposals if p.get('status') == 'rejected'),
            },
            'learned_rules': len(rules.get('rules') or []),
            'last_cycle': state.get('last_cycle'),
            'paths': {
                'state': str(self.state_path),
                'proposals': str(self.proposals_path),
                'rules': str(self.rules_path),
                'lab_dir': str(self.lab_dir),
            },
        }

    def run_cycle(self, focus: str = '', write_lab_files: bool = True, limit: int = 600) -> dict[str, Any]:
        feedback = self._load_feedback(limit=limit)
        learning = _safe_read_json(self.learning_path, {'entries': [], 'column_aliases': {}})
        policy = _safe_read_json(self.policy_path, {'buckets': {}})
        traces = self._load_recent_traces(limit=120)
        audit = self._load_agent_audit(limit=120)

        insights = self._analyze(feedback, learning, policy, traces, audit, focus=focus)
        new_proposals = self._build_proposals(insights, learning, focus=focus)
        merged = self._merge_proposals(new_proposals)
        if write_lab_files:
            self._write_lab_files(merged, insights)
        state = {
            'last_cycle': _now_text(),
            'focus': focus,
            'feedback_rows': len(feedback),
            'trace_rows': len(traces),
            'audit_rows': len(audit),
            'insights': insights,
        }
        _safe_write_json(self.state_path, state)
        return {
            'ok': True,
            'mode': 'governed_autonomy',
            'cycle_at': state['last_cycle'],
            'focus': focus,
            'insights': insights,
            'new_or_updated_proposals': [asdict(p) for p in new_proposals],
            'proposals': merged,
            'rules': _safe_read_json(self.rules_path, {'rules': []}),
        }

    def list_proposals(self, status: str = '', limit: int = 100) -> list[dict[str, Any]]:
        rows = self._load_proposals()
        if status:
            rows = [r for r in rows if str(r.get('status') or '') == status]
        priority_rank = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}
        rows.sort(key=lambda r: (priority_rank.get(str(r.get('priority') or 'medium'), 2), str(r.get('updated_at') or '')), reverse=False)
        return rows[: max(1, min(limit, 500))]

    def set_proposal_status(self, proposal_id: str, status: str, note: str = '') -> dict[str, Any]:
        status = status.lower().strip()
        if status not in {'pending', 'approved', 'rejected'}:
            raise ValueError('status deve ser pending, approved ou rejected')
        proposals = self._load_proposals()
        found = None
        for item in proposals:
            if item.get('id') == proposal_id:
                item['status'] = status
                item['updated_at'] = _now_text()
                item['approval_note'] = note or item.get('approval_note', '')
                found = item
                break
        if not found:
            raise KeyError(f'Proposta não encontrada: {proposal_id}')
        _safe_write_json(self.proposals_path, {'proposals': proposals})
        if status == 'approved':
            self._install_rule_from_proposal(found, note=note)
        return found

    def recent_rules(self, limit: int = 100) -> list[dict[str, Any]]:
        rules = _safe_read_json(self.rules_path, {'rules': []}).get('rules') or []
        return list(reversed(rules))[: max(1, min(limit, 500))]

    def _load_feedback(self, limit: int = 500) -> list[dict[str, Any]]:
        if not self.feedback_db.exists():
            return []
        conn = sqlite3.connect(str(self.feedback_db))
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute('SELECT * FROM sql_feedback ORDER BY id DESC LIMIT ?', (int(limit),)).fetchall()
            out: list[dict[str, Any]] = []
            for row in rows:
                item = dict(row)
                item['selected_tables'] = _parse_json(item.get('selected_tables_json'), [])
                item['used_tables'] = _parse_json(item.get('used_tables_json'), [])
                item['validation'] = _parse_json(item.get('validation_json'), {})
                item['reward_reasons'] = _parse_json(item.get('reward_reasons_json'), [])
                item['action'] = _parse_json(item.get('action_json'), {})
                item['oracle_ok'] = bool(item.get('oracle_ok'))
                out.append(item)
            return out
        finally:
            conn.close()

    def _load_recent_traces(self, limit: int = 120) -> list[dict[str, Any]]:
        if not self.trace_dir.exists():
            return []
        out: list[dict[str, Any]] = []
        for path in sorted(self.trace_dir.glob('trace_*.json'), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]:
            data = _safe_read_json(path, None)
            if isinstance(data, dict):
                data['_file'] = str(path)
                out.append(data)
        return out

    def _load_agent_audit(self, limit: int = 120) -> list[dict[str, Any]]:
        if not self.agent_audit_path.exists():
            return []
        lines = self.agent_audit_path.read_text(encoding='utf-8', errors='ignore').splitlines()[-limit:]
        out: list[dict[str, Any]] = []
        for line in reversed(lines):
            try:
                out.append(json.loads(line))
            except Exception:
                pass
        return out

    def _analyze(self, feedback: list[dict[str, Any]], learning: dict[str, Any], policy: dict[str, Any], traces: list[dict[str, Any]], audit: list[dict[str, Any]], focus: str = '') -> dict[str, Any]:
        errors = Counter()
        module_stats: dict[str, dict[str, Any]] = defaultdict(lambda: {'total': 0, 'ok': 0, 'reward_sum': 0.0, 'errors': Counter()})
        action_stats: dict[str, dict[str, Any]] = defaultdict(lambda: {'total': 0, 'reward_sum': 0.0, 'ok': 0})
        slow: list[dict[str, Any]] = []
        blocked_reasons = Counter()
        duplicated_mentions = 0

        for row in feedback:
            module = str(row.get('module_name') or 'GENERIC').upper() or 'GENERIC'
            ok = bool(row.get('oracle_ok'))
            reward = float(row.get('reward') or 0.0)
            module_stats[module]['total'] += 1
            module_stats[module]['reward_sum'] += reward
            if ok:
                module_stats[module]['ok'] += 1
            else:
                err = _norm_error(row.get('error_detail') or '')
                errors[err] += 1
                module_stats[module]['errors'][err] += 1
            action_name = str((row.get('action') or {}).get('name') or 'unknown')
            action_stats[action_name]['total'] += 1
            action_stats[action_name]['reward_sum'] += reward
            if ok:
                action_stats[action_name]['ok'] += 1
            latency = float(row.get('latency_s') or 0.0)
            if latency >= 20:
                slow.append({'question': row.get('question', '')[:240], 'latency_s': latency, 'module': module, 'reward': reward})
            validation = row.get('validation') or {}
            for reason in (validation.get('reasons') or []) + (validation.get('column_issues') or []) + (validation.get('schema_guard_issues') or []) + (validation.get('semantic_guard_issues') or []):
                blocked_reasons[str(reason)[:180]] += 1
            txt = f"{row.get('question','')} {row.get('error_detail','')}".lower()
            if 'duplic' in txt or 'muitas linhas' in txt:
                duplicated_mentions += 1

        module_summary = []
        for mod, st in module_stats.items():
            total = st['total'] or 1
            module_summary.append({
                'module': mod,
                'total': st['total'],
                'success_rate': round(st['ok'] / total, 3),
                'avg_reward': round(st['reward_sum'] / total, 3),
                'top_errors': st['errors'].most_common(5),
            })
        module_summary.sort(key=lambda x: (x['success_rate'], x['avg_reward']))

        action_summary = []
        for action, st in action_stats.items():
            total = st['total'] or 1
            action_summary.append({
                'action': action,
                'total': st['total'],
                'success_rate': round(st['ok'] / total, 3),
                'avg_reward': round(st['reward_sum'] / total, 3),
            })
        action_summary.sort(key=lambda x: x['avg_reward'])

        column_alias_tables = learning.get('column_aliases') or {}
        learned_entries = learning.get('entries') or []
        failed_agent_actions = Counter(str(x.get('action') or '') for x in audit if not x.get('ok'))
        return {
            'focus': focus,
            'feedback_total': len(feedback),
            'success_rate': round(sum(1 for r in feedback if r.get('oracle_ok')) / len(feedback), 3) if feedback else None,
            'avg_reward': round(sum(float(r.get('reward') or 0.0) for r in feedback) / len(feedback), 3) if feedback else None,
            'top_errors': errors.most_common(8),
            'top_blocked_reasons': blocked_reasons.most_common(8),
            'worst_modules': module_summary[:8],
            'action_summary': action_summary,
            'slow_examples': sorted(slow, key=lambda x: x['latency_s'], reverse=True)[:8],
            'duplicated_mentions': duplicated_mentions,
            'learned_entries': len(learned_entries),
            'column_alias_table_count': len(column_alias_tables),
            'policy_buckets': len((policy.get('buckets') or {})),
            'trace_count': len(traces),
            'audit_failures': failed_agent_actions.most_common(8),
        }

    def _build_proposals(self, insights: dict[str, Any], learning: dict[str, Any], focus: str = '') -> list[ImprovementProposal]:
        proposals: list[ImprovementProposal] = []
        total = int(insights.get('feedback_total') or 0)
        success_rate = insights.get('success_rate')

        if total == 0:
            proposals.append(ImprovementProposal(
                id=_proposal_id('bootstrap', 'Ativar coleta de feedback e treinamento por uso'),
                title='Ativar coleta de feedback e treinamento por uso',
                kind='bootstrap_learning', priority='high', risk='low',
                evidence=['Ainda não há feedback suficiente em data/learning/feedback.sqlite.'],
                recommended_actions=[
                    'Usar os botões de aprovação/rejeição nas respostas SQL.',
                    'Executar SQLs em modo validação antes de liberar para usuário.',
                    'Rodar este ciclo autônomo após alguns testes reais.'
                ],
                acceptance_criteria=['Após 20 interações, taxa de sucesso e recompensa média aparecem no painel.'],
            ))
            return proposals

        if success_rate is not None and success_rate < 0.75:
            proposals.append(ImprovementProposal(
                id=_proposal_id('quality_gate', 'Endurecer validação antes de responder SQL', str(success_rate)),
                title='Endurecer validação antes de responder SQL',
                kind='validator_rule', priority='high', risk='low',
                evidence=[f'Taxa de sucesso recente abaixo de 75%: {success_rate}.'],
                recommended_actions=[
                    'Obrigar schema_guard_ok=true e semantic_guard_ok=true antes de mostrar SQL como final.',
                    'Quando a validação falhar, responder com diagnóstico e pedir nova análise de schema, sem inventar coluna.',
                    'Priorizar exemplos aprovados de LearningStore no prompt.'
                ],
                acceptance_criteria=['SQL inválidas devem ser bloqueadas com explicação objetiva.', 'Nenhuma DML/DDL deve ser executada.'],
            ))

        top_errors = insights.get('top_errors') or []
        error_names = {e[0]: e[1] for e in top_errors}
        if error_names.get('ORA-00904', 0) >= 1:
            proposals.append(ImprovementProposal(
                id=_proposal_id('ora_00904', 'Criar regra anti-coluna-inventada', str(error_names.get('ORA-00904'))),
                title='Criar regra anti-coluna-inventada',
                kind='schema_learning', priority='high', risk='low',
                evidence=[f"Ocorrências recentes de ORA-00904: {error_names.get('ORA-00904')}.", 'Esse erro indica coluna inválida ou alias incorreto.'],
                recommended_actions=[
                    'Antes de chamar o LLM, resolver colunas candidatas via ColumnResolver.',
                    'Depois da geração, rodar validate_sql_columns_strict.',
                    'Quando houver correção manual, gravar alias em data/learning/sql_learning.json.'
                ],
                acceptance_criteria=['A mesma coluna inválida não deve aparecer duas vezes para o mesmo módulo/tabela.'],
            ))
        if error_names.get('ORA-00942', 0) >= 1:
            proposals.append(ImprovementProposal(
                id=_proposal_id('ora_00942', 'Criar regra anti-tabela-inventada', str(error_names.get('ORA-00942'))),
                title='Criar regra anti-tabela-inventada',
                kind='schema_learning', priority='high', risk='low',
                evidence=[f"Ocorrências recentes de ORA-00942: {error_names.get('ORA-00942')}.", 'Esse erro indica tabela/view ausente ou owner incorreto.'],
                recommended_actions=[
                    'Bloquear tabelas fora de candidate_tables/grouped_columns.',
                    'Sempre qualificar owner quando informado.',
                    'Recarregar Mapa ERP/Metadados quando schema estiver vazio.'
                ],
                acceptance_criteria=['SQL gerada só deve usar objetos existentes no schema analisado.'],
            ))
        if error_names.get('SQL_BLOCKED_BY_VALIDATOR', 0) >= 2:
            proposals.append(ImprovementProposal(
                id=_proposal_id('blocked_sql', 'Transformar bloqueios recorrentes em regras permanentes', str(error_names.get('SQL_BLOCKED_BY_VALIDATOR'))),
                title='Transformar bloqueios recorrentes em regras permanentes',
                kind='prompt_policy', priority='medium', risk='low',
                evidence=[f"Bloqueios recentes pelo validador: {error_names.get('SQL_BLOCKED_BY_VALIDATOR')}.", 'Bloqueios repetidos indicam lacuna no prompt ou no seletor de tabelas.'],
                recommended_actions=[
                    'Extrair top_blocked_reasons e adicioná-los ao prompt de sistema do SQL Copilot.',
                    'Manter resposta explicativa quando a SQL for insegura ou sem schema suficiente.'
                ],
                acceptance_criteria=['Motivos de bloqueio devem cair no próximo ciclo de feedback.'],
            ))

        if insights.get('duplicated_mentions', 0) >= 1:
            proposals.append(ImprovementProposal(
                id=_proposal_id('anti_dup', 'Adicionar guarda anti-duplicidade em consultas analíticas', str(insights.get('duplicated_mentions'))),
                title='Adicionar guarda anti-duplicidade em consultas analíticas',
                kind='semantic_guard', priority='medium', risk='low',
                evidence=[f"Menções a duplicidade/muitas linhas: {insights.get('duplicated_mentions')}.", 'Em ERP, joins N:N sem agregação criam explosão de linhas.'],
                recommended_actions=[
                    'Quando o objetivo for indicador/resumo, exigir nível de grão antes do SELECT.',
                    'Sugerir CTEs agregadas por chave antes de juntar CTB/CPR/EST.',
                    'Avisar quando join aumentar cardinalidade sem DISTINCT/GROUP BY adequado.'
                ],
                acceptance_criteria=['Consultas de indicadores devem declarar grão e reduzir duplicidade antes do join final.'],
            ))

        slow_examples = insights.get('slow_examples') or []
        if slow_examples:
            proposals.append(ImprovementProposal(
                id=_proposal_id('latency', 'Otimizar respostas lentas com cache e estratégia rápida', str(len(slow_examples))),
                title='Otimizar respostas lentas com cache e estratégia rápida',
                kind='performance', priority='medium', risk='low',
                evidence=[f'{len(slow_examples)} respostas recentes passaram de 20s.', 'Latência alta reduz usabilidade da interface.'],
                recommended_actions=[
                    'Usar traditional_fast quando pergunta for simples e schema já estiver carregado.',
                    'Cachear schema_fingerprint + pergunta normalizada.',
                    'Reduzir top_k e número de tabelas quando o módulo estiver claro.'
                ],
                acceptance_criteria=['Perguntas repetidas devem responder via cache.', 'Perguntas simples devem usar menos tabelas no contexto.'],
            ))

        action_summary = insights.get('action_summary') or []
        if len(action_summary) >= 2:
            worst = action_summary[0]
            best = sorted(action_summary, key=lambda x: x.get('avg_reward', 0), reverse=True)[0]
            if best.get('avg_reward', 0) - worst.get('avg_reward', 0) >= 2:
                proposals.append(ImprovementProposal(
                    id=_proposal_id('bandit', 'Ajustar política de escolha automática de estratégia', f"{worst.get('action')}->{best.get('action')}"),
                    title='Ajustar política de escolha automática de estratégia',
                    kind='policy_bandit', priority='medium', risk='low',
                    evidence=[f"Pior ação: {worst.get('action')} reward={worst.get('avg_reward')}.", f"Melhor ação: {best.get('action')} reward={best.get('avg_reward')}."] ,
                    recommended_actions=[
                        'Reduzir exploração temporariamente para módulos críticos.',
                        'Preferir a melhor ação quando o bucket tiver pelo menos 5 amostras.',
                        'Manter exploração controlada apenas em laboratório.'
                    ],
                    acceptance_criteria=['Reward médio por bucket deve subir no próximo ciclo.'],
                ))

        if total >= 20:
            proposals.append(ImprovementProposal(
                id=_proposal_id('dataset', 'Exportar dataset de preferências para ajuste fino futuro', str(total)),
                title='Exportar dataset de preferências para ajuste fino futuro',
                kind='training_dataset', priority='low', risk='low',
                evidence=[f'Há {total} registros recentes de feedback.', 'O projeto já possui training/export_preferences.py e train_dpo.py/train_grpo.py.'],
                recommended_actions=[
                    'Rodar /api/learning/export-preferences.',
                    'Revisar manualmente training/datasets/sql_preferences.json.',
                    'Só depois considerar DPO/GRPO em ambiente separado.'
                ],
                acceptance_criteria=['Dataset exportado sem dados sensíveis e com pares aprovado/rejeitado.'],
            ))

        if focus.strip():
            proposals.append(ImprovementProposal(
                id=_proposal_id('focus', f'Ciclo focado: {focus[:80]}', focus[:120]),
                title=f'Ciclo focado: {focus[:80]}',
                kind='operator_focus', priority='medium', risk='low',
                evidence=[f'Foco informado pelo operador: {focus}'],
                recommended_actions=[
                    'Transformar esse foco em checklist de validação.',
                    'Criar exemplos aprovados específicos desse cenário.',
                    'Rodar testes em laboratório antes de usar em produção.'
                ],
                acceptance_criteria=['Checklist aprovado pelo operador e aplicado em perguntas semelhantes.'],
            ))
        return proposals

    def _load_proposals(self) -> list[dict[str, Any]]:
        data = _safe_read_json(self.proposals_path, {'proposals': []})
        rows = data.get('proposals') if isinstance(data, dict) else data
        return rows if isinstance(rows, list) else []

    def _merge_proposals(self, proposals: list[ImprovementProposal]) -> list[dict[str, Any]]:
        existing = {p.get('id'): p for p in self._load_proposals() if p.get('id')}
        for proposal in proposals:
            p = asdict(proposal)
            old = existing.get(proposal.id)
            if old:
                # preserve human decision and notes; refresh evidence/action text
                p['status'] = old.get('status', 'pending')
                p['created_at'] = old.get('created_at', p['created_at'])
                p['approval_note'] = old.get('approval_note', '')
            existing[proposal.id] = p
        rows = list(existing.values())
        rows.sort(key=lambda r: str(r.get('updated_at') or r.get('created_at') or ''), reverse=True)
        _safe_write_json(self.proposals_path, {'proposals': rows})
        return rows

    def _write_lab_files(self, proposals: list[dict[str, Any]], insights: dict[str, Any]) -> None:
        ts = time.strftime('%Y%m%d_%H%M%S')
        cycle_dir = self.lab_dir / f'cycle_{ts}'
        cycle_dir.mkdir(parents=True, exist_ok=True)
        _safe_write_json(cycle_dir / 'insights.json', insights)
        pending = [p for p in proposals if p.get('status') == 'pending'][:12]
        for p in pending:
            md = [f"# {p.get('title')}", '', f"ID: `{p.get('id')}`", f"Tipo: `{p.get('kind')}`", f"Prioridade: `{p.get('priority')}`", f"Risco: `{p.get('risk')}`", '', '## Evidências']
            md += [f"- {x}" for x in p.get('evidence') or []]
            md += ['', '## Ações recomendadas']
            md += [f"- {x}" for x in p.get('recommended_actions') or []]
            md += ['', '## Critérios de aceite']
            md += [f"- {x}" for x in p.get('acceptance_criteria') or []]
            safe_name = re.sub(r'[^A-Za-z0-9_-]+', '_', str(p.get('id') or 'proposal'))
            path = cycle_dir / f'{safe_name}.md'
            path.write_text('\n'.join(md), encoding='utf-8')
            p.setdefault('lab_files', []).append(str(path))
        _safe_write_json(self.proposals_path, {'proposals': proposals})

    def _install_rule_from_proposal(self, proposal: dict[str, Any], note: str = '') -> None:
        data = _safe_read_json(self.rules_path, {'rules': []})
        rules = data.setdefault('rules', [])
        if any(r.get('proposal_id') == proposal.get('id') for r in rules):
            return
        rules.append({
            'id': _proposal_id('rule', proposal.get('title', ''), proposal.get('id', '')),
            'proposal_id': proposal.get('id'),
            'created_at': _now_text(),
            'title': proposal.get('title'),
            'kind': proposal.get('kind'),
            'rule': ' | '.join(proposal.get('recommended_actions') or [])[:2000],
            'acceptance_criteria': proposal.get('acceptance_criteria') or [],
            'operator_note': note,
            'enabled': True,
        })
        _safe_write_json(self.rules_path, data)
