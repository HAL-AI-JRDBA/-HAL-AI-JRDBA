from __future__ import annotations

import json
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from services.hall_safety.anomaly_detector import AgentAnomalyDetector


@dataclass
class A2AMessage:
    id: str
    ts: float
    run_id: str
    from_agent: str
    to_agent: str
    message_type: str
    payload: dict[str, Any] = field(default_factory=dict)
    correlation_id: str = ""


ALLOWED_MESSAGE_TYPES = {"task_assigned","task_result","finding","evidence","recommendation","status","approval_request","approval_result","error","handoff"}


class A2ABus:
    """Barramento Agent-to-Agent local auditável.

    Implementa o conceito A2A de forma simples, em JSONL, para não depender de serviço externo.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def send(self, from_agent: str, to_agent: str, message_type: str, payload: dict[str, Any] | None = None, run_id: str = "", correlation_id: str = "") -> dict[str, Any]:
        if message_type not in ALLOWED_MESSAGE_TYPES:
            raise PermissionError(f"Tipo A2A não permitido pelo HAL Structured Agent Protocol: {message_type}")
        if payload is not None and not isinstance(payload, dict):
            raise TypeError("A2A exige payload JSON/objeto estruturado.")
        payload = payload or {}
        text = json.dumps(payload, ensure_ascii=False, default=str)
        if AgentAnomalyDetector.probable_encoded_text(text):
            raise PermissionError("Payload A2A opaco/codificado bloqueado pelo No Hidden Protocol Policy.")
        msg = A2AMessage(
            id=f"a2a_{uuid.uuid4().hex[:14]}",
            ts=time.time(),
            run_id=run_id,
            from_agent=from_agent,
            to_agent=to_agent,
            message_type=message_type,
            payload=payload or {},
            correlation_id=correlation_id,
        )
        row = asdict(msg)
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
        return {"ok": True, "message": row}

    def recent(self, limit: int = 100, run_id: str | None = None) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        lines = self.path.read_text(encoding="utf-8", errors="ignore").splitlines()[-max(1, min(int(limit or 100), 1000)):]
        rows = []
        for line in lines:
            try:
                row = json.loads(line)
                if run_id and row.get("run_id") != run_id:
                    continue
                rows.append(row)
            except Exception:
                continue
        return list(reversed(rows))

    def status(self) -> dict[str, Any]:
        count = 0
        if self.path.exists():
            try:
                count = len(self.path.read_text(encoding="utf-8", errors="ignore").splitlines())
            except Exception:
                count = 0
        return {"ok": True, "path": str(self.path), "message_count": count, "mode": "local_jsonl"}
