from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import io
import math
import re
import unicodedata
from typing import Any

import numpy as np
import pandas as pd


@dataclass
class AnalysisBundle:
    dataframe: pd.DataFrame
    normalized_dataframe: pd.DataFrame
    semantic_map: dict[str, list[str]]
    profile: dict[str, Any]


SEMANTIC_RULES = {
    'date': ['DATA', 'DT', 'DTHR', 'DATAMOV', 'DATAHORA', 'EMISSAO', 'VENC', 'PAGAMENTO', 'BAIXA', 'TROCA'],
    'vehicle': ['VEIC', 'VEICULO', 'CARRO', 'FROTA', 'PREFIXO'],
    'driver': ['MOTORISTA', 'CONDUTOR', 'COBRADOR'],
    'line': ['LINHA', 'ROTA', 'SERVICO'],
    'garage': ['GARAGEM', 'GA'],
    'company': ['EMPRESA', 'EMP'],
    'branch': ['FILIAL', 'FL'],
    'item': ['ITEM', 'PRODUTO', 'PECA', 'COMPONENTE', 'ITM'],
    'document': ['DOCUMENTO', 'TITULO', 'NF', 'NOTA', 'OS', 'PEDIDO', 'RECNUM'],
    'supplier': ['FORNECEDOR', 'CREDOR'],
    'customer': ['CLIENTE', 'PASSAGEIRO', 'TOMADOR'],
    'amount': ['VALOR', 'TOTAL', 'MONTANTE', 'PRECO', 'CUSTO', 'RECEITA', 'DESPESA', 'SALDO'],
    'quantity': ['QTDE', 'QUANTIDADE', 'LITRO', 'KM', 'HORIMETRO'],
    'status': ['STATUS', 'SITUAC', 'MOTIVO', 'OCORRENCIA'],
    'user': ['USUARIO', 'LOGIN', 'OPERADOR'],
    'metric': ['INDICADOR', 'METRICA', 'CONTA', 'DESCRICAO', 'DESCR'],
}


def _strip_accents(value: str) -> str:
    value = unicodedata.normalize('NFKD', value)
    return ''.join(ch for ch in value if not unicodedata.combining(ch))


def normalize_column_name(name: Any) -> str:
    text = _strip_accents(str(name).upper().strip())
    text = re.sub(r'[^A-Z0-9]+', '_', text)
    text = re.sub(r'_+', '_', text).strip('_')
    return text or 'COL'


def load_dataframe_from_upload(uploaded_file) -> pd.DataFrame:
    suffix = Path(uploaded_file.name).suffix.lower()
    data = uploaded_file.read()
    bio = io.BytesIO(data)
    if suffix == '.csv':
        for encoding in ('utf-8', 'latin-1'):
            bio.seek(0)
            try:
                return pd.read_csv(bio, encoding=encoding)
            except Exception:
                continue
        raise ValueError('Não foi possível ler o CSV com UTF-8 ou Latin-1.')
    if suffix in {'.xlsx', '.xls'}:
        bio.seek(0)
        return pd.read_excel(bio)
    raise ValueError('Formato não suportado para análise tabular. Use CSV ou XLSX.')


def prepare_dataframe(df: pd.DataFrame) -> AnalysisBundle:
    raw = df.copy()
    raw.columns = [str(c) for c in raw.columns]
    norm = raw.copy()
    norm.columns = [normalize_column_name(c) for c in raw.columns]

    for col in norm.columns:
        if norm[col].dtype == object:
            sample = norm[col].dropna().astype(str).head(20)
            if sample.empty:
                continue
            maybe_numeric = sample.str.replace('.', '', regex=False).str.replace(',', '.', regex=False)
            converted = pd.to_numeric(maybe_numeric, errors='coerce')
            if converted.notna().mean() >= 0.8:
                norm[col] = pd.to_numeric(norm[col].astype(str).str.replace('.', '', regex=False).str.replace(',', '.', regex=False), errors='coerce')
                continue
            dt = pd.to_datetime(norm[col], errors='coerce', dayfirst=True)
            if dt.notna().mean() >= 0.8:
                norm[col] = dt

    semantic_map = infer_semantics(norm)
    profile = profile_dataframe(norm)
    return AnalysisBundle(dataframe=raw, normalized_dataframe=norm, semantic_map=semantic_map, profile=profile)


def infer_semantics(df: pd.DataFrame) -> dict[str, list[str]]:
    mapping: dict[str, list[str]] = {key: [] for key in SEMANTIC_RULES}
    for col in df.columns:
        up = normalize_column_name(col)
        for semantic, tokens in SEMANTIC_RULES.items():
            if any(token in up for token in tokens):
                mapping[semantic].append(col)
    return {k: v for k, v in mapping.items() if v}


def profile_dataframe(df: pd.DataFrame) -> dict[str, Any]:
    numeric_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    datetime_cols = [c for c in df.columns if pd.api.types.is_datetime64_any_dtype(df[c])]
    object_cols = [c for c in df.columns if c not in numeric_cols and c not in datetime_cols]
    null_pct = {c: round(float(df[c].isna().mean() * 100), 2) for c in df.columns[:30]}
    return {
        'rows': int(len(df)),
        'columns': int(len(df.columns)),
        'numeric_columns': numeric_cols,
        'datetime_columns': datetime_cols,
        'categorical_columns': object_cols,
        'null_pct': null_pct,
    }


def _first_semantic(semantic_map: dict[str, list[str]], key: str) -> str | None:
    values = semantic_map.get(key) or []
    return values[0] if values else None


def _safe_records(df: pd.DataFrame, limit: int = 200) -> list[dict[str, Any]]:
    safe = df.head(limit).copy()
    for col in safe.columns:
        if pd.api.types.is_datetime64_any_dtype(safe[col]):
            safe[col] = safe[col].dt.strftime('%Y-%m-%d %H:%M:%S')
        else:
            safe[col] = safe[col].astype(object).where(pd.notna(safe[col]), None)
    return safe.to_dict(orient='records')


def auto_diagnosis(bundle: AnalysisBundle) -> dict[str, Any]:
    df = bundle.normalized_dataframe
    profile = bundle.profile
    semantic = bundle.semantic_map
    findings = []
    numeric_cols = profile['numeric_columns'][:8]
    for col in numeric_cols:
        s = df[col].dropna()
        if len(s) >= 8 and float(s.std()) > 0:
            z = (s - s.mean()) / (s.std() + 1e-9)
            outliers = int((z.abs() >= 3).sum())
            if outliers:
                findings.append(f'{col}: {outliers} outlier(s) por z-score >= 3.')
    date_col = _first_semantic(semantic, 'date')
    if date_col and numeric_cols:
        findings.append(f'Série temporal detectada em {date_col} com métricas numéricas: {", ".join(numeric_cols[:4])}.')
    for col, pct in profile['null_pct'].items():
        if pct >= 30:
            findings.append(f'{col}: {pct}% de nulos.')
    return {
        'title': 'Auto diagnóstico do conjunto',
        'summary': f"{profile['rows']} linhas, {profile['columns']} colunas.",
        'findings': findings or ['Nenhum padrão crítico detectado automaticamente.'],
        'sample': _safe_records(df),
    }


def anomaly_detection(bundle: AnalysisBundle) -> dict[str, Any]:
    df = bundle.normalized_dataframe.copy()
    profile = bundle.profile
    numeric_cols = profile['numeric_columns'][:10]
    flagged_frames = []
    findings = []
    for col in numeric_cols:
        s = df[col]
        valid = s.dropna()
        if len(valid) < 8 or float(valid.std()) == 0:
            continue
        z = (s - valid.mean()) / (valid.std() + 1e-9)
        mask = z.abs() >= 3
        count = int(mask.fillna(False).sum())
        if count:
            temp = df.loc[mask.fillna(False)].copy()
            temp['ANOMALY_METRIC'] = col
            temp['ANOMALY_ZSCORE'] = z.loc[temp.index].round(2)
            flagged_frames.append(temp)
            findings.append(f'{col}: {count} linha(s) fora do padrão estatístico.')
    flagged = pd.concat(flagged_frames, ignore_index=True) if flagged_frames else pd.DataFrame()
    return {
        'title': 'Anomalias e inconsistências',
        'summary': '; '.join(findings) if findings else 'Nenhuma anomalia estatística forte detectada.',
        'findings': findings or ['Nenhuma anomalia estatística forte detectada.'],
        'sample': _safe_records(flagged if not flagged.empty else df),
    }


def predict_part_replacement(bundle: AnalysisBundle) -> dict[str, Any]:
    df = bundle.normalized_dataframe.copy()
    semantic = bundle.semantic_map
    asset = _first_semantic(semantic, 'vehicle') or _first_semantic(semantic, 'asset')
    part = _first_semantic(semantic, 'item')
    date_col = _first_semantic(semantic, 'date')
    qty_like = [c for c in bundle.profile['numeric_columns'] if any(x in c for x in ('KM', 'HORIM', 'QUANTIDADE', 'QTDE'))]
    meter_col = qty_like[0] if qty_like else None
    if not asset or not part or not date_col:
        return {
            'title': 'Previsão de troca de peça',
            'summary': 'Dataset sem colunas mínimas para previsão de troca.',
            'findings': [
                'Colunas esperadas: veículo/ativo, peça/item e data da troca.',
                'Opcionalmente KM ou horímetro para previsão por uso.',
            ],
            'sample': _safe_records(df),
        }
    df = df[[c for c in [asset, part, date_col, meter_col] if c]].copy()
    df = df.dropna(subset=[asset, part, date_col]).sort_values([asset, part, date_col])
    if df.empty:
        return {'title': 'Previsão de troca de peça', 'summary': 'Sem dados válidos após limpeza.', 'findings': [], 'sample': []}
    df['PREV_DATE'] = df.groupby([asset, part])[date_col].shift(1)
    df['DAYS_INTERVAL'] = (df[date_col] - df['PREV_DATE']).dt.days
    if meter_col:
        df['PREV_METER'] = df.groupby([asset, part])[meter_col].shift(1)
        df['METER_INTERVAL'] = df[meter_col] - df['PREV_METER']
    grp = df.groupby([asset, part], dropna=True).agg(
        LAST_DATE=(date_col, 'max'),
        AVG_DAYS=('DAYS_INTERVAL', 'mean'),
        MEDIAN_DAYS=('DAYS_INTERVAL', 'median'),
        EVENTS=(date_col, 'count'),
        LAST_METER=(meter_col, 'max') if meter_col else (asset, 'count'),
        AVG_METER_INTERVAL=('METER_INTERVAL', 'mean') if meter_col else (asset, 'count'),
    ).reset_index()
    grp['PRED_NEXT_DATE'] = grp['LAST_DATE'] + pd.to_timedelta(grp['MEDIAN_DAYS'].fillna(grp['AVG_DAYS']).fillna(0), unit='D')
    today = pd.Timestamp.today().normalize()
    grp['STATUS'] = np.where(grp['PRED_NEXT_DATE'] <= today, 'ATRASADA/DEVIDA', np.where(grp['PRED_NEXT_DATE'] <= today + pd.Timedelta(days=30), 'ATENÇÃO 30 DIAS', 'OK'))
    findings = [
        'Previsão baseada no histórico de intervalos por veículo/peça.',
        'Quanto mais recorrente e consistente o histórico, melhor a previsão.',
    ]
    return {
        'title': 'Previsão de troca de peça',
        'summary': f'{len(grp)} combinação(ões) veículo/peça avaliadas.',
        'findings': findings,
        'sample': _safe_records(grp.sort_values(['STATUS', 'PRED_NEXT_DATE']).rename(columns={asset: 'VEICULO', part: 'PECA'})),
    }


def analyze_fuel_driver_change(bundle: AnalysisBundle) -> dict[str, Any]:
    df = bundle.normalized_dataframe.copy()
    semantic = bundle.semantic_map
    vehicle = _first_semantic(semantic, 'vehicle')
    driver = _first_semantic(semantic, 'driver')
    line = _first_semantic(semantic, 'line')
    date_col = _first_semantic(semantic, 'date')
    liters_col = next((c for c in bundle.profile['numeric_columns'] if 'LITR' in c or 'COMB' in c), None)
    km_col = next((c for c in bundle.profile['numeric_columns'] if c.startswith('KM') or 'QUILOMETR' in c), None)
    if not all([vehicle, driver, date_col]) or not (liters_col and km_col):
        return {
            'title': 'Consumo x troca de motorista',
            'summary': 'Dataset sem colunas mínimas para essa análise.',
            'findings': [
                'Esperado: veículo, motorista, data, litros/consumo e KM/quilometragem.',
                'Linha/rota é opcional, mas melhora a comparação.',
            ],
            'sample': _safe_records(df),
        }
    df = df.dropna(subset=[vehicle, driver, date_col, liters_col, km_col]).sort_values([vehicle, date_col]).copy()
    df = df[df[km_col] > 0].copy()
    df['CONSUMO_LITRO_POR_KM'] = df[liters_col] / df[km_col]
    df['PREV_DRIVER'] = df.groupby(vehicle)[driver].shift(1)
    changes = df[df['PREV_DRIVER'].notna() & (df['PREV_DRIVER'] != df[driver])].copy()
    if changes.empty:
        return {
            'title': 'Consumo x troca de motorista',
            'summary': 'Nenhuma troca de motorista detectada no histórico informado.',
            'findings': [],
            'sample': _safe_records(df),
        }
    rows = []
    for idx, row in changes.iterrows():
        vehicle_value = row[vehicle]
        change_date = row[date_col]
        window = df[df[vehicle] == vehicle_value]
        before = window[window[date_col] < change_date].tail(5)
        after = window[window[date_col] >= change_date].head(5)
        if before.empty or after.empty:
            continue
        before_avg = before['CONSUMO_LITRO_POR_KM'].mean()
        after_avg = after['CONSUMO_LITRO_POR_KM'].mean()
        delta_pct = ((after_avg / before_avg) - 1.0) * 100 if before_avg else math.nan
        entry = {
            'VEICULO': vehicle_value,
            'MOTORISTA_ANTERIOR': row['PREV_DRIVER'],
            'MOTORISTA_ATUAL': row[driver],
            'DATA_TROCA': row[date_col],
            'CONSUMO_ANTES': round(float(before_avg), 6),
            'CONSUMO_DEPOIS': round(float(after_avg), 6),
            'DELTA_PCT': round(float(delta_pct), 2) if not math.isnan(delta_pct) else None,
        }
        if line and line in row:
            entry['LINHA'] = row[line]
        rows.append(entry)
    result = pd.DataFrame(rows)
    findings = []
    if not result.empty:
        worse = result[result['DELTA_PCT'] > 10]
        if not worse.empty:
            findings.append(f'{len(worse)} troca(s) mostraram piora superior a 10% no consumo por KM.')
        better = result[result['DELTA_PCT'] < -10]
        if not better.empty:
            findings.append(f'{len(better)} troca(s) mostraram melhora superior a 10% no consumo por KM.')
    return {
        'title': 'Consumo x troca de motorista',
        'summary': f'{len(result)} evento(s) de troca analisados.',
        'findings': findings or ['Trocas detectadas, sem variações relevantes acima de 10%.'],
        'sample': _safe_records(result if not result.empty else df),
    }


def detect_fraud_patterns(bundle: AnalysisBundle) -> dict[str, Any]:
    df = bundle.normalized_dataframe.copy()
    semantic = bundle.semantic_map
    amount = _first_semantic(semantic, 'amount')
    date_col = _first_semantic(semantic, 'date')
    supplier = _first_semantic(semantic, 'supplier') or _first_semantic(semantic, 'customer')
    document = _first_semantic(semantic, 'document')
    user_col = _first_semantic(semantic, 'user')
    findings = []
    frames = []
    if document and amount:
        dup = df[df.duplicated(subset=[document, amount], keep=False)].copy()
        if not dup.empty:
            dup['FRAUD_RULE'] = 'Documento/valor duplicados'
            frames.append(dup)
            findings.append(f'{len(dup)} linha(s) com documento e valor duplicados.')
    if amount:
        s = pd.to_numeric(df[amount], errors='coerce')
        valid = s.dropna()
        if len(valid) >= 8 and float(valid.std()) > 0:
            z = (s - valid.mean()) / (valid.std() + 1e-9)
            out = df[z.abs() >= 3].copy()
            if not out.empty:
                out['FRAUD_RULE'] = 'Valor fora do padrão estatístico'
                frames.append(out)
                findings.append(f'{len(out)} linha(s) com valor fora do padrão estatístico.')
    if date_col is not None and supplier and amount:
        work = df.dropna(subset=[date_col, supplier, amount]).copy()
        work['__DAY__'] = pd.to_datetime(work[date_col], errors='coerce').dt.date
        grouped = work.groupby([supplier, '__DAY__'], dropna=True).agg(QTD=(amount, 'count'), SOMA=(amount, 'sum')).reset_index()
        split = grouped[grouped['QTD'] >= 3]
        if not split.empty:
            findings.append(f'{len(split)} grupo(s) com possível fracionamento no mesmo dia por fornecedor/cliente.')
    if date_col is not None:
        dts = pd.to_datetime(df[date_col], errors='coerce')
        if dts.notna().any() and dts.dt.hour.nunique() > 1:
            out_hours = df[(dts.dt.hour < 5) | (dts.dt.hour > 22)].copy()
            if not out_hours.empty:
                out_hours['FRAUD_RULE'] = 'Evento fora do horário usual'
                frames.append(out_hours)
                findings.append(f'{len(out_hours)} linha(s) fora do horário usual (antes de 05h ou após 22h).')
    if user_col and amount:
        grp = df.groupby(user_col, dropna=True)[amount].agg(['count', 'sum', 'mean']).reset_index()
        if not grp.empty:
            heavy = grp[grp['sum'] > grp['sum'].median() * 3]
            if not heavy.empty:
                findings.append(f'{len(heavy)} usuário(s) com volume financeiro muito acima da mediana.')
    flagged = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
    return {
        'title': 'Fraude, inconsistências e padrões suspeitos',
        'summary': '; '.join(findings) if findings else 'Nenhum padrão suspeito forte detectado automaticamente.',
        'findings': findings or ['Nenhum padrão suspeito forte detectado automaticamente.'],
        'sample': _safe_records(flagged if not flagged.empty else df),
    }


def compute_financial_indicators(bundle: AnalysisBundle) -> dict[str, Any]:
    df = bundle.normalized_dataframe.copy()
    indicators: dict[str, float] = {}

    # Wide format
    for col in df.columns:
        up = normalize_column_name(col)
        if not pd.api.types.is_numeric_dtype(df[col]):
            continue
        val = float(pd.to_numeric(df[col], errors='coerce').dropna().sum())
        if 'ATIVO_CIRCULANTE' in up:
            indicators['ativo_circulante'] = val
        elif 'PASSIVO_CIRCULANTE' in up:
            indicators['passivo_circulante'] = val
        elif 'ESTOQUE' in up:
            indicators['estoques'] = val
        elif 'CAIXA' in up or 'DISPONIBIL' in up:
            indicators['caixa'] = val
        elif 'RECEITA' in up:
            indicators['receita'] = val
        elif 'LUCRO' in up or 'RESULTADO' in up:
            indicators['lucro'] = val

    # Long format metric/value
    if len(indicators) < 2:
        metric_col = next((c for c in df.columns if 'INDICADOR' in c or 'DESCR' in c or 'CONTA' in c), None)
        value_col = next((c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])), None)
        if metric_col and value_col:
            for _, row in df[[metric_col, value_col]].dropna().iterrows():
                key = normalize_column_name(row[metric_col])
                val = float(row[value_col])
                if 'ATIVO_CIRCULANTE' in key:
                    indicators['ativo_circulante'] = indicators.get('ativo_circulante', 0) + val
                elif 'PASSIVO_CIRCULANTE' in key:
                    indicators['passivo_circulante'] = indicators.get('passivo_circulante', 0) + val
                elif 'ESTOQUE' in key:
                    indicators['estoques'] = indicators.get('estoques', 0) + val
                elif 'CAIXA' in key or 'DISPONIVEL' in key:
                    indicators['caixa'] = indicators.get('caixa', 0) + val
                elif 'RECEITA' in key:
                    indicators['receita'] = indicators.get('receita', 0) + val
                elif 'LUCRO' in key or 'RESULTADO' in key:
                    indicators['lucro'] = indicators.get('lucro', 0) + val

    findings = []
    ratios = {}
    ac = indicators.get('ativo_circulante')
    pc = indicators.get('passivo_circulante')
    est = indicators.get('estoques', 0)
    caixa = indicators.get('caixa')
    receita = indicators.get('receita')
    lucro = indicators.get('lucro')
    if ac is not None and pc not in (None, 0):
        ratios['liquidez_corrente'] = round(ac / pc, 4)
        findings.append(f'Liquidez corrente calculada: {ratios["liquidez_corrente"]}.')
    if ac is not None and pc not in (None, 0):
        ratios['liquidez_seca'] = round((ac - est) / pc, 4)
        findings.append(f'Liquidez seca calculada: {ratios["liquidez_seca"]}.')
    if caixa is not None and pc not in (None, 0):
        ratios['liquidez_imediata'] = round(caixa / pc, 4)
        findings.append(f'Liquidez imediata calculada: {ratios["liquidez_imediata"]}.')
    if lucro is not None and receita not in (None, 0):
        ratios['margem_liquida'] = round(lucro / receita, 4)
        findings.append(f'Margem líquida calculada: {ratios["margem_liquida"]}.')
    if not ratios:
        findings.append('Não foi possível identificar métricas financeiras suficientes para calcular liquidez ou margem.')
    ratio_df = pd.DataFrame([ratios]) if ratios else pd.DataFrame([indicators])
    return {
        'title': 'Indicadores financeiros e visão do controller',
        'summary': 'Cálculo heurístico com base nas colunas ou métricas identificadas.',
        'findings': findings,
        'sample': _safe_records(ratio_df),
        'raw_metrics': indicators,
    }


def findings_to_text(result: dict[str, Any]) -> str:
    lines = [f"TÍTULO: {result.get('title', '')}", f"RESUMO: {result.get('summary', '')}"]
    for item in result.get('findings', []):
        lines.append(f"- {item}")
    sample = result.get('sample', [])[:20]
    if sample:
        lines.append('AMOSTRA:')
        for row in sample:
            lines.append(str(row))
    return '\n'.join(lines)
