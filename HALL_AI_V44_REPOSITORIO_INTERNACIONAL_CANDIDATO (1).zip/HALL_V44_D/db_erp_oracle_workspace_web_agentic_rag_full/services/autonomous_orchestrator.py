from __future__ import annotations

import re
from dataclasses import dataclass, asdict, field
from typing import Any


DANGEROUS_SQL_RE = re.compile(r'\b(INSERT|UPDATE|DELETE|MERGE|DROP|ALTER|TRUNCATE|CREATE|GRANT|REVOKE|EXEC|EXECUTE|BEGIN|DECLARE|DBMS_|UTL_|XP_)\b', re.IGNORECASE)


@dataclass
class AutonomousStep:
    name: str
    objective: str
    tool: str
    status: str = 'pending'
    result_summary: str = ''
    risk: str = 'low'


@dataclass
class AutonomousPlan:
    question: str
    mode: str
    risk: str
    blocked: bool
    block_reason: str = ''
    steps: list[AutonomousStep] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data['steps'] = [asdict(s) for s in self.steps]
        return data


def classify_question(question: str) -> dict[str, Any]:
    q = (question or '').lower()
    sql_words = ['sql', 'select', 'query', 'consulta', 'view', 'relatório', 'relatorio', 'listar', 'mostre', 'indicador', 'balancete', 'estoque', 'compras']
    dba_words = ['lock', 'sessão', 'sessao', 'tablespace', 'backup', 'rman', 'datapump', 'alert', 'listener', 'wait', 'awr', 'ash', 'job', 'scheduler', 'fra']
    tuning_words = ['índice', 'indice', 'lenta', 'custo', 'plano', 'explain', 'performance', 'tuning']
    wants_sql = any(w in q for w in sql_words)
    wants_dba = any(w in q for w in dba_words)
    wants_tuning = any(w in q for w in tuning_words)
    dangerous = bool(DANGEROUS_SQL_RE.search(question or ''))
    return {
        'wants_sql': wants_sql,
        'wants_dba': wants_dba,
        'wants_tuning': wants_tuning,
        'dangerous': dangerous,
        'risk': 'high' if dangerous else ('medium' if wants_dba or wants_tuning else 'low'),
    }


def build_autonomous_plan(question: str, mode: str = 'safe', has_schema: bool = False, has_rag: bool = False, allow_execute_select: bool = False) -> AutonomousPlan:
    info = classify_question(question)
    if info['dangerous']:
        return AutonomousPlan(
            question=question,
            mode=mode,
            risk='high',
            blocked=True,
            block_reason='A solicitação contém comandos potencialmente destrutivos ou administrativos. A IA autônoma só opera em modo read-only/laboratório.',
            steps=[],
        )
    steps: list[AutonomousStep] = []
    if has_rag:
        steps.append(AutonomousStep('consultar_memoria_rag', 'Buscar contexto em documentos locais/RAG.', 'rag_search'))
    if info['wants_dba']:
        steps.append(AutonomousStep('coletar_dba_readonly', 'Coletar diagnóstico Oracle somente leitura quando houver conexão.', 'dba_collect', risk='medium'))
    if info['wants_sql'] or info['wants_tuning']:
        if not has_schema:
            steps.append(AutonomousStep('descobrir_schema', 'Buscar tabelas e colunas candidatas no Oracle.', 'find_tables'))
        steps.append(AutonomousStep('gerar_sql_segura', 'Gerar SQL Oracle somente SELECT/WITH usando schema validado.', 'generate_sql'))
        steps.append(AutonomousStep('validar_sql', 'Validar read-only, schema, semântica e limite de linhas.', 'validate_sql'))
        if allow_execute_select:
            steps.append(AutonomousStep('executar_select_limitado', 'Executar apenas SELECT validado com limite de linhas.', 'run_select', risk='medium'))
    if info['wants_tuning']:
        steps.append(AutonomousStep('sugerir_tuning', 'Sugerir índices/tuning sem executar alterações.', 'suggest_indexes', risk='low'))
    if not steps:
        steps.append(AutonomousStep('responder_com_memoria', 'Responder usando memória, RAG e regras aprendidas disponíveis.', 'reasoning'))
    return AutonomousPlan(question=question, mode=mode, risk=info['risk'], blocked=False, steps=steps)
