from __future__ import annotations

import re
from typing import Any


CODE_FENCE_RE = re.compile(r"```(?P<lang>[A-Za-z0-9_+.#-]*)\s*\n(?P<code>.*?)```", re.DOTALL)


def detect_codex_intent(question: str, sql: str = "", mode: str = "auto") -> dict[str, Any]:
    """Classifica a intenção principal da pergunta para a aba Codex Consultor.

    A classificação é propositalmente simples e determinística. O objetivo é
    decidir o melhor fluxo local sem depender do LLM para roteamento básico.
    """
    q = (question or "").lower()
    s = (sql or "").strip().lower()
    requested = (mode or "auto").strip().lower()

    if requested and requested not in {"auto", "consultor"}:
        return {"name": requested, "reason": "modo escolhido na interface"}

    if s and any(w in q for w in ("tuning", "índice", "indice", "plano", "explain", "performance", "custo alto")):
        return {"name": "tuning_sql", "reason": "há SQL informada e a pergunta pede análise de performance"}

    code_words = (
        "view", "procedure", "function", "trigger", "package", "pl/sql", "plsql",
        "python", "streamlit", "fastapi", "javascript", "html", "css", "bat", "powershell",
        "código", "codigo", "programa", "script", "arquivo", "zip", "implemente", "corrija",
        "gere um código", "gerar código", "create or replace", "alter table", "create table",
    )
    if any(w in q for w in code_words):
        return {"name": "code_generation", "reason": "pergunta pede geração/correção de código ou objeto técnico"}

    sql_words = (
        "select", "query", "consulta", "sql", "relatório", "relatorio", "listar", "liste",
        "mostre", "traga", "buscar", "extrair", "indicador", "dashboard", "power bi", "bi",
    )
    if any(w in q for w in sql_words):
        return {"name": "sql_generation", "reason": "pergunta pede consulta/relatório SQL"}

    rag_words = ("documento", "pdf", "manual", "arquivo anexado", "texto anexado", "base de conhecimento", "rag")
    if any(w in q for w in rag_words):
        return {"name": "rag_explanation", "reason": "pergunta cita documentos/base de conhecimento"}

    dba_words = ("ora-", "oracle", "datapump", "expdp", "impdp", "listener", "scheduler", "awr", "addm", "tablespace", "sessão", "sessao", "lock")
    if any(w in q for w in dba_words):
        return {"name": "dba_explanation", "reason": "pergunta é de suporte/DBA Oracle"}

    return {"name": "general_explanation", "reason": "pergunta geral; responder como consultor técnico"}


def _safe_get(d: dict[str, Any], *names: str, default: Any = "") -> Any:
    for name in names:
        if name in d and d.get(name) is not None:
            return d.get(name)
    return default


def compact_schema_context(schema_package: dict[str, Any] | None, selected_tables: list[str] | None = None, max_tables: int = 12, max_columns: int = 24) -> str:
    """Monta um contexto compacto de tabelas/colunas para prompt."""
    if not schema_package:
        return "Nenhum pacote de schema foi informado/carregado."

    selected = [str(x).upper() for x in (selected_tables or []) if str(x).strip()]
    grouped = schema_package.get("grouped_columns") or {}
    candidates = schema_package.get("candidate_tables") or []
    relationships = schema_package.get("relationships") or schema_package.get("constraints") or schema_package.get("foreign_keys") or []

    table_names: list[str] = []
    if selected:
        table_names.extend(selected)
    for item in candidates:
        name = str(_safe_get(item, "table_name", "object_name", "OBJECT_NAME", default="")).upper()
        if name and name not in table_names:
            table_names.append(name)
        if len(table_names) >= max_tables:
            break
    table_names = table_names[:max_tables]

    lines: list[str] = []
    owner = schema_package.get("owner") or schema_package.get("schema") or ""
    module = schema_package.get("module_name") or schema_package.get("resolved_inputs", {}).get("module_name") or ""
    if owner:
        lines.append(f"OWNER/SCHEMA: {owner}")
    if module:
        lines.append(f"MÓDULO: {module}")
    if schema_package.get("warnings"):
        lines.append("AVISOS DO SCHEMA: " + " | ".join(map(str, schema_package.get("warnings")[:5])))

    for table in table_names:
        cols = grouped.get(table) or grouped.get(table.upper()) or []
        col_text: list[str] = []
        for c in cols[:max_columns]:
            col_name = _safe_get(c, "COLUMN_NAME", "name", "column_name", default="")
            data_type = _safe_get(c, "DATA_TYPE", "data_type", default="")
            nullable = _safe_get(c, "NULLABLE", "nullable", default="")
            if col_name:
                suffix = f" {data_type}".strip()
                if nullable:
                    suffix += f" NULLABLE={nullable}"
                col_text.append(f"{col_name}({suffix})" if suffix else str(col_name))
        if col_text:
            lines.append(f"TABELA {table}: " + ", ".join(col_text))
        else:
            lines.append(f"TABELA {table}: colunas não carregadas no contexto compacto.")

    rel_lines: list[str] = []
    for r in relationships[:30] if isinstance(relationships, list) else []:
        if not isinstance(r, dict):
            continue
        src_table = str(_safe_get(r, "table_name", "source_table", "TABLE_NAME", default="")).upper()
        dst_table = str(_safe_get(r, "ref_table_name", "target_table", "R_TABLE_NAME", "REFERENCED_TABLE_NAME", default="")).upper()
        src_col = _safe_get(r, "column_name", "source_column", "COLUMN_NAME", default="")
        dst_col = _safe_get(r, "ref_column_name", "target_column", "R_COLUMN_NAME", "REFERENCED_COLUMN_NAME", default="")
        if src_table and dst_table:
            rel_lines.append(f"{src_table}.{src_col} -> {dst_table}.{dst_col}")
    if rel_lines:
        lines.append("RELACIONAMENTOS/FKs relevantes:\n" + "\n".join(rel_lines[:20]))

    return "\n".join(lines) if lines else "Pacote de schema presente, mas sem tabelas/colunas compactáveis."


def format_evidence(evidence: list[dict[str, Any]] | None, max_items: int = 5) -> str:
    if not evidence:
        return "Nenhuma evidência RAG/documental foi usada."
    lines = []
    for i, item in enumerate(evidence[:max_items], start=1):
        source = item.get("source") or item.get("doc") or item.get("path") or item.get("title") or f"evidência {i}"
        score = item.get("score")
        text = str(item.get("text") or item.get("chunk") or item.get("content") or "")[:900]
        prefix = f"[{i}] {source}"
        if score is not None:
            prefix += f" score={score}"
        lines.append(prefix + "\n" + text)
    return "\n\n".join(lines)


def extract_code_blocks(answer: str) -> list[dict[str, str]]:
    blocks: list[dict[str, str]] = []
    for m in CODE_FENCE_RE.finditer(answer or ""):
        lang = (m.group("lang") or "text").strip() or "text"
        code = (m.group("code") or "").strip()
        if code:
            blocks.append({"language": lang, "code": code})
    return blocks


def build_consultor_system_prompt() -> str:
    return """
Você é um Consultor Oracle DBA/ERP Globus e assistente de código dentro de uma IA local.
Seu comportamento deve ser parecido com um especialista que explica bem antes de entregar código:
- Responda em português do Brasil, de forma objetiva e técnica.
- Mostre raciocínio operacional resumido, não cadeia de pensamento privada: entendimento, decisões tomadas, validações e riscos.
- Nunca invente tabela, coluna ou relacionamento. Se o contexto não trouxer a coluna/tabela, diga que precisa validar no dicionário.
- Quando gerar SQL Oracle, prefira código compatível com Oracle 11g/19c, aliases claros e comentários úteis.
- Quando gerar CREATE VIEW/PLSQL/scripts, entregue código completo em bloco ```sql ou linguagem adequada.
- Explique como executar, como testar e quais erros comuns observar.
- Para DDL/DML destrutivo, gere apenas como orientação e recomende homologação/backup; não incentive execução cega em produção.
- Se houver SQL gerada/validada por ferramenta, use-a como base e explique as validações.
- Se faltarem dados, faça melhor esforço com as informações disponíveis e marque claramente as premissas.
Formato recomendado da resposta:
1) Entendimento
2) Melhor caminho
3) Solução / Código
4) Como validar
5) Observações de segurança/performance
""".strip()


def build_consultor_user_prompt(
    question: str,
    intent: dict[str, Any],
    owner: str = "",
    module_name: str = "",
    schema_context: str = "",
    generated_sql: str = "",
    validation: dict[str, Any] | None = None,
    rag_answer: str = "",
    rag_evidence: list[dict[str, Any]] | None = None,
    current_sql: str = "",
    tool_steps: list[dict[str, Any]] | None = None,
) -> str:
    validation_text = ""
    if validation:
        validation_text = str(validation)[:5000]
    steps_text = "\n".join([f"- {s}" for s in (tool_steps or [])]) or "Nenhuma etapa automática executada."
    parts = [
        "PERGUNTA DO USUÁRIO:",
        question or "",
        "",
        "INTENÇÃO DETECTADA:",
        f"{intent.get('name')} - {intent.get('reason')}",
        "",
        "CONTEXTO OPERACIONAL:",
        f"OWNER: {owner or '(não informado)'}",
        f"MÓDULO: {module_name or '(não informado)'}",
        "",
        "ETAPAS AUTOMÁTICAS JÁ REALIZADAS:",
        steps_text,
        "",
        "CONTEXTO DE SCHEMA/TABELAS/COLUNAS:",
        schema_context or "Nenhum contexto de schema.",
    ]
    if generated_sql:
        parts.extend(["", "SQL GERADA/VALIDADA PELO PIPELINE LOCAL:", generated_sql])
    if validation_text:
        parts.extend(["", "RESULTADO DA VALIDAÇÃO:", validation_text])
    if current_sql:
        parts.extend(["", "SQL/CÓDIGO INFORMADO PELO USUÁRIO NA TELA:", current_sql[:8000]])
    if rag_answer or rag_evidence:
        parts.extend(["", "RESPOSTA/EVIDÊNCIA RAG:", rag_answer[:4000] if rag_answer else "", format_evidence(rag_evidence)])
    parts.extend([
        "",
        "TAREFA:",
        "Responda ao usuário como um consultor técnico. Entregue explicação e código quando aplicável. "
        "Se houver SQL ou código, inclua em bloco markdown apropriado. Não invente estruturas ausentes do contexto.",
    ])
    return "\n".join(parts)
