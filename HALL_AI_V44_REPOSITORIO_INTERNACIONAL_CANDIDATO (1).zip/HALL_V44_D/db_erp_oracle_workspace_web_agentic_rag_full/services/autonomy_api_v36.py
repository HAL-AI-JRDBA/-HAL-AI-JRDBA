from __future__ import annotations
import base64
import os
import threading
from pathlib import Path
from fastapi import HTTPException, Request
from fastapi.responses import FileResponse, PlainTextResponse
from .local_agent_v40 import LocalAgentEngine as AgentEngine, LocalTools as Tools
from .autonomy_channels_v36 import Channels


def register(app,root,require_admin,bridge,mcp_factory,secure_factory):
    lock=threading.Lock();state={}
    def service():
        with lock:
            if not state:
                tools=Tools(root,bridge=bridge,mcp=lambda sid,name,args,actor:mcp_factory().call_remote_tool(sid,name,args,actor,approved=True))
                engine=AgentEngine(root,tools);channels=Channels(engine)
                engine.channels=channels
                tools.cancelled=lambda tid:engine.get(tid)["state"]=="cancelled"
                state.update(engine=engine,channels=channels)
            return state['engine']
    def guard(request):
        # Reject cross-site mutations even if a browser happens to have an IAM cookie.
        if request.method not in {'GET','HEAD'}:
            origin=request.headers.get('origin')
            if origin and origin.rstrip('/')!=str(request.base_url).rstrip('/'):
                raise HTTPException(403,'Origem não autorizada.')
        return require_admin(request)
    def owner(request):return str(guard(request).get('username') or 'admin')
    def run_action(fn):
        try:return fn()
        except KeyError as exc:raise HTTPException(404,str(exc)) from None
        except (ValueError,TypeError) as exc:raise HTTPException(400,str(exc)) from None

    @app.on_event('startup')
    def startup():
        if os.getenv('HALL_V36_AUTOSTART','0')=='1':service().start()
    @app.on_event('shutdown')
    def shutdown():
        if state:state['engine'].stop()

    @app.get('/api/v36/status')
    def status(request:Request):
        guard(request);engine=service()
        return {**engine.status(),'channels':state['channels'].status(),'tools':engine.tools.catalog()}
    @app.get('/api/v36/config')
    def config(request:Request):
        guard(request);return service().tools.config()
    @app.put('/api/v36/config')
    def update_config(request:Request,payload:dict):
        actor=owner(request)
        def apply():
            engine=service();result=engine.tools.save_config(payload)
            with engine.db() as c:
                c.execute('BEGIN IMMEDIATE');engine.audit(c,'config_updated',detail={'actor':actor,'keys':list(payload)});c.commit()
            return result
        return run_action(apply)
    @app.post('/api/v36/worker/start')
    def start(request:Request):
        actor=owner(request);engine=service();engine.set_paused(False,actor);engine.start();return engine.status()
    @app.post('/api/v36/worker/pause')
    def pause(request:Request):
        actor=owner(request);engine=service();engine.set_paused(True,actor);return engine.status()
    @app.get('/api/v36/tasks')
    def tasks(request:Request):
        guard(request);return {'tasks':service().list()}
    @app.post('/api/v36/tasks')
    def create(request:Request,payload:dict):
        actor=owner(request)
        return run_action(lambda:service().create(actor,payload.get('objective',''),payload.get('options',{})))
    @app.get('/api/v36/tasks/{tid}')
    def get(request:Request,tid:str):
        guard(request);return run_action(lambda:service().get(tid))
    @app.post('/api/v36/tasks/{tid}/approve')
    def approve(request:Request,tid:str,payload:dict):
        actor=owner(request)
        return run_action(lambda:service().approve(tid,payload.get('step_id'),actor,payload.get('args_hash','')))
    @app.post('/api/v36/tasks/{tid}/cancel')
    def cancel(request:Request,tid:str):
        actor=owner(request);return run_action(lambda:service().cancel(tid,actor))
    @app.post('/api/v36/tasks/{tid}/retry')
    def retry(request:Request,tid:str):
        actor=owner(request);return run_action(lambda:service().retry(tid,actor))
    @app.post('/api/v36/tasks/{tid}/files')
    def upload(request:Request,tid:str,payload:dict):
        actor=owner(request)
        def save():
            engine=service();task=engine.get(tid)
            if task['state']!='queued' or task['steps']:
                raise ValueError('Anexe antes de iniciar o worker ou criar etapas.')
            name=str(payload.get('filename',''))
            if Path(name).suffix.lower() not in {'.csv','.txt','.md','.json','.py'}:
                raise ValueError('Extensão de entrada não permitida.')
            encoded=str(payload.get('base64',''))
            if len(encoded)>2800000:raise ValueError('Arquivo excede 2 MB.')
            content=base64.b64decode(encoded,validate=True)
            if len(content)>2_000_000:raise ValueError('Arquivo excede 2 MB.')
            p=engine.tools.path(task,name)
            if p.exists():raise ValueError('Arquivo já existe; use outro nome.')
            p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(content)
            with engine.db() as c:
                c.execute('BEGIN IMMEDIATE');engine.audit(c,'input_uploaded',tid,{'actor':actor,'path':name});c.commit()
            return {'ok':True,'filename':name}
        return run_action(save)
    @app.get('/api/v36/tasks/{tid}/artifacts')
    def artifacts(request:Request,tid:str,path:str):
        guard(request)
        def retrieve():
            engine=service();task=engine.get(tid);p=engine.tools.path(task,path)
            # Only expose evidence-backed outputs, never arbitrary runtime files.
            evidence=[e for s in task['steps'] for e in (s.get('result') or {}).get('evidence',[])]
            if not any(e.get('path')==path for e in evidence):raise KeyError('Artefato não registrado.')
            if not p.is_file():raise KeyError('Artefato indisponível.')
            return FileResponse(p,filename=p.name)
        return run_action(retrieve)
    @app.get('/api/v36/schedules')
    def schedules(request:Request):
        guard(request);return {'schedules':service().schedules()}
    @app.post('/api/v36/schedules')
    def schedule(request:Request,payload:dict):
        actor=owner(request)
        return run_action(lambda:service().schedule(actor,payload.get('objective',''),payload.get('interval_s',3600),payload.get('options',{}),payload.get('first_run')))
    @app.delete('/api/v36/schedules/{sid}')
    def disable(request:Request,sid:str):
        actor=owner(request);service().disable_schedule(sid,actor);return {'ok':True}
    @app.get('/api/v36/audit/verify')
    def audit(request:Request):
        guard(request);return service().verify_audit()
    @app.post('/api/v36/channels/slack/events')
    async def slack(request:Request):
        raw=await request.body()
        if len(raw)>100000:raise HTTPException(413,'Evento muito grande.')
        try:return state.get('channels',None).slack(raw,dict(request.headers)) if state else service().channels.slack(raw,dict(request.headers))
        except ValueError as exc:raise HTTPException(403,str(exc)) from None

    @app.get('/api/v36/channels/whatsapp/webhook')
    def whatsapp_challenge(request:Request):
        from .whatsapp_v361 import challenge
        try:return PlainTextResponse(challenge(service().tools,request.query_params))
        except ValueError as exc:raise HTTPException(403,str(exc)) from None
    @app.post('/api/v36/channels/whatsapp/webhook')
    async def whatsapp_events(request:Request):
        from .whatsapp_v361 import receive
        raw=await request.body()
        if len(raw)>500000:raise HTTPException(413,'Evento muito grande.')
        try:return receive(service().channels,raw,dict(request.headers))
        except ValueError as exc:raise HTTPException(403,str(exc)) from None
    @app.get('/api/v36/channels/whatsapp/status')
    def whatsapp_status(request:Request):
        guard(request)
        from .whatsapp_v361 import status
        return status(service())

    # V33 missions now use the same real tools and evidence verifier.
    def secure_connector(connector,payload):
        engine=service();action=payload.get('action');context=payload.get('context',{})
        mapping={'browser_read':'research','research':'research','database_read':'database','email_read':'email_read',
                 'send_email':'email_send','send_message':'message','calendar_read':'local_read','file_write':'document'}
        tool=mapping.get(action)
        if not tool:return {'ok':False,'detail':'Ação sem executor V36; use uma missão V36 com ferramenta explícita.'}
        # V33 only supplies exact tool arguments reviewed as part of its mission context.
        args=context.get('tool_args')
        if not isinstance(args,dict):return {'ok':False,'detail':'context.tool_args obrigatório; objetivo textual não basta para uma ação real.'}
        task={'id':'legacy_'+str(context.get('mission_workspace') or 'shared'),'owner':str(context.get('owner') or 'admin'),'objective':payload.get('objective','')}
        # Stable but constrained legacy workspace name.
        import re
        if not re.fullmatch('[A-Za-z0-9_-]{1,100}',task['id']):return {'ok':False,'detail':'Workspace inválido.'}
        try:
            result=engine.tools.execute(tool,args,task)
            if result.get('ok') and engine.tools.verify(tool,result,task):return result
            return {'ok':False,'detail':'Executor não confirmou o resultado.'}
        except Exception as exc:return {'ok':False,'detail':str(exc)[:1000]}
    return {'service':service,'secure_connector':secure_connector}
