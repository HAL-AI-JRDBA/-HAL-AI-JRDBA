from __future__ import annotations

ACTIONS = [
    {
        'name': 'template_strict',
        'max_catalog': 8,
        'max_hops': 1,
        'prefer_template': True,
        'rag_mode': 'hybrid',
    },
    {
        'name': 'balanced_hybrid',
        'max_catalog': 12,
        'max_hops': 2,
        'prefer_template': False,
        'rag_mode': 'hybrid',
    },
    {
        'name': 'vectorless_structured',
        'max_catalog': 10,
        'max_hops': 2,
        'prefer_template': False,
        'rag_mode': 'vectorless',
    },
    {
        'name': 'traditional_fast',
        'max_catalog': 6,
        'max_hops': 1,
        'prefer_template': False,
        'rag_mode': 'traditional',
    },
]
