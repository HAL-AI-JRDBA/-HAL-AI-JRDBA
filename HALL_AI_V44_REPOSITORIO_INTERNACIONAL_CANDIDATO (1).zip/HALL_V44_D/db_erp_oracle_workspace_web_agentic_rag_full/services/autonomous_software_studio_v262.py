from __future__ import annotations

import json
import re
import time
import uuid
from pathlib import Path
from typing import Any

from .production_quality_gates_v262 import ProductionQualityGate


class AutonomousSoftwareStudioV262:
    """BSPA governado: Brainstorm -> Spec -> Plan -> Audit.

    A camada é deliberadamente local-first e não executa deploy por conta própria.
    Publicação só é liberada quando os gates críticos passam e existe aprovação humana.
    """

    VERSION = "26.2"

    def __init__(self, root_dir: str | Path):
        self.root_dir = Path(root_dir)
        self.data_dir = self.root_dir / 'data' / 'autonomous_software_studio_v262'
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.projects_path = self.data_dir / 'projects.json'
        self.audit_path = self.data_dir / 'audit.jsonl'
        if not self.projects_path.exists():
            self.projects_path.write_text(json.dumps({'projects': []}, ensure_ascii=False, indent=2), encoding='utf-8')
        self.gates = ProductionQualityGate(self.root_dir)

    @staticmethod
    def _norm(text: str) -> str:
        repl = str.maketrans('áàãâéêíóôõúç', 'aaaaeeiooouc')
        return str(text or '').lower().translate(repl)

    def _load(self) -> dict[str, Any]:
        try:
            data = json.loads(self.projects_path.read_text(encoding='utf-8-sig'))
            return data if isinstance(data, dict) else {'projects': []}
        except Exception:
            return {'projects': []}

    def _save(self, data: dict[str, Any]) -> None:
        self.projects_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

    def _audit(self, event: str, payload: dict[str, Any] | None = None) -> None:
        row = {'ts': time.strftime('%Y-%m-%d %H:%M:%S'), 'event': event, 'payload': payload or {}}
        with self.audit_path.open('a', encoding='utf-8') as fh:
            fh.write(json.dumps(row, ensure_ascii=False) + '\n')

    def status(self) -> dict[str, Any]:
        projects = self._load().get('projects', [])
        return {
            'ok': True,
            'name': 'HAL Autonomous Software Studio',
            'version': self.VERSION,
            'method': 'BSPA - Brainstorm, Spec, Plan, Audit',
            'projects_count': len(projects),
            'production_security_baseline': True,
            'backup_restore_gate': True,
            'lgpd_readiness_gate': True,
            'deploy_gate': True,
            'unrestricted_windows_access': False,
            'host_shell_for_generated_apps': False,
        }

    def brainstorm(self, idea: str, app_name: str = '') -> dict[str, Any]:
        idea = (idea or '').strip()
        if not idea:
            return {'ok': False, 'error': 'Informe a ideia do sistema.'}
        n = self._norm(idea)
        project_id = f"studio_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
        domain = 'general'
        if any(x in n for x in ['clinica', 'paciente', 'saude', 'medico']): domain = 'health'
        elif any(x in n for x in ['rh', 'folha', 'funcionario', 'colaborador']): domain = 'hr'
        elif any(x in n for x in ['finance', 'financeiro', 'contabil', 'faturamento']): domain = 'finance'
        elif any(x in n for x in ['crm', 'lead', 'venda', 'comercial']): domain = 'crm'
        elif any(x in n for x in ['transporte', 'frota', 'viagem', 'bilhetagem']): domain = 'transport'

        sensitive = domain in {'health', 'hr', 'finance'} or any(x in n for x in ['cpf','cnpj','senha','cartao','salario','prontuario'])
        questions = [
            {'id': 'users', 'question': 'Quem utilizará o sistema e quais perfis/papéis existirão?', 'required': True},
            {'id': 'core_process', 'question': 'Qual processo principal deve ser resolvido do início ao fim?', 'required': True},
            {'id': 'modules', 'question': 'Quais módulos/telas são obrigatórios no primeiro release?', 'required': True},
            {'id': 'integrations', 'question': 'Quais bancos, ERPs, APIs, WhatsApp, e-mail ou serviços precisam integrar?', 'required': False},
            {'id': 'deploy', 'question': 'Onde será executado: local, intranet, VPS, cloud ou on-premise?', 'required': True},
            {'id': 'availability', 'question': 'Qual disponibilidade, volume de usuários e janela de manutenção esperados?', 'required': False},
            {'id': 'data_class', 'question': 'Que tipos de dados pessoais, sensíveis, financeiros ou confidenciais serão tratados?', 'required': True},
            {'id': 'retention', 'question': 'Qual prazo de retenção e regra de exclusão/exportação dos dados?', 'required': sensitive},
            {'id': 'audit', 'question': 'Quais ações precisam de auditoria e aprovação humana?', 'required': True},
            {'id': 'backup', 'question': 'Qual RPO/RTO desejado para backup e recuperação?', 'required': True},
            {'id': 'acceptance', 'question': 'Quais resultados objetivos definem que o sistema está pronto?', 'required': True},
        ]
        project = {
            'id': project_id,
            'name': app_name or self._suggest_name(idea),
            'idea': idea,
            'domain': domain,
            'sensitive_data_expected': sensitive,
            'phase': 'brainstorm',
            'brainstorm': {'questions': questions, 'answers': {}},
            'spec': {}, 'plan': {}, 'audit': {},
            'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
            'updated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        }
        data = self._load(); data.setdefault('projects', []).insert(0, project); self._save(data)
        self._audit('brainstorm_created', {'project_id': project_id, 'domain': domain})
        return {'ok': True, 'project': project, 'questions': questions, 'next': 'spec'}

    def _suggest_name(self, idea: str) -> str:
        n = self._norm(idea)
        if 'crm' in n: return 'HAL CRM Pro'
        if 'clinica' in n: return 'HAL Clinic Pro'
        if 'transporte' in n: return 'HAL Transport Pro'
        if 'finance' in n: return 'HAL Finance Pro'
        return 'HAL Business App'

    def _get(self, project_id: str) -> tuple[dict[str, Any] | None, dict[str, Any]]:
        data = self._load()
        for p in data.get('projects', []):
            if p.get('id') == project_id:
                return p, data
        return None, data

    def spec(self, project_id: str, answers: dict[str, Any] | None = None) -> dict[str, Any]:
        project, data = self._get(project_id)
        if not project: return {'ok': False, 'error': 'Projeto não encontrado.'}
        answers = answers or {}
        project['brainstorm']['answers'].update(answers)
        idea = project['idea']; n = self._norm(idea)
        roles = ['admin', 'user']
        if project['domain'] == 'crm': roles += ['sales_manager', 'sales_rep']
        if project['domain'] == 'hr': roles += ['hr_manager', 'employee']
        if project['domain'] == 'finance': roles += ['controller', 'analyst']
        if project['domain'] == 'transport': roles += ['operations', 'revenue', 'finance']
        entities = self._infer_entities(project['domain'])
        modules = self._infer_modules(project['domain'], idea)
        spec = {
            'prd_version': '1.0',
            'objective': idea,
            'actors_roles': list(dict.fromkeys(roles)),
            'modules': modules,
            'entities': entities,
            'functional_requirements': [
                'Autenticação sem credenciais padrão/hardcoded.',
                'RBAC em rotas e ações sensíveis.',
                'CRUD e consultas parametrizadas.',
                'Auditoria de login, alteração, exclusão, exportação e ações administrativas.',
                'Exportação/relatório conforme permissões.',
            ],
            'non_functional_requirements': {
                'security': 'Production Security Baseline V26.2',
                'privacy': 'LGPD Readiness Gate; não equivale a parecer jurídico.',
                'availability': answers.get('availability') or 'Definir antes do deploy.',
                'backup': answers.get('backup') or 'Backup automatizado + restore test obrigatório.',
                'performance': 'Paginação/limites, índices conforme banco e teste de carga proporcional.',
                'accessibility': 'HTML semântico, labels, teclado e contraste no quality gate.',
                'responsive': 'Layout responsivo obrigatório.',
            },
            'data_governance': {
                'classification': 'confidential' if project.get('sensitive_data_expected') else 'internal',
                'retention': answers.get('retention') or 'Definir política de retenção.',
                'data_subject_rights': ['access', 'correction', 'export', 'deletion_request'],
                'minimization_required': True,
            },
            'security_controls': self.gates.required_security_controls(),
            'acceptance_criteria': [
                'Todos os testes funcionais críticos passam.',
                'Security Gate sem achado crítico.',
                'Backup criado e restore drill aprovado.',
                'LGPD Readiness sem pendência crítica.',
                'Deploy Readiness aprovado.',
                'Aprovação humana antes da publicação.',
            ],
        }
        project['spec'] = spec; project['phase'] = 'spec'; project['updated_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
        self._save(data); self._audit('spec_created', {'project_id': project_id})
        return {'ok': True, 'project_id': project_id, 'spec': spec, 'next': 'plan'}

    def _infer_entities(self, domain: str) -> list[str]:
        return {
            'crm': ['users','roles','leads','opportunities','activities','tasks','audit_log'],
            'health': ['users','roles','patients','appointments','encounters','consents','audit_log'],
            'hr': ['users','roles','employees','departments','payroll_refs','requests','audit_log'],
            'finance': ['users','roles','accounts','transactions','cost_centers','budgets','audit_log'],
            'transport': ['users','roles','vehicles','trips','routes','revenue_events','audit_log'],
        }.get(domain, ['users','roles','records','settings','audit_log'])

    def _infer_modules(self, domain: str, idea: str) -> list[str]:
        base = ['Authentication','RBAC','Dashboard','Audit','Settings','Privacy Center','Backup/Restore']
        extra = {
            'crm': ['Leads','Pipeline','Opportunities','Follow-up'],
            'health': ['Patients','Scheduling','Clinical Records'],
            'hr': ['Employees','HR Requests','Payroll Integration'],
            'finance': ['Transactions','Cash Flow','DRE/KPIs'],
            'transport': ['Fleet','Trips','Revenue','Operations'],
        }.get(domain, ['Core Business CRUD'])
        return base + extra

    def plan(self, project_id: str) -> dict[str, Any]:
        project, data = self._get(project_id)
        if not project: return {'ok': False, 'error': 'Projeto não encontrado.'}
        if not project.get('spec'):
            self.spec(project_id, {})
            project, data = self._get(project_id)
        plan = {
            'architecture': {
                'default': 'FastAPI + frontend web + banco selecionado + Docker opcional',
                'principles': ['local-first', 'least privilege', 'secure by default', 'observable', 'rollbackable'],
            },
            'phases': [
                {'id': 1, 'name': 'Foundation', 'tasks': ['estrutura','config/env','logging','health','migrations']},
                {'id': 2, 'name': 'Security', 'tasks': ['auth hash','signed session','CSRF','rate limit','RBAC','headers','audit']},
                {'id': 3, 'name': 'Domain', 'tasks': project['spec'].get('modules', [])},
                {'id': 4, 'name': 'Quality', 'tasks': ['unit tests','integration','SAST heuristics','responsive/accessibility']},
                {'id': 5, 'name': 'Privacy', 'tasks': ['data map','retention','DSAR workflow','export/delete request']},
                {'id': 6, 'name': 'Resilience', 'tasks': ['backup','restore drill','rollback']},
                {'id': 7, 'name': 'Release', 'tasks': ['production gate','deploy manifest','human approval','publish']},
            ],
            'mandatory_gates': ['functional','security','backup_restore','lgpd_readiness','responsive_accessibility','deploy_readiness','human_approval'],
            'deploy_policy': 'deny_by_default_until_all_critical_gates_pass',
        }
        project['plan'] = plan; project['phase'] = 'plan'; project['updated_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
        self._save(data); self._audit('plan_created', {'project_id': project_id})
        return {'ok': True, 'project_id': project_id, 'plan': plan, 'next': 'build_or_audit'}

    def audit(self, project_id: str, app_path: str, production_env: dict[str, Any] | None = None) -> dict[str, Any]:
        project, data = self._get(project_id)
        if not project: return {'ok': False, 'error': 'Projeto não encontrado.'}
        result = self.gates.run_all(app_path, production_env or {})
        project['audit'] = result; project['phase'] = 'audit'; project['updated_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
        self._save(data); self._audit('audit_completed', {'project_id': project_id, 'deploy_allowed': result.get('deploy_allowed')})
        return {'ok': True, 'project_id': project_id, 'audit': result}

    def list_projects(self, limit: int = 100) -> dict[str, Any]:
        rows = self._load().get('projects', [])[:max(1, min(int(limit or 100), 500))]
        return {'ok': True, 'projects': rows, 'count': len(rows)}
