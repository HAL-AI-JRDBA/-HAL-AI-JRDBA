from __future__ import annotations

import re
from typing import Iterable


def _sanitize_identifier(name: str) -> str:
    name = (name or '').strip().upper()
    return re.sub(r'[^A-Z0-9_#$]', '_', name)


def _oracle_type(column: dict) -> str:
    dtype = str(column.get('DATA_TYPE') or 'VARCHAR2').upper()
    data_length = int(column.get('DATA_LENGTH') or 0)
    if dtype in {'VARCHAR2', 'CHAR', 'NCHAR', 'NVARCHAR2', 'RAW'} and data_length > 0:
        return f"{dtype}({data_length})"
    return dtype


def _pk_map(schema_package: dict) -> dict[str, list[str]]:
    result: dict[str, list[str]] = {}
    for row in schema_package.get('candidate_tables', []) or []:
        table = str(row.get('table_name') or '').upper()
        raw = str(row.get('pk_columns') or '').strip()
        if table and raw and raw.lower() != 'sem pk visível':
            result[table] = [c.strip().upper() for c in raw.split(',') if c.strip()]
    return result


def _join_pairs(join_sql: str) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    for part in re.split(r'\s+AND\s+', join_sql or '', flags=re.IGNORECASE):
        m = re.match(r'a\.([A-Z0-9_#$]+)\s*=\s*b\.([A-Z0-9_#$]+)', part.strip(), flags=re.IGNORECASE)
        if m:
            pairs.append((m.group(1).upper(), m.group(2).upper()))
    return pairs


def _filter_tables(grouped_columns: dict, selected_tables: Iterable[str] | None) -> dict[str, list[dict]]:
    if not selected_tables:
        return grouped_columns
    allowed = {_sanitize_identifier(t) for t in selected_tables if str(t).strip()}
    return {k: v for k, v in grouped_columns.items() if _sanitize_identifier(k) in allowed}


def build_chartdb_ddl(schema_package: dict, owner: str, selected_tables: Iterable[str] | None = None) -> str:
    grouped = _filter_tables(schema_package.get('grouped_columns', {}) or {}, selected_tables)
    if not grouped:
        return '-- Nenhum schema carregado para exportar ao ChartDB.\n'

    owner = _sanitize_identifier(owner or 'SCHEMA')
    pk_map = _pk_map(schema_package)
    statements: list[str] = []
    for table_name, cols in grouped.items():
        safe_table = _sanitize_identifier(table_name)
        lines: list[str] = []
        for col in cols:
            col_name = _sanitize_identifier(col.get('COLUMN_NAME') or 'COLUNA')
            col_type = _oracle_type(col)
            nullable = str(col.get('NULLABLE') or 'Y').upper() != 'N'
            line = f'    {col_name} {col_type}'
            if not nullable:
                line += ' NOT NULL'
            lines.append(line)
        pk_cols = [c for c in pk_map.get(safe_table, []) if c]
        if pk_cols:
            pk_name = _sanitize_identifier(f'PK_{safe_table}')[:30]
            lines.append(f"    CONSTRAINT {pk_name} PRIMARY KEY ({', '.join(pk_cols)})")
        statements.append(f"CREATE TABLE {owner}.{safe_table} (\n" + ',\n'.join(lines) + '\n);')

    fk_seen: set[tuple[str, str, tuple[tuple[str, str], ...]]] = set()
    for idx, item in enumerate(schema_package.get('join_suggestions', []) or [], start=1):
        if str(item.get('join_type')).upper() != 'FK':
            continue
        left = _sanitize_identifier(item.get('left_table') or '')
        right = _sanitize_identifier(item.get('right_table') or '')
        if left not in grouped or right not in grouped:
            continue
        pairs = tuple(_join_pairs(item.get('join_sql') or ''))
        if not pairs:
            continue
        sig = (left, right, pairs)
        if sig in fk_seen:
            continue
        fk_seen.add(sig)
        fk_name = _sanitize_identifier(f'FK_{left}_{right}_{idx}')[:30]
        child_cols = ', '.join([a for a, _ in pairs])
        parent_cols = ', '.join([b for _, b in pairs])
        statements.append(
            f"ALTER TABLE {owner}.{left} ADD CONSTRAINT {fk_name} FOREIGN KEY ({child_cols}) REFERENCES {owner}.{right} ({parent_cols});"
        )

    return '\n\n'.join(statements) + '\n'


def build_chartdb_dbml(schema_package: dict, owner: str, selected_tables: Iterable[str] | None = None) -> str:
    grouped = _filter_tables(schema_package.get('grouped_columns', {}) or {}, selected_tables)
    if not grouped:
        return '// Nenhum schema carregado para exportar ao ChartDB.\n'

    owner = _sanitize_identifier(owner or 'SCHEMA')
    pk_map = _pk_map(schema_package)
    blocks: list[str] = []
    for table_name, cols in grouped.items():
        safe_table = _sanitize_identifier(table_name)
        pk_cols = set(pk_map.get(safe_table, []))
        lines = [f'Table {owner}.{safe_table} {{']
        for col in cols:
            col_name = _sanitize_identifier(col.get('COLUMN_NAME') or 'COLUNA')
            col_type = _oracle_type(col).lower()
            attrs: list[str] = []
            if col_name in pk_cols:
                attrs.append('pk')
            if str(col.get('NULLABLE') or 'Y').upper() == 'N':
                attrs.append('not null')
            attr_text = f" [{', '.join(attrs)}]" if attrs else ''
            lines.append(f'  {col_name} {col_type}{attr_text}')
        lines.append('}')
        blocks.append('\n'.join(lines))

    refs: list[str] = []
    seen_refs: set[tuple[str, str, str, str]] = set()
    for item in schema_package.get('join_suggestions', []) or []:
        if str(item.get('join_type')).upper() != 'FK':
            continue
        left = _sanitize_identifier(item.get('left_table') or '')
        right = _sanitize_identifier(item.get('right_table') or '')
        if left not in grouped or right not in grouped:
            continue
        for left_col, right_col in _join_pairs(item.get('join_sql') or ''):
            sig = (left, left_col, right, right_col)
            if sig in seen_refs:
                continue
            seen_refs.add(sig)
            refs.append(f'Ref: {owner}.{left}.{left_col} > {owner}.{right}.{right_col}')

    payload = '\n\n'.join(blocks)
    if refs:
        payload += '\n\n' + '\n'.join(refs)
    return payload + '\n'
