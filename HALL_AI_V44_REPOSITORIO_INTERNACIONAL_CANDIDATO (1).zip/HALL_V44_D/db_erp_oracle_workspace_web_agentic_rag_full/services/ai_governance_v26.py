from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import threading
import time
import unicodedata
import uuid
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urlparse


DATA_CLASS_ORDER = {"public": 0, "internal": 1, "confidential": 2, "restricted": 3}
RISK_LEVELS = ((30, "low"), (60, "medium"), (80, "high"), (101, "critical"))
REGISTRY_KINDS = {"applications", "providers", "models", "use_cases", "policies", "connectors", "risk_intel"}


def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def _norm(value: str) -> str:
    raw = unicodedata.normalize("NFKD", str(value or ""))
    raw = "".join(c for c in raw if not unicodedata.combining(c))
    return " ".join(raw.lower().replace("_", " ").replace("-", " ").split())


def _id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:14]}"


def _risk_level(score: int) -> str:
    score = max(0, min(int(score), 100))
    for ceiling, name in RISK_LEVELS:
        if score < ceiling:
            return name
    return "critical"


def _safe_json_load(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return default


def _luhn(number: str) -> bool:
    digits = [int(x) for x in re.sub(r"\D", "", number)]
    if not 13 <= len(digits) <= 19:
        return False
    checksum = 0
    parity = len(digits) % 2
    for i, d in enumerate(digits):
        if i % 2 == parity:
            d *= 2
            if d > 9:
                d -= 9
        checksum += d
    return checksum % 10 == 0


def _cpf_valid(value: str) -> bool:
    digits = re.sub(r"\D", "", value)
    if len(digits) != 11 or digits == digits[0] * 11:
        return False
    for pos in (9, 10):
        total = sum(int(digits[i]) * ((pos + 1) - i) for i in range(pos))
        check = (total * 10) % 11
        if check == 10:
            check = 0
        if check != int(digits[pos]):
            return False
    return True


def _cnpj_valid(value: str) -> bool:
    digits = re.sub(r"\D", "", value)
    if len(digits) != 14 or digits == digits[0] * 14:
        return False
    def digit(base: str, weights: list[int]) -> str:
        total = sum(int(n) * w for n, w in zip(base, weights))
        r = total % 11
        return "0" if r < 2 else str(11 - r)
    d1 = digit(digits[:12], [5,4,3,2,9,8,7,6,5,4,3,2])
    d2 = digit(digits[:12] + d1, [6,5,4,3,2,9,8,7,6,5,4,3,2])
    return digits[-2:] == d1 + d2


class AIGovernanceManager:
    """HAL V26 - Enterprise AI Governance & Shadow AI Defense.

    A camada é intencionalmente independente de fornecedor. Ela não promete descobrir
    tráfego corporativo sem telemetria: proxy/DNS/firewall/endpoint/browser/CASB/SIEM
    devem enviar eventos ao endpoint de ingestão. O HAL então classifica, pontua,
    audita, abre incidentes e recomenda a alternativa corporativa.
    """

    DEFAULT_CONFIG = {
        "enabled": True,
        "prompt_firewall_enabled": True,
        "dlp_enabled": True,
        "shadow_ai_discovery_enabled": True,
        "audit_enabled": True,
        "auto_incident_on_critical": True,
        "auto_incident_on_block": True,
        "unknown_external_app_action": "approval",
        "confidential_external_action": "approval",
        "restricted_external_action": "block",
        "secret_material_action": "block",
        "local_restricted_action": "allow_with_controls",
        "default_corporate_app": "hall",
        "risk_thresholds": {"medium": 30, "high": 60, "critical": 80},
        "weights": {
            "restricted_data": 45,
            "confidential_data": 28,
            "personal_account": 18,
            "unknown_app": 20,
            "blocked_app": 55,
            "external_provider": 12,
            "upload": 12,
            "credential_or_secret": 45,
            "unapproved_model": 15,
            "unapproved_provider": 15,
        },
        "retention_days": {"audit": 365, "telemetry": 180, "incidents": 730},
        "monitoring": {"expected_ingest_interval_minutes": 15, "alert_if_stale_minutes": 60},
    }

    SEED_PROVIDERS = [
        {"id": "hall-local", "name": "HAL Local / Ollama", "status": "approved", "external": False, "data_residency": "local", "dpa": True, "security_review": True, "retention_documented": True, "training_policy_documented": True, "audit_supported": True, "notes": "Padrão corporativo para dados internos/sensíveis."},
        {"id": "hall-approved-web", "name": "HAL Approved Web Research", "status": "approved", "external": True, "data_residency": "internet", "dpa": False, "security_review": True, "retention_documented": False, "training_policy_documented": False, "audit_supported": True, "notes": "Somente pesquisa pública/interna sem dados confidenciais/restritos."},
        {"id": "openai", "name": "OpenAI", "status": "conditional", "external": True, "data_residency": "provider", "notes": "Uso conforme contrato e política corporativa."},
        {"id": "anthropic", "name": "Anthropic", "status": "conditional", "external": True, "data_residency": "provider", "notes": "Uso conforme contrato e política corporativa."},
        {"id": "google", "name": "Google Gemini", "status": "conditional", "external": True, "data_residency": "provider", "notes": "Uso conforme contrato e política corporativa."},
        {"id": "microsoft", "name": "Microsoft Copilot", "status": "conditional", "external": True, "data_residency": "provider", "notes": "Uso conforme tenant/política corporativa."},
    ]

    SEED_APPS = [
        {"id": "hall", "name": "HAL", "provider_id": "hall-local", "status": "approved", "external": False, "domains": [], "allowed_data_classes": ["public", "internal", "confidential", "restricted"], "allowed_departments": ["*"], "account_types": ["corporate"], "replacement": "HAL"},
        {"id": "hall-web-research", "name": "HAL Pesquisa Web Confiável", "provider_id": "hall-approved-web", "status": "approved", "external": True, "domains": [], "allowed_data_classes": ["public", "internal"], "allowed_departments": ["*"], "account_types": ["corporate"], "replacement": "HAL local/RAG"},
        {"id": "chatgpt", "name": "ChatGPT", "provider_id": "openai", "status": "conditional", "external": True, "domains": ["chatgpt.com", "chat.openai.com", "openai.com"], "allowed_data_classes": ["public", "internal"], "allowed_departments": ["*"], "account_types": ["corporate"], "replacement": "HAL"},
        {"id": "claude", "name": "Claude", "provider_id": "anthropic", "status": "conditional", "external": True, "domains": ["claude.ai", "anthropic.com"], "allowed_data_classes": ["public", "internal"], "allowed_departments": ["*"], "account_types": ["corporate"], "replacement": "HAL"},
        {"id": "gemini", "name": "Gemini", "provider_id": "google", "status": "conditional", "external": True, "domains": ["gemini.google.com", "aistudio.google.com"], "allowed_data_classes": ["public", "internal"], "allowed_departments": ["*"], "account_types": ["corporate"], "replacement": "HAL"},
        {"id": "copilot", "name": "Microsoft Copilot", "provider_id": "microsoft", "status": "conditional", "external": True, "domains": ["copilot.microsoft.com", "copilot.cloud.microsoft"], "allowed_data_classes": ["public", "internal"], "allowed_departments": ["*"], "account_types": ["corporate"], "replacement": "HAL"},
        {"id": "perplexity", "name": "Perplexity", "provider_id": "perplexity", "status": "unreviewed", "external": True, "domains": ["perplexity.ai"], "allowed_data_classes": ["public"], "allowed_departments": ["*"], "account_types": ["corporate"], "replacement": "HAL Pesquisa Web Confiável"},
        {"id": "deepseek-web", "name": "DeepSeek Web", "provider_id": "deepseek", "status": "unreviewed", "external": True, "domains": ["chat.deepseek.com", "deepseek.com"], "allowed_data_classes": ["public"], "allowed_departments": ["*"], "account_types": ["corporate"], "replacement": "HAL"},
    ]

    SEED_MODELS = [
        {"id": "hall-chat", "name": "HAL CHAT local", "provider_id": "hall-local", "status": "approved", "roles": ["chat", "dialog"], "external": False},
        {"id": "hall-code", "name": "HAL CODE local", "provider_id": "hall-local", "status": "approved", "roles": ["code", "sql"], "external": False},
    ]

    SEED_USE_CASES = [
        {"id": "public_research", "name": "Pesquisa pública", "status": "approved", "max_data_class": "internal", "external_allowed": True},
        {"id": "internal_documents", "name": "Documentos internos / RAG", "status": "approved", "max_data_class": "restricted", "external_allowed": False},
        {"id": "software_development", "name": "Desenvolvimento de software", "status": "approved", "max_data_class": "confidential", "external_allowed": False},
        {"id": "hr_payroll", "name": "RH / Folha", "status": "approved", "max_data_class": "restricted", "external_allowed": False},
        {"id": "finance_legal", "name": "Financeiro / Jurídico", "status": "approved", "max_data_class": "restricted", "external_allowed": False},
    ]

    SEED_CONNECTORS = [
        {"id": "proxy", "name": "Proxy / Secure Web Gateway", "type": "push", "enabled": False, "format": "json", "description": "Envie URL/domínio, usuário, ação, conta e classificação conhecida."},
        {"id": "dns", "name": "DNS Resolver", "type": "push", "enabled": False, "format": "json", "description": "Descoberta por consultas DNS a serviços de IA."},
        {"id": "firewall", "name": "Firewall / NGFW", "type": "push", "enabled": False, "format": "json", "description": "Eventos de aplicação/URL e ações de bloqueio."},
        {"id": "endpoint", "name": "Endpoint / EDR", "type": "push", "enabled": False, "format": "json", "description": "Processos, extensões e clientes de IA instalados."},
        {"id": "browser", "name": "Browser / Extensão corporativa", "type": "push", "enabled": False, "format": "json", "description": "Acesso a ferramentas e uploads no navegador corporativo."},
        {"id": "casb", "name": "CASB / SSE / SIEM", "type": "push", "enabled": False, "format": "json", "description": "Alertas consolidados de SaaS/IA."},
    ]

    DLP_PATTERNS: list[dict[str, Any]] = [
        {"id": "private_key", "label": "Chave privada", "class": "restricted", "secret": True, "regex": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----", re.I)},
        {"id": "bearer_token", "label": "Bearer token", "class": "restricted", "secret": True, "regex": re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{18,}", re.I)},
        {"id": "aws_access_key", "label": "AWS access key", "class": "restricted", "secret": True, "regex": re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b")},
        {"id": "generic_secret", "label": "Senha/API secret", "class": "restricted", "secret": True, "regex": re.compile(r"(?i)\b(?:password|passwd|pwd|api[_ -]?key|secret|token)\s*[:=]\s*['\"]?[^\s'\"]{8,}")},
        {"id": "oracle_connect", "label": "String de conexão com credencial", "class": "restricted", "secret": True, "regex": re.compile(r"(?i)\b(?:oracle|postgres(?:ql)?|mysql|mssql|mongodb(?:\+srv)?)://[^\s:@/]+:[^\s@/]+@")},
        {"id": "cpf", "label": "CPF", "class": "confidential", "secret": False, "regex": re.compile(r"(?<!\d)(?:\d{3}[.\s-]?\d{3}[.\s-]?\d{3}[-\s]?\d{2})(?!\d)")},
        {"id": "cnpj", "label": "CNPJ", "class": "confidential", "secret": False, "regex": re.compile(r"(?<!\d)\d{2}[.\s-]?\d{3}[.\s-]?\d{3}[/\s-]?\d{4}[-\s]?\d{2}(?!\d)")},
        {"id": "email", "label": "E-mail", "class": "internal", "secret": False, "regex": re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)},
        {"id": "phone", "label": "Telefone", "class": "internal", "secret": False, "regex": re.compile(r"(?<!\d)(?:\+?55\s*)?(?:\(?\d{2}\)?\s*)?9?\d{4}[-\s]?\d{4}(?!\d)")},
        {"id": "credit_card", "label": "Cartão de pagamento", "class": "restricted", "secret": True, "regex": re.compile(r"(?<!\d)(?:\d[ -]?){13,19}(?!\d)")},
    ]

    def __init__(self, root_dir: Path, data_dir: Path):
        self.root_dir = Path(root_dir)
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self.config_path = self.data_dir / "config.json"
        self.audit_path = self.data_dir / "audit.jsonl"
        self.telemetry_path = self.data_dir / "telemetry.jsonl"
        self.approvals_path = self.data_dir / "approvals.json"
        self.incidents_path = self.data_dir / "incidents.json"
        self._ensure_seed()

    def _registry_path(self, kind: str) -> Path:
        if kind not in REGISTRY_KINDS:
            raise KeyError(f"Registro inválido: {kind}")
        return self.data_dir / f"{kind}.json"

    def _write_json(self, path: Path, data: Any) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)

    def _ensure_seed(self) -> None:
        with self._lock:
            if not self.config_path.exists():
                self._write_json(self.config_path, dict(self.DEFAULT_CONFIG))
            seeds = {
                "providers": self.SEED_PROVIDERS,
                "applications": self.SEED_APPS,
                "models": self.SEED_MODELS,
                "use_cases": self.SEED_USE_CASES,
                "policies": [
                    {"id": "restricted_external", "name": "Dados restritos não saem da empresa", "enabled": True, "priority": 100, "condition": {"min_data_class": "restricted", "external": True}, "action": "block"},
                    {"id": "confidential_external", "name": "Dados confidenciais externos exigem aprovação", "enabled": True, "priority": 90, "condition": {"min_data_class": "confidential", "external": True}, "action": "approval"},
                    {"id": "personal_ai_account", "name": "Conta pessoal de IA é Shadow AI", "enabled": True, "priority": 95, "condition": {"account_type": "personal", "external": True}, "action": "block"},
                    {"id": "unknown_ai", "name": "Aplicação IA desconhecida exige avaliação", "enabled": True, "priority": 80, "condition": {"app_status": "unknown", "external": True}, "action": "approval"},
                ],
                "connectors": self.SEED_CONNECTORS,
                "risk_intel": [],
            }
            for kind, data in seeds.items():
                p = self._registry_path(kind)
                if not p.exists():
                    self._write_json(p, data)
            if not self.approvals_path.exists():
                self._write_json(self.approvals_path, [])
            if not self.incidents_path.exists():
                self._write_json(self.incidents_path, [])

    def config(self) -> dict[str, Any]:
        cfg = _safe_json_load(self.config_path, {})
        merged = json.loads(json.dumps(self.DEFAULT_CONFIG))
        for k, v in cfg.items():
            if isinstance(v, dict) and isinstance(merged.get(k), dict):
                merged[k].update(v)
            else:
                merged[k] = v
        return merged

    def update_config(self, changes: dict[str, Any], actor: str = "admin") -> dict[str, Any]:
        cfg = self.config()
        allowed = set(self.DEFAULT_CONFIG)
        for k, v in (changes or {}).items():
            if k in allowed:
                cfg[k] = v
        self._write_json(self.config_path, cfg)
        self.audit("config_updated", actor, {"keys": sorted(set(changes or {}) & allowed)})
        return cfg

    def registry(self, kind: str) -> list[dict[str, Any]]:
        data = _safe_json_load(self._registry_path(kind), [])
        return data if isinstance(data, list) else []

    def upsert_registry(self, kind: str, item: dict[str, Any], actor: str = "admin") -> dict[str, Any]:
        if kind not in REGISTRY_KINDS:
            raise KeyError(kind)
        row = dict(item or {})
        row_id = str(row.get("id") or _id(kind[:-1] if kind.endswith("s") else kind)).strip()
        row["id"] = row_id
        row["updated_at"] = _utcnow()
        rows = self.registry(kind)
        found = False
        for i, old in enumerate(rows):
            if str(old.get("id")) == row_id:
                merged = dict(old)
                merged.update(row)
                rows[i] = merged
                row = merged
                found = True
                break
        if not found:
            row.setdefault("created_at", _utcnow())
            rows.append(row)
        self._write_json(self._registry_path(kind), rows)
        self.audit("registry_upsert", actor, {"kind": kind, "id": row_id})
        return row

    def delete_registry(self, kind: str, row_id: str, actor: str = "admin") -> bool:
        rows = self.registry(kind)
        after = [r for r in rows if str(r.get("id")) != str(row_id)]
        if len(after) == len(rows):
            return False
        self._write_json(self._registry_path(kind), after)
        self.audit("registry_delete", actor, {"kind": kind, "id": row_id})
        return True

    def _append_jsonl(self, path: Path, row: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8", newline="\n") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

    def audit(self, event: str, actor: str, detail: dict[str, Any] | None = None) -> None:
        if not self.config().get("audit_enabled", True):
            return
        clean = dict(detail or {})
        # Nunca persistir prompt/segredo bruto no audit do governance.
        for key in list(clean):
            if any(x in key.lower() for x in ("prompt", "password", "secret", "token", "raw", "content")):
                value = str(clean.pop(key) or "")
                clean[f"{key}_sha256"] = hashlib.sha256(value.encode("utf-8", errors="ignore")).hexdigest() if value else ""
                clean[f"{key}_length"] = len(value)
        self._append_jsonl(self.audit_path, {"ts": _utcnow(), "event": event, "actor": actor, "detail": clean})

    def recent_audit(self, limit: int = 200) -> list[dict[str, Any]]:
        return self._recent_jsonl(self.audit_path, limit)

    def _recent_jsonl(self, path: Path, limit: int = 200) -> list[dict[str, Any]]:
        if not path.exists():
            return []
        rows = []
        for line in path.read_text(encoding="utf-8-sig", errors="replace").splitlines()[-max(1, min(int(limit), 5000)):]:
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
        return rows

    def dlp_scan(self, text: str) -> dict[str, Any]:
        text = str(text or "")
        findings: list[dict[str, Any]] = []
        redacted = text
        rules = self.DLP_PATTERNS if self.config().get("dlp_enabled", True) else []
        for rule in rules:
            for m in rule["regex"].finditer(text):
                value = m.group(0)
                if rule["id"] == "cpf" and not _cpf_valid(value):
                    continue
                if rule["id"] == "cnpj" and not _cnpj_valid(value):
                    continue
                if rule["id"] == "credit_card" and not _luhn(value):
                    continue
                findings.append({
                    "type": rule["id"], "label": rule["label"], "data_class": rule["class"],
                    "secret": bool(rule["secret"]), "length": len(value),
                    "fingerprint": hashlib.sha256(value.encode("utf-8", errors="ignore")).hexdigest()[:16],
                })
                redacted = redacted.replace(value, f"[REDACTED:{rule['id'].upper()}]")
        highest = "public"
        for f in findings:
            if DATA_CLASS_ORDER[f["data_class"]] > DATA_CLASS_ORDER[highest]:
                highest = f["data_class"]
        # Heurísticas corporativas sem capturar conteúdo bruto.
        low = _norm(text)
        keywords = {
            "restricted": ["folha de pagamento", "holerite", "prontuario", "senha", "credencial", "chave privada", "salary", "payroll", "medical record"],
            "confidential": ["contrato", "cliente", "fornecedor", "dre", "fluxo de caixa", "codigo fonte", "código fonte", "source code", "juridico", "jurídico"],
            "internal": ["interno", "procedimento", "manual corporativo", "intranet", "empresa"],
        }
        for cls in ("restricted", "confidential", "internal"):
            if any(k in low for k in keywords[cls]) and DATA_CLASS_ORDER[cls] > DATA_CLASS_ORDER[highest]:
                highest = cls
        return {
            "ok": True,
            "findings": findings,
            "finding_types": sorted({f["type"] for f in findings}),
            "data_class": highest,
            "contains_secret": any(f["secret"] for f in findings),
            "redacted_text": redacted,
            "original_length": len(text),
        }

    def classify_data(self, text: str, declared: str = "") -> dict[str, Any]:
        scan = self.dlp_scan(text)
        declared = str(declared or "").strip().lower()
        if declared in DATA_CLASS_ORDER and DATA_CLASS_ORDER[declared] > DATA_CLASS_ORDER[scan["data_class"]]:
            scan["data_class"] = declared
        return scan

    def _find_provider(self, provider_id: str) -> dict[str, Any] | None:
        pid = _norm(provider_id)
        for p in self.registry("providers"):
            if _norm(p.get("id")) == pid or _norm(p.get("name")) == pid:
                return p
        return None

    def _find_model(self, model_id: str) -> dict[str, Any] | None:
        mid = _norm(model_id)
        for m in self.registry("models"):
            if _norm(m.get("id")) == mid or _norm(m.get("name")) == mid:
                return m
        return None

    def _find_app(self, app_id: str = "", domain: str = "", url: str = "") -> dict[str, Any] | None:
        app_norm = _norm(app_id)
        host = (domain or "").strip().lower()
        if not host and url:
            try:
                host = (urlparse(url).hostname or "").lower()
            except Exception:
                host = ""
        for app in self.registry("applications"):
            if app_norm and (_norm(app.get("id")) == app_norm or _norm(app.get("name")) == app_norm):
                return app
            for d in app.get("domains") or []:
                d = str(d).lower().lstrip(".")
                if host == d or host.endswith("." + d):
                    return app
        return None

    def _policy_action(self, ctx: dict[str, Any]) -> tuple[str, list[str]]:
        hits: list[str] = []
        action = "allow"
        action_rank = {"allow": 0, "allow_with_controls": 1, "approval": 2, "block": 3}
        for policy in sorted(self.registry("policies"), key=lambda x: int(x.get("priority", 0)), reverse=True):
            if not policy.get("enabled", True):
                continue
            cond = policy.get("condition") or {}
            matched = True
            if "external" in cond and bool(ctx.get("external")) != bool(cond.get("external")):
                matched = False
            if cond.get("account_type") and _norm(ctx.get("account_type")) != _norm(cond.get("account_type")):
                matched = False
            if cond.get("app_status") and _norm(ctx.get("app_status")) != _norm(cond.get("app_status")):
                matched = False
            if cond.get("min_data_class"):
                matched = matched and DATA_CLASS_ORDER.get(ctx.get("data_class", "public"), 0) >= DATA_CLASS_ORDER.get(cond["min_data_class"], 0)
            if matched:
                hits.append(str(policy.get("id") or policy.get("name") or "policy"))
                candidate = str(policy.get("action") or "allow")
                if action_rank.get(candidate, 0) > action_rank.get(action, 0):
                    action = candidate
        return action, hits

    def evaluate_prompt(
        self, prompt: str, *, actor: str = "", department: str = "", app_id: str = "hall",
        provider_id: str = "hall-local", model_id: str = "", use_case: str = "",
        external: bool | None = None, account_type: str = "corporate", action: str = "prompt",
        declared_data_class: str = "", persist: bool = False,
    ) -> dict[str, Any]:
        cfg = self.config()
        scan = self.classify_data(prompt, declared_data_class)
        app = self._find_app(app_id=app_id)
        provider = self._find_provider(provider_id or (app or {}).get("provider_id", ""))
        model = self._find_model(model_id) if model_id else None
        if external is None:
            external = bool((app or {}).get("external", (provider or {}).get("external", False)))
        app_status = str((app or {}).get("status") or "unknown")
        provider_status = str((provider or {}).get("status") or ("unknown" if provider_id else "approved"))
        model_status = str((model or {}).get("status") or ("unknown" if model_id else "approved"))
        weights = cfg.get("weights") or {}
        reasons: list[str] = []
        score = 0
        data_class = scan["data_class"]
        if data_class == "restricted":
            score += int(weights.get("restricted_data", 45)); reasons.append("restricted_data")
        elif data_class == "confidential":
            score += int(weights.get("confidential_data", 28)); reasons.append("confidential_data")
        if scan["contains_secret"]:
            score += int(weights.get("credential_or_secret", 45)); reasons.append("credential_or_secret")
        if _norm(account_type) == "personal":
            score += int(weights.get("personal_account", 18)); reasons.append("personal_account")
        if app_status in {"unknown", "unreviewed"}:
            score += int(weights.get("unknown_app", 20)); reasons.append("unknown_app")
        if app_status == "blocked":
            score += int(weights.get("blocked_app", 55)); reasons.append("blocked_app")
        if external:
            score += int(weights.get("external_provider", 12)); reasons.append("external_provider")
        if _norm(action) in {"upload", "file upload", "paste file"}:
            score += int(weights.get("upload", 12)); reasons.append("upload")
        if provider_status in {"unknown", "unreviewed", "blocked"}:
            score += int(weights.get("unapproved_provider", 15)); reasons.append("unapproved_provider")
        if model_status in {"unknown", "unreviewed", "blocked"}:
            score += int(weights.get("unapproved_model", 15)); reasons.append("unapproved_model")
        score = min(100, score)

        policy_action, policy_hits = self._policy_action({
            "external": external, "account_type": account_type, "app_status": app_status,
            "data_class": data_class, "department": department, "action": action,
        })
        decision = policy_action
        # Controles determinísticos de segurança.
        if app_status == "blocked":
            decision = "block"
        if scan["contains_secret"] and external and cfg.get("secret_material_action") == "block":
            decision = "block"
        if data_class == "restricted" and external:
            decision = str(cfg.get("restricted_external_action", "block"))
        elif data_class == "confidential" and external and decision != "block":
            decision = str(cfg.get("confidential_external_action", "approval"))
        if not app and external and decision not in {"block"}:
            decision = str(cfg.get("unknown_external_app_action", "approval"))
        if not external and data_class == "restricted" and decision == "allow":
            decision = str(cfg.get("local_restricted_action", "allow_with_controls"))

        local_only = bool(data_class in {"confidential", "restricted"} or scan["contains_secret"])
        if not cfg.get("enabled", True) or not cfg.get("prompt_firewall_enabled", True):
            decision = "allow_with_controls" if local_only else "allow"
        allowed = decision in {"allow", "allow_with_controls"}
        approval_required = decision == "approval"
        replacement = (app or {}).get("replacement") or "HAL"
        coaching = ""
        if decision == "block":
            coaching = f"Uso bloqueado pela política corporativa. Utilize {replacement} ou remova/mascare dados sensíveis."
        elif approval_required:
            coaching = f"Uso exige aprovação. Para evitar Shadow AI, prefira {replacement} com modelo corporativo/local."
        elif local_only:
            coaching = "Conteúdo sensível detectado: mantenha o processamento em modelo local/corporativo aprovado."
        else:
            coaching = "Uso compatível com a política atual."

        result = {
            "ok": True,
            "decision": decision,
            "allowed": allowed,
            "approval_required": approval_required,
            "risk_score": score,
            "risk_level": _risk_level(score),
            "data_class": data_class,
            "dlp": {k: v for k, v in scan.items() if k != "redacted_text"},
            "redacted_prompt": scan["redacted_text"],
            "app": app or {"id": app_id or "unknown", "name": app_id or "Unknown AI", "status": "unknown", "external": bool(external)},
            "provider": provider or {"id": provider_id or "unknown", "status": provider_status, "external": bool(external)},
            "model": model or ({"id": model_id, "status": model_status} if model_id else {}),
            "use_case": use_case,
            "department": department,
            "account_type": account_type,
            "action": action,
            "external": bool(external),
            "local_only": local_only,
            "reasons": reasons,
            "policy_hits": policy_hits,
            "coaching": coaching,
            "evaluated_at": _utcnow(),
        }
        if persist:
            self.audit("prompt_evaluated", actor or "unknown", {
                "risk_score": score, "risk_level": result["risk_level"], "decision": decision,
                "data_class": data_class, "app_id": (app or {}).get("id") or app_id,
                "provider_id": (provider or {}).get("id") or provider_id, "model_id": model_id,
                "finding_types": scan["finding_types"], "prompt": prompt,
            })
        return result

    def gateway_decision(self, payload: dict[str, Any], actor: str = "") -> dict[str, Any]:
        result = self.evaluate_prompt(
            str(payload.get("prompt") or payload.get("message") or ""), actor=actor,
            department=str(payload.get("department") or ""), app_id=str(payload.get("app_id") or "hall"),
            provider_id=str(payload.get("provider_id") or "hall-local"), model_id=str(payload.get("model_id") or ""),
            use_case=str(payload.get("use_case") or ""), external=payload.get("external"),
            account_type=str(payload.get("account_type") or "corporate"), action=str(payload.get("action") or "prompt"),
            declared_data_class=str(payload.get("data_class") or ""), persist=True,
        )
        route = "hall_local"
        if result["allowed"] and not result["local_only"] and result["external"]:
            route = "approved_external"
        elif result["approval_required"]:
            route = "approval_queue"
        elif not result["allowed"]:
            route = "blocked"
        result["route"] = route
        if result["approval_required"]:
            approval = self.create_approval({
                "type": "ai_use", "summary": f"Uso de IA: {result['app'].get('name')}",
                "risk_score": result["risk_score"], "data_class": result["data_class"],
                "app_id": result["app"].get("id"), "provider_id": result["provider"].get("id"),
                "department": result.get("department"), "requested_by": actor,
            }, actor=actor or "unknown")
            result["approval_id"] = approval["id"]
        if result["decision"] == "block" and self.config().get("auto_incident_on_block", True):
            incident = self.create_incident({
                "type": "ai_policy_block", "severity": result["risk_level"], "risk_score": result["risk_score"],
                "summary": result["coaching"], "app_id": result["app"].get("id"), "department": result.get("department"),
                "finding_types": result["dlp"].get("finding_types", []), "actor": actor,
            }, actor="policy_engine")
            result["incident_id"] = incident["id"]
        return result

    def resolve_shadow_app(self, event: dict[str, Any]) -> tuple[dict[str, Any] | None, str]:
        app = self._find_app(str(event.get("app_id") or event.get("app") or ""), str(event.get("domain") or ""), str(event.get("url") or ""))
        if app:
            return app, str(app.get("status") or "unknown")
        return None, "unknown"

    def ingest_telemetry(self, events: Iterable[dict[str, Any]], source: str = "api", actor: str = "collector") -> dict[str, Any]:
        rows = []
        incidents = []
        for raw in events:
            event = dict(raw or {})
            app, status = self.resolve_shadow_app(event)
            domain = str(event.get("domain") or "")
            if not domain and event.get("url"):
                try: domain = urlparse(str(event.get("url"))).hostname or ""
                except Exception: domain = ""
            declared_class = str(event.get("data_class") or "public").lower()
            if declared_class not in DATA_CLASS_ORDER:
                declared_class = "public"
            prompt_hint = str(event.get("content_hint") or "")
            decision = self.evaluate_prompt(
                prompt_hint, actor=str(event.get("user") or actor), department=str(event.get("department") or ""),
                app_id=str((app or {}).get("id") or event.get("app_id") or event.get("app") or "unknown"),
                provider_id=str((app or {}).get("provider_id") or event.get("provider_id") or "unknown"),
                external=True, account_type=str(event.get("account_type") or "unknown"),
                action=str(event.get("action") or "access"), declared_data_class=declared_class, persist=False,
            )
            shadow = status not in {"approved"} or _norm(event.get("account_type")) == "personal"
            row = {
                "id": _id("evt"), "ts": str(event.get("ts") or _utcnow()), "ingested_at": _utcnow(),
                "source": str(event.get("source") or source), "user": str(event.get("user") or ""),
                "department": str(event.get("department") or ""), "device": str(event.get("device") or ""),
                "domain": domain, "url": str(event.get("url") or ""), "action": str(event.get("action") or "access"),
                "account_type": str(event.get("account_type") or "unknown"),
                "app_id": str((app or {}).get("id") or event.get("app_id") or "unknown"),
                "app_name": str((app or {}).get("name") or event.get("app") or domain or "Unknown AI"),
                "app_status": status, "shadow_ai": shadow,
                "data_class": decision["data_class"], "risk_score": decision["risk_score"],
                "risk_level": decision["risk_level"], "decision": decision["decision"],
                "finding_types": decision["dlp"].get("finding_types", []),
                "replacement": (app or {}).get("replacement") or "HAL",
            }
            self._append_jsonl(self.telemetry_path, row)
            rows.append(row)
            if (row["risk_level"] == "critical" and self.config().get("auto_incident_on_critical", True)) or (row["decision"] == "block" and self.config().get("auto_incident_on_block", True)):
                incidents.append(self.create_incident({
                    "type": "shadow_ai", "severity": row["risk_level"], "risk_score": row["risk_score"],
                    "summary": f"Shadow AI: {row['app_name']} / {row['action']} / {row['data_class']}",
                    "event_id": row["id"], "app_id": row["app_id"], "department": row["department"],
                    "user": row["user"], "finding_types": row["finding_types"],
                }, actor="shadow_ai_discovery"))
        self.audit("telemetry_ingested", actor, {"source": source, "count": len(rows), "incidents": len(incidents)})
        return {"ok": True, "ingested": len(rows), "events": rows, "incidents_created": len(incidents)}

    def ingest_text(self, content: str, fmt: str = "jsonl", source: str = "import", actor: str = "admin") -> dict[str, Any]:
        fmt = _norm(fmt).replace(" ", "")
        events: list[dict[str, Any]] = []
        if fmt in {"json", "jsonarray"}:
            data = json.loads(content)
            events = data if isinstance(data, list) else [data]
        elif fmt in {"csv"}:
            events = [dict(row) for row in csv.DictReader(io.StringIO(content))]
        else:
            for line in str(content or "").splitlines():
                line = line.strip()
                if line:
                    events.append(json.loads(line))
        return self.ingest_telemetry(events, source=source, actor=actor)

    def recent_telemetry(self, limit: int = 500, shadow_only: bool = False) -> list[dict[str, Any]]:
        rows = self._recent_jsonl(self.telemetry_path, limit)
        return [r for r in rows if r.get("shadow_ai")] if shadow_only else rows

    def create_approval(self, item: dict[str, Any], actor: str = "") -> dict[str, Any]:
        rows = _safe_json_load(self.approvals_path, [])
        row = dict(item or {})
        row.update({"id": row.get("id") or _id("apr"), "status": "pending", "created_at": _utcnow(), "created_by": actor or row.get("requested_by") or "unknown"})
        rows.append(row)
        self._write_json(self.approvals_path, rows)
        self.audit("approval_created", actor or "unknown", {"approval_id": row["id"], "type": row.get("type"), "risk_score": row.get("risk_score")})
        return row

    def list_approvals(self, status: str = "", limit: int = 200) -> list[dict[str, Any]]:
        rows = _safe_json_load(self.approvals_path, [])
        if status:
            rows = [r for r in rows if str(r.get("status")) == status]
        return rows[-max(1, min(int(limit), 1000)):][::-1]

    def decide_approval(self, approval_id: str, approved: bool, reviewer: str, reason: str = "") -> dict[str, Any]:
        rows = _safe_json_load(self.approvals_path, [])
        found = None
        for r in rows:
            if str(r.get("id")) == str(approval_id):
                r["status"] = "approved" if approved else "rejected"
                r["reviewer"] = reviewer
                r["reason"] = reason
                r["decided_at"] = _utcnow()
                found = r
                break
        if not found:
            raise KeyError("Aprovação não encontrada.")
        self._write_json(self.approvals_path, rows)
        self.audit("approval_decided", reviewer, {"approval_id": approval_id, "approved": approved, "reason": reason})
        return found

    def create_incident(self, item: dict[str, Any], actor: str = "system") -> dict[str, Any]:
        rows = _safe_json_load(self.incidents_path, [])
        row = dict(item or {})
        row.update({"id": row.get("id") or _id("inc"), "status": row.get("status") or "open", "created_at": _utcnow(), "created_by": actor})
        rows.append(row)
        self._write_json(self.incidents_path, rows)
        self.audit("incident_created", actor, {"incident_id": row["id"], "severity": row.get("severity"), "type": row.get("type")})
        return row

    def list_incidents(self, status: str = "", limit: int = 200) -> list[dict[str, Any]]:
        rows = _safe_json_load(self.incidents_path, [])
        if status:
            rows = [r for r in rows if str(r.get("status")) == status]
        return rows[-max(1, min(int(limit), 1000)):][::-1]

    def update_incident(self, incident_id: str, changes: dict[str, Any], actor: str = "admin") -> dict[str, Any]:
        allowed = {"status", "owner", "notes", "containment", "resolution"}
        rows = _safe_json_load(self.incidents_path, [])
        found = None
        for r in rows:
            if str(r.get("id")) == str(incident_id):
                for k, v in (changes or {}).items():
                    if k in allowed:
                        r[k] = v
                r["updated_at"] = _utcnow()
                found = r
                break
        if not found:
            raise KeyError("Incidente não encontrado.")
        self._write_json(self.incidents_path, rows)
        self.audit("incident_updated", actor, {"incident_id": incident_id, "keys": sorted(set(changes) & allowed)})
        return found

    def dashboard(self) -> dict[str, Any]:
        events = self.recent_telemetry(5000)
        shadow = [e for e in events if e.get("shadow_ai")]
        incidents = self.list_incidents(limit=5000)
        approvals = self.list_approvals(limit=5000)
        apps = self.registry("applications")
        by_risk = Counter(e.get("risk_level", "unknown") for e in events)
        by_app = Counter(e.get("app_name", "Unknown") for e in shadow)
        by_department = Counter(e.get("department") or "Não informado" for e in shadow)
        by_action = Counter(e.get("action") or "access" for e in shadow)
        blocked = sum(1 for e in events if e.get("decision") == "block")
        sensitive = sum(1 for e in events if e.get("data_class") in {"confidential", "restricted"})
        last_ingest = max((e.get("ingested_at", "") for e in events), default="")
        return {
            "ok": True,
            "generated_at": _utcnow(),
            "summary": {
                "events": len(events), "shadow_ai_events": len(shadow), "blocked_events": blocked,
                "sensitive_events": sensitive, "applications": len(apps),
                "approved_apps": sum(1 for a in apps if a.get("status") == "approved"),
                "unreviewed_apps": sum(1 for a in apps if a.get("status") in {"unreviewed", "unknown"}),
                "open_incidents": sum(1 for i in incidents if i.get("status") not in {"closed", "resolved"}),
                "pending_approvals": sum(1 for a in approvals if a.get("status") == "pending"),
                "last_ingest_at": last_ingest,
            },
            "risk": dict(by_risk),
            "top_shadow_apps": by_app.most_common(10),
            "top_departments": by_department.most_common(10),
            "top_actions": by_action.most_common(10),
            "connectors": self.connector_health(last_ingest),
        }

    def connector_health(self, last_ingest: str = "") -> dict[str, Any]:
        connectors = self.registry("connectors")
        enabled = [c for c in connectors if c.get("enabled")]
        stale = False
        age_minutes = None
        if last_ingest:
            try:
                dt = datetime.fromisoformat(last_ingest.replace("Z", "+00:00"))
                age_minutes = max(0, (datetime.now(timezone.utc) - dt).total_seconds() / 60)
                stale = age_minutes > float(self.config().get("monitoring", {}).get("alert_if_stale_minutes", 60))
            except Exception:
                pass
        return {"configured": len(connectors), "enabled": len(enabled), "last_ingest_at": last_ingest, "age_minutes": age_minutes, "stale": stale}

    def status(self) -> dict[str, Any]:
        dash = self.dashboard()
        return {
            "ok": True, "version": "V26", "enabled": bool(self.config().get("enabled", True)),
            "components": {
                "shadow_ai_discovery": True, "ai_inventory": True, "enterprise_ai_gateway": True,
                "prompt_firewall": True, "dlp": True, "data_classification": True,
                "risk_engine": True, "policy_engine": True, "approvals": True,
                "incident_response": True, "audit_trail": True, "policy_simulator": True,
                "telemetry_ingest": True,
            },
            "summary": dash["summary"],
        }

    def vendor_assessment(self, provider_id: str) -> dict[str, Any]:
        provider = self._find_provider(provider_id)
        if not provider:
            raise KeyError("Provedor não encontrado.")
        checks = {
            "approved_status": provider.get("status") == "approved",
            "security_review": bool(provider.get("security_review")),
            "dpa_or_local": bool(provider.get("dpa")) or not bool(provider.get("external")),
            "retention_documented": bool(provider.get("retention_documented")),
            "training_policy_documented": bool(provider.get("training_policy_documented")),
            "audit_supported": bool(provider.get("audit_supported")),
            "data_residency_known": bool(provider.get("data_residency")),
        }
        score = round(100 * sum(checks.values()) / len(checks))
        grade = "A" if score >= 85 else "B" if score >= 70 else "C" if score >= 50 else "D"
        return {
            "ok": True, "provider": provider, "score": score, "grade": grade, "checks": checks,
            "recommendation": "approved" if score >= 85 else "conditional" if score >= 50 else "review_or_block",
            "generated_at": _utcnow(),
        }

    def report(self) -> dict[str, Any]:
        return {
            "ok": True, "title": "HAL V26 Enterprise AI Governance Report", "generated_at": _utcnow(),
            "dashboard": self.dashboard(),
            "applications": self.registry("applications"), "providers": self.registry("providers"),
            "models": self.registry("models"), "use_cases": self.registry("use_cases"),
            "policies": self.registry("policies"), "connectors": self.registry("connectors"),
            "risk_intel": self.registry("risk_intel"),
            "open_incidents": self.list_incidents(limit=100), "pending_approvals": self.list_approvals("pending", 100),
        }

    def simulate(self, payload: dict[str, Any]) -> dict[str, Any]:
        # persist=False: não cria aprovação/incidente nem grava prompt.
        return self.evaluate_prompt(
            str(payload.get("prompt") or payload.get("message") or ""), actor=str(payload.get("actor") or "simulator"),
            department=str(payload.get("department") or ""), app_id=str(payload.get("app_id") or "hall"),
            provider_id=str(payload.get("provider_id") or "hall-local"), model_id=str(payload.get("model_id") or ""),
            use_case=str(payload.get("use_case") or ""), external=payload.get("external"),
            account_type=str(payload.get("account_type") or "corporate"), action=str(payload.get("action") or "prompt"),
            declared_data_class=str(payload.get("data_class") or ""), persist=False,
        )
