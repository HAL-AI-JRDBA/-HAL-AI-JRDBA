# Guía de instalación (Español)

> Versión preliminar experimental; no validada para producción.

## Requirements / Prerequisites

Windows 10 22H2/11 x64; unidad D: con aproximadamente 20 GB libres; internet para la instalación inicial. El instalador prepara Python 3.11 x64 y Ollama portátil.

## Installation

Descargue el ZIP de la versión v44.0 y extráigalo en D:\AI_HALL para obtener D:\AI_HALL\HALL_V44_D. Revise y ejecute 01_INSTALAR_HALL_D.bat y después 02_INICIAR_HALL_D.bat. Abra http://127.0.0.1:8000 y cree una cuenta administradora.

## Test and stop

Pruebe una consulta sencilla y ejecute 03_DIAGNOSTICAR_HALL_D.bat. Para voz, consulte 00_LEIA_PRIMEIRO.txt. Detenga la aplicación con 06_PARAR_HALL_D.bat.

## Privacy

La inferencia principal funciona localmente después de las descargas. No use datos de producción en las pruebas.

**Official release:** https://github.com/HAL-AI-JRDBA/-HAL-AI-JRDBA/releases/tag/v44.0

**Demonstration:** https://huggingface.co/spaces/HAL-AI-JRDBA/README
