# Installationsanleitung (Deutsch)

> Experimentelle Vorabversion — nicht für Produktivbetrieb geprüft.

## Requirements / Prerequisites

Windows 10 22H2/11 x64; Laufwerk D: mit ungefähr 20 GB freiem Speicher; Internet für die Erstinstallation. Das Setup installiert Python 3.11 x64 und portables Ollama.

## Installation

Laden Sie die ZIP-Datei der Version v44.0 herunter und entpacken Sie sie nach D:\AI_HALL, sodass D:\AI_HALL\HALL_V44_D entsteht. Prüfen und starten Sie 01_INSTALAR_HALL_D.bat, danach 02_INICIAR_HALL_D.bat. Öffnen Sie http://127.0.0.1:8000 und erstellen Sie ein Administratorkonto.

## Test and stop

Testen Sie eine einfache Anfrage und führen Sie 03_DIAGNOSTICAR_HALL_D.bat aus. Für Sprache siehe 00_LEIA_PRIMEIRO.txt. Beenden mit 06_PARAR_HALL_D.bat.

## Privacy

Die Hauptinferenz erfolgt nach dem Download lokal. Verwenden Sie zunächst keine Produktivdaten.

**Official release:** https://github.com/HAL-AI-JRDBA/-HAL-AI-JRDBA/releases/tag/v44.0

**Demonstration:** https://huggingface.co/spaces/HAL-AI-JRDBA/README
