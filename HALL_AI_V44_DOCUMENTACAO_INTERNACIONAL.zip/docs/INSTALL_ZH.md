# 安装指南（简体中文）

> 实验性预发布版本，尚未经过生产环境验证。

## Requirements / Prerequisites

Windows 10 22H2/11 64 位；D: 盘建议有约 20 GB 可用空间；首次安装需要联网。安装脚本会配置 Python 3.11 64 位和便携版 Ollama。

## Installation

下载 v44.0 发布包 ZIP，解压到 D:\AI_HALL，使 D:\AI_HALL\HALL_V44_D 目录存在。检查后运行 01_INSTALAR_HALL_D.bat，再运行 02_INICIAR_HALL_D.bat。打开 http://127.0.0.1:8000 创建管理员账户。

## Test and stop

先测试简单对话，再运行 03_DIAGNOSTICAR_HALL_D.bat。语音功能请参阅 00_LEIA_PRIMEIRO.txt。运行 06_PARAR_HALL_D.bat 可停止服务。

## Privacy

模型下载后，核心推理在本地运行。初次测试请勿使用生产数据库或客户真实数据。

**Official release:** https://github.com/HAL-AI-JRDBA/-HAL-AI-JRDBA/releases/tag/v44.0

**Demonstration:** https://huggingface.co/spaces/HAL-AI-JRDBA/README
