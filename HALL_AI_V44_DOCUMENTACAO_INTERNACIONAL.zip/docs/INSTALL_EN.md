# Installation guide (English)

> Experimental pre-release — not validated for production.

## Requirements / Prerequisites

Windows 10 22H2/11 x64; D: drive with about 20 GB free; internet access for first installation. Installer provisions Python 3.11 x64 and portable Ollama.

## Installation

Download the V44.0 Release ZIP. Extract to D:\AI_HALL so D:\AI_HALL\HALL_V44_D exists. Review and run 01_INSTALAR_HALL_D.bat; then run 02_INICIAR_HALL_D.bat. Open http://127.0.0.1:8000 and create an admin account.

## Test and stop

Test a simple chat prompt and run 03_DIAGNOSTICAR_HALL_D.bat. For voice, consult 00_LEIA_PRIMEIRO.txt and the provided voice scripts. Stop with 06_PARAR_HALL_D.bat.

## Privacy

Core model inference runs locally after downloads. Do not use production customer data during initial tests.

**Official release:** https://github.com/HAL-AI-JRDBA/-HAL-AI-JRDBA/releases/tag/v44.0

**Demonstration:** https://huggingface.co/spaces/HAL-AI-JRDBA/README
