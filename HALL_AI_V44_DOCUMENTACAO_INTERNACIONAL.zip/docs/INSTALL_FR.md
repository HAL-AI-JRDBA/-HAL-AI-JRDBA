# Guide d’installation (Français)

> Préversion expérimentale — non validée pour la production.

## Requirements / Prerequisites

Windows 10 22H2/11 x64 ; lecteur D: avec environ 20 Go libres ; accès Internet pour la première installation. Le programme installe Python 3.11 x64 et Ollama portable.

## Installation

Téléchargez le ZIP de la version v44.0 et extrayez-le dans D:\AI_HALL pour obtenir D:\AI_HALL\HALL_V44_D. Vérifiez et lancez 01_INSTALAR_HALL_D.bat, puis 02_INICIAR_HALL_D.bat. Ouvrez http://127.0.0.1:8000 et créez un compte administrateur.

## Test and stop

Essayez une question simple et lancez 03_DIAGNOSTICAR_HALL_D.bat. Pour la voix, consultez 00_LEIA_PRIMEIRO.txt. Arrêtez le programme avec 06_PARAR_HALL_D.bat.

## Privacy

L’inférence principale s’exécute localement après téléchargement. N’utilisez pas de données de production pour les premiers essais.

**Official release:** https://github.com/HAL-AI-JRDBA/-HAL-AI-JRDBA/releases/tag/v44.0

**Demonstration:** https://huggingface.co/spaces/HAL-AI-JRDBA/README
