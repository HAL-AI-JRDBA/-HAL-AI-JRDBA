# Guia de instalação (Português do Brasil)

> Pré-lançamento experimental — não validado para produção.

## Requirements / Prerequisites

Windows 10 22H2/11 x64; unidade D: com cerca de 20 GB livres; acesso à internet na primeira instalação. O instalador prepara Python 3.11 x64 e Ollama portátil.

## Installation

Baixe o arquivo ZIP da Release v44.0. Extraia o conteúdo em D:\AI_HALL para obter D:\AI_HALL\HALL_V44_D. Revise e execute 01_INSTALAR_HALL_D.bat; depois execute 02_INICIAR_HALL_D.bat. Abra http://127.0.0.1:8000 e crie o administrador.

## Test and stop

Teste uma pergunta simples e execute 03_DIAGNOSTICAR_HALL_D.bat. Para a voz, siga 00_LEIA_PRIMEIRO.txt e os scripts de voz fornecidos. Para desligar, use 06_PARAR_HALL_D.bat.

## Privacy

A inferência principal ocorre localmente após os downloads. Não configure dados de produção nos primeiros testes.

**Official release:** https://github.com/HAL-AI-JRDBA/-HAL-AI-JRDBA/releases/tag/v44.0

**Demonstration:** https://huggingface.co/spaces/HAL-AI-JRDBA/README
